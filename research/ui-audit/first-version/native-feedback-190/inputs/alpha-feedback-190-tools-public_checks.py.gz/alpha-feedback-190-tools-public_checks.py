from pathlib import Path
import json,time,importlib.util
stage=Path(__file__).resolve().parent;out=Path('/private/tmp/elab-alpha-feedback-190')
spec=importlib.util.spec_from_file_location('collector190',stage/'collect.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
results=[]
def refusals(client,label):
 before=client.ask('project.inspect');r=before['recording'];assert r and not r['playing'] and before['paused']
 responses=[]
 for params in [{'time_s':'oops'},{'index':1.5},{'index':r['sample_count']},{'time_s':r['duration_s']+1},{'index':0,'time_s':0}]:
  response=client.ask('recording.seek',params,True,expect_error=True);after=client.ask('project.inspect');assert after==before
  h=response['help'];assert h['code']=='invalid-params' and h['source']=='request' and h['details']==response['error']['message'];assert not h['object_ids'] and not h['terminal_refs'] and not h['wire_ids']
  if r['duration_s']==0:assert 'sample index 0 or time 0 s' in h['action']
  else:assert f"0 to {r['sample_count']-1}" in h['action'] and f"{r['duration_s']:g} s" in h['action'] and 'ms' in h['action']
  responses.append(response)
 (out/(label+'-refusals.json')).write_text(json.dumps(responses,indent=2)+'\n');results.append(dict(adapter=label,refusals=len(responses),sample_count=r['sample_count'],duration_s=r['duration_s'],state_preserved=True));return responses
socket=m.Client('public-socket')
try:native=refusals(socket,'native-socket')
finally:socket.close_connection()
headless=m.Client('public-headless',False)
try:
 headless.ask('project.inspect');headless.ask('project.load',{'path':str(out/'fixture.elab'),'discard_changes':True},True);headless.ask('simulation.wait')
 reference=refusals(headless,'headless-rc')
 assert [r['help'] for r in native]==[r['help'] for r in reference]
 headless.ask('example.reset',{'discard_changes':True},True);headless.ask('simulation.pause',{},True);headless.ask('simulation.wait');admitted=headless.ask('simulation.verify',{},True);identity=admitted['last_operation'];deadline=time.monotonic()+15
 while True:
  operation=headless.ask('operation.inspect',{'id':identity});assert operation['operation']['status'] not in ['failed','canceled']
  if operation['operation']['status']=='completed':break
  assert time.monotonic()<deadline;time.sleep(.01)
 headless.ask('operation.select',{'id':identity},True);headless.ask('recording.view.set',{'mode':'recorded'},True);refusals(headless,'headless-dc')
 job=headless.ask('app.close',{'discard_changes':True},True)['shutdown'];deadline=time.monotonic()+15
 while job['status'] in ['queued','running']:
  assert time.monotonic()<deadline;time.sleep(.01);job=headless.ask('app.close.inspect',{'id':job['id']})
 assert job['status']=='completed' and all(job[k] for k in ['workers_joined','recovery_finalized','exit_ready']);(out/'public-headless-shutdown.json').write_text(json.dumps(job,indent=2)+'\n')
finally:headless.close_connection()
(out/'public-checks.json').write_text(json.dumps(dict(passed=True,rc_help_equal=True,checks=results),indent=2)+'\n');print(json.dumps(dict(passed=True,checks=results)))
