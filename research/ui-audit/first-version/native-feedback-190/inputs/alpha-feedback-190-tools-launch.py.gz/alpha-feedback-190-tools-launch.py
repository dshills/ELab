"""Owned /189 recorded-navigation recheck; protected LaunchServices entry."""
from pathlib import Path
import gzip,hashlib,importlib.util,json,os,plistlib,signal,subprocess,sys,time,traceback
ROOT=Path('/Users/dshills/Development/projects/ELab');STAGE=Path(__file__).resolve().parent;OUT=Path('/private/tmp/elab-alpha-feedback-190');OUT.mkdir(mode=0o700,exist_ok=True)
RUNTIME=Path('/private/tmp/elab-alpha-feedback-190-runtime');BINARY=RUNTIME/'ELab.app/Contents/MacOS/ELab';ENDPOINT=OUT/'endpoint.json';APP=OUT/'ELab-owned-recorded-transport.app'
sys.path.insert(0,str(ROOT/'scripts'));from package_review import members
from runtime_isolation import bundle_tree
import shutil
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();receipt_path=ROOT/'research/ui-audit/first-version/recorded-step-review-checkpoint.json';release=json.loads(receipt_path.read_text());prior_review=Path(release['review_path']);before_prior=members(prior_review);built=json.loads((ROOT/'build/first-version-190-tools/build-result-signed.json').read_text());review=Path(built['review']);before_review=members(review);
assert not ENDPOINT.exists() and not (OUT/"launcher.pid").exists() and not APP.exists()
if not RUNTIME.exists():
 RUNTIME.mkdir(mode=0o700);shutil.copytree(review/'ELab.app',RUNTIME/'ELab.app');shutil.copyfile(review/'elab-agent',RUNTIME/'elab-agent');(RUNTIME/'elab-agent').chmod(0o755);shutil.copyfile(Path('/private/tmp/elab-first-version-188-signed-runtime/runtime.sb'),RUNTIME/'runtime.sb');shutil.copyfile(Path('/private/tmp/elab-first-version-188-signed-runtime/geometry-probe.py'),RUNTIME/'geometry-probe.py');(RUNTIME/'agent').write_text('#!/bin/sh\nexec /usr/bin/sandbox-exec -f '+str(RUNTIME/'runtime.sb')+' '+str(RUNTIME/'elab-agent')+' \"$@\"\n');(RUNTIME/'agent').chmod(0o755);
before_copy=members(RUNTIME/'ELab.app');assert sha(BINARY)==built['native_sha256'] and sha(RUNTIME/'elab-agent')==built['agent_sha256'];assert before_copy==members(review/'ELab.app') and bundle_tree(RUNTIME/'ELab.app')==built['source_bundle']
assert (RUNTIME/'runtime.sb').read_bytes()==gzip.decompress((ROOT/'docs/validation/recorded-step-review-188/runtime.sb.gz').read_bytes())
shared=Path.home()/'Library/Cogent Core';geometry=lambda:{str(p.relative_to(shared)):dict(sha256=sha(p),mode=oct(p.stat().st_mode&0o777)) for p in shared.rglob('*') if p.is_file()};before_geometry=geometry();canonical=ROOT/'build/ELab.app/Contents/MacOS/ELab';before_canonical=sha(canonical)
quality=json.loads((ROOT/'build/recorded-position-help-tools/quality.json').read_text());assert quality['exit_code']==0 and quality['sources_unchanged'] and len(quality['source_sha256'])==670;assert all(sha(ROOT/n)==h for n,h in quality['source_sha256'].items())
control=subprocess.run(['/usr/bin/sandbox-exec','-f',str(RUNTIME/'runtime.sb'),sys.executable,'-I',str(RUNTIME/'geometry-probe.py'),str(shared/'window-geometry-0.3.6.json')],capture_output=True,text=True,timeout=15);(OUT/'geometry-control-stdout.txt').write_text(control.stdout);(OUT/'geometry-control-stderr.txt').write_text(control.stderr);control.check_returncode();(OUT/'geometry-control.json').write_text(control.stdout);assert all(r['denied'] for r in json.loads(control.stdout).values())
(APP/'Contents/MacOS').mkdir(parents=True);exe=APP/'Contents/MacOS/ELabOwnedLauncher';source=(ROOT/'docs/validation/latency-launch-preflight-170/launcher.swift.txt').read_text().replace('/private/tmp/elab-latency-launch-preflight-170',str(OUT)).replace('/private/tmp/elab-first-version-170-runtime',str(RUNTIME));source=source.replace('import Darwin\n','import Darwin\nif \"'+str(OUT/'stop.request')+'\".withCString({ access($0, F_OK) }) == 0 { exit(75) }\n');(OUT/'launcher.swift.txt').write_text(source);(STAGE/'launcher.swift').write_text(source)
with (OUT/'Info.plist').open('wb') as f:plistlib.dump(dict(CFBundleExecutable='ELabOwnedLauncher',CFBundleIdentifier='com.dshills.elab.alphafeedback190',CFBundleName='ELab Alpha Feedback Test',CFBundlePackageType='APPL',CFBundleVersion='190',CFBundleShortVersionString='0.173.0',NSHighResolutionCapable=True),f)
(APP/'Contents/Info.plist').write_bytes((OUT/'Info.plist').read_bytes());compile_run=subprocess.run(['/usr/bin/xcrun','swiftc',str(STAGE/'launcher.swift'),'-o',str(exe)],capture_output=True,text=True,timeout=60);(OUT/'launcher-build.txt').write_text(compile_run.stdout+compile_run.stderr);compile_run.check_returncode()
spec=importlib.util.spec_from_file_location('owned_native_client',ROOT/'scripts/persistence-demo.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
report=dict(status='starting',release='0.173.0 /190 alpha',qualification_pending=True,source_commit=built['source_commit'],source_payload_exact=True,observation_ttl_removed=True,receipt_sha256=sha(receipt_path),native_sha256=sha(BINARY),agent_sha256=built['agent_sha256'],policy_sha256=sha(RUNTIME/'runtime.sb'),launcher_sha256=sha(exe),shared_geometry_before=before_geometry,eligible_latency_observations=0,native_exit_status=None,native_exit_status_reason='LaunchServices owns the native host; open -W status is separate',forced_cleanup=False)
(OUT/'plan.json').write_text(json.dumps(dict(cases=['Observe current protected native window presentation','Load LED example through shared public command if presentation is visible'],scope='One owned clean signed /189 candidate native session; capture seeded publicly, transport input via CUA only, public observations and matching packaged-agent/RC-law replay. No new latency/reader/all-binding/ordinary-startup qualification',no_new_privacy_grants=True,no_extra_printing=True),indent=2)+'\n')
launch=client=pid=None
def save(): (OUT/'controller.json').write_text(json.dumps(report,indent=2)+'\n')
def observed():
 if pid is None:return None
 p=subprocess.run(['/bin/ps','-p',str(pid),'-o','command='],capture_output=True,text=True,timeout=5);return p.stdout.strip() if p.returncode==0 else None
try:
 with (OUT/'open-output.txt').open('x') as log:launch=subprocess.Popen(['/usr/bin/open','-n','-W','-g','-a',str(APP),'--stdout',str(OUT/'native-stdout.txt'),'--stderr',str(OUT/'native-stderr.txt')],stdout=log,stderr=subprocess.STDOUT)
 report['open_pid']=launch.pid;save();deadline=time.monotonic()+30
 while not ((OUT/'launcher.pid').exists() and ENDPOINT.exists()):
  assert launch.poll() is None and time.monotonic()<deadline,'owned launch readiness';time.sleep(.05)
 pid=int((OUT/'launcher.pid').read_text());command=observed();assert command and command.startswith(str(BINARY)+' ') and str(ENDPOINT) in command
 report.update(owned_pid=pid,observed_command=command,same_pid_after_exec=True,status='ready_for_cua');save()
 client=helper.Client(str(ENDPOINT),command_preconditions=True,agent_binary=RUNTIME/'agent');state=client.ask('project.inspect');assert not state['components'] and not state['wires'];(OUT/'initial.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(dict(status=report['status'],owned_pid=pid,exact_app=str(RUNTIME/'ELab.app'))),flush=True)
 while not (OUT/'stop.request').exists():
  assert observed()==command,'owned process identity ended or changed';time.sleep(.25)
except BaseException:
 report['failure']=traceback.format_exc();report['status']='failed';save();raise
finally:
 try:
  if client is not None:
   client.ask('project.inspect');closed=client.ask('app.close',dict(discard_changes=True),True);(OUT/'close-response.json').write_text(json.dumps(closed,indent=2)+'\n');job=closed['shutdown'];deadline=time.monotonic()+15
   while job['status'] in ('queued','running'):
    assert time.monotonic()<deadline;time.sleep(.05);job=client.ask('app.close.inspect',dict(id=job['id']))
   assert job['status']=='completed' and all(job[k] for k in ('workers_joined','recovery_finalized','exit_ready'));report['shutdown']=job;client.close();client=None
  if launch is not None:report['open_exit_code']=launch.wait(timeout=20)
  deadline=time.monotonic()+10
  while pid and observed() and time.monotonic()<deadline:time.sleep(.05)
  report.update(owned_process_absent=pid is not None and observed() is None,endpoint_removed=not ENDPOINT.exists());assert report['owned_process_absent'] and report['endpoint_removed']
 except BaseException:
  report['cleanup_error']=traceback.format_exc()
  if pid and observed() and observed().startswith(str(BINARY)+' ') and str(ENDPOINT) in observed():os.kill(pid,signal.SIGTERM);report['forced_cleanup']=True
  if launch and launch.poll() is None:launch.wait(timeout=20)
 finally:
  report.update(shared_geometry_after=geometry(),shared_geometry_unchanged=geometry()==before_geometry,review_unchanged=members(review)==before_review,copied_app_unchanged=members(RUNTIME/'ELab.app')==before_copy,canonical_unchanged=sha(canonical)==before_canonical,prior_review_unchanged=members(prior_review)==before_prior);save();assert all(report[k] for k in ('shared_geometry_unchanged','review_unchanged','copied_app_unchanged','canonical_unchanged','prior_review_unchanged'))
print(json.dumps(dict(closed=True,forced_cleanup=report['forced_cleanup'],open_exit_code=report.get('open_exit_code'))),flush=True)
