from pathlib import Path
import hashlib,json,shutil,stat,subprocess,sys,zipfile
root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
assert (stage/'quality-exit-code.txt').read_text().strip()=='0'
b=json.loads((stage/'build-result-signed.json').read_text());check=json.loads((stage/'protocol-report.json').read_text());assert check['passed'] and check['source_commit']==b['source_commit']
native=json.loads((stage/'native-protocol-report.json').read_text()); visible=json.loads((stage/'native-ui.json').read_text()); equivalence=json.loads((stage/'native-equivalence.json').read_text())
assert native['passed'] and native['source_commit']==b['source_commit'] and native['agent_sha256']==b['agent_sha256']
assert visible['passed'] and visible['source_commit']==b['source_commit']
assert equivalence['candidate_native_sha256']==b['native_sha256'] and equivalence['unsigned_compiled_executables_identical']
sys.path.insert(0,str(root/'scripts'));from package_review import members,verify_archive
previous=root/'build/releases/ELab-0.181.4-macos-arm64';preserved=members(previous)
release=root/'build/releases/ELab-0.181.5-macos-arm64';assert not release.exists();release.mkdir()
candidate=Path(b['review']);shutil.copytree(candidate/'ELab.app',release/'ELab.app');shutil.copy2(candidate/'elab-agent',release/'elab-agent')
for name in ('Examples','Licenses'):shutil.copytree(previous/name,release/name)
for name in ('AGENT_PROTOCOL.md','ROLLBACK.md'):shutil.copy2(previous/name,release/name)

pin=json.loads((root/'third_party/vellum/sdk.lock.json').read_text());sdk=root/pin['cache'];licenses=release/'Licenses/Vellum'
for name in ('LICENSE','PRIVATE_BUILD.txt','THIRD_PARTY_INVENTORY.json'):shutil.copy2(sdk/name,licenses/name)
shutil.rmtree(licenses/'THIRD_PARTY_NOTICES');shutil.copytree(sdk/'THIRD_PARTY_NOTICES',licenses/'THIRD_PARTY_NOTICES')
shutil.copy2(root/'third_party/vellum/sdk.lock.json',licenses/'sdk.lock.json')

readme=(previous/'README.md').read_text().replace('ELab 0.181.4','ELab 0.181.5')
readme=readme.replace('## Component value guidance', '## Cursor correction\n\nRejected cursor times remain available to correct in their originating live run\nor recording. Shared user/agent guidance shows actual retained time bounds and\naccepted units. Corrected Return places the cursor through the existing command.\nThe earlier component-value and mouse/scrolling repairs are retained.\n\n## Component value guidance',1)
(release/'README.md').write_text(readme)
(release/'RELEASE_NOTES.md').write_text(f"# ELab 0.181.5 /206 — October 23, 2026\n\nRejected live and recorded cursor times remain in the originating editor for\ncorrection. First corrected Return places the cursor through the existing shared\ncommand. Rejected fields cannot be silently bypassed by selecting another cursor.\nA new run/capture or an accepted replacement cursor clears the old draft.\n\nUsers and agents receive the same actual retained time interval and unit syntax.\nMalformed and stale requests do not borrow another run or recording's guidance.\nError codes, technical details, time parsing, boundary tolerance, command\ncontracts, component set, models and file formats remain unchanged.\n\nThe complete source quality gate, matching/extracted agent checks and native\nchecks are identified in docs/validation/cursor-guidance-206 and\nresearch/82-cursor-value-recovery.md. Native visible tests use a separately\nidentified test bundle whose unsigned compiled executable is byte-identical;\nthat evidence is not an exact signed-distribution desktop qualification.\nSource: {b['source_commit']}.\n\nThis remains the owner-selected unsigned channel with an ad-hoc integrity seal,\nwithout Developer ID or notarization. Earlier packages are preserved. Broader\nPRD, participant-study, clean-account, VoiceOver and IME acceptance remain open.\n")
status=dict(kind='unsigned-macos-arm64-maintenance',version=b['version'],build=b['build'],source_commit=b['source_commit'],native_sha256=b['native_sha256'],agent_sha256=b['agent_sha256'],architecture='arm64',binary_minimum_macos='26.0',developer_id_signed=False,ad_hoc_integrity_seal=True,notarized=False,validation_receipt='docs/validation/cursor-guidance-206/report.json',published=False)
(release/'RELEASE_STATUS.json').write_text(json.dumps(status,indent=2)+'\n');(release/'RELEASE_MANIFEST.json').write_text(json.dumps(dict(status=status,files=members(release)),indent=2)+'\n')
expected=members(release);archive=release.parent/(release.name+'.zip');assert not archive.exists()
with archive.open('xb') as f:
 archive.chmod(0o644)
 with zipfile.ZipFile(f,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,value in expected.items():
   entry=zipfile.ZipInfo(release.name+'/'+name,date_time=(1980,1,1,0,0,0));entry.create_system=3;entry.external_attr=(stat.S_IFREG|int(value['mode'],8))<<16;entry.compress_type=zipfile.ZIP_DEFLATED;z.writestr(entry,(release/name).read_bytes(),compresslevel=9)
verify_archive(archive,release.name,expected)
out=Path('/private/tmp/elab-cursor-guidance-206-extracted');assert not out.exists()
subprocess.run(['/usr/bin/ditto','-x','-k',str(archive),str(out/'Extracted download µ with spaces')],check=True,timeout=120)
extracted=out/'Extracted download µ with spaces'/release.name
assert members(extracted)==expected and members(previous)==preserved
subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict','--verbose=2',str(extracted/'ELab.app')],check=True,timeout=30)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(archive.parent/(archive.name+'.sha256')).write_text(sha(archive)+'  '+archive.name+'\n')
report=dict(passed=True,release=str(release),archive=str(archive),archive_sha256=sha(archive),members=len(expected),source_commit=b['source_commit'],native_sha256=b['native_sha256'],agent_sha256=b['agent_sha256'],extraction_verified=True,unicode_space_path_verified=True,modes_preserved=True,strict_ad_hoc_signature_valid=True,previous_release_unchanged=True,sdk_license_record_matches_active_pin=(licenses/'sdk.lock.json').read_bytes()==(root/'third_party/vellum/sdk.lock.json').read_bytes())
(stage/'package-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
