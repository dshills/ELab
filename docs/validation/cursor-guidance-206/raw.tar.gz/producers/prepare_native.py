"""Prepare an isolated, separately identified app from the candidate's compiled code."""
from pathlib import Path
import hashlib
import json
import plistlib
import shutil
import subprocess

root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
build = json.loads((stage / 'build-result-signed.json').read_text())
base = Path('/private/tmp/elab-cursor-guidance-206')
base.mkdir(mode=0o700)
pin = json.loads((root / 'third_party/vellum/sdk.lock.json').read_text())
sdk = root / pin['cache']
app = base / 'ELab Cursor Recovery.app'
subprocess.run(['python3', '-B', str(sdk / 'scripts/package-app.py'),
                '--binary', str(stage / 'build/elab'), '--output', str(app),
                '--name', 'ELab Cursor Recovery', '--identifier', 'com.dshills.elab.cursor-guidance206',
                '--version', build['version'], '--build-version', build['build'], '--sign-identity', '-'],
               check=True, capture_output=True, timeout=90)
profile = base / 'runtime.sb'
profile.write_text('(version 1)\n(allow default)\n'
                   '(deny file-read* file-write* (subpath "/Users/dshills/Library/Cogent Core"))\n'
                   '(deny network-outbound (remote ip "*:*"))\n')
launcher = app / 'Contents/MacOS/Launcher'
launcher.write_text('#!/bin/sh\nexec /usr/bin/sandbox-exec -f /private/tmp/elab-cursor-guidance-206/runtime.sb '
                    '"/private/tmp/elab-cursor-guidance-206/ELab Cursor Recovery.app/Contents/MacOS/ELab Cursor Recovery" '
                    '--agent-endpoint /private/tmp/elab-cursor-guidance-206/endpoint.json '
                    '--no-recovery --no-appearance > /private/tmp/elab-cursor-guidance-206/native.log 2>&1\n')
launcher.chmod(0o755)
info = app / 'Contents/Info.plist'
data = plistlib.loads(info.read_bytes())
data['CFBundleExecutable'] = 'Launcher'
info.write_bytes(plistlib.dumps(data))
subprocess.run(['/usr/bin/codesign', '--force', '--deep', '--sign', '-', str(app)], check=True, capture_output=True)
subprocess.run(['/usr/bin/codesign', '--verify', '--deep', '--strict', str(app)], check=True, capture_output=True)
candidate_binary = Path(build['review']) / 'ELab.app/Contents/MacOS/ELab'
test_binary = app / 'Contents/MacOS/ELab Cursor Recovery'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(candidate_binary) == build['native_sha256']
for name, path in [('candidate', candidate_binary), ('native-test', test_binary)]:
    out = base / (name + '-unsigned-code')
    shutil.copyfile(path, out)
    subprocess.run(['/usr/bin/codesign', '--remove-signature', str(out)], check=True, capture_output=True)
assert (base / 'candidate-unsigned-code').read_bytes() == (base / 'native-test-unsigned-code').read_bytes()
report = dict(source_commit=build['source_commit'], candidate_native_sha256=build['native_sha256'],
              native_test_sha256=sha(test_binary), unsigned_code_sha256=sha(base / 'native-test-unsigned-code'),
              unsigned_compiled_executables_identical=True, native_test_bundle_id='com.dshills.elab.cursor-guidance206',
              native_test_scope='Same compiled source, distinct test bundle/signature; not exact distribution bundle',
              isolated_appearance_and_recovery=True, shared_geometry_access_denied=True)
(stage / 'native-equivalence.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(app=str(app), unsigned_compiled_executables_identical=True)))
