from pathlib import Path
import importlib.util,json,subprocess,sys,time
R=Path('/Users/dshills/Development/projects/ELab');O=Path('/private/tmp/elab-walkthrough-195');run=Path('/private/tmp/elab-walkthrough-195-runtime')
report=json.loads((O/'session.json').read_text());observed=subprocess.check_output(['/bin/ps','-p',str(report['owned_pid']),'-o','command='],text=True).strip();assert observed==report['observed_command'] and report['status']=='ready_for_cua'
spec=importlib.util.spec_from_file_location('nativeclient',R/'scripts/persistence-demo.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
c=m.Client(str(O/'endpoint.json'),command_preconditions=True,agent_binary=run/'agent')
try:
 for request in json.loads(sys.argv[1]):
  result=c.ask(request['command'],request.get('params'),request.get('mutate',False),request.get('expect'))
  record=dict(request=request,result=result);(O/(str(time.time_ns())+'-rpc.json')).write_text(json.dumps(record,indent=2)+'\n')
  print(json.dumps(record))
finally:c.close()
