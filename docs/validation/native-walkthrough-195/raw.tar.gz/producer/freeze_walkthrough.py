from pathlib import Path
import hashlib, json, shutil, subprocess, sys, tarfile

R = Path('/Users/dshills/Development/projects/ELab')
S = Path(__file__).resolve().parent
W = Path('/private/tmp/elab-walkthrough-195')
I = Path('/private/tmp/elab-input-final-195')
D = R/'docs/validation/native-walkthrough-195'
D.mkdir(parents=True, exist_ok=True)
assert not (D/'report.json').exists() and not (D/'raw.tar.gz').exists()
sys.path.insert(0, str(R/'scripts'))
from package_review import members, verify_archive
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
walk = json.loads((W/'walkthrough-verification-report.json').read_text())
inputs = json.loads((I/'input-verification-report.json').read_text())
assert walk['passed'] and inputs['passed']
sessions = [json.loads((o/'session.json').read_text()) for o in (W,I)]
assert all(s['status']=='closed' and s['owned_process_absent'] and s['endpoint_removed'] and s['open_exit_code']==0 for s in sessions)
quality = json.loads((S/'quality-inputs.json').read_text())['go_sources']
assert len(quality)==671 and all(sha(R/p)==digest for p,digest in quality.items())
assert set(quality)==set(subprocess.check_output(['git','ls-files','--','*.go'],cwd=R,text=True).splitlines())
protected=json.loads((S/'preservation-before.json').read_text())
assert all(sha(R/p)==digest for p,digest in protected.items())
prior=json.loads((S/'prior-candidates-before.json').read_text())
assert all(members(R/'build'/name)==tree for name,tree in prior.items())
package=R/'build/ELab-0.178.0-195-candidate'
archive=package.parent/(package.name+'.zip')
assert sha(archive)=='76da198544ebb7aff0d1fc1d9e98b1bf052e37abbc44963396ef99c8f9a2f02d'
verify_archive(archive, package.name, members(package))
fixtures=json.loads(Path('/private/tmp/elab-native-check-193-prepared/fixtures.json').read_text())
assert all(sha(Path(info['project']))==info['sha256'] for info in fixtures.values())
for o in (W,I):
    assert sha(o/'rc-fixture.elab')==fixtures['rc']['sha256']

attempts = dict(
    numeric_setter_refusal='CUA rejects setValue("bad") for an AX integer before sending input. The second owned native session uses confirmed numeric-editor keyboard focus and actual typing instead.',
    focus='Initial offscreen setters and scroll/menu attempts are retained. Accepted entries use confirmed keyboard/native focus; no refused delivery is counted as an app test.',
    cursor='The first RC cursor delivery had uncertain focus and unexpectedly running time; it is not counted. Restart/Charge/20 native steps established a confirmed paused reference before the successful cursors.',
    helper='The original helper matched the focused-element footer as a second Pause node. It sent no click; the final helper matches actual button nodes only. One-row DC Next is disabled; its seek refusal is tested with Return.',
    first_verifier='The first headless checker incorrectly assumed every saved document was paused. The hand-built DC LED was saved running. The failed report/protocol remain; final verification compares the actual saved paused flag.',
    boundary='A human reply interrupted one flasher example attempt. A fresh AX observation confirmed the unchanged RC state before retry.',
    guidance='The first scroll/disclosure attempts did not display the guidance. Native Shift+Tab reached the diagnostic and the preceding output checkbox, visibly revealing the exact one-row range. The 32-step keyboard route is retained.')
(W/'attempt-limitations.json').write_text(json.dumps(attempts,indent=2)+'\n')
entries={}
for label,o in [('walkthrough',W),('final-input',I)]:
    for p in sorted(o.rglob('*')):
        if p.is_file() and not p.is_relative_to(o/'swift-cache') and not p.is_relative_to(o/'ELab-owned-195.app') and p.name!='endpoint.json':
            entries[label+'/'+p.relative_to(o).as_posix()]=p
for name in ['walkthrough_session.py','walkthrough_rpc.py','verify_walkthrough.py','input_final_session.py','input_final_rpc.py','verify_final_inputs.py','freeze_walkthrough.py','quality-inputs.json']:
    entries['producer/'+name]=S/name
for label,folder in [('walkthrough','elab-walkthrough-195-runtime'),('final-input','elab-input-final-195-runtime')]:
    entries['producer/'+label+'-runtime.sb']=Path('/private/tmp')/folder/'runtime.sb'
    entries['producer/'+label+'-agent-wrapper']=Path('/private/tmp')/folder/'agent'
manifest={name:dict(sha256=sha(p),bytes=p.stat().st_size) for name,p in entries.items()}
with tarfile.open(D/'raw.tar.gz','w:gz') as tar:
    for name,p in entries.items():tar.add(p,arcname=name,recursive=False)
(D/'raw-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
screens=['led-repaired-native.jpg','rc-measured-native.jpg','flasher20-measured-native.jpg','minimum-dark.jpg','normal-light.jpg','dc-guidance-visible.jpg']
for name in screens:shutil.copy2(W/name,D/name)
report=dict(date='2026-10-21',candidate='0.178.0 /195',source_commit=walk['source_commit'],native_sha256=walk['native_sha256'],agent_sha256=walk['agent_sha256'],archive_sha256=sha(archive),passed=True,
    native_reference_workflows_engineering_passed=True,owner_workflow_accepted=False,
    walkthrough=walk,final_native_inputs=inputs,native_sessions=sessions,
    physical_input_scope='CUA native component search/keyboard placement, named terminal wiring, value edit/Undo/Redo/delete/repair, native RC/flasher examples and transport/probes/cursors, capacitor preset, native CSV dialog, invalid/corrected inputs. Fixture seeding and owned project saves are explicitly public API; prior /195 native Save/Open/SVG/cancel evidence is reused.',
    layout=dict(themes=['Light','Dark'],minimum_capture_px=[1053,762],minimum_declared_dp=[1040,720],minimum_floor_confirmed_by_resize_clamp=True,normal_capture_px=[1293,834],scope_final_control_revealed_by_native_tab=True,schematic_expands_when_scope_hidden=True,exhaustive_layout_or_accessibility=False),
    quality=dict(all_671_go_hashes_still_match_full_gate=True,full_go_suite_repeated=False,implementation_changed=False,prior_gate='docs/validation/inspector-scroll-ownership/report.json'),
    preservation=dict(canonical_120_owner_189_and_both_sdks_unchanged=True,prior_191_through_194_trees_unchanged=True,candidate_195_matches_all_124_archived_file_bytes_and_modes=True,original_fixtures_unchanged=True),
    offline='Both native copies and fresh agent subprocesses run under the retained deny policy for source/SDK/toolchain/cache/shared geometry and outbound IP. Controllers and CUA run outside that child policy; this is not clean-account/default installation acceptance.',
    prior_evidence=['docs/validation/native-acceptance-194','docs/validation/inspector-candidate-195','docs/validation/headless-release-193','research/ui-audit/first-version/native-decisions-156','research/ui-audit/first-version/native-recovery-161','research/ui-audit/first-version/native-recording-recovery-161','docs/validation/native-recovery-error-174'],
    known_minor_feedback=['Rejected numeric editor text uses framework-worded validation feedback and AX reports the accepted value; native correction and transport recovery pass.'],
    owner_feedback='October 21: Not tried yet. No owner workflow acceptance or request to promote.',
    limitations=['Representative private-alpha workflows and affected input classes only; broader MVP accessibility/IME, exhaustive bindings, performance, participant study and distribution retain their separate gates.','No fresh PDF/PNG/margin/scale/tiling or physical print qualification; prior complete readable print confirmation is retained.','Ordinary startup/clean-account installation remains explicitly owner-deferred for this private alpha.'],
    ready_for_owner_testing=True,release_qualified=False,promoted=False,
    raw_archive=dict(files=len(entries),sha256=sha(D/'raw.tar.gz'),bytes=(D/'raw.tar.gz').stat().st_size))
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n')
receipt={k:report[k] for k in ['date','candidate','source_commit','native_sha256','agent_sha256','archive_sha256','passed','native_reference_workflows_engineering_passed','owner_workflow_accepted','ready_for_owner_testing','release_qualified','promoted']}
receipt.update(evidence='docs/validation/native-walkthrough-195/report.json',owner_feedback=report['owner_feedback'])
(R/'research/ui-audit/first-version/native-walkthrough-195.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(passed=True,raw_archive=report['raw_archive'],owner_workflow_accepted=False,promoted=False)))
