from pathlib import Path
import csv, hashlib, importlib.util, json, math, statistics, sys, traceback

R = Path('/Users/dshills/Development/projects/ELab')
O = Path('/private/tmp/elab-walkthrough-195')
RUN = Path('/private/tmp/elab-walkthrough-195-runtime')
sys.path.insert(0, str(R/'scripts'))
spec = importlib.util.spec_from_file_location('parity195', R/'scripts/first-version-parity.py')
ref = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ref)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def saved(name):
    return json.loads((O/name).read_text().splitlines()[0])['result']
def near(a, b):
    assert math.isclose(a, b, rel_tol=1e-9, abs_tol=1e-12), (a, b)
report = {'passed': False, 'candidate': '0.178.0 /195', 'cases': [], 'shutdowns': []}

class LoggedClient(ref.helper.Client):
    def __init__(self, name):
        self.log = []
        self.name = name
        super().__init__(command_preconditions=True, agent_binary=RUN/'agent')
    def ask(self, command, params=None, mutate=False, expect=None):
        result = super().ask(command, params, mutate, expect)
        self.log.append(dict(command=command, params=params, mutate=mutate, expect=expect, result=result))
        return result
    def close(self):
        try:
            super().close()
        finally:
            (O/(self.name+'-headless-protocol.json')).write_text(json.dumps(self.log, indent=2)+'\n')

def finish(c):
    state = c.ask('project.inspect')
    assert not state['document']['dirty']
    job = c.ask('app.close', {'discard_changes': False}, True)['shutdown']
    job = c.wait_for_shutdown_outcome(job)
    assert job['status'] == 'completed'
    assert all(job[k] for k in ('workers_joined', 'recovery_finalized', 'exit_ready'))
    report['shutdowns'].append(job)

def crossings(trace):
    result = []
    for a, b in zip(trace['points'], trace['points'][1:]):
        if a['value'] < 1.5 <= b['value']:
            result.append(a['time_s']+(1.5-a['value'])/(b['value']-a['value'])*(b['time_s']-a['time_s']))
    return result

try:
    session = json.loads((O/'session.json').read_text())
    assert session['status'] == 'closed' and session['owned_process_absent'] and session['endpoint_removed']
    assert session['open_exit_code'] == 0 and session['shutdown']['workers_joined']
    assert sha(RUN/'elab-agent') == session['agent_sha256']
    report.update(source_commit=session['source_commit'], native_sha256=session['native_sha256'], agent_sha256=session['agent_sha256'])
    rc_charge = saved('rc-charge-10ms.jsonl')['transient']['sample']
    rc_discharge = saved('rc-discharged.jsonl')['transient']['sample']
    near(rc_charge['time_s'], .01)
    near(rc_charge['voltage_v'], 5*(1-math.exp(-1)))
    near(rc_charge['current_a'], .0005*math.exp(-1))
    near(rc_discharge['time_s'], .02)
    near(rc_discharge['voltage_v'], rc_charge['voltage_v']*math.exp(-1))
    near(rc_discharge['current_a'], -rc_discharge['voltage_v']/10000)
    rc = saved('rc-final.jsonl')
    rows = list(csv.DictReader((O/'RC scope.csv').open()))
    traces = rc['scope']['traces']
    assert len(rows) == len(traces[0]['points']) == len(traces[1]['points'])
    for index, row in enumerate(rows):
        t = float(row['time_s'])
        assert row['engine'] == 'elab.ideal-rc-exact.v1'
        assert int(row['run_id']) == rc['run_id'] and int(row['electrical_revision']) == rc['electrical_revision']
        for trace, column in zip(traces, ('v:C1.1 [V]', 'i:R1 [A]')):
            near(t, trace['points'][index]['time_s'])
            near(float(row[column]), trace['points'][index]['value'])
        near(float(row['v:C1.1 [V]']), 5*(1-math.exp(-t/.01)))
        if t > 0:
            near(float(row['i:R1 [A]']), .0005*math.exp(-t/.01))
    near(rc['scope']['delta_s'], .01)
    report['independent_rc_reference'] = dict(charge_10ms=rc_charge, discharge_after_10ms=rc_discharge, csv_rows=len(rows), csv_all_trace_points_match=True, csv_positive_time_rows_match_analytic_law=True, initial_duplicate_zero_row='Original paused discharge startup and applied Charge startup are both retained; the first zero-time current is intentionally zero.')

    names = [
        ('led', 'LED-built-native.elab', 'led-built-final.jsonl'),
        ('rc', 'RC-native.elab', 'rc-final.jsonl'),
        ('flasher10', 'Flasher-10u-native.elab', 'flasher-10u-final.jsonl'),
        ('flasher20', 'Flasher-20u-native.elab', 'flasher-20u-final.jsonl'),
        ('rc-recorded', 'RC-recorded-recovered.elab', 'timing-interval-pair-final.jsonl'),
        ('dc-recorded', 'LED-DC-recorded.elab', 'dc-one-row-final.jsonl'),
    ]
    for name, filename, snapshot in names:
        native = saved(snapshot)
        path = O/filename
        before = sha(path)
        c = LoggedClient(name)
        try:
            c.ask('project.load', {'path': str(path)}, True)
            state = c.ask('simulation.wait')
            assert state['components'] == native['components'] and state['wires'] == native['wires']
            assert state['scope']['selected'] == native['scope']['selected']
            assert state['transient_settings'] == native['transient_settings']
            assert state['paused'] == json.loads(path.read_text())['paused'] and not state['document']['dirty']
            if name == 'led':
                ref.compare(state['result'], native['result'])
                assert len(state['components']) == 4 and len(state['wires']) == 4
                near(state['result']['current_a'], .001476723549138745)
            elif name == 'rc':
                c.ask('simulation.input.set', {'mode': 'charge'}, True)
                c.ask('simulation.step', {'duration_s': .038}, True)
                state = c.ask('simulation.wait')
                ref.compare(state['transient']['sample'], native['transient']['sample'])
                for cursor, at in [('a', 0), ('b', .01)]:
                    c.ask('scope.cursor.set', {'cursor': cursor, 'time_s': at}, True)
                state = c.ask('project.inspect')
                ref.compare(state['scope']['readings'], native['scope']['readings'])
                near(state['scope']['delta_s'], native['scope']['delta_s'])
            elif name.startswith('flasher'):
                remaining = native['mixed']['time_s']
                while remaining > 1e-12:
                    duration = min(1, remaining)
                    c.ask('simulation.step', {'duration_s': duration}, True)
                    remaining -= duration
                state = c.ask('simulation.wait')
                ref.compare(ref.numerical(state), ref.numerical(native))
                for cursor in ('a', 'b'):
                    c.ask('scope.cursor.set', {'cursor': cursor, 'time_s': native['scope'][cursor]['time_s']}, True)
                measured = c.ask('project.inspect')
                ref.compare(measured['scope']['readings'], native['scope']['readings'])
                near(measured['scope']['delta_s'], native['scope']['delta_s'])
            else:
                recording = state['recording']
                count = recording['sample_count']
                exact_rows = []
                for offset in range(0, count, 100):
                    exact_rows += c.ask('operation.samples', {'id': recording['id'], 'offset': offset, 'limit': 100})['rows']
                (O/(name+'-reopened-rows.json')).write_text(json.dumps(exact_rows, indent=2)+'\n')
                if name == 'rc-recorded':
                    original = json.loads(Path('/private/tmp/elab-native-check-193-prepared/rc-rows.json').read_text())
                    assert count == 1001 and exact_rows == original
                    params = dict(native['recording']['timing']['settings'], id=recording['id'])
                    timing = c.ask('recording.timing', params)
                    def semantic(value):
                        value = json.loads(json.dumps(value)); value['settings'].pop('id'); value.pop('origin_id')
                        return value
                    assert semantic(timing) == semantic(native['recording']['timing'])
                    crossing = timing['crossings'][0]
                    assert crossing['before']['time_s'] < .01*math.log(2) < crossing['after']['time_s']
                else:
                    assert count == 1 and exact_rows[0]['time_s'] == 0
                    assert len(exact_rows[0]['values']) == 4
            report['cases'].append(dict(name=name, project=filename, sha256=before, graph_values_models_settings_probes_preserved=True, exact_packaged_agent_matches=True))
        finally:
            try:
                finish(c)
            finally:
                c.close()
        assert sha(path) == before

    periods = {}
    for name, file in [('10uF', 'flasher-10u-final.jsonl'), ('20uF', 'flasher-20u-final.jsonl')]:
        state = saved(file)
        periods[name] = {}
        for trace in state['scope']['traces'][:2]:
            arrivals = crossings(trace)
            gaps = [b-a for a,b in zip(arrivals, arrivals[1:])]
            assert len(gaps) >= 2
            periods[name][trace['probe']['id']] = dict(rising_crossings_1_5V_interpolated_s=arrivals, periods_s=gaps, mean_period_s=statistics.mean(gaps))
    for probe in periods['10uF']:
        ratio = periods['20uF'][probe]['mean_period_s']/periods['10uF'][probe]['mean_period_s']
        assert 1.99 < ratio < 2.01
        periods['20uF'][probe]['ratio_to_10uF'] = ratio
    report['independent_crossing_arithmetic'] = periods
    report['limits'] = ['Native versus matching agent comparisons test parity, not independent device accuracy.', 'Collector crossing interpolation is a calculation from saved samples, separate from the UI nearest-sample cursor values.', 'Live time, rolling history, cursors and measurement sessions are not claimed persisted by project save.', 'Clean-account/default installation remains owner-deferred; no owner workflow acceptance or promotion.']
    report['passed'] = True
except BaseException:
    report['failure'] = traceback.format_exc()
    raise
finally:
    (O/'walkthrough-verification-report.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(dict(passed=report['passed'], cases=len(report['cases']), clean_shutdowns=len(report['shutdowns']))))
