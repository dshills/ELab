from pathlib import Path
import hashlib, importlib.util, json, sys, time

R = Path('/Users/dshills/Development/projects/ELab')
O = Path('/private/tmp/elab-input-final-195')
RUN = Path('/private/tmp/elab-input-final-195-runtime')
spec = importlib.util.spec_from_file_location('finalinput195', R/'scripts/persistence-demo.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
session = json.loads((O/'session.json').read_text())
assert session['status'] == 'closed' and session['owned_process_absent'] and session['endpoint_removed']
assert session['open_exit_code'] == 0
records = [json.loads(line) for line in (O/'verify-sampling-final.jsonl').read_text().splitlines()]
native = records[0]['result']
captured = records[1]['result']['rows']+records[2]['result']['rows']
assert len(captured) == 105
index = json.loads((O/'index-next-final.jsonl').read_text())['result']
assert index['recording']['sample_index'] == 9 and index['recording']['time_s'] == .009000000000000001
assert 'Could not finish recorded playback entry' in (O/'index-invalid-next.ax.txt').read_text()
assert 'sample 9 / 1000' in (O/'index-next-recovered.ax.txt').read_text()
assert 'Value: bad' in (O/'verify-step-refused.ax.txt').read_text()
assert 'Recorded · 105 samples' in (O/'verify-step-recovered.ax.txt').read_text()
before = json.loads((O/'rc-fixture-loaded.jsonl').read_text())['result']
fields = ['components', 'wires', 'result', 'mixed', 'transient', 'run_id', 'electrical_revision']
assert {k:before.get(k) for k in fields} == {k:native.get(k) for k in fields}
original = json.loads(Path('/private/tmp/elab-native-check-193-prepared/rc-rows.json').read_text())
jobs = []
protocol = []
def ask(c, command, params=None, mutate=False):
    value = c.ask(command, params, mutate)
    protocol.append(dict(command=command, params=params, mutate=mutate, result=value))
    return value
def rows(c, identifier):
    out = []
    offset = 0
    while True:
        page = ask(c, 'operation.samples', dict(id=identifier, offset=offset, limit=100))
        out += page['rows']
        if page['next_offset'] == page['total']: return out
        assert page['next_offset'] > offset
        offset = page['next_offset']
def finish(c):
    job = ask(c, 'app.close', {'discard_changes': False}, True)['shutdown']
    job = c.wait_for_shutdown_outcome(job)
    assert job['status'] == 'completed' and all(job[k] for k in ('workers_joined', 'recovery_finalized', 'exit_ready'))
    jobs.append(job)

saved = O/'RC-final-inputs.elab'; saved_hash = sha(saved)
c = m.Client(command_preconditions=True, agent_binary=RUN/'agent')
try:
    ask(c, 'project.load', {'path': str(saved)}, True)
    restored = ask(c, 'simulation.wait')
    assert restored['components'] == native['components'] and restored['wires'] == native['wires']
    all_rows = [rows(c, operation['id']) for operation in restored['operations']]
    assert captured in all_rows and original in all_rows
    assert len(all_rows) == 2
    # Match native row 9 through the same public index command in a fresh fixture.
    ask(c, 'project.load', {'path': str(O/'rc-fixture.elab')}, True)
    at9 = ask(c, 'recording.seek', {'index': 9}, True)
    assert at9['recording']['readings'] == index['recording']['readings']
    ask(c, 'verification.settings.set', native['verification_settings'], True)
    admitted = ask(c, 'simulation.verify', {'probe_ids': native['recording']['scope']['selected']}, True)
    deadline = time.monotonic()+15
    while True:
        operation = ask(c, 'operation.inspect', {'id': admitted['last_operation']})
        assert operation['operation']['status'] not in ('failed', 'canceled')
        if operation['operation']['status'] == 'completed': break
        assert time.monotonic() < deadline
        time.sleep(.01)
    assert rows(c, admitted['last_operation']) == captured
    ask(c, 'project.save', {'path': str(O/'headless-counterpart.elab')}, True)
finally:
    try: finish(c)
    finally: c.close(); (O/'headless-protocol.json').write_text(json.dumps(protocol, indent=2)+'\n')
assert sha(saved) == saved_hash
report = dict(passed=True, native_index_invalid_text_delivered_by_keyboard=True,
    native_index_bad_then_accepted_8_next_without_return_reaches_9=True,
    native_index_readings_match_exact_packaged_agent=True,
    native_sample_step_bad_then_accepted_0_verify_without_return=True,
    native_verify_105_rows_match_fresh_packaged_agent=True,
    original_1001_rows_preserved=True, original_live_physics_preserved=True,
    both_saved_recordings_reopen_exact=True, saved_project_sha256=saved_hash,
    shutdowns=jobs, native_session=session,
    limitations=['Numeric field accessibility value reports the accepted 8 while local validation retains rejection; the screenshot records the framework-worded error. No claim that AX exposes the raw bad draft.', 'Representative input classes, not exhaustive keyboard/IME/screen-reader or every verification startup override.'])
(O/'input-verification-report.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(dict(passed=True, recording_rows=[1001,105], clean_headless_shutdowns=len(jobs))))
