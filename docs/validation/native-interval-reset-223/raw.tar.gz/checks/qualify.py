from pathlib import Path
import copy,datetime,hashlib,importlib.util,json,math,subprocess,sys
r=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent
read=lambda n:json.loads((s/(n+'.json')).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cases=[
 ('live','live-window','live-private-valid','live-valid-reset'),
 ('live','live-invalid-baseline','live-private-invalid','live-invalid-reset'),
 ('live','live-end-valid-baseline','live-end-private-valid','live-end-valid-reset'),
 ('live','live-end-invalid-baseline','live-end-private-invalid','live-end-invalid-reset'),
 ('recorded','recorded-baseline','recorded-private-valid','recorded-valid-reset'),
 ('recorded','recorded-invalid-baseline','recorded-private-invalid','recorded-invalid-reset'),
 ('recorded','recorded-end-valid-baseline','recorded-end-private-valid','recorded-end-valid-reset'),
 ('recorded','recorded-end-invalid-baseline','recorded-end-private-invalid','recorded-end-invalid-reset')]
allowed={'scope','recording','command_revision','revision','last_actor'}
physical=lambda value:{k:v for k,v in value.items() if k not in allowed}
base=read('live-window')
for mode,before,private,after in cases:
 a,p,b=read(before),read(private),read(after);assert a==p,private
 assert physical(a)==physical(b),after
 w=b['scope']['window'] if mode=='live' else b['recording']['scope']['window']
 assert w=={'mode':'live' if mode=='live' else 'fixed','start_s':0,'end_s':.02 if mode=='live' else .001},w
 assert b['command_revision']==a['command_revision']+1,after
margins={}
for mode in ['live','recorded']:
 trial=s/(mode+'-held');b=json.loads((trial/'bracket.json').read_text());a=json.loads((trial/'intervention.json').read_text())
 assert b['hold_ms']==3000 and b['call_end_wall_ms']-b['call_start_wall_ms']>=3000
 lo=b['call_end_wall_ms']-3000;hi=b['call_start_wall_ms']+3000
 assert lo<a['command_start_wall_ms']<a['command_end_wall_ms']<hi
 assert read(mode+'-held-released')==a['accepted']
 fresh=read(mode+'-fresh-retry');assert fresh['command_revision']==a['accepted']['command_revision']+1
 assert physical(fresh)==physical(a['accepted'])
 w=fresh['scope']['window'] if mode=='live' else fresh['recording']['scope']['window']
 assert w['start_s']==0 and w['end_s']==(.02 if mode=='live' else .001)
 margins[mode]=dict(guaranteed_hold_start_wall_ms=lo,guaranteed_hold_end_wall_ms=hi,
  call_duration_ms=b['call_end_wall_ms']-b['call_start_wall_ms'],request_start_margin_ms=a['command_start_wall_ms']-lo,request_end_margin_ms=hi-a['command_end_wall_ms'])
for p in s.glob('*.json'):
 if p.stem=='live-view':continue # setup snapshot precedes the intentional 20 ms simulation step
 state=json.loads(p.read_text())
 if isinstance(state,dict) and 'components' in state and 'command_revision' in state:assert physical(state)==physical(base),p.name
errors=[]
for trace in read('live-end-invalid-reset')['scope']['traces']:
 assert trace['probe']['id'] in ['v:C1.1','v:V1.positive']
 for point in trace['points']:
  target=5 if trace['probe']['id']=='v:V1.positive' else 5*-math.expm1(-point['time_s']/.01)
  errors.append(abs(point['value']-target));assert math.isclose(point['value'],target,rel_tol=1e-12,abs_tol=1e-12)
assert len(errors)==42
spec=importlib.util.spec_from_file_location('client',r/'scripts/persistence-demo.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
c=h.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json',command_preconditions=True,agent_binary=r/'build/ELab-0.181.22-223-candidate/elab-agent')
try:
 state=c.ask('project.inspect');rows=[];offset=0
 while True:
  page=c.ask('operation.samples',{'id':state['selected_operation'],'offset':offset,'limit':200});rows.extend(page['rows'])
  if len(rows)==page['total']:break
  offset=page['next_offset']
 assert rows==json.loads((r/'build/native-acceptance-220-tools/native-recording-rows.json').read_text()) and len(rows)==1001
 for row in rows:
  for value,target in zip(row['values'],[5*-math.expm1(-row['time_s']/.01),5],strict=True):
   errors.append(abs(value-target));assert math.isclose(value,target,rel_tol=1e-12,abs_tol=1e-12)
 (s/'native-recorded-rows.json').write_text(json.dumps(rows,indent=2)+'\n')
 restored=c.ask('project.load',{'path':str(r/'build/native-acceptance-220-tools/RC native 220.elab')},True)
 assert restored['paused'] and not restored['document']['dirty'] and restored['transient']['sample']['time_s']==0
 assert restored['recording']['seconds_per_wall_second']==.1 and restored['theme']=='light'
 (s/'final-state.json').write_text(json.dumps(restored,indent=2)+'\n')
finally:c.close()
inputs=json.loads((r/'docs/validation/number-step-223/source-inputs.json').read_text());assert all(sha(r/p)==digest for p,digest in inputs.items())
project=json.loads((r/'build/number-step-223-tools/preserved-project.json').read_text());assert sha(Path(project['path']))==project['sha256']
update=read('prepared-update');app=Path(update['installed']);assert sha(app/'Contents/MacOS/ELab Cursor Recovery')==update['native_sha256']
with (s/'signature-after-checks.txt').open('x') as log:subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict','--verbose=2',str(app)],stdout=log,stderr=-2,check=True)
sys.path.insert(0,str(r/'scripts'));from runtime_isolation import bundle_tree
build=json.loads((r/'build/number-step-223-tools/build-result-signed.json').read_text());assert bundle_tree(Path(build['review'])/'ELab.app')==build['source_bundle']
assert sha(r/'build/releases/ELab-0.181.4-macos-arm64.zip')=='d13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
proc=subprocess.run(['/bin/ps','-p','24972','-o','pid=,lstart=,etime=,comm='],capture_output=True,text=True);assert proc.returncode==0 and '/ELab Cursor Recovery.app/Contents/MacOS/ELab Cursor Recovery' in proc.stdout
(s/'same-process-after-checks.txt').write_text(proc.stdout)
report=dict(passed=True,source_commit=build['source_commit'],build='0.181.22 /223',native_sha256=update['native_sha256'],
 native_check_completed=8,first_click_cases=8,both_fields_and_both_views=True,private_snapshot_equalities=8,
 held_agent_trials=2,held_agent_state_preserved_exactly=True,fresh_retries_passed=2,
 hold_overlap=margins,hold_proof_scope='Documented CUA hold duration and enclosing call bracket; not hardware event latency',
 physical_snapshot_keys_preserved='Every root field except scope, recording, command_revision, revision and last_actor; viewport is exact too',
 stored_rows_exact=1001,independent_voltage_references=len(errors),max_absolute_error_v=max(errors),
 source_inputs_unchanged=len(inputs),strict_signature_valid=True,original_candidate_unchanged=True,preserved_205_unchanged=True,
 saved_project_unchanged=True,final_clean_paused_at_zero=True,same_recorded_pid_live=24972,
 other_native_checks_not_retested=True,no_new_owner_permission_question=True,production_source_changes=0,full_source_suites_repeated=False,
 lifecycle_classification='Native Quit-menu request preceded the earlier exit; initiator unknown; no spontaneous crash demonstrated; no general lifecycle pass claimed',
 remaining_original_native_checks=9,release_ready=False,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(s/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
