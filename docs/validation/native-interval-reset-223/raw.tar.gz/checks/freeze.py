from pathlib import Path
import gzip,hashlib,io,json,tarfile
r=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent;o=r/'docs/validation/native-interval-reset-223'
sha=lambda b:hashlib.sha256(b).hexdigest();assert not o.exists()
report=json.loads((s/'report.json').read_text());assert report['passed'] and report['native_check_completed']==8
files={}
for p in sorted(s.rglob('*')):
 rel=p.relative_to(s)
 if p.is_file() and p.suffix in {'.py','.txt','.json','.png'}:files['checks/'+rel.as_posix()]=p.read_bytes()
life=r/'build/native-lifecycle-223-tools'
for name in ['termination-evidence.txt','reviewed-sources.json','report.json']:
 files['lifecycle/'+name]=(life/name).read_bytes()
o.mkdir(parents=True)
with (o/'raw.tar.gz').open('xb') as disk:
 with gzip.GzipFile(fileobj=disk,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name,data in sorted(files.items()):
    info=tarfile.TarInfo(name);info.size,info.mode,info.mtime=len(data),0o644,0
    tar.addfile(info,io.BytesIO(data))
(o/'raw-manifest.json').write_text(json.dumps({n:sha(b) for n,b in sorted(files.items())},indent=2)+'\n')
report.update(raw_archive_sha256=sha((o/'raw.tar.gz').read_bytes()),raw_members=len(files))
(o/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(o/'lifecycle-classification.json').write_text((life/'report.json').read_text())
(o/'quit-event.txt').write_text((life/'termination-evidence.txt').read_text())
pending=json.loads((r/'docs/validation/number-step-223/native-acceptance-pending.json').read_text())
pending.update(completed_checks_for_copied_runtime=[1,2,4,5,7,8,16,17,18],remaining_checks_count=9,
 new_native_checks=[8],carried_forward_checks=[1,2,4,5,7,16,17,18],current_build_fresh_native_checks=[8],
 current_build_fresh_native_scope='Both live/recorded start/end first-click reset cases, timed held-button agent edits, and fresh retries',
 prior_evidence='../number-step-223/README.md',evidence='README.md',
 additional_open_issue='The earlier exit is now classified from AppKit logs as a native Quit-menu action followed by terminate. The pinned GLFW delegate intentionally returns NSTerminateCancel while forwarding close requests. The menu action initiator remains unknown; no spontaneous crash or restoration failure is demonstrated. No crash fix or broad lifecycle pass is claimed.')
(o/'native-acceptance-pending.json').write_text(json.dumps(pending,indent=2)+'\n')
(o/'README.md').write_text('''# Native interval reset and exit classification /223

[Receipt](report.json), [raw checks/captures](raw.tar.gz),
[hashes](raw-manifest.json), [current checklist](native-acceptance-pending.json),
[Quit event](quit-event.txt), [classification](lifecycle-classification.json).

Native checklist item 8 passes on the unchanged code-equivalent /223 test copy.
Eight first-click cases cover private valid/invalid entries in both start/end
fields and live/recorded views. The private snapshots remain exactly equal to
the accepted baselines. One reset clears the draft, restores the complete
interval and delivers exactly one shared command. No interval guidance remains.

In each view, a three-second documented CUA button hold overlaps an external
agent interval edit. Releasing the old gesture preserves the complete accepted
agent snapshot exactly. A fresh click then resets on its first attempt. The
native source returns to the full 0–20 ms history or exact 0–1 ms recording.
For call start S, completion E and hold D, the documented hold must contain
[E−D, S+D]. Both complete agent requests lie inside that intersection, with
more than 700 ms and 1,970 ms margins. This is ordering evidence under CUA's
hold contract, not a hardware-input latency measurement.

Every physical root field, including viewport, is unchanged throughout the
interval checks. Only scope/recording presentation, revisions and actor differ.
All 1,001 stored rows remain exact and 2,044 independent voltage references pass
(maximum absolute error below 5e-16 V). The first verifier incorrectly compared
the pre-step setup snapshot with post-step physics; that harness failure is
retained and excluded explicitly. No product source changes or full source-suite
repetition. All 897 source inputs, strict signatures, original candidate, saved
fixture and /205 ZIP remain unchanged. The final app is clean, paused at zero,
Light, with original playback preferences restored. The recorded process stays
live at the final check; general stability is not inferred from checkpoints.

## Earlier exit: a native Quit request, with unknown initiator

macOS AppKit logs at 04:12:42.358 show a menu-item action, sendAction and terminate.
The delegate then reports NSTerminateCancel; the pinned GLFW implementation
explicitly forwards window-close requests and returns that result. Launchd
removes the exact child shortly afterward. The normal launcher has no smoke or
exit timer. Two restoration repeats did not reproduce a failure, and the same
reopened process remains live through these checks. This changes the earlier
unexplained-exit classification: no spontaneous crash or restoration defect is
demonstrated. The initiator of the Quit-menu action remains unknown. No source
fix or general lifecycle pass is claimed. Only relevant owned-process log lines
are archived; unrelated application inventories remain excluded.

Nine of eighteen accumulated native checks now have scoped evidence; nine remain.
/223 stays held and the /205 download remains preserved. Owner review is deferred;
standing launch/desktop authorization is used without another permission question.
''')
(r/'research/105-native-reset-and-exit-classification.md').write_text('''# Native interval reset and exit classification

October 24, 2026. [Evidence and current checklist](../docs/validation/native-interval-reset-223/README.md).

Native item 8 passes without changing product code. Both live and recorded views
reset on the first click after valid or invalid unfinished start/end entries.
Timed held-button trials overlap real agent edits; the old gesture preserves
the complete agent state exactly, and a fresh reset succeeds. All physical state,
1,001 recorded rows and 2,044 independent voltage references are preserved.
The test app is restored clean and paused; signatures, saved files and /205 stay
unchanged. Existing source gates still apply to all 897 unchanged inputs.

The previous unexplained exit is now traced to an AppKit Quit-menu action at
04:12:42.358, followed by the native terminate/close sequence. NSTerminateCancel
is expected in the pinned GLFW delegate while it forwards window-close requests.
The menu action's initiator remains unknown. There is no demonstrated spontaneous
crash or restoration defect, so no speculative fix is made. General lifecycle
acceptance remains separate from this classification and bounded surviving process.

Nine original native checks remain. Next: recorded-position refusal/correction
and queued pre-agent parser ownership, then captured-measurement defaults and
cached-result presentation. Preserve the private-alpha download and continue
without waiting for owner review or another launch/desktop permission reply.
''')
with (r/'research/README.md').open('a') as f:f.write('\n- [Native interval reset and exit classification](105-native-reset-and-exit-classification.md): both fields/views, timed agent interventions, immutable captures, and the AppKit Quit-menu evidence for the earlier exit.\n')
p=r/'research/34-first-version-plan.md';text=p.read_text();a=text.index('**Current maintenance work:**');b=text.index('\n## Historical plan',a)
text=text[:a]+'''**Current maintenance work:** /223's decimal-step repair and the
[latest native interval-reset checks](105-native-reset-and-exit-classification.md)
pass within scope. Nine of eighteen original native items now have evidence;
nine remain. The earlier exit is classified as a native Quit-menu request from
AppKit logs; its initiator is unknown, and no spontaneous crash or restoration
defect is demonstrated. General lifecycle acceptance is not inferred.

Earlier validation-scroll, private-draft, footer/theme, manual-step, slider,
Verify endpoint and numeric-wheel repairs remain included. [Electronics reference
checks](95-gate-common-mode.md) cover seven RC-driven MOSFET circuits and active
work preservation. /207–/223 stay held for remaining native acceptance and do not
replace /205. Owner review remains deferred. Standing run/desktop authorization
is saved in `AGENTS.md` and must not be requested again.
''' +text[b:];p.write_text(text)
p=r/'research/80-overnight-work-plan.md'
with p.open('a') as f:f.write('''

## Checkpoint: native interval reset and exit classification

[Native item 8](105-native-reset-and-exit-classification.md) is complete: eight
start/end/view/private-entry resets, both timed agent interventions and immediate
fresh retries pass with preserved physics/captures. Nine original checks remain.
The earlier process exit follows a native Quit-menu action in AppKit logs; the
initiator is unknown, but no spontaneous crash or restoration defect is shown.
No speculative source fix or general lifecycle pass. Next continue item 9's
recorded-position correction and pre-agent parser ownership, then captured
measurement defaults/presentation. /205 stays preserved; no owner-review or
launch-permission wait and no unrelated source-gate repetition.
''')
print(json.dumps({'raw_members':len(files),'completed_native_check':8,'remaining_original_checks':9,'production_changes':0}))
