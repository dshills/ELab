"""One public-agent edit during a documented CUA held click; no UI interaction."""
from pathlib import Path
import importlib.util,json,sys,time
r=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent
mode=sys.argv[1];assert mode in ['live','recorded'];trial=s/(mode+'-held');assert not trial.exists();trial.mkdir()
spec=importlib.util.spec_from_file_location('client',r/'scripts/persistence-demo.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
c=h.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json',command_preconditions=True,agent_binary=r/'build/ELab-0.181.22-223-candidate/elab-agent')
try:
 baseline=c.ask('project.inspect');(trial/'ready.json').write_text(json.dumps({'ready_wall_ms':time.time_ns()/1e6,'baseline':baseline},indent=2)+'\n')
 deadline=time.monotonic()+45
 while not (trial/'trigger.json').exists():
  if time.monotonic()>deadline:raise TimeoutError('no held-click trigger; no command sent')
  time.sleep(.02)
 trigger=json.loads((trial/'trigger.json').read_text());seen=time.time_ns()/1e6;time.sleep(1)
 before=c.ask('project.inspect');start=time.time_ns()/1e6
 command='scope.window.set' if mode=='live' else 'recording.window.set'
 params={'start_s':.006,'end_s':.018} if mode=='live' else {'start_s':.00025,'end_s':.00075}
 if mode=='live':params['mode']='fixed'
 result=c.ask(command,params,True);end=time.time_ns()/1e6
 (trial/'intervention.json').write_text(json.dumps({'mode':mode,'trigger':trigger,'trigger_seen_wall_ms':seen,'command_start_wall_ms':start,'command_end_wall_ms':end,'command':command,'params':params,'before':before,'accepted':result},indent=2)+'\n')
 print(json.dumps({'mode':mode,'command':command,'start_wall_ms':start,'end_wall_ms':end,'revision':result['command_revision']}))
finally:c.close()
