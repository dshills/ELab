"""Confirm the represented 1000-interval boundary on the untouched /217 agent."""
from pathlib import Path
import hashlib,importlib.util,json,math,time
r=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent
pin=json.loads((r/'build/gate-common-mode-217-tools/packaged-source.json').read_text());binary=Path(pin['binary']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==pin['agent_sha256']
spec=importlib.util.spec_from_file_location('client',r/'scripts/persistence-demo.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
results=[]
for label,duration,step in [('exact-number',.001,1e-6),('exact-units','1 ms','1 us'),('below',math.nextafter(.001,0),1e-6),('above',math.nextafter(.001,math.inf),1e-6)]:
 c=helper.Client(command_preconditions=True,agent_binary=binary);result=dict(case=label,duration=duration,step=step)
 try:
  c.ask('example.rc',{'discard_changes':True},True);c.ask('simulation.pause',{},True);c.ask('simulation.wait');before=c.ask('project.inspect')
  request=dict(version=1,id='boundary-'+label,key='boundary-'+label,command='simulation.verify',expected_command_revision=before['command_revision'],params=dict(duration_s=duration,sample_step_s=step,input_mode='charge',probe_ids=['v:C1']))
  c.process.stdin.write(json.dumps(request)+'\n');c.process.stdin.flush();response=json.loads(c.process.stdout.readline());result['request']=request;result['response']=response
  state=c.ask('project.inspect')
  if response.get('error'):
   result['accepted_state_unchanged']=state==before
  else:
   identifier=response['result']['last_operation'];deadline=time.monotonic()+5
   while True:
    op=c.ask('operation.inspect',{'id':identifier})
    if op['operation']['status'] in ['completed','failed','canceled']:break
    assert time.monotonic()<deadline;time.sleep(.001)
   result['operation']=op
   if op['operation']['status']=='completed':result['last_row']=c.ask('operation.samples',{'id':identifier,'offset':op['metadata']['sample_count']-1,'limit':1})
  job=c.ask('app.close',{'discard_changes':True},True)['shutdown'];job=c.wait_for_shutdown_outcome(job);assert job['workers_joined'] and job['exit_ready'];result['shutdown']=job
 finally:c.close()
 assert c.process.returncode==0;result['exit_code']=0;results.append(result)
 print(label,response.get('error',{}).get('message','accepted'),flush=True)
(s/'before-report.json').write_text(json.dumps(dict(source=pin,cases=results),indent=2)+'\n')
