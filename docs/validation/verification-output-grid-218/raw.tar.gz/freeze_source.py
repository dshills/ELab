"""Freeze the shared Verify/import boundary repair after the full quality gate."""
from pathlib import Path
import gzip, hashlib, io, json, re, subprocess, tarfile

root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
out = root/'docs/validation/verification-output-grid-218'
sha = lambda data: hashlib.sha256(data).hexdigest()
assert (stage/'quality-exit-code.txt').read_text().strip() == '0'
assert (stage/'regression-after-exit-code.txt').read_text().strip() == '0'
inputs = json.loads((stage/'source-inputs.json').read_text())
prior = json.loads((root/'docs/validation/number-field-wheel-217/source-inputs.json').read_text())
assert len(inputs) == 888 and all(sha((root/p).read_bytes()) == h for p, h in inputs.items())
changed = sorted(p for p, h in inputs.items() if prior[p] != h)
assert changed == ['workbench/recording_grid_precision_test.go', 'workbench/recording_import.go',
                   'workbench/verification.go', 'workbench/verification_capabilities.go']
before = json.loads((stage/'before-report.json').read_text())
assert len(before['cases']) == 4 and all(c['exit_code'] == 0 for c in before['cases'])
for case in before['cases']:
    if case['case'] == 'below':
        assert case['operation']['operation']['status'] == 'completed'
    else:
        assert case['response']['error']['code'] == 'invalid-params' and case['accepted_state_unchanged']
regression = (stage/'regression-before.txt').read_text()
assert 'FAIL: TestVerificationOutputGridUsesRepresentedEndpoints/limit' in regression
quality = (stage/'quality.txt').read_text()
times = re.findall(r'ok\s+github.com/dshills/elab/desktop\s+(\d+\.\d+)s', quality)
assert len(times) == 2
assert 'Ran 67 tests' in quality and '\nOK\n' in quality
sdk = json.loads((root/'third_party/vellum/sdk.lock.json').read_text())
assert sdk == json.loads((root/'docs/validation/number-field-wheel-217/report.json').read_text())['sdk']
assert sha((root/sdk['archive']).read_bytes()) == sdk['sha256']
current = root/'build/releases/ELab-0.181.4-macos-arm64.zip'
assert sha(current.read_bytes()) == 'd13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
parent = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
files = {p.name: p.read_bytes() for p in sorted(stage.iterdir())
         if p.is_file() and p.suffix in {'.py', '.txt', '.json'}}
for name in changed+['docs/verification.md', 'AGENTS.md']:
    files['source/'+name] = (root/name).read_bytes()
    files['source-before/'+name] = subprocess.check_output(['git', 'show', parent+':'+name], cwd=root)
assert not out.exists()
out.mkdir(parents=True)
with (out/'raw.tar.gz').open('xb') as disk:
    with gzip.GzipFile(fileobj=disk, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(files.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
(out/'raw-manifest.json').write_text(json.dumps({p: sha(data) for p, data in sorted(files.items())}, indent=2)+'\n')
(out/'source-inputs.json').write_text(json.dumps(inputs, indent=2)+'\n')
report = dict(kind='verification-output-grid', application_checks_passed=True,
              source_parent_commit=parent, source_inputs=888, changed_source_inputs=changed,
              initial_public_agent=before['source'], initial_public_false_refusals=2,
              initial_source_regression_failed=True, focused_race_seconds=2.371,
              root_race_and_vet_passed=True, desktop_race_seconds=float(times[0]),
              mounted_race_seconds=float(times[1]), python_tests=67,
              sdk_unchanged=sdk, production_desktop_sources_unchanged=126,
              new_commands=0, new_components=0, new_models=0, new_formats=0,
              max_verification_steps=1000, distinct_final_times_preserved=True,
              manual_step_unchanged=True, graphical_app_launched=False,
              preserved_download='0.181.4 /205', release_ready=False, published=False,
              native_acceptance_passed=False, owner_review_required=False,
              raw_archive_sha256=sha((out/'raw.tar.gz').read_bytes()), raw_members=len(files))
(out/'report.json').write_text(json.dumps(report, indent=2)+'\n')
(out/'README.md').write_text(f'''# Represented Verify output grid /218

October 23, 2026. [Receipt](report.json), [source inputs](source-inputs.json),
[raw evidence](raw.tar.gz), [member hashes](raw-manifest.json),
[repair notes](../../../research/96-verification-output-grid.md).

The unchanged /217 public agent falsely refuses both numeric and unit-based
1 ms / 1 µs requests, while its lower neighbor succeeds. The source regression
fails at the same exact 1,000-step endpoint. Division and worker multiplication
disagree by rounding. Shared admission/import now count actual represented
output endpoints, keeping 1,000 steps, distinct final times and completeness
checks. No simulation kernel, manual step, SDK or desktop source changes.

The new successful capture regressions match analytic RC voltage and survive
JSON import and embedded project validation. The upper neighbor still refuses
with an exact unchanged snapshot. Existing tiny-final-grid and mixed-solver
minimum-step failure regressions remain unchanged and pass. Focused race checks
take 2.371 s. The full gate passes lint/staticcheck, 67 Python tests, root/desktop
race and vet, mounted race and offscreen vet: desktop {times[0]} s, mounted
{times[1]} s. All 888 frozen source/check inputs match. Native UI acceptance is
separate; /205 remains the download. Clean packaging follows this source receipt.
''')
notes = root/'research/96-verification-output-grid.md'
text = notes.read_text().replace('Full quality checks are in progress. Clean packaging and matching-agent storage\nchecks follow those checks.',
    f'The [full quality gate passes](../docs/validation/verification-output-grid-218/README.md):\nlint/staticcheck, 67 Python tests, root/desktop race and vet, mounted race and\noffscreen vet. Desktop race takes {times[0]} s; mounted race {times[1]} s. All\n888 frozen source/check inputs match. Clean packaging and matching-agent storage\nchecks follow this source receipt.')
notes.write_text(text)
index = root/'research/README.md'
index.write_text(index.read_text().replace('Focused regressions pass; full quality and clean packaging are in progress.',
    'Focused regressions and full quality pass; clean packaging is next.'))
(out/'MANIFEST.json').write_text(json.dumps({p.name: sha(p.read_bytes()) for p in sorted(out.iterdir()) if p.is_file()}, indent=2)+'\n')
print(json.dumps({k: report[k] for k in ['application_checks_passed', 'source_inputs', 'desktop_race_seconds', 'mounted_race_seconds', 'raw_members']}))
