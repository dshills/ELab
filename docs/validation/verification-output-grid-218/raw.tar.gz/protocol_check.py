"""Exercise represented grid boundaries and storage through the packaged agent."""
from pathlib import Path
import hashlib, importlib.util, json, math, time

root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
build = json.loads((stage/'build-result-signed.json').read_text())
binary = Path(build['review'])/'elab-agent'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(binary) == build['agent_sha256']
spec = importlib.util.spec_from_file_location('client', root/'scripts/persistence-demo.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
report = dict(source_commit=build['source_commit'], agent_sha256=sha(binary),
              cases=[], scalar_readings_checked=0, max_voltage_error_v=0.,
              max_current_error_a=0., shutdowns=[])
records = {}

def close(client):
    try:
        job = client.ask('app.close', {'discard_changes': True}, True)['shutdown']
        job = client.wait_for_shutdown_outcome(job)
        assert job['workers_joined'] and job['exit_ready']
        report['shutdowns'].append(job)
    finally:
        client.close()
    assert client.process.returncode == 0

def rows(client, identifier):
    result = []
    while True:
        page = client.ask('operation.samples', {'id': identifier, 'offset': len(result), 'limit': 200})
        result.extend(page['rows'])
        assert page['next_offset'] == len(result)
        if len(result) == page['total']:
            return result

client = helper.Client(command_preconditions=True, agent_binary=binary)
try:
    client.ask('example.rc', {'discard_changes': True}, True)
    client.ask('simulation.pause', {}, True)
    client.ask('simulation.wait')
    baseline = client.ask('project.inspect')
    for label, duration, step, end, steps in [
        ('number', .001, 1e-6, .001, 1000),
        ('units', '1 ms', '1 us', .001, 1000),
        ('below', math.nextafter(.001, 0), 1e-6, math.nextafter(.001, 0), 1000),
        ('distinct-tail', math.nextafter(.000063, math.inf), 1e-6, math.nextafter(.000063, math.inf), 64),
    ]:
        identifier = client.ask('simulation.verify', dict(duration_s=duration, sample_step_s=step,
                                input_mode='charge', probe_ids=['v:C1', 'i:C1']), True)['last_operation']
        deadline = time.monotonic()+10
        while True:
            operation = client.ask('operation.inspect', {'id': identifier})
            status = operation['operation']['status']
            if status in ['completed', 'failed', 'canceled']:
                break
            assert time.monotonic() < deadline
            time.sleep(.001)
        assert status == 'completed', operation
        assert operation['operation']['total_steps'] == operation['operation']['completed_steps'] == steps
        captured = rows(client, identifier)
        assert len(captured) == steps+1 and captured[-1]['time_s'] == end
        assert operation['metadata']['settings']['step_s'] == 1e-6
        for i, row in enumerate(captured):
            assert row['time_s'] == min(end, i*1e-6)
            expected = [5*-math.expm1(-row['time_s']/.01), .0005*math.exp(-row['time_s']/.01)]
            for column, name, tolerance in [(0, 'max_voltage_error_v', 1e-12), (1, 'max_current_error_a', 1e-15)]:
                error = abs(row['values'][column]-expected[column])
                report[name] = max(report[name], error)
                assert error < tolerance
                report['scalar_readings_checked'] += 1
        record = dict(metadata=operation['metadata'], rows=captured)
        records[identifier] = record
        (stage/(label+'-record.json')).write_text(json.dumps(record, indent=2)+'\n')
        report['cases'].append(dict(case=label, total_steps=steps, rows=len(captured), final_time_s=end))
    current = client.ask('project.inspect')
    protected = ['components', 'wires', 'nets', 'paused', 'run_id', 'electrical_revision',
                 'transient', 'mixed', 'transient_settings', 'view', 'drawing', 'scope']
    assert all(current.get(k) == baseline.get(k) for k in protected)
    before = client.ask('project.inspect')
    client.ask('simulation.verify', dict(duration_s=math.nextafter(.001, math.inf), sample_step_s=1e-6), True, 'invalid-params')
    assert before == client.ask('project.inspect')
    report['above_limit_refused_without_mutation'] = True
    first_id = next(iter(records))
    exported = stage/'1000 intervals.json'
    assert not exported.exists()
    client.ask('verification.export', dict(id=first_id, path=str(exported), format='json'), True)
    assert json.loads(exported.read_text()) == records[first_id]
    project = stage/'Output grid boundaries.elab'
    assert not project.exists()
    saved = client.ask('project.save', dict(path=str(project)), True)
    assert not saved['document']['dirty'] and saved['document']['recording_count'] == 4
    report.update(live_state_preserved=True, saved_project_sha256=sha(project), exported_sha256=sha(exported))
finally:
    close(client)

client = helper.Client(command_preconditions=True, agent_binary=binary)
try:
    loaded = client.ask('project.load', {'path': str(project)}, True)
    assert loaded['document']['recording_count'] == 4 and not loaded['document']['dirty']
    restored = set()
    for item in loaded['operations']:
        operation = client.ask('operation.inspect', {'id': item['id']})
        origin = operation['metadata']['operation_id']
        assert operation['metadata'] == records[origin]['metadata']
        assert rows(client, item['id']) == records[origin]['rows']
        restored.add(origin)
    assert restored == set(records) and sha(project) == report['saved_project_sha256']
    report['fresh_project_reopen_preserves_all_records'] = True
finally:
    close(client)

client = helper.Client(command_preconditions=True, agent_binary=binary)
try:
    client.ask('simulation.pause', {}, True)
    client.ask('simulation.wait')
    imported = client.ask('verification.import', {'path': str(exported)}, True)
    identifier = imported['recording']['id']
    assert client.ask('operation.inspect', {'id': identifier})['metadata'] == records[first_id]['metadata']
    assert rows(client, identifier) == records[first_id]['rows']
    copy = stage/'1000 intervals reexported.json'
    assert not copy.exists()
    client.ask('verification.export', dict(id=identifier, path=str(copy), format='json'), True)
    assert exported.read_bytes() == copy.read_bytes() and sha(exported) == report['exported_sha256']
    report['fresh_import_and_byte_exact_reexport'] = True
finally:
    close(client)

assert len(report['shutdowns']) == 3
report.update(passed=True, owned_agent_exit_codes=[0, 0, 0], graphical_app_launched=False)
(stage/'protocol-report.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({k: report[k] for k in ['passed', 'scalar_readings_checked', 'max_voltage_error_v', 'max_current_error_a', 'fresh_project_reopen_preserves_all_records', 'fresh_import_and_byte_exact_reexport']}))
