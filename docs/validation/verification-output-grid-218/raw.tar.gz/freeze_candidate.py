"""Record clean package integrity and exact-agent grid/storage checks."""
from pathlib import Path
import gzip, hashlib, io, json, subprocess, sys, tarfile

root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
out = root/'docs/validation/verification-output-grid-218'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
build = json.loads((stage/'build-result-signed.json').read_text())
protocol = json.loads((stage/'protocol-report.json').read_text())
assert build['passed'] and protocol['passed'] and protocol['scalar_readings_checked'] == 6136
assert build['source_commit'] == protocol['source_commit']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root).strip()
inputs = json.loads((out/'source-inputs.json').read_text())
assert all(sha(root/p) == h for p, h in inputs.items())
sys.path.insert(0, str(root/'scripts'))
from runtime_isolation import bundle_tree
review = Path(build['review'])
app = review/'ELab.app'
assert sha(app/'Contents/MacOS/ELab') == build['native_sha256']
assert sha(review/'elab-agent') == build['agent_sha256'] == protocol['agent_sha256']
assert bundle_tree(app) == build['source_bundle']
verified = subprocess.run(['/usr/bin/codesign', '--verify', '--deep', '--strict', '--verbose=2', str(app)], capture_output=True)
(stage/'signature-after-agent.txt').write_bytes(verified.stdout+verified.stderr)
verified.check_returncode()
prior = json.loads((root/'docs/validation/number-field-wheel-217/candidate-report.json').read_text())
assert sha(Path(prior['candidate'])/'ELab.app/Contents/MacOS/ELab') == prior['native_sha256']
assert sha(Path(prior['candidate'])/'elab-agent') == prior['agent_sha256']
assert sha(root/'build/releases/ELab-0.181.4-macos-arm64.zip') == 'd13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
receipt = dict(version=build['version'], build=build['build'], source_commit=build['source_commit'],
               candidate=str(review), native_sha256=build['native_sha256'], agent_sha256=build['agent_sha256'],
               clean_build_vcs=True, source_inputs_still_match=len(inputs), strict_ad_hoc_signature_valid=True,
               bundle_unchanged_after_headless_checks=True, matching_headless_agent_passed=True,
               scalar_readings_checked=6136, captured_rows=3068, boundary_cases=protocol['cases'],
               max_voltage_error_v=protocol['max_voltage_error_v'], max_current_error_a=protocol['max_current_error_a'],
               above_limit_refused_without_mutation=True, live_state_preserved=True,
               fresh_project_reopen_preserves_all_records=True, fresh_import_and_byte_exact_reexport=True,
               shutdowns=protocol['shutdowns'], owned_agent_exit_codes=protocol['owned_agent_exit_codes'],
               prior_candidate_preserved=True, graphical_app_launched=False, native_acceptance_passed=False,
               promotion_status='held', release_ready=False, published=False, owner_review_required=False,
               preserved_download='0.181.4 /205',
               limitations='Headless checks qualify the shared grid/storage repair, not the accumulated native UI changes. Ad-hoc sealing is not Developer ID signing/notarization. No new graphical app or unattended launch prompt is started.')
(out/'candidate-report.json').write_text(json.dumps(receipt, indent=2)+'\n')
pending = json.loads((root/'docs/validation/number-field-wheel-217/native-acceptance-pending.json').read_text())
pending.update(source_commit=build['source_commit'], native_sha256=build['native_sha256'], agent_sha256=build['agent_sha256'])
pending['required_checks'].append('Native Verify fields accept 1 ms at 1 us, complete 1000 output intervals and reopen the capture; a duration beyond the represented bound still refuses')
(out/'native-acceptance-pending.json').write_text(json.dumps(pending, indent=2)+'\n')
evidence = out/'candidate'
assert not evidence.exists()
evidence.mkdir()
names = ['build.txt', 'package.txt', 'signature-signed-verify.txt', 'signature-signed-details.txt',
         'signature-after-agent.txt', 'build-result-signed.json', 'source-commit.txt', 'build_candidate.py',
         'protocol_check.py', 'protocol-check.txt', 'protocol-report.json', 'freeze_candidate.py',
         'number-record.json', 'units-record.json', 'below-record.json', 'distinct-tail-record.json',
         '1000 intervals.json', '1000 intervals reexported.json', 'Output grid boundaries.elab']
files = {name: (stage/name).read_bytes() for name in names}
for name in ['elab-build-info.txt', 'elab-agent-build-info.txt', 'elab-conformance-build-info.txt']:
    files['build/'+name] = (stage/'build'/name).read_bytes()
with (evidence/'raw.tar.gz').open('xb') as disk:
    with gzip.GzipFile(fileobj=disk, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(files.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
(evidence/'raw-manifest.json').write_text(json.dumps({p: hashlib.sha256(data).hexdigest() for p, data in sorted(files.items())}, indent=2)+'\n')
(evidence/'README.md').write_text('''# /218 clean package and matching-agent boundary checks

The exact packaged agent completes numeric and unit-based 1 ms / 1 µs captures,
the lower neighbor and a distinct short final interval. All 3,068 saved rows
match the declared grid; 6,136 voltage/current readings match independent RC
equations. A duration immediately above the 1,000-step endpoint still refuses
with a byte-equivalent public snapshot. The captures preserve live physics.

A separate fresh agent opens the saved four-capture project with every row and
metadata field exact. Another fresh agent imports the full 1,001-row boundary
JSON recording and reexports identical bytes. All three headless processes join
workers and exit 0. Strict ad-hoc bundle verification passes before and after;
the native bundle is unchanged. All executables identify the clean source commit.

This does not pass native UI acceptance. The candidate remains held; /217 and
the qualified /205 download stay preserved. No graphical launch is attempted.
''')
with (out/'README.md').open('a') as stream:
    stream.write('\nThe [clean /218 package and matching agent](candidate-report.json) pass\n6,136 independent RC readings, exact grid endpoints, four-capture fresh project\nreopen and separate JSON import/byte-exact reexport. The bundle stays intact;\nall owned headless workers join. The candidate remains held for the\n[native acceptance list](native-acceptance-pending.json); /205 stays current.\n')
notes = root/'research/96-verification-output-grid.md'
notes.write_text(notes.read_text().replace('Clean packaging and matching-agent storage\nchecks follow this source receipt.',
    'The clean 0.181.17 /218 package and matching agent pass 6,136 independent\nRC voltage/current readings across 3,068 captured rows. A fresh process reopens\nall four saved captures unchanged; another imports the 1,001-row boundary JSON\nand reexports identical bytes. Above-limit refusal preserves the full snapshot,\nall owned workers join and all three processes exit 0. The app bundle remains\nunchanged with valid strict ad-hoc integrity. The candidate is held for native\nacceptance and does not replace /205.'))
index = root/'research/README.md'
index.write_text(index.read_text().replace('Focused regressions and full quality pass; clean packaging is next.',
    'Focused regressions, full quality and clean /218 matching-agent grid/storage checks pass; native acceptance remains separate.'))
plan = root/'research/34-first-version-plan.md'
text = plan.read_text().replace('**Current maintenance work:** /217 prevents wheel input from accidentally\nediting focused number fields. [Implementation and checks](94-number-field-wheel.md).\nThe /207–/217 changes remain held for fresh changed-candidate native acceptance;',
    '**Current maintenance work:** /218 repairs false Verify output-limit refusals\nwhile preserving distinct final samples. [Implementation and checks](96-verification-output-grid.md).\nThe /217 numeric wheel repair remains included. [Electronics reference checks](95-gate-common-mode.md)\ncover seven RC-driven MOSFET circuits and active-work preservation.\nThe /207–/218 changes remain held for fresh changed-candidate native acceptance;')
plan.write_text(text)
checklist = root/'research/66-first-version-completion-checklist.md'
checklist.write_text(checklist.read_text().replace('/207–/217 maintenance candidates', '/207–/218 maintenance candidates'))
(out/'MANIFEST.json').write_text(json.dumps({p.relative_to(out).as_posix(): sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p != out/'MANIFEST.json'}, indent=2)+'\n')
print(json.dumps({k: receipt[k] for k in ['version', 'build', 'source_commit', 'native_sha256', 'agent_sha256', 'scalar_readings_checked', 'promotion_status']}))
