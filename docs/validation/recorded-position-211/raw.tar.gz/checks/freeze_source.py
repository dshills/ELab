"""Freeze request-context evidence after the full ELab source gate."""
import gzip,hashlib,io,json,re,shutil,subprocess,tarfile
from pathlib import Path
root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
out=root/'docs/validation/recorded-position-211'
assert (stage/'quality-exit-code.txt').read_text().strip()=='0' and not out.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
inputs=json.loads((stage/'source-inputs.json').read_text())
assert all(sha((root/p).read_bytes())==digest for p,digest in inputs.items())
assert not (root/'go.sum').exists()
quality=(stage/'quality.txt').read_text();times=re.findall(r'ok\s+github.com/dshills/elab/desktop\s+(\d+\.\d+)s',quality)
assert len(times)==2,times
assert '--- FAIL' in (stage/'backend-before.txt').read_text() and '--- FAIL' in (stage/'desktop-before.txt').read_text()
baseline=json.loads((stage/'packaged-before.json').read_text());assert baseline['state_unchanged'] and baseline['agent_exit_code']==0
lock=json.loads((root/'third_party/vellum/sdk.lock.json').read_text())
assert lock==json.loads((root/'docs/validation/scope-interval-210/report.json').read_text())['sdk_unchanged']
assert sha((root/lock['archive']).read_bytes())==lock['sha256']
zipsha=sha((root/'build/releases/ELab-0.181.4-macos-arm64.zip').read_bytes())
assert zipsha=='d13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
old=json.loads((root/'docs/validation/scope-interval-210/source-inputs.json').read_text())
changed=[p for p,digest in inputs.items() if old.get(p)!=digest]
files={'checks/'+p.name:p.read_bytes() for p in sorted(stage.iterdir()) if p.is_file() and p.suffix in {'.py','.json','.txt'}}
absent=[]
for name in changed:
 files['source/'+name]=(root/name).read_bytes()
 if name in old:files['source-before/'+name]=subprocess.check_output(['git','show',base+':'+name],cwd=root)
 else:absent.append(name)
files['source-before/absent.json']=(json.dumps(absent,indent=2)+'\n').encode()
out.mkdir(parents=True);shutil.copyfile(stage/'source-inputs.json',out/'source-inputs.json')
with (out/'raw.tar.gz').open('xb') as disk:
 with gzip.GzipFile(fileobj=disk,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name,data in sorted(files.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
(out/'raw-manifest.json').write_text(json.dumps({p:sha(b) for p,b in sorted(files.items())},indent=2)+'\n')
report=dict(kind='recorded-position-request-context',source_checks_passed=True,quality_exit_code=0,source_parent_commit=base,
 source_inputs=len(inputs),absent_source_inputs=['go.sum'],changed_source_inputs=changed,python_tests=67,
 source_quality_command="GOFLAGS='-p=1' GOPROXY=off GOTOOLCHAIN=local PYTHONDONTWRITEBYTECODE=1 ./scripts/check.sh",
 desktop_race_seconds=float(times[0]),mounted_race_seconds=float(times[1]),backend_focused_seconds=1.574,callback_and_mounted_focused_seconds=5.931,
 inventory_comparison=json.loads((stage/'inventory-comparison.json').read_text()),
 old_packaged_agent_baseline=dict(version='0.181.9 /210',transport='headless-stdio',old_capture_duration_s=.02,replacement_duration_s=.01,
  stale_request_reported_replacement_range=True,state_unchanged=True,agent_exit_code=0),
 sdk_unchanged=lock,preserved_download_sha256=zipsha,native_app_launched=False,native_acceptance_passed=False,
 release_ready=False,published=False,owner_review_required=False,new_commands=0,new_components=0,new_formats=0,
 download_unchanged='0.181.4 /205',raw_archive_sha256=sha((out/'raw.tar.gz').read_bytes()),raw_members=len(files))
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'README.md').write_text(f'''# Recorded-position request context /211

October 23, 2026. [Receipt](report.json), [source/check inputs](source-inputs.json),
[repair notes](../../../research/88-recorded-position-context.md).

The exact /210 packaged agent reproduces an old 20 ms seek request receiving
the replacement 10 ms capture's bounds. State remains unchanged, but the help
describes the wrong context. UI callback regressions separately reproduce old
malformed text appearing after agent cursor, playback-speed or live-model edits.

One central request-context check now protects all specialized diagnostics and
target references. Strict position intent retains useful whole-index/time and
DC guidance. Malformed/ill-typed requests do not invent position intent, and
stale UI parser failures cannot install text or a continuation in the new editor.
Original error codes/details, parsing precedence, accepted values and schemas
are preserved. Fresh corrections retain the agent's other edits.

Focused backend checks pass in 1.574 s. Callback and existing mounted playback/
private-buffer checks pass in 5.931 s. The complete gate passes lint/staticcheck,
67 Python tests, root/desktop race and vet, mounted UI race and offscreen vet.
Desktop race takes {times[0]} s; mounted race takes {times[1]} s. All {len(inputs)}
captured source/check inputs match. Every semantic native site, public command,
alias and route set is unchanged; only one source hash and line locations move.
Inventory remains 166 commands, 134 routes, 404 sites and 77 native sources.

[Raw records](raw.tar.gz) and [member hashes](raw-manifest.json) include original
source/callback/packaged failures, current and baseline sources, final checks
and producers. An added test initially expected raw JSON `1e309` to be a strict
seek intent. The common decoder rejects that unrepresentable number; it now
correctly remains in generic-decoder cases. Quantity text `"1e309 s"` still gets
current-range guidance. No validation was relaxed for the test.

No graphical application is launched for this checkpoint. The SDK and /205
download remain unchanged, and previous candidates are preserved. Fresh native
acceptance of this UI guard and the accumulated /207–/210 changes remains
separate from source/offscreen and headless evidence. No permission or owner
review is requested and no launch prompt is left waiting.
''')
notes=root/'research/88-recorded-position-context.md';text=notes.read_text();marker='The full source gate is running as exec session 73931'
assert marker in text
notes.write_text(text.partition(marker)[0]+f'''The [full source gate passes](../docs/validation/recorded-position-211/README.md):
lint/staticcheck, 67 Python tests, root/desktop race and vet, mounted UI race and
offscreen vet. Desktop race takes {times[0]} s; mounted race {times[1]} s. All
{len(inputs)} captured source/check inputs remain exact. The SDK, current /205
download and earlier candidates are preserved.

Changed-binary native acceptance remains separate from source/offscreen and
headless-agent evidence. Use the saved authorization without a new permission
request or unattended launch prompt. The owned native session is untouched by
this checkpoint.
''')
manifest={p.relative_to(out).as_posix():sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file()}
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['source_checks_passed','source_inputs','desktop_race_seconds','mounted_race_seconds','raw_members']}))
