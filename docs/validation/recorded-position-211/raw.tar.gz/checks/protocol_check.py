"""Validate packaged seek feedback and captured RC readings after a live edit."""
import hashlib,importlib.util,json,math,time
from pathlib import Path
root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
build=json.loads((stage/'build-result-signed.json').read_text());binary=Path(build['review'])/'elab-agent'
assert hashlib.sha256(binary.read_bytes()).hexdigest()==build['agent_sha256']
spec=importlib.util.spec_from_file_location('client',root/'scripts/persistence-demo.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
c=helper.Client(command_preconditions=True,agent_binary=binary)
report=dict(source_commit=build['source_commit'],agent_sha256=build['agent_sha256'],transport='headless-stdio',
 stale_context_cases=0,malformed_cases=0,fresh_refusal_cases=0,scalar_readings_checked=0,max_voltage_error_v=0.,max_current_error_a=0.)
def capture(duration):
 admitted=c.ask('simulation.verify',{'duration_s':duration,'probe_ids':['v:C1','i:C1']},True)
 identifier=admitted['last_operation'];deadline=time.monotonic()+5
 while True:
  work=c.ask('operation.inspect',{'id':identifier})
  if work['operation']['status']=='completed':return c.ask('project.inspect')
  assert work['operation']['status'] not in {'failed','canceled'} and time.monotonic()<deadline,work
  time.sleep(.01)
def refuse(params,guards=None,generic=True,code='invalid-params'):
 before=c.ask('project.inspect');c.sequence+=1
 request=dict(version=1,id=f'seek-{c.sequence}',key=f'seek-{c.sequence}',command='recording.seek',params=params)
 request.update(guards or dict(expected_command_revision=c.command_revision))
 c.process.stdin.write(json.dumps(request)+'\n');c.process.stdin.flush();line=c.process.stdout.readline();assert line
 response=json.loads(line);assert response['error']['code']==code,response
 if code=='conflict':assert response.get('help') is None
 else:
  h=response['help'];assert h['details']==response['error']['message']
  if generic:assert h['summary']=='That request could not be applied.'
  else:assert 'whole sample index from 0 to 10' in h['action'] and '0.01 s' in h['action']
 assert before==c.ask('project.inspect'),'refusal changed accepted state'
try:
 c.ask('example.rc',{'discard_changes':True},True);c.ask('simulation.pause',{},True)
 original=capture(.02);current=capture(.01)
 assert original['recording']['id']!=current['recording']['id']
 for guards in [dict(expected_command_revision=original['command_revision']),dict(expected_revision=current['revision']+1),
                dict(expected_command_revision=current['command_revision'],expected_document_generation=current['document']['generation']+1)]:
  refuse({'time_s':'oops'},guards);report['stale_context_cases']+=1
 refuse({'time_s':.02},dict(expected_command_revision=original['command_revision']),code='conflict')
 for p in [{'time_s':'oops','extra':True},{'time_s':True},{'time_s':[]},{'index':'1'},{'index':False}]:
  refuse(p);report['malformed_cases']+=1
 for p in [{'time_s':'oops'},{'index':1.5},{'index':-1},{'index':1e100},{'index':None,'time_s':'1e309 s'},{'index':None,'time_s':None}]:
  refuse(p,generic=False);report['fresh_refusal_cases']+=1
 c.ask('recording.view.set',{'mode':'recorded'},True)
 c.ask('recording.window.set',{'start_s':'2 ms','end_s':'8 ms'},True)
 for cursor,at in [('a','3 ms'),('b','7 ms')]:c.ask('recording.cursor.set',{'cursor':cursor,'time_s':at},True)
 captured=c.ask('operation.inspect',{'id':current['recording']['id']})['metadata']
 assert next(p for p in captured['graph']['components'] if p['id']=='R1')['value']==10000
 old=c.ask('project.inspect')['command_revision']
 c.ask('component.set',{'id':'R1','value':'20k'},True);c.ask('simulation.wait')
 assert captured==c.ask('operation.inspect',{'id':current['recording']['id']})['metadata']
 refuse({'time_s':'oops'},dict(expected_command_revision=old));report['stale_context_cases']+=1
 assert next(p for p in c.ask('project.inspect')['components'] if p['id']=='R1')['value']==20000
 for index in range(11):
  before=c.ask('project.inspect');after=c.ask('recording.seek',{'index':index},True)
  changed={k for k in before.keys()|after.keys() if before.get(k)!=after.get(k)}
  assert changed<={'revision','command_revision','last_actor','recording'},changed
  a,b=before['recording'],after['recording'];changed={k for k in a.keys()|b.keys() if a.get(k)!=b.get(k)}
  assert changed<={'sample_index','time_s','readings','playing'},changed
  assert b['sample_index']==index and math.isclose(b['time_s'],index*.001,rel_tol=0,abs_tol=2e-14)
  assert b['scope']['window']['start_s']==.002 and b['scope']['window']['end_s']==.008
  assert len(b['readings'])==2
  for reading in b['readings']:
   probe=reading['probe'];at=index*.001
   if probe['id']=='v:C1':value,unit=5*(1-math.exp(-at/.01)),'V'
   else:
    assert probe['id']=='i:C1';value,unit=.0005*math.exp(-at/.01),'A'
   assert probe['unit']==unit
   error=abs(value-reading['value']);key='max_voltage_error_v' if unit=='V' else 'max_current_error_a'
   report[key]=max(report[key],error);assert error<(1e-10 if unit=='V' else 1e-14)
   report['scalar_readings_checked']+=1
 # A fresh time quantity still selects the intended saved row on the first request.
 corrected=c.ask('recording.seek',{'time_s':'3 ms'},True)
 assert corrected['recording']['sample_index']==3
 job=c.ask('app.close',{'discard_changes':True},True)['shutdown'];job=c.wait_for_shutdown_outcome(job)
 assert job['status']=='completed' and job['workers_joined'] and job['exit_ready'];report['shutdown']=job
finally:c.close()
assert c.process.returncode==0;report.update(passed=True,agent_exit_code=0,live_resistance_ohm=20000,captured_resistance_ohm=10000,
 capture_window_cursors_and_metadata_preserved=True,independent_reference='5 V / 10 kohm / 1 uF: Vc=5*(1-exp(-t/.01)), Ic=.0005*exp(-t/.01); live R1 changed afterward to 20 kohm')
(stage/'protocol-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['passed','stale_context_cases','malformed_cases','fresh_refusal_cases','scalar_readings_checked','max_voltage_error_v','max_current_error_a','agent_exit_code']}))
