"""One predeclared current-build LED cohort. Never replace/retry a scheduled ID."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,re,subprocess,sys,time,traceback
from reference import seed,independent,compare_states
if sys.flags.optimize:raise SystemExit('Assertions required')
os.umask(0o077)
ROOT=Path('/Users/dshills/Development/projects/ELab');STAGE=Path(__file__).resolve().parent;OUT=Path('/private/tmp/elab-latency-led3-185');RUNTIME=Path('/private/tmp/elab-first-version-185-signed-runtime')
PLAN=json.loads((STAGE/'declaration.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
prepare=load('baseline_prepare',ROOT/'tools/baseline-admission/prepare.py');helper=load('owned_client',ROOT/'scripts/persistence-demo.py')
for name,h in PLAN['pinned_files'].items():assert sha(Path(name))==h,name
host={k:subprocess.check_output(v,text=True).strip() for k,v in {'model':['/usr/sbin/sysctl','-n','hw.model'],'os_version':['/usr/bin/sw_vers','-productVersion'],'os_build':['/usr/bin/sw_vers','-buildVersion']}.items()};assert all(host[k]==PLAN['expected_host'][k] for k in host)
session=json.loads((OUT/'report.json').read_text());assert session['status']=='ready_for_controller_binding';pid=session['owned_pid'];window=session['target_windows'][0]['window_id']
recorder_tool=ROOT/'build/display-frame-probe-tools/display-frame-probe';tool=ROOT/'build/baseline-admission-tools/baseline-admission';profile=ROOT/'tools/baseline-admission/profiles/led.json'
identity=['--pid',str(pid),'--window',str(window),'--executable',session['registration']['executable_path'],'--sha256',PLAN['native_sha256']]
def write(folder,name,value):
 with (folder/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def wait(folder,name,seconds=120):
 end=time.monotonic()+seconds
 while not (folder/name).exists():
  assert time.monotonic()<end,'Controller deadline: '+name
  if (folder/'abort.request').exists():raise RuntimeError((folder/'abort.request').read_text())
  time.sleep(.003)
 return json.loads((folder/name).read_text())
client=helper.Client(str(OUT/'endpoint.json'),command_preconditions=True,agent_binary=RUNTIME/'agent');outcomes=[];(OUT/'trials').mkdir(mode=0o700)
canonical=OUT/'seed-project.elab';halt=None
try:
 for trial in PLAN['trials']:
  folder=OUT/'trials'/trial['id'];folder.mkdir(mode=0o700);result=dict(id=trial['id'],status='started',eligible_latency_observations=0,latency_gate_passed=None,attempted_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());recorder=None
  write(folder,'intent.json',trial)
  try:
   seed(client,canonical);client.ask('view.fit',dict(follow_viewport=True),True)
   client.ask('project.save',dict(path=str(folder/'baseline.elab')),True);baseline_file_sha=sha(folder/'baseline.elab');result['baseline_sha256']=baseline_file_sha
   baseline=client.ask('project.inspect');write(folder,'baseline.json',baseline);assert next(p['value'] for p in baseline['components'] if p['id']=='Limit')==1000;independent(baseline)
   inspection=subprocess.run([str(recorder_tool),'--inspect-target']+identity,capture_output=True,text=True,check=True,timeout=15);write(folder,'inspection.json',dict(stdout=inspection.stdout,stderr=inspection.stderr,exit_code=inspection.returncode))
   config=json.loads(inspection.stdout);capture=config['capture_plan'];assert capture['window_global_points']==PLAN['expected_host']['window_global_points'];assert capture['display_id']==PLAN['expected_host']['display_id'] and config['display_mode']==PLAN['expected_host']['display_mode'] and capture['point_pixel_scale']==PLAN['expected_host']['point_pixel_scale']
   write(folder,'ready.json',dict(id=trial['id'],owned_pid=pid,window_id=window,part='Limit',target='2k'))
   draft=wait(folder,'draft-ready.json',180);assert draft['id']==trial['id']
   before=client.ask('project.inspect');write(folder,'before-apply.json',before);assert next(p['value'] for p in before['components'] if p['id']=='Limit')==1000 and not before['result']['stale'];assert before['electrical_revision']==baseline['electrical_revision'];independent(before)
   crop=capture['source_display_local_points'];command=[str(recorder_tool),'--capture-display']+identity+['--display',str(capture['display_id']),'--crop',','.join(str(crop[k]) for k in ('x','y','width','height')),'--output',str(folder/'capture'),'--seconds','3']
   write(folder,'armed.json',dict(command=command));start=wait(folder,'capture-start.request',30);assert start['id']==trial['id'] and re.fullmatch(r'[a-zA-Z0-9-]{16,80}',start['attempt_id']);write(folder,'accepted-handshake.json',start)
   with (folder/'recorder-stdout.txt').open('x') as stdout,(folder/'recorder-stderr.txt').open('x') as stderr:
    recorder=subprocess.Popen(command,stdout=stdout,stderr=stderr);result['recorder_pid']=recorder.pid
    admission=prepare.wait_and_admit(folder/'capture',folder/'admission.json',trial_id=trial['id'],attempt_id=start['attempt_id'],tool=tool,tool_sha256=PLAN['pinned_files'][str(tool)],profile=profile,profile_sha256=PLAN['pinned_files'][str(profile)])
    recorder.wait(timeout=15);result['recorder_exit_code']=recorder.returncode
   controller=wait(folder,'controller.finished',15);write(folder,'controller-result.json',controller)
   assert recorder.returncode==0 and admission['admitted'] and controller['input_call_completed'] and not controller['error'],(admission,controller)
   after=client.ask('simulation.wait');write(folder,'after-apply.json',after);assert next(p['value'] for p in after['components'] if p['id']=='Limit')==2000 and not after['result']['stale']
   assert after['electrical_revision']==before['electrical_revision']+1 and after['run_id']==before['run_id']+1 and after['wires']==before['wires']
   matching=helper.Client(command_preconditions=True,agent_binary=RUNTIME/'agent')
   try:
    seed(matching);matching.ask('component.set',dict(id='Limit',value='2k'),True);matched=matching.ask('simulation.wait');compare_states(after,matched);write(folder,'agent-expected.json',matched);write(folder,'independent.json',dict(native=independent(after),agent=independent(matched)))
   finally:matching.close()
   client.ask('project.save',dict(path=str(folder/'final.elab')),True);assert sha(folder/'baseline.elab')==baseline_file_sha
   result['status']='collected_pending_pixel_analysis'
  except BaseException:
   result.update(status='unavailable',reason=traceback.format_exc())
  finally:
   if recorder is not None and recorder.poll() is None:
    recorder.wait(timeout=15);result['recorder_exit_code']=recorder.returncode
   write(folder,'outcome.json',result)
  decision=dict(id=trial['id'],status='unavailable',reason=result.get('reason'))
  if result['status']=='collected_pending_pixel_analysis':
   with (folder/'analysis-output.txt').open('x') as log:
    analyzed=subprocess.run([PLAN['analysis_python'],'-B',str(STAGE/'analyze.py'),str(folder)],stdout=log,stderr=subprocess.STDOUT)
   decision['analysis_exit_code']=analyzed.returncode
   if analyzed.returncode==0:
    analysis=json.loads((folder/'analysis.json').read_text());assert analysis['measurement_status']=='available';decision.update(status='available',marker_to_committed_ms=analysis['marker_to_committed_ms'],marker_to_fresh_ms=analysis['marker_to_fresh_ms'])
   else:decision['reason']='Frozen all-frame analysis refused the complete recording; see original analysis-output.txt'
  write(folder,'decision.json',decision);outcomes.append(decision);write(folder,'done.json',dict(id=trial['id'],status=decision['status']))
  if decision['status']!='available':halt=trial['id'];break
  if trial!=PLAN['trials'][-1]:wait(folder,'next.request',180)
except BaseException:
 halt=halt or (outcomes[-1]['id'] if outcomes else 'worker-preparation')
 write(OUT,'worker-failure.json',dict(error=traceback.format_exc(),halted_at=halt))
 raise
finally:
 ledger=[]
 for trial in PLAN['trials']:
  entry=next((v for v in outcomes if v['id']==trial['id']),None);ledger.append(entry or dict(id=trial['id'],status='not_attempted',reason='Block stopped after '+str(halt)))
 write(OUT,'cohort-result.json',dict(cohort_id=PLAN['cohort_id'],scheduled=20,attempted=len(outcomes),ledger=ledger,halted_at=halt,replacements=0,raw_eligibility_flags_unchanged=True))
 client.close();(OUT/'stop.request').write_text('One declared LED block ended; no retries.\n')
print(json.dumps(dict(scheduled=20,attempted=len(outcomes),available=sum(v['status']=='available' for v in outcomes),halted_at=halt)))
