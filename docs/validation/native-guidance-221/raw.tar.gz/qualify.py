from pathlib import Path
import hashlib,importlib.util,json,math,shutil,subprocess,sys
root=Path('/Users/dshills/Development/projects/ELab'); stage=Path(__file__).resolve().parent
read=lambda n:json.loads((stage/(n+'.json')).read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=read('live-20ms'); corrected=read('live-corrected')
protected=['components','wires','transient','document','recording','operations','run_id','electrical_revision','undo_name','undo_entry']
for name in ['live-refused-light','disclosure-light-expanded','live-refused-dark','live-corrected','save-editor-after-undo-redo']:
 s=read(name)
 for key in protected: assert s.get(key)==base.get(key),(name,key)
for name in ['live-refused-light','live-refused-dark']: assert read(name)['scope'].get('a') is None
assert corrected['scope']['a']==dict(requested_s=.004,time_s=.004,valid=True)
assert read('disclosure-light-expanded')['diagnostic_presentation']['details_visible']
assert read('live-refused-dark')['diagnostic_presentation']['details_visible']
assert read('live-corrected')==read('save-editor-after-undo-redo')
checks=[]
for trace in base['scope']['traces']:
 identifier=trace['probe']['id']; assert identifier in ['v:C1.1','v:V1.positive']
 assert len(trace['points'])==21
 for point in trace['points']:
  expected=5 if identifier=='v:V1.positive' else 5*-math.expm1(-point['time_s']/.01)
  checks.append(abs(point['value']-expected)); assert math.isclose(point['value'],expected,rel_tol=1e-12,abs_tol=1e-12)
for name in ['02-cursor-refusal-light.txt','06-cursor-range-refusal-dark.txt']:
 text=(stage/name).read_text(); assert '0 s to 0.02 s' in text and 'ms and us' in text
for name in ['04-disclosure-keyboard-light.txt','08-disclosure-keyboard-dark.txt']:
 text=(stage/name).read_text(); assert 'Value: on' in text and 'focused UI element is 192 disclosure' in text
for name in ['15-after-save-tab.txt','19-after-cancel-tab.txt']:
 assert 'focused UI element is 26 button Save' in (stage/name).read_text()
assert '\t100 Examples\n\t101 Appearance' in (stage/'20-normal-reopen-menu.txt').read_text()
assert '\t100 Edit' not in (stage/'20-normal-reopen-menu.txt').read_text()
files=read('file-preservation')
for kind in ['native_saved','original']: assert sha(Path(files[kind+'_path']))==files[kind+'_sha256']
assert not Path(files['native_saved_path']).with_name('Never saved 221.elab').exists()
shutil.copyfile(files['native_saved_path'],stage/'native-saved.elab')
spec=importlib.util.spec_from_file_location('client',root/'scripts/persistence-demo.py'); h=importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
c=h.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json',command_preconditions=True,agent_binary=root/'build/ELab-0.181.20-221-candidate/elab-agent')
try:
 state=c.ask('project.inspect'); assert not state['document']['dirty'] and state['paused'] and state['transient']['sample']['time_s']==0
 assert state['components']==base['components'] and state['wires']==base['wires']
 rows=[]; offset=0
 while True:
  page=c.ask('operation.samples',{'id':state['selected_operation'],'offset':offset,'limit':200}); rows.extend(page['rows'])
  if len(rows)==page['total']:break
  offset=page['next_offset']
 prior=json.loads((root/'build/native-acceptance-220-tools/native-recording-rows.json').read_text()); assert len(rows)==1001 and rows==prior
 (stage/'reopened-recorded-rows.json').write_text(json.dumps(rows,indent=2)+'\n')
 for row in rows:
  for actual,target in zip(row['values'],[5*-math.expm1(-row['time_s']/.01),5],strict=True):
   checks.append(abs(actual-target)); assert math.isclose(actual,target,rel_tol=1e-12,abs_tol=1e-12)
 final=c.ask('project.load',{'path':files['original_path']},True)
 assert not final['document']['dirty'] and final['paused'] and final['theme']=='light'
 assert not final['diagnostic_presentation']['details_visible']
 (stage/'final-state.json').write_text(json.dumps(final,indent=2)+'\n')
finally:c.close()
assert c.process.returncode==0
prepared=read('prepared-update'); installed=Path(prepared['installed']); assert sha(installed/'Contents/MacOS/ELab Cursor Recovery')==prepared['native_sha256']
with (stage/'signature-after.txt').open('x') as log:subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict','--verbose=2',str(installed)],stdout=log,stderr=-2,check=True)
sys.path.insert(0,str(root/'scripts')); from runtime_isolation import bundle_tree
build=json.loads((root/'build/footer-layout-221-tools/build-result-signed.json').read_text()); assert bundle_tree(Path(build['review'])/'ELab.app')==build['source_bundle']
inputs=json.loads((root/'docs/validation/footer-layout-221/source-inputs.json').read_text()); assert len(inputs)==891 and all(sha(root/p)==v for p,v in inputs.items())
assert sha(root/'build/releases/ELab-0.181.4-macos-arm64.zip')=='d13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
report=dict(passed=True,new_native_checks=[1,2,4],cursor_valid_range_s=[0,.02],correction_time_s=.004,disclosure_themes=['light','dark'],disclosure_direct_pointer_and_space_verified=True,save_filename_menu_undo_redo_exact_snapshot_preserved=True,native_save_and_cancel_focus_verified=True,native_dialog_tab_moves_to_tag_editor=True,cancel_changes_only=['viewport','command_revision','revision'],native_saved_copy_reopened=True,captured_rows_exact=1001,independent_voltage_checks=len(checks),maximum_voltage_error_v=max(checks),normal_shutdown=read('normal-shutdown'),clean_native_reopen_without_temporary_edit_menu=True,final_clean_paused_light=True,original_saved_fixture_unchanged=True,source_inputs_match=891,source_bundle_unchanged=True,strict_installed_signature_valid=True,public_client_exit_code=0,save_command_a_still_unqualified=True,save_command_a_cause='not established; direct pointer focus plus 200 ms key hold also fails through CUA; native menu editing and Tab work',new_owner_permission_questions=False)
(stage/'checks.json').write_text(json.dumps(report,indent=2)+'\n'); print(json.dumps(report))
