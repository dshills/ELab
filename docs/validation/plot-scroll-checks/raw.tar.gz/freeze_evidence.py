"""Freeze native observations and narrow routing regressions; do not rebuild."""
from pathlib import Path
import gzip, hashlib, io, json, shutil, tarfile
root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
out = root/'docs/validation/plot-scroll-checks'
images = root/'research/ui-audit/plot-scroll-checks'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['routing-tests', 'staticcheck', 'vet']:
    assert (stage/(name+'-exit-code.txt')).read_text().strip() == '0'
before = json.loads((stage/'before.json').read_text())
scope = json.loads((stage/'after-scope.json').read_text())
zoomed = json.loads((stage/'after-zoom.json').read_text())
restored = json.loads((stage/'restored.json').read_text())
assert scope == before
for state in [zoomed, restored]:
    changed = {k for k in before.keys() | state.keys() if before.get(k) != state.get(k)}
    assert changed <= {'view', 'revision', 'command_revision', 'last_actor'}
assert zoomed['view']['zoom'] > before['view']['zoom']
errors = [abs(restored['view']['zoom']-before['view']['zoom'])]
errors += [abs(restored['view']['center'][k]-before['view']['center'][k]) for k in ['x', 'y']]
assert max(errors) < 1e-12
comparison = json.loads((stage/'source-comparison.json').read_text())
assert all(comparison['source_files_equal'].values())
assert all(comparison['framework_files_equal_from_elab6_to_elab11'].values())
inputs = json.loads((root/'docs/validation/slider-wheel-219/source-inputs.json').read_text())
assert len(inputs) == 889 and all(sha(root/p) == h for p, h in inputs.items())
prep = json.loads((root/'build/inspector-slider-wheel-219-tools/native-preparation.json').read_text())
for name, field in [('Pot wheel baseline.elab', 'pot_fixture_sha256'), ('RC before slider checks.elab', 'previous_file_sha256')]:
    assert sha(root/'build/inspector-slider-wheel-219-tools'/name) == prep[field]
assert not out.exists() and not images.exists()
out.mkdir(parents=True)
images.mkdir(parents=True)
for p in sorted(stage.glob('0[1-5]-*')):
    if p.suffix in {'.png', '.txt'}:
        shutil.copyfile(p, images/p.name)
assert len(list(images.glob('*.png'))) == 5
files = {p.name: p.read_bytes() for p in sorted(stage.iterdir()) if p.is_file() and p.suffix in {'.py', '.json', '.txt'}}
files['source/desktop/scope_scroll_routing_test.go'] = (root/'desktop/scope_scroll_routing_test.go').read_bytes()
for p in comparison['source_files_equal']:
    files['unchanged-source/'+p] = (root/p).read_bytes()
with (out/'raw.tar.gz').open('xb') as disk:
    with gzip.GzipFile(fileobj=disk, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(files.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
(out/'raw-manifest.json').write_text(json.dumps({p: hashlib.sha256(data).hexdigest() for p, data in sorted(files.items())}, indent=2)+'\n')
report = dict(passed=True, native_session='owned /206', native_observations=5,
              source_comparison=comparison, scope_full_public_snapshot_exact=True,
              schematic_zoom_changes_only=['view', 'revision', 'command_revision', 'last_actor'],
              schematic_zoom_before=before['view']['zoom'], schematic_zoom_after=zoomed['view']['zoom'],
              reverse_zoom_max_absolute_coordinate_error=max(errors), reverse_zoom_tolerance=1e-12,
              whole_snapshot_restored=False, circuit_physics_history_and_document_exact=True,
              fixture_files_unchanged=True, routing_test_cases=3, focused_race_seconds=1.747,
              staticcheck_passed=True, vet_passed=True, prior_qualification_inputs_unchanged=889,
              added_test_file='desktop/scope_scroll_routing_test.go', added_test_sha256=sha(root/'desktop/scope_scroll_routing_test.go'),
              product_source_changed=False, sdk_changed=False, new_candidate_built=False,
              graphical_app_launched=False, owner_review_required=False, current_candidate='/219 held',
              preserved_download='0.181.4 /205', raw_archive_sha256=sha(out/'raw.tar.gz'), raw_members=len(files),
              limitations='Five observations on the existing paused single-frame live scope and schematic, with unchanged wheel-routing sources. This does not qualify every gesture, new candidate window or accumulated native repairs.')
(out/'report.json').write_text(json.dumps(report, indent=2)+'\n')
(out/'README.md').write_text('''# Scope wheel forwarding and schematic zoom

October 24, 2026. [Receipt](report.json), [raw producers/state/logs](raw.tar.gz),
[member hashes](raw-manifest.json), [native captures](../../../research/ui-audit/plot-scroll-checks/README.md),
[notes](../../../research/98-plot-wheel-validation.md).

The existing owned /206 window scrolls the short scope dock when the wheel is
over the plot, revealing its controls. Scrolling back returns the viewport;
the complete public snapshot stays exact. Schematic wheel zoom deliberately
changes presentation only, from 44% to 99%; reverse zoom restores the view within
1e-12. Its graph, values, paused physical state, history and document stay exact.
Revision/actor metadata change, and tiny floating-point view differences remain.

The five relevant app sources and framework mesh/frame sources are identical to
the old native build. Three focused race-test cases exercise named-host routing,
temporary scroll-ability restoration and the undocked no-zoom/no-other-pane path.
They pass in 1.747 s; desktop staticcheck and vet pass. The first test fixture
mistakenly chained SetName, which returns a tree base; its compile failure is
retained separately and no product defect is inferred.

No product, SDK or package changes for this check. All 889 earlier qualification
inputs match; only a new regression file is added. No full gate or replacement
build is repeated solely for this evidence. /219 remains held for its separately
listed native repairs, and /205 stays the download. The owned paused pot and its
previously saved RC capture remain available, with both files unchanged.
''')
(images/'README.md').write_text('''# Native plot wheel checks

The existing owned /206 test window is reused; no app is launched.

1. [Before](01-before.png): short scope dock at its lower scroll position.
2. [Wheel over the scope plot](02-scope-wheel-up.png): its playback/input toolbar appears.
3. [Reverse scope scroll](03-scope-wheel-restored.png): prior dock position returns.
4. [Schematic wheel zoom](04-schematic-zoom.png): 44%→99%, with accepted physics unchanged.
5. [Reverse schematic zoom](05-schematic-restored.png): prior view within 1e-12.

The complete public snapshot is exact across the scope-wheel pair. Schematic
zoom changes only presentation and revision/actor metadata. All protected
physical, graph, history, document and scope state remains exact. The paused
single-frame plot is the observed case; no exhaustive gesture or changed-build
acceptance is claimed. [Receipt](../../../docs/validation/plot-scroll-checks/report.json).
''')
for directory in [out, images]:
    (directory/'MANIFEST.json').write_text(json.dumps({p.name: sha(p) for p in sorted(directory.iterdir()) if p.is_file()}, indent=2)+'\n')
print(json.dumps({k: report[k] for k in ['passed', 'scope_full_public_snapshot_exact', 'reverse_zoom_max_absolute_coordinate_error', 'focused_race_seconds', 'raw_members']}))
