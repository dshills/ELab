package main

import (
	"github.com/dshills/elab/workbench"
	"github.com/dshills/vellum/ui"
)

type recordedTimingContinuation struct {
	from, to    actionContext
	recordingID string
	settings    workbench.RecordingTimingParams
	next, total int
}

type recordedTimingFieldRejection struct {
	context     actionContext
	recordingID string
	probeID     string
	value, text string
	message     string
	help        *workbench.DiagnosticHelp
}

type recordedTimingPageWork struct {
	context     actionContext
	recordingID string
	direction   string
	arrival     string
	menuSerial  uint64
	settings    workbench.RecordingTimingParams
	next, total int
	field       int
	failed      bool
	feedback    *recordedTimingFieldRejection
}

// Only this recording's accepted threshold/interval field responses can
// continue a page or direction choice. Never adopt a later agent's settings.
func (s *screen) changeRecordedTimingField(state workbench.Snapshot, field, text string) {
	s.changeRecordedTimingFields(state, map[string]string{field: text})
}

func (s *screen) changeRecordedTimingFields(state workbench.Snapshot, fields map[string]string) {
	r := state.Recording
	pending := s.pendingRecordedTimingPage
	var origin *actionContext
	if s.fieldContext != nil {
		copy := *s.fieldContext
		origin = &copy
	}
	if pending != nil && (origin == nil || *origin != pending.context || r.ID != pending.recordingID) {
		pending.failed = true
		s.recordedTimingAccepted = nil
		s.errorMessage = "Threshold settings changed while the timing action was pending. Review them and try again."
		s.app.Invalidate("main")
		return
	}
	cfg := workbench.RecordingTimingParams(r.Timing.Settings)
	cfg.Offset = 0
	response := s.invokeAtCommandRevision("recording.timing.set", textFieldsParams(cfg, fields), state.CommandRevision)
	if response.Error != nil {
		s.recordedTimingAccepted = nil
		if origin != nil && response.Error.Code == "invalid-params" {
			if s.recordedTimingRejected == nil {
				s.recordedTimingRejected = make(map[string]*recordedTimingFieldRejection)
			}
			for field, text := range fields {
				s.recordedTimingRejected[field] = &recordedTimingFieldRejection{
					context: *origin, recordingID: r.ID, probeID: cfg.ProbeID,
					value: recordedTimingFieldValue(cfg, field), text: text,
					message: response.Error.Message, help: response.Help,
				}
			}
		}
		if pending != nil {
			pending.failed = true
		}
		return
	}
	for field := range fields {
		delete(s.recordedTimingRejected, field)
	}
	accepted := response.Result.(workbench.Snapshot)
	s.pruneRecordedTimingRejections(accepted)
	if origin == nil {
		return
	}
	result := accepted.Recording.Timing
	from := *origin
	if previous := s.recordedTimingAccepted; previous != nil && previous.to == from && previous.recordingID == r.ID {
		from = previous.from
	}
	s.recordedTimingAccepted = &recordedTimingContinuation{
		from: from, to: actionContext{accepted.CommandRevision, accepted.Document.Generation}, recordingID: r.ID,
		settings: workbench.RecordingTimingParams(result.Settings), next: result.NextOffset, total: result.Total,
	}
	if pending != nil {
		pending.context = s.recordedTimingAccepted.to
		pending.settings, pending.next, pending.total = s.recordedTimingAccepted.settings, result.NextOffset, result.Total
		if feedback := pending.feedback; feedback != nil {
			// Hiding this action's related refusal can resize the canvas while
			// its remaining fields settle. Keep it through our accepted response
			// and clear it only when the direction/page action finishes.
			s.requestHelp, s.errorMessage = feedback.help, feedback.message
			s.requestHelpRevision = accepted.CommandRevision
		}
	}
}

// A native popup can choose an option while the threshold still has focus.
// Settle the related drafts before dispatching the choice, using only this
// action's captured context and its own accepted field continuations.
func (s *screen) changeRecordedTimingDirection(state workbench.Snapshot, direction string) {
	previousField, previousAccepted, previousMenu := s.fieldContext, s.fieldAccepted, s.menuCommandRevision
	s.fieldContext, s.fieldAccepted, s.menuCommandRevision = nil, nil, nil
	defer func() {
		s.fieldContext, s.fieldAccepted, s.menuCommandRevision = previousField, previousAccepted, previousMenu
	}()
	s.beginRecordedTimingAction(state, "", direction)
}

func (s *screen) recordedTimingPageAction(state workbench.Snapshot, direction string) ui.Node {
	text := "Next arrivals"
	if direction == "previous" {
		text = "Previous arrivals"
	}
	return buttonStyle(ui.Node{ID: "recorded-timing-" + direction, Kind: ui.Button, Text: text, Accessibility: ui.Accessibility{Name: text}, Disabled: s.pendingRecordedTimingPage != nil, Activate: func() {
		s.beginRecordedTimingAction(state, direction, "")
	}}, false)
}

func (s *screen) beginRecordedTimingAction(state workbench.Snapshot, direction, arrival string) {
	if s.pendingRecordedTimingPage != nil {
		return
	}
	r := state.Recording
	result := r.Timing
	context := actionContext{state.CommandRevision, state.Document.Generation}
	pending := &recordedTimingPageWork{context: context, recordingID: r.ID, direction: direction, arrival: arrival, menuSerial: s.menuSerial, settings: workbench.RecordingTimingParams(result.Settings), next: result.NextOffset, total: result.Total}
	current := s.service.Snapshot()
	s.pruneRecordedTimingRejections(current)
	for _, rejected := range s.recordedTimingRejected {
		if rejected.recordingID == r.ID && rejected.context.generation == current.Document.Generation &&
			rejected.help != nil && rejected.help == s.requestHelp && rejected.help.Code == "invalid-params" && s.requestHelpRevision == current.CommandRevision {
			// Only this field's help can continue its refusal through the
			// viewport publisher's error-row layout and its own correction.
			pending.feedback = rejected
			break
		}
	}
	if accepted := s.recordedTimingAccepted; accepted != nil && accepted.recordingID == r.ID && accepted.from.generation == context.generation &&
		accepted.from.revision <= context.revision && context.revision <= accepted.to.revision && accepted.to == (actionContext{current.CommandRevision, current.Document.Generation}) {
		pending.context = accepted.to
		pending.settings, pending.next, pending.total = accepted.settings, accepted.next, accepted.total
	}
	if current.CommandRevision != pending.context.revision || current.Document.Generation != pending.context.generation {
		s.invokeAtCommandRevision("recording.timing.set", pending.settings, pending.context.revision, pending.context.generation)
		return
	}
	s.pendingRecordedTimingPage = pending
	s.settleRecordedTimingPage(pending, 0)
}

func (s *screen) settleRecordedTimingPage(pending *recordedTimingPageWork, index int) {
	if s.pendingRecordedTimingPage != pending || pending.field != index {
		return
	}
	if pending.failed || index == 4 {
		if !pending.failed {
			s.revalidateRecordedTimingFields(pending)
		}
		s.finishRecordedTimingPage(pending)
		return
	}
	fields := [...]string{"recorded-timing-level", "recorded-timing-second-level", "recorded-timing-start", "recorded-timing-end"}
	done := func(err error) {
		if s.pendingRecordedTimingPage != pending || pending.field != index {
			return
		}
		pending.field++
		if err != nil {
			pending.failed = true
			s.errorMessage = err.Error()
		}
		s.settleRecordedTimingPage(pending, index+1)
	}
	if s.settleField == nil {
		done(nil)
	} else if err := s.settleField(fields[index], done); err != nil {
		done(err)
	}
}

// A retained value can become valid after another field changes, even though
// native settlement emits no new Change for that unchanged text. Revalidate
// all owned retained entries together against this action's exact context.
func (s *screen) revalidateRecordedTimingFields(pending *recordedTimingPageWork) {
	if pending.arrival != "" && (s.menuSerial != pending.menuSerial || s.fileBusy || s.pendingCommand != "") {
		return
	}
	current := s.service.Snapshot()
	s.pruneRecordedTimingRejections(current)
	if current.CommandRevision != pending.context.revision || current.Document.Generation != pending.context.generation || current.Recording == nil || current.Recording.ID != pending.recordingID {
		return
	}
	fields := make(map[string]string)
	for field, rejected := range s.recordedTimingRejected {
		fields[field] = rejected.text
	}
	if len(fields) == 0 {
		return
	}
	previous, previousAccepted := s.fieldContext, s.fieldAccepted
	s.fieldContext, s.fieldAccepted = &pending.context, nil
	defer func() { s.fieldContext, s.fieldAccepted = previous, previousAccepted }()
	s.changeRecordedTimingFields(current, fields)
}

func (s *screen) finishRecordedTimingPage(pending *recordedTimingPageWork) {
	if s.pendingRecordedTimingPage != pending {
		return
	}
	s.pendingRecordedTimingPage = nil
	if feedback := pending.feedback; feedback != nil && s.requestHelp == feedback.help {
		s.requestHelp = nil
		if s.errorMessage == feedback.message {
			s.errorMessage = ""
		}
	}
	if pending.failed {
		s.app.Invalidate("main")
		return
	}
	if pending.arrival != "" && (s.menuSerial != pending.menuSerial || s.fileBusy || s.pendingCommand != "") {
		s.errorMessage = "The timing menu or file operation changed. Review the settings and choose again."
		s.app.Invalidate("main")
		return
	}
	current := s.service.Snapshot()
	s.pruneRecordedTimingRejections(current)
	if current.CommandRevision == pending.context.revision && current.Document.Generation == pending.context.generation {
		// Settle first so a fresh private correction can replace its refusal.
		// Another field's success must not accept an untouched invalid entry.
		for _, field := range []string{"level", "second_level", "start_s", "end_s"} {
			if rejected := s.recordedTimingRejected[field]; rejected != nil {
				s.errorMessage, s.requestHelp = rejected.message, rejected.help
				s.requestHelpRevision = current.CommandRevision
				s.app.Invalidate("main")
				return
			}
		}
		if current.Recording == nil || current.Recording.ID != pending.recordingID || !current.Recording.Viewing {
			s.errorMessage = "The selected recording changed. Review it before changing threshold timing."
			s.app.Invalidate("main")
			return
		}
		if pending.arrival == "" && pending.direction == "next" && pending.next >= pending.total {
			s.errorMessage = "There are no more arrivals with these threshold settings."
			s.app.Invalidate("main")
			return
		}
	}
	if pending.arrival != "" {
		pending.settings.Direction = pending.arrival
		pending.settings.Offset = 0
	} else if pending.direction == "previous" {
		pending.settings.Offset = max(0, pending.settings.Offset-pending.settings.Limit)
	} else {
		pending.settings.Offset = pending.next
	}
	s.invokeAtCommandRevision("recording.timing.set", pending.settings, pending.context.revision, pending.context.generation)
}

func recordedTimingFieldValue(cfg workbench.RecordingTimingParams, field string) string {
	switch field {
	case "level":
		return cfg.Level
	case "second_level":
		return cfg.SecondLevel
	case "start_s":
		return timeText(cfg.Start)
	default:
		return timeText(cfg.End)
	}
}

func (s *screen) recordedTimingEntryText(cfg workbench.RecordingTimingParams, field string) string {
	if rejected := s.recordedTimingRejected[field]; rejected != nil {
		return rejected.text
	}
	return recordedTimingFieldValue(cfg, field)
}

func (s *screen) pruneRecordedTimingRejections(state workbench.Snapshot) {
	r := state.Recording
	for field, rejected := range s.recordedTimingRejected {
		if r == nil || !r.Viewing || r.Timing == nil || state.Document.Generation != rejected.context.generation || r.ID != rejected.recordingID || r.Timing.Settings.ProbeID != rejected.probeID || recordedTimingFieldValue(workbench.RecordingTimingParams(r.Timing.Settings), field) != rejected.value {
			delete(s.recordedTimingRejected, field)
		}
	}
}
