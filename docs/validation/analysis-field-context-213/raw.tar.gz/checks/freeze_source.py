"""Freeze the field-ownership failure and complete source check."""
import gzip, hashlib, io, json, re, shutil, subprocess, tarfile
from pathlib import Path

root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
out = root/'docs/validation/analysis-field-context-213'
sha = lambda b: hashlib.sha256(b).hexdigest()
assert (stage/'quality-exit-code.txt').read_text().strip() == '0' and not out.exists()
inputs = json.loads((stage/'source-inputs.json').read_text())
assert len(inputs) == 880 and all(sha((root/p).read_bytes()) == h for p,h in inputs.items())
assert not (root/'go.sum').exists()
quality = (stage/'quality.txt').read_text()
times = re.findall(r'ok\s+github.com/dshills/elab/desktop\s+(\d+\.\d+)s', quality)
assert len(times) == 2, times
baseline = (stage/'desktop-baseline-visible.txt').read_text()
assert baseline.count('old parser failure installed a refusal in the newer form oops') == 5
assert 'ok ' in (stage/'desktop-final.txt').read_text()
previous = root/'docs/validation/statistics-coverage-212'
lock = json.loads((root/'third_party/vellum/sdk.lock.json').read_text())
assert lock == json.loads((previous/'report.json').read_text())['sdk_unchanged']
assert sha((root/lock['archive']).read_bytes()) == lock['sha256']
download = root/'build/releases/ELab-0.181.4-macos-arm64.zip'
assert sha(download.read_bytes()) == 'd13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
base = subprocess.check_output(['git','rev-parse','HEAD'], cwd=root, text=True).strip()
old = json.loads((previous/'source-inputs.json').read_text())
changed = [p for p,h in inputs.items() if old.get(p) != h]
assert not any(p.startswith('workbench/') for p in changed)
files = {'checks/'+p.name:p.read_bytes() for p in sorted(stage.iterdir()) if p.is_file() and p.suffix in {'.py','.json','.txt'}}
absent = []
for name in changed:
    files['source/'+name] = (root/name).read_bytes()
    if name in old:
        files['source-before/'+name] = subprocess.check_output(['git','show',base+':'+name], cwd=root)
    else:
        absent.append(name)
files['source-before/absent.json'] = (json.dumps(absent,indent=2)+'\n').encode()
out.mkdir(parents=True)
shutil.copyfile(stage/'source-inputs.json',out/'source-inputs.json')
with (out/'raw.tar.gz').open('xb') as disk:
    with gzip.GzipFile(fileobj=disk,mode='wb',filename='',mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for name,data in sorted(files.items()):
                info = tarfile.TarInfo(name)
                info.size,info.mode,info.mtime = len(data),0o644,0
                tar.addfile(info,io.BytesIO(data))
(out/'raw-manifest.json').write_text(json.dumps({p:sha(b) for p,b in sorted(files.items())},indent=2)+'\n')
report = dict(kind='analysis-field-request-context',source_checks_passed=True,quality_exit_code=0,
              source_parent_commit=base,source_inputs=len(inputs),changed_source_inputs=changed,
              absent_source_inputs=['go.sum'],desktop_race_seconds=float(times[0]),mounted_race_seconds=float(times[1]),
              python_tests=67,focused_race_seconds=12.048,visible_baseline_failed_fields=5,
              stale_field_cases=9,current_refusal_correction_cases=9,backend_source_unchanged=True,
              inventory_comparison=json.loads((stage/'inventory-comparison.json').read_text()),sdk_unchanged=lock,
              preserved_download_sha256=sha(download.read_bytes()),native_app_launched=False,
              native_acceptance_passed=False,release_ready=False,published=False,owner_review_required=False,
              new_commands=0,new_components=0,new_formats=0,download_unchanged='0.181.4 /205',
              raw_archive_sha256=sha((out/'raw.tar.gz').read_bytes()),raw_members=len(files))
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'README.md').write_text(f'''# Analysis field context /213

October 23, 2026. [Receipt](report.json), [source inputs](source-inputs.json),
[repair notes](../../../research/90-analysis-field-context.md).

The three prior production form handlers, loaded through a Go build overlay, install
old malformed text into five fields after an agent advances the editor. The
baseline preserves accepted service state but renders `oops` in the newer form.
A shared command-revision/document check now protects refusal retention in
verification, sweep and threshold controls. Stale local count parsing reports
changed settings. Already owned refusals remain correctable after unrelated work.

All nine stale-field and nine current-refusal correction cases pass, preserving
the agent's draft, physics, document and history. Focused race tests, including
existing form settlement/continuation checks, pass in 12.048 s. The full gate
passes lint/staticcheck, 67 Python tests, root/desktop race and vet, mounted race
and offscreen vet. Desktop race takes {times[0]} s; mounted race {times[1]} s.
All {len(inputs)} captured source/check inputs match. Backend source, SDK, all
semantic command sites, commands, aliases and route sets remain unchanged.

[Raw evidence and producers](raw.tar.gz), with [member hashes](raw-manifest.json),
retain the original and refined failures, overlay/source bytes and final logs.
This is production-callback/source evidence, not fresh native event-queue
acceptance. No graphical launch or promotion is performed and no permission
request is queued. The running owned native session and /205 remain preserved.
''')
notes = root/'research/90-analysis-field-context.md'
text = notes.read_text().replace('The full quality gate is running.',f'The [full quality gate passes](../docs/validation/analysis-field-context-213/README.md):\nlint/staticcheck, 67 Python tests, root/desktop race and vet, mounted race and\noffscreen vet. Desktop race takes {times[0]} s; mounted race {times[1]} s. All\n{len(inputs)} source/check inputs remain exact.')
notes.write_text(text)
manifest = {p.relative_to(out).as_posix():sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file()}
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['source_checks_passed','source_inputs','desktop_race_seconds','mounted_race_seconds','raw_members']}))
