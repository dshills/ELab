from pathlib import Path
import hashlib,json,os,subprocess,time

os.umask(0o077)
root=Path('/Users/dshills/Development/projects/ELab')
out=Path('/private/tmp/elab-display-causal-input-173')
tool=root/'build/display-frame-probe-tools/display-frame-probe'
digest='a8cec4e8f9d16b2b5ad6b751f5657b537c5ed6ea956e7695403168b445bb923f'
assert hashlib.sha256(tool.read_bytes()).hexdigest()==digest
session=json.loads((out/'report.json').read_text())
inspect=json.loads((out/'inspect-stdout.json').read_text());plan=inspect['capture_plan']
assert session['status']=='ready_for_controller_binding'
assert inspect['pid']==session['owned_pid'] and inspect['window_id']==session['target_windows'][0]['window_id']
assert plan['point_pixel_scale']==1 and plan['width_pixels']==1053 and plan['height_pixels']==802
assert not (out/'capture').exists()
arguments=[str(tool),'--capture-display','--pid',str(inspect['pid']),'--window',str(inspect['window_id']),
    '--executable',session['registration']['executable_path'],'--sha256',session['native_sha256'],
    '--display',str(plan['display_id']),'--crop',','.join(str(plan['source_display_local_points'][k]) for k in ['x','y','width','height']),
    '--output',str(out/'capture'),'--seconds','3']
def write(name,value):
    with (out/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
write('recorder-armed.json',dict(command=arguments,recorder_sha256=digest,waiting_for_cua=True))
deadline=time.monotonic()+60
while not (out/'capture-start.request').exists():
    assert time.monotonic()<deadline,'CUA start-signal wait expired'
    time.sleep(.002)
start=time.monotonic()
with (out/'recorder-stdout.txt').open('x') as stdout,(out/'recorder-stderr.txt').open('x') as stderr:
    child=subprocess.Popen(arguments,stdout=stdout,stderr=stderr)
    write('recorder-started.json',dict(pid=child.pid,command=arguments,recorder_sha256=digest))
    child.wait(timeout=15)
write('recorder-finished.json',dict(pid=child.pid,exit_code=child.returncode,elapsed_s=time.monotonic()-start,
    recorder_sha256=digest,eligible_latency_observations=0,latency_gate_passed=None))
raise SystemExit(child.returncode)
