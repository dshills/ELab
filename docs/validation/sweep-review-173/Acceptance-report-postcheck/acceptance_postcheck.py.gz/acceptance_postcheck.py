"""Finish metadata checks after the successful acceptance child's wrapper path error.

No app/agent is started, no UI is read and no elapsed run duration is inferred.
"""
from pathlib import Path
import hashlib
import json
import shutil

root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
p=Path('/private/tmp/elab-first-version-173-signed-acceptance-qualified/report.json')
shutil.copyfile(p,stage/'child-report-before-postcheck.json')
report=json.loads(p.read_text());runtime=json.loads(Path('/private/tmp/elab-first-version-173-signed-runtime/runtime-report.json').read_text())
for key in ['sweep_capture_commands','discovery_commands','component_startup_commands','coil_startup_reset_commands','verification_handoff_commands','preset_value_commands','reference_parity','live_grid']:
 if key not in ['live_grid']:assert report[key]['passed'],key
assert report['passed'] and report['native_host_closed_normally']
assert report['sweep_capture_commands']['exact_retained_capture_document_transition']
shared=Path.home()/'Library/Cogent Core'
geometry={p.relative_to(shared).as_posix():dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),mode=oct(p.stat().st_mode&0o777)) for p in shared.rglob('*') if p.is_file()}
assert geometry==runtime['shared_geometry_before']==runtime['shared_geometry_after']
post=dict(passed=True,acceptance_child_passed=True,child_native_closed_normally=True,shared_geometry_matches_proven_baseline=True,app_or_agent_started=False,ui_operated=False,acceptance_elapsed_s=None,elapsed_unavailable_reason='Successful child completed; wrapper subsequently read the obsolete first-attempt report path. Its after-geometry assertion preceded that failing read; this fresh read-only comparison also matches the runtime baseline.',report_path=str(p))
report.update(shared_geometry_unchanged=True,elapsed_s=None,metadata_postcheck=post)
p.write_text(json.dumps(report,indent=2)+'\n')
(stage/'acceptance-postcheck.json').write_text(json.dumps(post,indent=2)+'\n');print(json.dumps(post))
