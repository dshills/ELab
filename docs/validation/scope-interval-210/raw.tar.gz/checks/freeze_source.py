"""Freeze the reviewed interval repair and its bounded evidence after the gate."""
import gzip
import hashlib
import io
import json
import re
import shutil
import subprocess
import tarfile
from pathlib import Path

root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
out=root/'docs/validation/scope-interval-210'
assert (stage/'quality-exit-code.txt').read_text().strip()=='0'
assert not out.exists()
sha=lambda data:hashlib.sha256(data).hexdigest()
inputs=json.loads((stage/'source-inputs.json').read_text())
assert all(sha((root/name).read_bytes())==digest for name,digest in inputs.items())
assert not (root/'go.sum').exists()
assert '--- FAIL' in (stage/'mounted-before.txt').read_text()
assert '--- FAIL' in (stage/'guidance-before.txt').read_text()
assert 'expected command revision' in (stage/'reset-private-entry.txt').read_text()
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
lock=json.loads((root/'third_party/vellum/sdk.lock.json').read_text())
assert lock==json.loads((root/'docs/validation/window-background-209/report.json').read_text())['sdk']
assert sha((root/lock['archive']).read_bytes())==lock['sha256']
zip_sha=sha((root/'build/releases/ELab-0.181.4-macos-arm64.zip').read_bytes())
assert zip_sha=='d13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
quality=(stage/'quality.txt').read_text()
times=re.findall(r'ok\s+github.com/dshills/elab/desktop\s+(\d+\.\d+)s',quality)
assert len(times)==2,times
out.mkdir(parents=True)
shutil.copyfile(stage/'source-inputs.json',out/'source-inputs.json')
files={}
for p in sorted(stage.rglob('*')):
 if p.is_file() and 'build' not in p.relative_to(stage).parts and p.suffix in {'.py','.txt','.json'}:
  files['checks/'+p.relative_to(stage).as_posix()]=p.read_bytes()
before=json.loads((root/'docs/validation/window-background-209/source-inputs.json').read_text())
changed=[name for name,digest in inputs.items() if before.get(name)!=digest]
absent=[]
for name in changed:
 files['source/'+name]=(root/name).read_bytes()
 if name not in before:
  absent.append(name)
 else:
  files['source-before/'+name]=subprocess.check_output(['git','show',base+':'+name],cwd=root)
files['source-before/absent.json']=(json.dumps(absent,indent=2)+'\n').encode()
with (out/'raw.tar.gz').open('xb') as disk:
 with gzip.GzipFile(fileobj=disk,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name,data in sorted(files.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
    tar.addfile(info,io.BytesIO(data))
(out/'raw-manifest.json').write_text(json.dumps({name:sha(data) for name,data in sorted(files.items())},indent=2)+'\n')
report=dict(kind='live-and-recorded-interval-correction',source_checks_passed=True,quality_exit_code=0,
 source_parent_commit=base,source_inputs=len(inputs),absent_source_inputs=['go.sum'],python_tests=67,
 source_quality_command="GOFLAGS='-p=1' GOPROXY=off GOTOOLCHAIN=local PYTHONDONTWRITEBYTECODE=1 ./scripts/check.sh",
 desktop_race_seconds=float(times[0]),mounted_race_seconds=float(times[1]),
 focused_mounted_race_seconds=16.008,changed_source_inputs=changed,
 inventory_comparison=json.loads((stage/'inventory-comparison.json').read_text()),
 native_baseline=json.loads((stage/'native-baseline-report.json').read_text()),
 sdk_unchanged=lock,preserved_download_sha256=zip_sha,
 native_acceptance_passed=False,release_ready=False,published=False,owner_review_required=False,
 new_commands=0,new_components=0,new_formats=0,download_unchanged='0.181.4 /205',
 raw_archive_sha256=sha((out/'raw.tar.gz').read_bytes()),raw_members=len(files))
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'README.md').write_text(f'''# Scope interval correction /210

October 23, 2026. [Receipt](report.json), [source/check inputs](source-inputs.json),
[repair notes](../../../research/87-scope-interval-correction.md),
[old native baseline](../../../research/ui-audit/scope-interval-210/README.md).

All four interval fields originally discard rejected text. The independently
running old /206 fixture reproduces the live end case through actual CUA input.
It is restored afterward: complete before/after snapshots differ only in the
presentation and command revision counters. No new graphical launch is used.

The repair retains private rejected text with its accepted window and owner,
allows correction back to the accepted value, preserves an unchanged rejected
peer, and makes explicit reset actions clear private interval entries. A valid
blur commit initially makes Reset conflict with its own revision; the narrow
own-field continuation repairs that first-click failure without crossing an
agent edit. Shared command guidance explains actual bounds, order and units;
malformed/stale requests do not borrow unrelated history or captures.

Focused tests cover both endpoints, live/recorded source ownership, sampling,
restart/capture replacement, stale parser callbacks, first-click resets, held
agent interleavings, retained callbacks and unchanged full physics/document/
history state. Corrections match an independent public service's scope. Shared
domain tests retain legacy boundary normalization and DC-point behavior.

The complete source gate passes: lint/staticcheck, 67 Python tests, full root
and desktop race/vet, mounted UI race and offscreen vet. Desktop race takes
{times[0]} s; mounted race takes {times[1]} s. The final focused mounted race
run takes 16.008 s. Static inventory retains all 166 public commands, aliases
and 134 route IDs, with 404 sites and 77 production native sources. This does
not establish complete dynamic binding or accessibility acceptance.

[Raw records](raw.tar.gz) and [member hashes](raw-manifest.json) include original
failures, before/current source snapshots, corrections to test producers,
focused/full checks, native snapshots and packaging producers. Two formatting
commands failed in the wrong directory before tests ran. The initial held
fixture assumed blur precedes mouse release; the corrected physical test avoids
that assumption and a separate callback test proves the accepted-continuation
case. These fixture mistakes are separate from the reproduced product defects.

All {len(inputs)} captured source/check inputs match. No SDK bytes, model,
command set, file format or current download changes. The /205 ZIP still hashes
to `{zip_sha}`. Prior candidates are preserved.

Fresh changed-binary native interval/correction/reset acceptance and the
accumulated /207–/209 native checks remain pending. Offscreen evidence and old
native baseline cannot qualify those paths. No new owner permission or review
is requested and no unattended launch prompt is queued.
''')
notes=root/'research/87-scope-interval-correction.md';text=notes.read_text()
marker='The full source quality process is running as exec session 60952'
assert marker in text
notes.write_text(text.partition(marker)[0]+f'''The [complete source gate passes](../docs/validation/scope-interval-210/README.md):
lint/staticcheck, 67 Python tests, full root/desktop race and vet, mounted UI race
and offscreen vet. Desktop race takes {times[0]} s; mounted race {times[1]} s.
All {len(inputs)} captured source/check inputs remain exact. The SDK and /205 ZIP
are unchanged. The raw receipt preserves original failures, focused passes,
native before/after snapshots and the corrected fixture assumptions separately.

Fresh native acceptance of the changed interval behavior and the accumulated
/207–/209 changes remains separate. Preserve /205 until those paths pass; no
new owner approval or unattended launch prompt is requested. The current owned
old-code fixture remains paused and restored for applicable subsequent checks.
''')
manifest={p.relative_to(out).as_posix():sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file()}
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['source_checks_passed','source_inputs','desktop_race_seconds','mounted_race_seconds','raw_members']}))
