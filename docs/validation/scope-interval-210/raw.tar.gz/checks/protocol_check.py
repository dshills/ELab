"""Exercise interval refusals/corrections through the matching packaged agent."""
import hashlib
import importlib.util
import json
import math
import time
from pathlib import Path

root=Path('/Users/dshills/Development/projects/ELab')
stage=Path(__file__).resolve().parent
build=json.loads((stage/'build-result-signed.json').read_text())
binary=Path(build['review'])/'elab-agent'
assert hashlib.sha256(binary.read_bytes()).hexdigest()==build['agent_sha256']
spec=importlib.util.spec_from_file_location('client',root/'scripts/persistence-demo.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
c=helper.Client(command_preconditions=True,agent_binary=binary)
report=dict(source_commit=build['source_commit'],agent_sha256=build['agent_sha256'],
 transport='headless-stdio',checks=[],scalar_readings_checked=0,max_voltage_error_v=0.,max_current_error_a=0.)

def raw(command,params,revision=None):
 c.sequence+=1
 req=dict(version=1,id=f'interval-{c.sequence}',key=f'interval-{c.sequence}',command=command,params=params,
          expected_command_revision=c.command_revision if revision is None else revision)
 c.process.stdin.write(json.dumps(req)+'\n');c.process.stdin.flush()
 line=c.process.stdout.readline();assert line,'agent ended during interval request'
 return json.loads(line)

def unchanged(before):
 assert before==c.ask('project.inspect'),'refusal changed accepted state'

def protected(before,after,recorded):
 allowed={'recording' if recorded else 'scope','revision','command_revision','last_actor'}
 changed={k for k in before.keys()|after.keys() if before.get(k)!=after.get(k)}
 assert changed<=allowed,changed

def expected(identifier,at):
 if identifier in {'v:C1.1','v:C1'}:return 5*(1-math.exp(-at/.01)),'V'
 if identifier=='v:V1.positive':return 5.,'V'
 assert identifier=='i:C1',identifier
 return .0005*math.exp(-at/.01),'A'

def check_rows(scope):
 assert len(scope['traces'])==2
 stats={s['probe_id']:s for s in scope['statistics']}
 for trace in scope['traces']:
  identifier=trace['probe']['id'];points=trace['points']
  assert len(points)==13 and stats[identifier]['count']==13
  for i,p in enumerate(points):
   at=(i+4)/1000
   assert math.isclose(p['time_s'],at,rel_tol=0,abs_tol=2e-14)
   value,unit=expected(identifier,at);assert trace['probe']['unit']==unit
   error=abs(value-p['value']);key='max_voltage_error_v' if unit=='V' else 'max_current_error_a'
   report[key]=max(report[key],error)
   assert error<(1e-10 if unit=='V' else 1e-14),(identifier,at,error)
   report['scalar_readings_checked']+=1
  ends=[expected(identifier,at)[0] for at in (.004,.016)]
  assert math.isclose(stats[identifier]['min'],min(ends),rel_tol=0,abs_tol=1e-10)
  assert math.isclose(stats[identifier]['max'],max(ends),rel_tol=0,abs_tol=1e-10)

try:
 c.ask('example.rc',{'discard_changes':True},True)
 c.ask('simulation.pause',{},True);c.ask('simulation.restart',{},True)
 c.ask('simulation.step',{'duration_s':.02},True)
 parts={p['id']:p for p in c.ask('project.inspect')['components']}
 assert parts['V1']['value']==5 and parts['R1']['value']==10000 and parts['C1']['value']==1e-6
 for recorded in (False,True):
  if recorded:
   admitted=c.ask('simulation.verify',{'duration_s':.02,'probe_ids':['v:C1','i:C1']},True)
   identifier=admitted['last_operation'];deadline=time.monotonic()+5
   while True:
    work=c.ask('operation.inspect',{'id':identifier})
    if work['operation']['status']=='completed':break
    assert work['operation']['status'] not in {'failed','canceled'} and time.monotonic()<deadline,work
    time.sleep(.01)
   c.ask('recording.view.set',{'mode':'recorded'},True)
  command='recording.window.set' if recorded else 'scope.window.set'
  def params(start,end):
   p=dict(start_s=start,end_s=end)
   if not recorded:p['mode']='fixed'
   return p
  for start,end in [('oops','20 ms'),('0 s','10 Hz'),('-1 ms','20 ms'),(0,.03),('15 ms','10 ms'),('10 ms','10 ms')]:
   before=c.ask('project.inspect');response=raw(command,params(start,end))
   assert response['error']['code']=='invalid-params',response
   h=response['help']
   assert 'interval' in h['summary'] and '0 s to 0.02 s' in h['action'] and 'start before end' in h['action'] and 'ms' in h['action']
   assert h['details']==response['error']['message'];unchanged(before)
  before=c.ask('project.inspect')
  valid=c.ask(command,params('4 ms','16 ms'),True);protected(before,valid,recorded)
  check_rows(valid['recording']['scope'] if recorded else valid['scope'])
  revision=valid['command_revision']
  c.ask(command,params('2 ms','18 ms'),True);current=c.ask('project.inspect')
  response=raw(command,params('oops','20 ms'),revision)
  assert response['error']['code']=='invalid-params' and response['help']['summary']=='That request could not be applied.'
  unchanged(current)
  response=raw(command,params(0,.03),revision)
  assert response['error']['code']=='conflict' and response.get('help') is None;unchanged(current)
  malformed=params('oops','20 ms');malformed['extra']=True
  response=raw(command,malformed)
  assert response['error']['code']=='invalid-params' and response['help']['summary']=='That request could not be applied.'
  unchanged(current)
  report['checks'].append(dict(mode='recorded' if recorded else 'live',refusals=6,
      units_range_order_guidance=True,original_error_and_state_preserved=True,corrected_interval_samples=13,
      stale_and_malformed_context_not_borrowed=True,independent_reference='5 V, 10 kohm, 1 uF: Vc=5*(1-exp(-t/0.01)); Ic=0.0005*exp(-t/0.01)'))
 job=c.ask('app.close',{'discard_changes':True},True)['shutdown']
 job=c.wait_for_shutdown_outcome(job)
 assert job['status']=='completed' and job['workers_joined'] and job['exit_ready'],job
 report.update(passed=True,shutdown=job)
finally:
 c.close()
assert c.process.returncode==0,c.process.returncode
report['agent_exit_code']=c.process.returncode
(stage/'protocol-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['passed','scalar_readings_checked','max_voltage_error_v','max_current_error_a','agent_exit_code']}))
