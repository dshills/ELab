"""Qualify exact packaged public captures against independently computed rows."""
from pathlib import Path
import hashlib,importlib.util,json,time
from reference import MODEL,BODY,at
r=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent
pin=json.loads((s/'packaged-source.json').read_text());binary=Path(pin['binary']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==pin['agent_sha256']
spec=importlib.util.spec_from_file_location('client',r/'scripts/persistence-demo.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
probes=['v:CG','v:M1.gate-source','v:M1','i:M1.drain','v:M1.source','i:CG'];results=[]
for case in json.loads((s/'fixtures.json').read_text()):
 path=s/case['file'];assert hashlib.sha256(path.read_bytes()).hexdigest()==case['sha256']
 folder=s/path.stem;assert not folder.exists();folder.mkdir();c=helper.Client(command_preconditions=True,agent_binary=binary)
 report=dict(case,passed=False,scalar_checks=0,max_errors=[0.]*6)
 try:
  loaded=c.ask('project.load',{'path':str(path)},True);loaded=c.ask('simulation.wait')
  (folder/'loaded.json').write_text(json.dumps(loaded,indent=2)+'\n')
  assert loaded['paused'] and not loaded['diagnostics'] and not loaded['mixed']['stale']
  component=loaded['mixed']['mosfets'][0];assert component['id']=='M1'
  for key,value in MODEL.items():assert component['model'][key]==value
  for key,value in BODY.items():assert component['model']['body_diode'][key]==value
  assert len([p for p in loaded['components'] if p['id'].startswith('RG')])==case['gate_resistors']
  assert sum(p['value'] for p in loaded['components'] if p['id'].startswith('RG'))==1000
  started=time.monotonic();op=c.ask('simulation.verify',{'duration_s':.01,'sample_step_s':.00025,'probe_ids':probes},True)['last_operation'];deadline=started+15
  while True:
   operation=c.ask('operation.inspect',{'id':op});status=operation['operation']['status']
   if status in ['completed','failed','canceled']:break
   assert time.monotonic()<deadline,operation;time.sleep(.005)
  report['verify_seconds']=time.monotonic()-started;(folder/'operation.json').write_text(json.dumps(operation,indent=2)+'\n')
  assert status=='completed',operation['operation']
  page=c.ask('operation.samples',{'id':op,'offset':0,'limit':100})
  (folder/'rows.json').write_text(json.dumps(page,indent=2)+'\n');assert len(page['rows'])==41
  assert [p['id'] for p in operation['metadata']['probes']]==probes
  assert operation['metadata']['graph']==dict(components=loaded['components'],wires=loaded['wires'])
  for row in page['rows']:
   expected=at(row['time_s'],case['reference_v'],case['reverse'],case['initial_vgs_v'])
   for i,(actual,want) in enumerate(zip(row['values'],expected)):
    tolerance=max(1e-8,.005*abs(want)) if i in [3,5] else max(.001,.01*abs(want))
    error=abs(actual-want);report['max_errors'][i]=max(report['max_errors'][i],error)
    assert error<=tolerance,dict(time_s=row['time_s'],probe=probes[i],actual=actual,expected=want,error=error,tolerance=tolerance)
    report['scalar_checks']+=1
  after=c.ask('project.inspect');(folder/'after.json').write_text(json.dumps(after,indent=2)+'\n')
  protected=['components','wires','nets','circuit','view','drawing','analysis','paused','run_id','electrical_revision','transient_settings','transient','mixed','status','model','scope']
  assert all(loaded.get(k)==after.get(k) for k in protected),[k for k in protected if loaded.get(k)!=after.get(k)]
  changes=[k for k in loaded if loaded[k]!=after.get(k)]
  assert set(changes)<={'revision','command_revision','operations','last_operation','selected_operation','verification','recording','document'},changes
  assert after['document']['recording_count']==1 and after['document']['recordings_dirty'] and not after['document']['schematic_dirty']
  report['changed_snapshot_keys']=changes;report['live_physical_state_exact']=True
  report.update(passed=True,rows=41,simulated_parts=loaded['simulated_component_count'],nodes=len(loaded['nets']))
 except Exception as exc:
  report['error']=str(exc)[:2500]
 finally:
  try:
   job=c.ask('app.close',{'discard_changes':True},True)['shutdown'];job=c.wait_for_shutdown_outcome(job);assert job['workers_joined'] and job['exit_ready'];report['shutdown']=job
  finally:c.close()
  report['exit_code']=c.process.returncode
 (folder/'report.json').write_text(json.dumps(report,indent=2)+'\n');results.append(report)
 print(case['file'],report['passed'],report.get('error',''),flush=True)
 assert hashlib.sha256(path.read_bytes()).hexdigest()==case['sha256']
summary=dict(source=pin,cases=results,all_passed=all(v['passed'] and v['exit_code']==0 for v in results),scalar_checks=sum(v['scalar_checks'] for v in results))
(s/'qualification.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Qualified:',summary['all_passed'],'scalars:',summary['scalar_checks'])
