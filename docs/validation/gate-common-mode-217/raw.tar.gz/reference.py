"""Independent analytic gate RC plus a scalar educational MOSFET load line.

Imports no ELab code. The gate has zero leakage and C=1 uF, R=1 kohm.
The body-junction equation is solved with Newton in junction voltage; the
load line uses interval bisection, independently of ELab's coupled MNA/Newton.
These are the pinned educational equations, not measurements or SPICE results.
"""
import math

MODEL=dict(threshold_v=1.5,beta_a_per_v2=.1,lambda_per_v=.02)
BODY=dict(is_a=1e-9,n=1.7,rs_ohm=1.,temperature_c=27.)
THERMAL=BODY['n']*1.380649e-23*(273.15+BODY['temperature_c'])/1.602176634e-19

def body_current(voltage):
 junction=voltage
 for _ in range(12):
  e=math.exp(junction/THERMAL);current=BODY['is_a']*(e-1)
  correction=(junction+BODY['rs_ohm']*current-voltage)/(1+BODY['rs_ohm']*BODY['is_a']*e/THERMAL)
  junction-=correction
  if abs(correction)<1e-15:break
 return BODY['is_a']*math.expm1(junction/THERMAL)

def drain_current(vgs,vds):
 over=vgs-MODEL['threshold_v'];channel=0.
 if over>0:
  channel=MODEL['beta_a_per_v2']*((over*vds-.5*vds*vds) if vds<over else .5*over*over)*(1+MODEL['lambda_per_v']*vds)
 return channel-body_current(-vds)

def at(time,shift,reverse,initial=1.25):
 vgs=5-(5-initial)*math.exp(-time/.001)
 lo,hi=0.,5.
 for _ in range(80):
  vds=(lo+hi)/2
  if (5-vds)/1000>drain_current(vgs,vds):lo=vds
  else:hi=vds
 vds=(lo+hi)/2;sign=-1 if reverse else 1
 return [sign*vgs,vgs,vds,drain_current(vgs,vds),float(shift),sign*(5-vgs)/1000]
