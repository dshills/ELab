"""Observe public Save/Undo/Pause/cancel during ordinary full-size verification."""
from pathlib import Path
import hashlib,importlib.util,json,time
r=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent;pin=json.loads((s/'packaged-source.json').read_text());binary=Path(pin['binary'])
assert hashlib.sha256(binary.read_bytes()).hexdigest()==pin['agent_sha256']
spec=importlib.util.spec_from_file_location('client',r/'scripts/persistence-demo.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
c=helper.Client(command_preconditions=True,agent_binary=binary)
report=dict(source=pin,passed=False,commands=[],observations=[],injected_kernel_block=False)
try:
 c.ask('project.load',{'path':str(s/'gate-large.elab')},True);c.ask('simulation.wait')
 before=c.ask('project.inspect');(s/'load-before.json').write_text(json.dumps(before,indent=2)+'\n');part=next(p for p in before['components'] if p['id']=='RG1');original=part['position']
 moved=c.ask('component.move',{'id':'RG1','position':{'x':original['x']+10,'y':original['y']}},True);entry=moved['undo_entry']['command_revision']
 op=c.ask('simulation.verify',{'duration_s':.25,'sample_step_s':.00025,'probe_ids':['v:CG','v:M1.gate-source','v:M1','i:M1.drain']},True)['last_operation']
 deadline=time.monotonic()+5
 while True:
  state=c.ask('operation.inspect',{'id':op});report['observations'].append(state['operation'])
  if state['operation']['status']=='running':break
  assert state['operation']['status'] not in ['completed','failed','canceled'] and time.monotonic()<deadline,state
  time.sleep(.001)
 saved=s/'During active verification.elab';assert not saved.exists()
 for command,params in [('view.pan',{'dx':20,'dy':10}),('project.save',{'path':str(saved)}),('edit.undo',{'expected_entry_revision':entry}),('simulation.pause',{})]:
  observed=c.ask('operation.inspect',{'id':op})['operation'];start=time.monotonic();result=c.ask(command,params,True);elapsed=time.monotonic()-start
  after=c.ask('operation.inspect',{'id':op})['operation']
  report['commands'].append(dict(command=command,seconds=elapsed,before=observed,after=after));report['observations'].append(after)
 start=time.monotonic();c.ask('operation.cancel',{'id':op},True);report['cancel_request_seconds']=time.monotonic()-start
 deadline=time.monotonic()+5
 while True:
  terminal=c.ask('operation.inspect',{'id':op});status=terminal['operation']['status']
  if status in ['completed','canceled','failed']:break
  assert time.monotonic()<deadline;time.sleep(.001)
 report['terminal']=terminal;assert status=='canceled' and terminal['metadata']['sample_count']==0 and terminal['metadata']['statistics']==[]
 assert not any(k in terminal['metadata'] for k in ['mixed','npn','led'])
 c.ask('operation.samples',{'id':op,'offset':0,'limit':1},expect='not-ready')
 final=c.ask('project.inspect');(s/'load-final.json').write_text(json.dumps(final,indent=2)+'\n')
 for key in ['mixed','transient','transient_settings','run_id','electrical_revision','wires','nets','scope']:
  assert before[key]==final[key],key
 assert before['components']==final['components'] and final['paused']
 assert final['document']['recording_count']==0 and not final['document']['recordings_dirty']
 assert all(p['before']['status']=='running' and p['after']['status']=='running' for p in report['commands'])
 report.update(passed=True,no_partial_samples=True,physical_state_exact=True,active_during_all_commands=True,saved_sha256=hashlib.sha256(saved.read_bytes()).hexdigest())
except Exception as exc:report['error']=repr(exc)[:2500]
finally:
 try:
  job=c.ask('app.close',{'discard_changes':True},True)['shutdown'];job=c.wait_for_shutdown_outcome(job);assert job['workers_joined'] and job['exit_ready'];report['shutdown']=job
 finally:c.close()
 report['exit_code']=c.process.returncode
(s/'load-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report.get(k) for k in ['passed','error','cancel_request_seconds','exit_code']}))
