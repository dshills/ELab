"""Reopen the file actually saved while Verify was publicly running."""
from pathlib import Path
import hashlib, importlib.util, json

root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
pin = json.loads((stage/'packaged-source.json').read_text())
binary = Path(pin['binary'])
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(binary) == pin['agent_sha256']
previous = json.loads((stage/'load-report.json').read_text())
path = stage/'During active verification.elab'
assert previous['passed'] and digest(path) == previous['saved_sha256']
document = json.loads(path.read_text())
spec = importlib.util.spec_from_file_location('client', root/'scripts/persistence-demo.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
client = helper.Client(command_preconditions=True, agent_binary=binary)
report = dict(source=pin, passed=False, saved_sha256=digest(path))
try:
    client.ask('project.load', {'path': str(path)}, True)
    loaded = client.ask('simulation.wait')
    (stage/'active-save-reopened.json').write_text(json.dumps(loaded, indent=2)+'\n')
    assert document['graph'] == dict(components=loaded['components'], wires=loaded['wires'])
    assert document['view'] == loaded['view']
    assert loaded['paused'] and not loaded['diagnostics'] and not loaded['mixed']['stale']
    assert loaded['document']['recording_count'] == 0
    assert not loaded['document']['recordings_dirty'] and not loaded['document']['schematic_dirty']
    original = json.loads((stage/'load-before.json').read_text())
    old = next(p for p in original['components'] if p['id'] == 'RG1')['position']
    moved = next(p for p in loaded['components'] if p['id'] == 'RG1')['position']
    assert moved == dict(x=old['x']+10, y=old['y'])
    assert loaded['view'] != original['view']
    assert digest(path) == previous['saved_sha256']
    report.update(passed=True, saved_graph_and_view_exact=True,
                  saved_before_undo=True, no_partial_recording=True, file_unchanged=True)
finally:
    try:
        job = client.ask('app.close', {'discard_changes': True}, True)['shutdown']
        job = client.wait_for_shutdown_outcome(job)
        assert job['workers_joined'] and job['exit_ready']
        report['shutdown'] = job
    finally:
        client.close()
    report['exit_code'] = client.process.returncode
    (stage/'active-save-reopen-report.json').write_text(json.dumps(report, indent=2)+'\n')
assert report['passed'] and report['exit_code'] == 0
print('Fresh public reopen preserves the saved graph/view; no incomplete recording.')
