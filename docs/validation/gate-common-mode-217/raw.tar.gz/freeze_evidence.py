"""Freeze bounded, independently referenced /217 electronics evidence."""
from pathlib import Path
import gzip, hashlib, io, json, tarfile
from reference import at

root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
out = root/'docs/validation/gate-common-mode-217'
sha = lambda data: hashlib.sha256(data).hexdigest()
qualification = json.loads((stage/'qualification.json').read_text())
load = json.loads((stage/'load-report.json').read_text())
reopen = json.loads((stage/'active-save-reopen-report.json').read_text())
assert qualification['all_passed'] and qualification['scalar_checks'] == 1722
assert load['passed'] and reopen['passed'] and load['exit_code'] == reopen['exit_code'] == 0
pin = qualification['source']
assert sha(Path(pin['binary']).read_bytes()) == pin['agent_sha256']
assert pin == load['source'] == reopen['source']
maximum = [0.]*6
rows = 0
for case in qualification['cases']:
    assert case['passed'] and case['exit_code'] == 0 and case['live_physical_state_exact']
    assert sha((stage/case['file']).read_bytes()) == case['sha256']
    page = json.loads((stage/Path(case['file']).stem/'rows.json').read_text())
    for row in page['rows']:
        expected = at(row['time_s'], case['reference_v'], case['reverse'], case['initial_vgs_v'])
        for i, (actual, want) in enumerate(zip(row['values'], expected)):
            error = abs(actual-want)
            tolerance = max(1e-8, .005*abs(want)) if i in [3, 5] else max(.001, .01*abs(want))
            assert error <= tolerance
            maximum[i] = max(maximum[i], error)
        rows += 1
assert rows == 287
assert all(p['before']['status'] == p['after']['status'] == 'running' for p in load['commands'])
assert load['terminal']['operation']['status'] == 'canceled' and load['physical_state_exact']
assert reopen['saved_sha256'] == load['saved_sha256']
current = root/'build/releases/ELab-0.181.4-macos-arm64.zip'
assert sha(current.read_bytes()) == 'd13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
assert not out.exists()
out.mkdir(parents=True)
files = {p.relative_to(stage).as_posix(): p.read_bytes()
         for p in sorted(stage.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
files['helpers/persistence-demo.py'] = (root/'scripts/persistence-demo.py').read_bytes()
with (out/'raw.tar.gz').open('xb') as disk:
    with gzip.GzipFile(fileobj=disk, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(files.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
(out/'raw-manifest.json').write_text(json.dumps({p: sha(data) for p, data in sorted(files.items())}, indent=2)+'\n')
report = dict(source=pin, passed=True, cases=7, rows=rows, scalar_comparisons=1722,
              probe_order=['v:CG', 'v:M1.gate-source', 'v:M1', 'i:M1.drain', 'v:M1.source', 'i:CG'],
              max_absolute_errors=maximum, large_simulated_parts=56, large_electrical_nodes=55,
              current_tolerance='max(10 nA, 0.5% of reference)',
              voltage_tolerance='max(1 mV, 1% of reference)',
              reference='Independent analytic RC and scalar educational MOSFET load line; not device measurements or SPICE',
              live_state_preserved=True, active_work_commands=load['commands'],
              cancel_request_seconds=load['cancel_request_seconds'], canceled_without_partial_record=True,
              running_status_observed_around_commands=True, published_progress_before_cancel=0,
              blocked_kernel_injected=False, latency_distribution_qualified=False,
              fresh_active_save_reopen=reopen, all_owned_headless_workers_joined=True,
              source_changed_for_these_trials=False, graphical_app_launched=False,
              raw_archive_sha256=sha((out/'raw.tar.gz').read_bytes()), raw_members=len(files),
              preserved_download='0.181.4 /205', candidate_native_acceptance=False,
              limitations='Seven specific existing-model circuits, one workstation and one ordinary active-work observation. Running status does not prove exact solver overlap. No new model, arbitrary topology, capacity, physical latency or full PRD acceptance is claimed.')
(out/'report.json').write_text(json.dumps(report, indent=2)+'\n')
(out/'README.md').write_text('''# Gate-RC MOSFET reference and active-work checks /217

October 23, 2026. [Receipt](report.json), [raw captures and producers](raw.tar.gz),
[member hashes](raw-manifest.json), [research notes](../../../research/95-gate-common-mode.md).

The exact packaged /217 headless agent passes seven existing-model circuits:
gate RC with NMOS source at −5, 0 and +5 V, each capacitor orientation, and a
56-part/55-node equivalent network using fifty gate resistors. All 287 rows and
1,722 scalar comparisons satisfy the declared tolerances. References use the
analytic gate exponential and an independent scalar load line with the pinned
educational channel/body-diode equations. Every loaded source file and protected
live physical state is preserved; expected completed-record metadata is allowed.

On the larger graph, Pan, Save, Undo and Pause return while public Verify status
is running before and after each command. Cancellation completes without partial
rows or live charge/time changes. A fresh process opens the file saved before
Undo, retaining its moved component/view and containing no incomplete recording.
All owned headless workers join and processes exit normally.

This is one ordinary active-work observation, canceled before the first published
progress update. It proves neither exact solver overlap nor a latency percentile.
The controlled blocked-kernel regressions remain a separate source-test result.
Earlier fixture/status/snapshot/layout/metadata assertion mistakes are retained
under named harness directories; they are not application defect reports.

No product source, command, model, SDK or graphical session changes for these
trials. /205 stays the qualified download; /217 remains held for native acceptance.
''')
(out/'MANIFEST.json').write_text(json.dumps({p.name: sha(p.read_bytes()) for p in sorted(out.iterdir()) if p.is_file()}, indent=2)+'\n')
print(json.dumps({k: report[k] for k in ['passed', 'cases', 'rows', 'scalar_comparisons', 'max_absolute_errors', 'raw_members']}))
