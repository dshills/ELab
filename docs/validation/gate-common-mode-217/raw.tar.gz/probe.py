"""Collect an initial public capture; no private product API or GUI is used."""
from pathlib import Path
import importlib.util,json,time
r=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent;pin=json.loads((s/'packaged-source.json').read_text())
spec=importlib.util.spec_from_file_location('client',r/'scripts/persistence-demo.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
c=helper.Client(command_preconditions=True,agent_binary=Path(pin['binary']))
probes=['v:CG','v:M1.gate-source','v:M1','i:M1.drain','v:M1.source','i:CG']
try:
 state=c.ask('project.load',{'path':str(s/'gate-+0-reverse-0.elab')},True);state=c.ask('simulation.wait');(s/'probe-loaded.json').write_text(json.dumps(state,indent=2)+'\n')
 assert state['paused'] and state['status']=='paused' and not state['mixed']['stale'] and not state['diagnostics'],state.get('diagnostics')
 assert all(p in [x['id'] for x in state['scope']['available']] for p in probes)
 op=c.ask('simulation.verify',{'duration_s':.01,'sample_step_s':.00025,'probe_ids':probes},True)['last_operation']
 end=time.monotonic()+10
 while True:
  result=c.ask('operation.inspect',{'id':op});status=result['operation']['status']
  if status in ['completed','failed','canceled']:break
  assert time.monotonic()<end,result;time.sleep(.01)
 (s/'probe-operation.json').write_text(json.dumps(result,indent=2)+'\n')
 print('Capture status:',status)
 if status=='completed':
  page=c.ask('operation.samples',{'id':op,'offset':0,'limit':100});(s/'probe-rows.json').write_text(json.dumps(page,indent=2)+'\n');print('Rows:',len(page['rows']))
 job=c.ask('app.close',{'discard_changes':True},True)['shutdown'];job=c.wait_for_shutdown_outcome(job);assert job['workers_joined'] and job['exit_ready']
finally:c.close()
assert c.process.returncode==0
