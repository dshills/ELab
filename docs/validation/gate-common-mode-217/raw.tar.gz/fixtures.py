"""Create supported DC-driven MOSFET gate-RC fixtures from the saved public template."""
from pathlib import Path
import copy,hashlib,json
S=Path(__file__).resolve().parent
BASE=json.loads((S/'nmos-template.elab').read_text())

def fixture(shift=0,reverse=False,count=1,initial=1.25):
 d=copy.deepcopy(BASE)
 for key in ['example_id','dc_sweeps']:d.pop(key,None)
 parts={p['id']:p for p in d['graph']['components']}
 vin=copy.deepcopy(parts['VCC']);vin.update(id='VIN',name='DC source',value=5,position={'x':-300,'y':60})
 ref=copy.deepcopy(parts['VCC']);ref.update(id='VREF',value=abs(shift),position={'x':-400,'y':300})
 cap=dict(id='CG',kind='capacitor',name='Capacitor',terminals=['1','2'],position={'x':100,'y':150},value=1e-6,unit='F',model='ideal-capacitor.v1',rotation=90,initial_voltage_v=-initial if reverse else initial)
 gate=[]
 for i in range(count):
  p=copy.deepcopy(parts['RG']);p.update(id='RG'+str(i+1),value=1000/count,position=({'x':-200+(i%8)*100,'y':-500+(i//8)*80} if count>1 else {'x':-200,'y':60}));gate.append(p)
 d['graph']['components']=[parts['VCC'],vin,ref,parts['RL'],parts['M1'],parts['GND1'],cap]+gate
 common='VREF.negative' if shift<0 else 'VREF.positive';groundside='VREF.positive' if shift<0 else 'VREF.negative'
 pairs=[('VCC.positive','RL.1'),('RL.2','M1.drain'),('M1.source',common),('VCC.negative',common),('VIN.negative',common),(groundside,'GND1.reference'),('VIN.positive','RG1.1')]
 pairs += [(f'RG{i}.2',f'RG{i+1}.1') for i in range(1,count)]
 pairs += [(f'RG{count}.2','M1.gate'),('CG.2' if reverse else 'CG.1','M1.gate'),('CG.1' if reverse else 'CG.2',common)]
 d['graph']['wires']=[dict(id=f'W{i+1}',**{'from':a,'to':b},connected=True) for i,(a,b) in enumerate(pairs)]
 d['scope_probes']={'ids':['v:CG','v:M1.gate-source','v:M1','i:M1.drain','v:M1.source','i:CG']}
 d['paused']=True;d['transient_settings'].update(step_s=.00025,seconds_per_wall_second=.02,initial_voltage_v=0)
 return d

if __name__=='__main__':
 manifest=[]
 for shift in [-5,0,5]:
  for reverse in [False,True]:
   name=f'gate-{shift:+g}-reverse-{int(reverse)}.elab';data=(json.dumps(fixture(shift,reverse),indent=2)+'\n').encode();p=S/name;assert not p.exists();p.write_bytes(data)
   manifest.append(dict(file=name,sha256=hashlib.sha256(data).hexdigest(),reference_v=shift,reverse=reverse,gate_resistors=1,initial_vgs_v=1.25))
 name='gate-large.elab';data=(json.dumps(fixture(5,False,50),indent=2)+'\n').encode();p=S/name;assert not p.exists();p.write_bytes(data)
 manifest.append(dict(file=name,sha256=hashlib.sha256(data).hexdigest(),reference_v=5,reverse=False,gate_resistors=50,initial_vgs_v=1.25))
 (S/'fixtures.json').write_text(json.dumps(manifest,indent=2)+'\n');print('Created',len(manifest),'new owned fixtures.')
