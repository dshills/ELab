"""Export a disposable public example using the exact packaged /217 agent."""
from pathlib import Path
import hashlib,importlib.util,json
r=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent
receipt=json.loads((r/'docs/validation/number-field-wheel-217/candidate-report.json').read_text());binary=Path(receipt['candidate'])/'elab-agent'
assert hashlib.sha256(binary.read_bytes()).hexdigest()==receipt['agent_sha256']
spec=importlib.util.spec_from_file_location('client',r/'scripts/persistence-demo.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
c=helper.Client(command_preconditions=True,agent_binary=binary)
try:
 c.ask('example.load',{'id':'nmos','discard_changes':True},True);c.ask('simulation.pause',{},True);state=c.ask('simulation.wait')
 path=s/'nmos-template.elab';assert not path.exists();saved=c.ask('project.save',{'path':str(path)},True)
 (s/'template-snapshot.json').write_text(json.dumps(saved,indent=2)+'\n')
 (s/'packaged-source.json').write_text(json.dumps(dict(source_commit=receipt['source_commit'],agent_sha256=receipt['agent_sha256'],binary=str(binary)),indent=2)+'\n')
 job=c.ask('app.close',{'discard_changes':True},True)['shutdown'];job=c.wait_for_shutdown_outcome(job);assert job['workers_joined'] and job['exit_ready']
finally:c.close()
assert c.process.returncode==0
print('Public NMOS template saved; owned headless process exited 0.')
