"""Record the clean /217 package without inferring native acceptance."""
import gzip,hashlib,io,json,shutil,subprocess,sys,tarfile
from pathlib import Path
r=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent
out=r/'docs/validation/number-field-wheel-217';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((s/'build-result-signed.json').read_text());p=json.loads((s/'protocol-report.json').read_text());inputs=json.loads((out/'source-inputs.json').read_text())
assert p['passed'] and b['passed'] and p['source_commit']==b['source_commit']
assert p['scalar_readings_checked']==42 and p['capture_samples']==21 and p['agent_exit_code']==0
assert p['shutdown']['workers_joined'] and p['shutdown']['exit_ready'] and p['explicit_playback_rate_command']
assert b['version']=='0.181.16' and b['build']=='217' and b['clean_build_vcs']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r).strip()
assert all(sha(r/name)==digest for name,digest in inputs.items())
sys.path.insert(0,str(r/'scripts'));from runtime_isolation import bundle_tree
review=Path(b['review']);app=review/'ELab.app'
assert bundle_tree(app)==b['source_bundle']
assert sha(app/'Contents/MacOS/ELab')==b['native_sha256'] and sha(review/'elab-agent')==b['agent_sha256']==p['agent_sha256']
verify=subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict','--verbose=2',str(app)],capture_output=True)
(s/'signature-after-agent.txt').write_bytes(verify.stdout+verify.stderr)
assert verify.returncode==0
previous=json.loads((r/'docs/validation/keyboard-focus-216/candidate-report.json').read_text())
assert sha(Path(previous['candidate'])/'ELab.app/Contents/MacOS/ELab')==previous['native_sha256']
assert sha(Path(previous['candidate'])/'elab-agent')==previous['agent_sha256']
assert sha(r/'build/releases/ELab-0.181.4-macos-arm64.zip')=='d13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
receipt=dict(version=b['version'],build=b['build'],source_commit=b['source_commit'],candidate=str(review),clean_build_vcs=True,
 source_inputs_still_match=len(inputs),native_sha256=b['native_sha256'],agent_sha256=b['agent_sha256'],strict_ad_hoc_signature_valid=True,
 bundle_unchanged_after_agent_test=True,matching_headless_agent_passed=True,scalar_readings_checked=p['scalar_readings_checked'],capture_samples=p['capture_samples'],
 max_voltage_error_v=p['max_voltage_error_v'],max_current_error_a=p['max_current_error_a'],history_undo_redo=p['history_undo_redo'],
 saved_reopen_retains_capture=p['saved_reopen_retains_capture'],dirty_replacement_refusal_preserves_work=p['dirty_replacement_refusal_preserves_work'],
 explicit_playback_rate_command=p['explicit_playback_rate_command'],headless_shutdown=p['shutdown'],agent_exit_code=p['agent_exit_code'],previous_candidate_preserved=True,native_app_launched=False,
 native_acceptance_passed=False,promotion_status='held',release_ready=False,published=False,owner_review_required=False,preserved_download='0.181.4 /205',
 limitations='Headless checks do not exercise private widget text. Changed-candidate native numeric wheel behavior and accumulated /207–/216 checks remain pending. Supplemental full upstream Core race checks are not green. No fresh graphical launch or unattended approval is queued.')
(out/'candidate-report.json').write_text(json.dumps(receipt,indent=2)+'\n')
pending=json.loads((r/'docs/validation/keyboard-focus-216/native-acceptance-pending.json').read_text())
pending['required_checks'].append('Wheel input over focused and unfocused number fields scrolls the enclosing pane without changing accepted values or unfinished text; explicit typing, step buttons and arrow keys remain usable')
pending.update(source_commit=b['source_commit'],native_sha256=b['native_sha256'],agent_sha256=b['agent_sha256'])
(out/'native-acceptance-pending.json').write_text(json.dumps(pending,indent=2)+'\n')
evidence=out/'candidate';assert not evidence.exists();evidence.mkdir()
files={}
for name in ['build.txt','package.txt','signature-signed-verify.txt','signature-signed-details.txt','signature-after-agent.txt','build-result-signed.json','protocol-check.txt','protocol-report.json','source-commit.txt','build_candidate.py','protocol_check.py','freeze_candidate.py','RC history and capture.elab']:
 files[name]=(s/name).read_bytes()
for name in ['elab-build-info.txt','elab-agent-build-info.txt','elab-conformance-build-info.txt']:
 files['build/'+name]=(s/'build'/name).read_bytes()
with (evidence/'raw.tar.gz').open('xb') as disk:
 with gzip.GzipFile(fileobj=disk,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name,data in sorted(files.items()):
    info=tarfile.TarInfo(name);info.size,info.mode,info.mtime=len(data),0o644,0;tar.addfile(info,io.BytesIO(data))
(evidence/'raw-manifest.json').write_text(json.dumps({name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())},indent=2)+'\n')
(evidence/'README.md').write_text('''# /217 clean package and matching agent

The package is ELab 0.181.16 /217, built from the clean source in the parent
receipt. All three executables embed that revision with vcs.modified=false.
Strict ad-hoc bundle verification passes before and after the headless check.
This is an integrity seal, not Developer ID signing or notarization.

The exact packaged agent passes explicit recorded-rate setting, circuit Undo/Redo,
42 independent RC references
across 21 saved voltage/current samples, Save, dirty replacement refusal and
Open with the captured data/metadata preserved. Owned headless workers join;
the process exits 0. This does not exercise the numeric wheel repair in a
native window. Supported-control mounted evidence is documented separately.

The candidate is held for the native checks in the parent pending list. /216,
the /205 download and SDK archives/caches remain preserved. No graphical app
is launched or promoted and no launch-approval question is queued. Raw logs,
helpers, build metadata and the synthetic project are in raw.tar.gz.
''')
with (out/'README.md').open('a') as stream:stream.write('\nThe [clean /217 candidate and matching agent](candidate-report.json) pass\npackaging integrity, circuit Undo/Redo, 42 independent RC readings, saved-capture\nreopen, dirty-work refusal and normal headless cleanup. The candidate is held\nfor [fresh native acceptance](native-acceptance-pending.json); /205 remains current.\n')
notes=r/'research/94-number-field-wheel.md';text=notes.read_text().replace('Clean packaging is next.','The clean /217 package and matching agent also pass circuit Undo/Redo, 42\nindependent RC readings, saved-capture reopen, dirty-work refusal and normal\nheadless cleanup. The candidate is held for fresh native acceptance.');notes.write_text(text)
manifest={path.relative_to(out).as_posix():sha(path) for path in sorted(out.rglob('*')) if path.is_file() and path!=out/'MANIFEST.json'}
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['version','build','source_commit','native_sha256','agent_sha256','source_inputs_still_match','matching_headless_agent_passed','promotion_status']}))
