"""Smoke-check the exact packaged agent's history and saved RC capture."""
import hashlib,importlib.util,json,math,time
from pathlib import Path
r=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent
build=json.loads((s/'build-result-signed.json').read_text());binary=Path(build['review'])/'elab-agent'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(binary)==build['agent_sha256']
spec=importlib.util.spec_from_file_location('client',r/'scripts/persistence-demo.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
c=helper.Client(command_preconditions=True,agent_binary=binary)
report=dict(source_commit=build['source_commit'],agent_sha256=sha(binary),transport='headless-stdio',scalar_readings_checked=0,max_voltage_error_v=0.,max_current_error_a=0.)
def resistance(state):return next(p for p in state['components'] if p['id']=='R1')['value']
try:
 c.ask('example.rc',{'discard_changes':True},True);c.ask('simulation.pause',{},True)
 assert resistance(c.ask('component.set',{'id':'R1','value':'20k'},True))==20000
 assert resistance(c.ask('edit.undo',{},True))==10000
 assert resistance(c.ask('edit.redo',{},True))==20000
 c.ask('simulation.wait')
 identifier=c.ask('simulation.verify',dict(duration_s=.02,sample_step_s=.001,input_mode='charge',probe_ids=['v:C1','i:C1']),True)['last_operation']
 deadline=time.monotonic()+5
 while True:
  operation=c.ask('operation.inspect',{'id':identifier});status=operation['operation']['status']
  if status=='completed':break
  assert status not in ['failed','canceled'] and time.monotonic()<deadline,operation
  time.sleep(.01)
 page=c.ask('operation.samples',dict(id=identifier,offset=0,limit=21))
 assert len(page['rows'])==21
 assert [p['id'] for p in operation['metadata']['probes']]==['v:C1','i:C1']
 for row in page['rows']:
  expected=[5*(1-math.exp(-row['time_s']/.02)),.00025*math.exp(-row['time_s']/.02)]
  for i,key,tolerance in [(0,'max_voltage_error_v',1e-10),(1,'max_current_error_a',1e-14)]:
   error=abs(row['values'][i]-expected[i]);report[key]=max(report[key],error)
   assert error<tolerance,(row,expected);report['scalar_readings_checked']+=1
 c.ask('operation.select',{'id':identifier},True);c.ask('recording.view.set',{'mode':'recorded'},True)
 rate=c.ask('recording.speed.set',{'seconds_per_wall_second':.101},True)
 assert rate['recording']['seconds_per_wall_second']==.101 and rate['paused'] and not rate['recording']['playing']
 report['explicit_playback_rate_command']=True
 c.ask('recording.keep.set',{'id':identifier,'keep':True},True)
 path=s/'RC history and capture.elab';assert not path.exists()
 saved=c.ask('project.save',{'path':str(path)},True);assert not saved['document']['dirty']
 digest=sha(path)
 c.ask('component.set',{'id':'R1','value':'30k'},True);c.ask('simulation.wait')
 c.ask('project.load',{'path':str(path)},True,'unsaved-changes')
 assert resistance(c.ask('project.inspect'))==30000 and sha(path)==digest
 loaded=c.ask('project.load',{'path':str(path),'discard_changes':True},True)
 assert resistance(loaded)==20000 and not loaded['document']['dirty'] and sha(path)==digest
 restored=loaded['recording']['id']
 assert c.ask('operation.inspect',{'id':restored})['metadata']==operation['metadata']
 assert c.ask('operation.samples',dict(id=restored,offset=0,limit=21))['rows']==page['rows']
 report.update(history_undo_redo=True,saved_reopen_retains_capture=True,dirty_replacement_refusal_preserves_work=True,saved_sha256=digest,capture_samples=21)
 job=c.ask('app.close',{'discard_changes':True},True)['shutdown'];job=c.wait_for_shutdown_outcome(job)
 assert job['status']=='completed' and job['workers_joined'] and job['exit_ready'];report['shutdown']=job
finally:c.close()
assert c.process.returncode==0;report.update(passed=True,agent_exit_code=0)
(s/'protocol-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['passed','scalar_readings_checked','capture_samples','history_undo_redo','saved_reopen_retains_capture','agent_exit_code']}))
