"""Restore only the disposable session's changed playback preference."""
import importlib.util,json
from pathlib import Path
r=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent
before=json.loads((s/'native-before.json').read_text())
spec=importlib.util.spec_from_file_location('client',r/'scripts/persistence-demo.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
c=helper.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json',command_preconditions=True,agent_binary=r/'build/ELab-0.181.5-206-candidate/elab-agent')
try:
 current=c.ask('project.inspect');assert current['paused'] and not current['recording']['playing']
 # The UI used the 0.1 fallback while the accepted snapshot stored the default sentinel 0.
 result=current if current['recording']['seconds_per_wall_second']==.1 else c.ask('recording.speed.set',{'seconds_per_wall_second':.1},True)
 (s/'native-restored.json').write_text(json.dumps(result,indent=2)+'\n')
 changed=[k for k in before if before[k]!=result[k]]
 assert set(changed)<= {'recording','revision','command_revision','last_actor'},changed
 recording_changes={key:[before['recording'].get(key),value] for key,value in result['recording'].items() if before['recording'].get(key)!=value}
 assert recording_changes=={'seconds_per_wall_second':[0,.1]},recording_changes
 (s/'native-restoration-report.json').write_text(json.dumps(dict(effective_playback_rate_restored=True,changed_snapshot_keys=changed,recording_changes=recording_changes,other_snapshot_fields_exact=True,default_sentinel_becomes_explicit_rate=True,scope='The original stored rate 0 was displayed as the 0.1 fallback. Public speed.set requires a positive rate; the original effective rate is restored as explicit 0.1. Revision counters and last_actor also change.'),indent=2)+'\n')
 print('Effective playback rate restored; all other snapshot fields exact except revision/actor metadata. Stored default 0 is now explicit 0.1.')
finally:c.close()
