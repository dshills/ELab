"""Read the existing owned /206 session, without launching an app."""
import hashlib,importlib.util,json,sys
from pathlib import Path
r=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent
assert len(sys.argv)==2 and sys.argv[1] in ['before','after-unfocused','after-focused','restored']
p=s/('native-'+sys.argv[1]+'.json');assert not p.exists()
spec=importlib.util.spec_from_file_location('client',r/'scripts/persistence-demo.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
binary=r/'build/ELab-0.181.5-206-candidate/elab-agent'
assert Path('/private/tmp/elab-cursor-guidance-206/endpoint.json').is_file()
c=helper.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json',command_preconditions=True,agent_binary=binary)
try:
 state=c.ask('project.inspect');assert state['paused']
 p.write_text(json.dumps(state,indent=2)+'\n')
 print(json.dumps({'captured':sys.argv[1],'command_revision':state['command_revision'],'settings':state['transient']['settings'],'transient_time_s':state['transient']['sample']['time_s']}))
finally:c.close()
