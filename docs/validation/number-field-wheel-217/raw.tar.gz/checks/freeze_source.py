"""Record the numeric wheel repair and keep native baseline scope explicit."""
import gzip,hashlib,io,json,re,shutil,subprocess,tarfile
from pathlib import Path
r=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent
out=r/'docs/validation/number-field-wheel-217';sha=lambda b:hashlib.sha256(b).hexdigest()
assert not out.exists()
for name in ['quality','focused-final','sdk-quality','sdk-wheel-after']:
 assert (s/(name+'-exit-code.txt')).read_text().strip()=='0',name
inputs=json.loads((s/'source-inputs.json').read_text());prior=json.loads((r/'docs/validation/keyboard-focus-216/source-inputs.json').read_text())
assert len(inputs)==888 and all(sha((r/p).read_bytes())==h for p,h in inputs.items())
native=[p for p in inputs if p.startswith('desktop/') and p.endswith('.go') and not p.endswith('_test.go')]
assert len(native)==126 and all(inputs[p]==prior[p] for p in native)
assert all(inputs[p]==prior[p] for p in inputs if p.startswith('workbench/'))
assert not (r/'go.sum').exists()
lock=json.loads((r/'third_party/vellum/sdk.lock.json').read_text());oldlock=json.loads((s/'previous-sdk.lock.json').read_text())
for obj in [lock,oldlock]:
 assert sha((r/obj['archive']).read_bytes())==obj['sha256']
 assert sha((r/obj['compatibility_patch']['path']).read_bytes())==obj['compatibility_patch']['sha256']
assert sha((r/'build/releases/ELab-0.181.4-macos-arm64.zip').read_bytes())=='d13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
oldcandidate=json.loads((r/'docs/validation/keyboard-focus-216/candidate-report.json').read_text())
assert sha((Path(oldcandidate['candidate'])/'ELab.app/Contents/MacOS/ELab').read_bytes())==oldcandidate['native_sha256']
assert sha((Path(oldcandidate['candidate'])/'elab-agent').read_bytes())==oldcandidate['agent_sha256']
quality=(s/'quality.txt').read_text();times=re.findall(r'ok\s+github.com/dshills/elab/desktop\s+(\d+\.\d+)s',quality);assert len(times)==2,times
before=(s/'mounted-before.txt').read_text();assert before.count('wheel changed accepted numeric state instead of scrolling')==2 and before.count('focused=true')==2
assert (s/'sdk-wheel-before-final.txt').read_text().count('wheel changed the number or its private draft')==2
focused=re.search(r'ok\s+github.com/dshills/elab/desktop\s+(\d+\.\d+)s',(s/'focused-final.txt').read_text()).group(1)
comparison=json.loads((s/'sdk-member-comparison.json').read_text());assert len(comparison['changed_files'])==3 and comparison['file_count']==8434
assert comparison['bootstrap_unchanged'] and not any('/build/upstream/' in p for p in comparison['changed_files'])
assert (s/'inventory-check.txt').read_text()==(r/'build/keyboard-focus-216-tools/inventory-check.txt').read_text()
nativeproof=json.loads((r/'research/ui-audit/number-field-wheel-217/report.json').read_text())
assert nativeproof['native_baseline_reproduced'] and not nativeproof['native_fix_qualified']
assert nativeproof['restoration']['other_snapshot_fields_exact'] and nativeproof['restoration']['default_sentinel_becomes_explicit_rate']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r/'build/vellum-public-e58d405').strip()
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();changed=sorted(p for p,h in inputs.items() if prior.get(p)!=h)
files={'checks/'+p.name:p.read_bytes() for p in sorted(s.iterdir()) if p.is_file() and p.suffix in {'.py','.json','.txt'}}
absent=[];external={}
for name in changed:
 if name==lock['archive']:external[name]=inputs[name];absent.append(name);continue
 files['source/'+name]=(r/name).read_bytes()
 if name in prior:files['source-before/'+name]=subprocess.check_output(['git','show',base+':'+name],cwd=r)
 else:absent.append(name)
files['source-before/absent.json']=(json.dumps(absent,indent=2)+'\n').encode();files['source/external-artifacts.json']=(json.dumps(external,indent=2)+'\n').encode()
out.mkdir(parents=True);shutil.copyfile(s/'source-inputs.json',out/'source-inputs.json')
with (out/'raw.tar.gz').open('xb') as disk:
 with gzip.GzipFile(fileobj=disk,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name,data in sorted(files.items()):
    info=tarfile.TarInfo(name);info.size,info.mode,info.mtime=len(data),0o644,0;tar.addfile(info,io.BytesIO(data))
(out/'raw-manifest.json').write_text(json.dumps({p:sha(b) for p,b in sorted(files.items())},indent=2)+'\n')
report=dict(kind='number-field-wheel',application_checks_passed=True,quality_exit_code=0,source_parent_commit=base,source_inputs=len(inputs),
 changed_source_inputs=changed,absent_source_inputs=['go.sum'],desktop_race_seconds=float(times[0]),mounted_race_seconds=float(times[1]),
 python_tests=67,focused_keyboard_and_wheel_seconds=float(focused),sdk_python_tests=30,sdk_root_driver_race_vet_passed=True,
 driver_before_cases=2,application_before_cases=2,driver_focused_seconds=1.906,prospective_application_seconds=2.724,
 sdk_member_comparison=comparison,sdk=lock,previous_sdk=oldlock,upstream_dependencies_unchanged=True,
 production_desktop_go_sources_unchanged=126,inventory_sources_unchanged=79,backend_source_unchanged=True,public_commands=166,source_routes=134,sites=404,
 old_native_baseline=nativeproof,native_candidate_launched=False,native_acceptance_passed=False,release_ready=False,published=False,owner_review_required=False,
 new_commands=0,new_components=0,new_formats=0,download_unchanged='0.181.4 /205',previous_candidate_preserved='0.181.15 /216',
 raw_archive_sha256=sha((out/'raw.tar.gz').read_bytes()),raw_members=len(files),
 supplemental_upstream_core_race_status='Prior /216 supplemental Core race failures remain recorded; all upstream dependency bytes are unchanged. No broad upstream Core pass is inferred.')
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'README.md').write_text(f'''# Number fields and wheel scrolling /217

October 23, 2026. [Receipt](report.json), [inputs](source-inputs.json),
[repair notes](../../../research/94-number-field-wheel.md),
[old native baseline](../../../research/ui-audit/number-field-wheel-217/README.md).

A focused number field treated wheel movement as numeric editing, consuming the
pane's scroll. The owned /206 native session changed displayed recorded speed
from 0.1 to 0.13000001; its unfocused control scrolled without changing the full
public snapshot. Current production live-initial-voltage and recorded-speed
nodes reproduce two focused failures; both unfocused cases pass.

The managed factory removes the Spinner's default wheel handlers. Driver tests
preserve the accepted 25 and unfinished `925` text/selection, submit no Change
and move the parent pane. Standalone fields ignore the wheel. Up/Down still
submit one explicit increment each. Both final driver cases fail on a read-only
original-factory overlay and pass with the repair in 1.906 s. Application cases
pass prospectively in 2.724 s; final pinned keyboard/wheel checks take {focused} s.
The supported-control fixtures do not mount a custom schematic or AppKit loop.

SDK source `{lock['source_commit']}` is clean. Its 30 preparation tests and
framework root/driver normal/offscreen race and vet checks pass. All 8,434 export
members match the manifest; only controls.go, its new test and the generated
provenance note change. Upstream Core/typesetting, notices and all six bootstrap
scripts match elab9. Prior full upstream Core race failures remain recorded in
/216; no broad upstream test pass is inferred from these narrower gates.

The full application gate passes lint/staticcheck, 67 Python tests, root/desktop
race and vet, mounted race and offscreen vet. Desktop race takes {times[0]} s;
mounted race {times[1]} s. All 888 source/check inputs match. All 126 non-test
desktop Go files, backend sources and the 79-source command inventory are
unchanged: 166 commands, 134 routes, 404 sites. [Raw evidence](raw.tar.gz),
[member hashes](raw-manifest.json). Initial label/inspector fixture errors and
probe/default-sentinel mistakes are kept separately from genuine failures.

The old native test restores the effective rate as explicit 0.1; its original
stored default was 0. Revision/actor metadata also differ, while every other
snapshot field and both viewport positions are preserved. This is a scoped
restoration, not exact equality. New candidate native acceptance is still
separate. /205, /216, user projects and the existing owned session are preserved;
no graphical launch or unattended launch-approval prompt is queued.
''')
notes=r/'research/94-number-field-wheel.md';text=notes.read_text().replace('Full framework gates, a new pin and application packaging remain in\nprogress.',f'The [full framework and application gates pass](../docs/validation/number-field-wheel-217/README.md).\nThe elab10 export changes three members and preserves all upstream dependency\nbytes. Final pinned keyboard/wheel checks pass in {focused} s. Desktop race takes\n{times[0]} s; mounted race {times[1]} s. All 888 source/check inputs match.\nClean packaging is next.');notes.write_text(text)
index=r/'research/README.md';text=index.read_text().replace('Qualification is in progress.','The elab10 pin and full source/offscreen gates pass; fresh native acceptance remains separate.');index.write_text(text)
manifest={p.relative_to(out).as_posix():sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file()}
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['application_checks_passed','source_inputs','desktop_race_seconds','mounted_race_seconds','raw_members']}))
