"""Preserve old native behavior without claiming a repaired native app check."""
from pathlib import Path
import hashlib,json,shutil
r=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent
out=r/'research/ui-audit/number-field-wheel-217';assert not out.exists()
before=json.loads((s/'native-before.json').read_text());unfocused=json.loads((s/'native-after-unfocused.json').read_text());after=json.loads((s/'native-after-focused.json').read_text());restored=json.loads((s/'native-restored.json').read_text())
assert before==unfocused
changes=[k for k in before if before[k]!=after[k]];assert set(changes)=={'recording','command_revision','revision'}
delta={k:[before['recording'].get(k),v] for k,v in after['recording'].items() if before['recording'].get(k)!=v}
assert set(delta)=={'seconds_per_wall_second'} and delta['seconds_per_wall_second'][0]==0
assert abs(delta['seconds_per_wall_second'][1]-.1300000101327896)<1e-15
restoration=json.loads((s/'native-restoration-report.json').read_text());assert restoration['effective_playback_rate_restored'] and restoration['other_snapshot_fields_exact']
source=json.loads((s/'native-source-comparison.json').read_text());assert source['number_field_factory_equal'] and source['spinner_source_equal']
out.mkdir(parents=True)
for name in ['01-ready','02-unfocused-scroll','03-focused','04-focused-scroll','05-restored']:
 for suffix in ['.txt','.png']:shutil.copyfile(s/(name+suffix),out/(name+suffix))
report=dict(native_baseline_reproduced=True,native_fix_qualified=False,source=source,unfocused_whole_snapshot_unchanged=True,
 focused_changed_snapshot_keys=changes,focused_recording_change=delta,displayed_rate_before=.1,displayed_rate_after=.13000001,
 restoration=restoration,native_app_launched=False,owner_projects_untouched=True,
 scope='Existing owned /206 session. Production number-field factory and spinner source match before-repair elab9. This is an old native baseline, not acceptance of the newly repaired source.')
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'README.md').write_text('''# Numeric wheel baseline on the existing /206 test session

October 23, 2026. [Receipt](report.json), [repair notes](../../94-number-field-wheel.md).
No new app is launched; the ordinary owner app/projects are untouched.

1. `01-ready`: recorded rate 0.1 and the top of the scrollable scope.
2. `02-unfocused-scroll`: the wheel moves the scope; the entire service snapshot
   stays exact.
3. `03-focused`: the actual playback number field has focus.
4. `04-focused-scroll`: the same normal wheel gesture changes playback to
   0.13000001 instead of scrolling. The public snapshot changes only recorded
   speed and revision counters; live graph/results/measurements stay exact.
5. `05-restored`: effective rate 0.1, original viewport positions and focus moved
   to the unchanged Sample step field.

Before the trial the public snapshot stored the unset speed sentinel 0, while
the UI displayed its 0.1 fallback. The public setter requires .001–10, so the
restoration stores explicit 0.1. Last actor and revision counters also change;
all remaining snapshot fields are exact. This is not a byte-identical restore.
The raw snapshots and helpers are retained with the source validation.

The native number-field factory and complete spinner source match elab9 before
the repair. Current-source mounted failures independently reproduce both live
initial-voltage and recorded-speed edits. These old native images cannot prove
the new SDK fix, new AppKit behavior or the other held-candidate native checks.
''')
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()}
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');print('Native baseline evidence preserved:',len(manifest))
