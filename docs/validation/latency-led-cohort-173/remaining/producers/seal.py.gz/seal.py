from pathlib import Path
import gzip,hashlib,json,shutil,tarfile,statistics
root=Path('/Users/dshills/Development/projects/ELab');proof=root/'docs/validation/latency-led-cohort-173';proof.mkdir()
phases=[('initial','elab-latency-cohort-led-173','latency-cohort-led-173-work'),('remaining','elab-latency-cohort-led-173-remaining','latency-cohort-led-173-remaining-work')]
rows=[]
for label,temp,stage in phases:
 source=Path('/private/tmp')/temp;dest=proof/label;dest.mkdir()
 for p in source.rglob('*'):
  if not p.is_file() or '.app' in p.as_posix() or p.suffix=='.png' or p.name=='endpoint.json':continue
  relative=p.relative_to(source);target=dest/relative;target.parent.mkdir(parents=True,exist_ok=True);raw=p.read_bytes()
  if len(raw)>16000:target.with_name(target.name+'.gz').write_bytes(gzip.compress(raw,mtime=0))
  else:target.write_bytes(raw)
 for folder in sorted((source/'trials').iterdir()):
  outcome=json.loads((folder/'outcome.json').read_text());analysis=json.loads((folder/'analysis.json').read_text()) if (folder/'analysis.json').exists() else None
  rows.append(dict(id=folder.name,phase=label,original_status=outcome['status'],available=outcome['status']=='collected_pending_pixel_analysis' and analysis is not None,reason=outcome.get('reason'),analysis=analysis))
  images=sorted((folder/'capture').glob('*.png')) if (folder/'capture').exists() else []
  if images:
   capture=dest/'trials'/folder.name/'capture'
   with tarfile.open(capture/'frames.tar.xz','x:xz') as archive:
    for p in images:archive.add(p,arcname=p.name,recursive=False)
   manifest={p.name:dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size,mode=oct(p.stat().st_mode&0o777)) for p in images}
   (capture/'image-manifest.json.gz').write_bytes(gzip.compress((json.dumps(manifest,indent=2)+'\n').encode(),mtime=0))
 producer=dest/'producers';producer.mkdir()
 for p in (root/'build'/stage).iterdir():
  if p.is_file() and p.suffix in ['.py','.swift','.plist','.txt','.json']:(producer/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
assert [r['id'] for r in rows]==[f'led-{n:02}' for n in range(1,21)]
available=[r for r in rows if r['available']]
assert len(available)==14
summary=dict(scheduled=20,attempted=20,available=14,unavailable=6,replacements=0,full_cohort_p95=None,performance_gate_passed=None,eligible_latency_observations=0,interval_scope='Before-input marker to supplied composition-frame timestamp; conservative software bounds, not OS event/acceptance or physical scanout timing',complete_image_frames=sum(r['analysis']['complete_frames'] for r in rows if r['analysis']),original_pngs=sum(r['analysis']['unique_images'] for r in rows if r['analysis']),available_only_descriptive={key:dict(min=min(r['analysis'][key] for r in available),median=statistics.median(r['analysis'][key] for r in available),max=max(r['analysis'][key] for r in available)) for key in ['marker_to_committed_ms','marker_to_fresh_ms']},outcomes=rows)
(proof/'cohort-outcomes.json').write_text(json.dumps(summary,indent=2)+'\n')
shutil.copy2(root/'build/latency-cohort-led-173-remaining-work/analyze.py',proof/'analyze.py')
shutil.copy2(root/'build/latency-cohort-led-173-remaining-work/check-marker-order.py',proof/'check-marker-order.py')
groups=json.loads((Path('/private/tmp')/phases[1][1]/'all-roi-groups-v2.json').read_text())
for index,g in enumerate(groups['global_groups']):shutil.copy2(g['path'],proof/('representative-'+str(index+1)+'.png'))
print(dict(proof=str(proof),scheduled=20,available=14,unavailable=6,images=summary['original_pngs']))
