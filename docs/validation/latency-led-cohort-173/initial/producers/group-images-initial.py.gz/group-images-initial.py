from pathlib import Path
from PIL import Image
import hashlib,json
roots=[Path('/private/tmp/elab-latency-cohort-led-173'),Path('/private/tmp/elab-latency-cohort-led-173-remaining')]
regions={'resistor':(440,295,555,316),'current':(30,718,180,744),'reading_status':(775,728,1010,750),'header_status':(724,60,815,121)}
global_groups={};trials=[]
for root in roots:
 for folder in sorted((root/'trials').iterdir()):
  if not (folder/'capture/frames.jsonl').exists():continue
  rows=[json.loads(line) for line in (folder/'capture/frames.jsonl').read_text().splitlines()]
  groups={};cache={}
  for row in rows:
   if not row.get('png'):continue
   path=folder/'capture'/row['png']
   if path.name not in cache:
    im=Image.open(path).convert('RGB');assert im.size==(1053,802)
    cache[path.name]=tuple(hashlib.sha256(im.crop(box).tobytes()).hexdigest() for box in regions.values())
   key=cache[path.name]
   if key not in groups:groups[key]=dict(first_frame=row['index'],png=row['png'],hashes=dict(zip(regions,key)),count=0)
   groups[key]['count']+=1
   if key not in global_groups:global_groups[key]=dict(trial=folder.name,path=str(path),first_frame=row['index'],hashes=dict(zip(regions,key)))
  record=dict(trial=folder.name,regions=regions,groups=list(groups.values()))
  with (folder/'roi-groups.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
  trials.append(dict(trial=folder.name,states=len(groups),frames=sum(g['count'] for g in groups.values())))
result=dict(regions=regions,global_groups=list(global_groups.values()),trials=trials)
with (roots[1]/'all-roi-groups.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
