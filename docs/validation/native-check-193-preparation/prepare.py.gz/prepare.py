from pathlib import Path
import hashlib,json,time
from client import Client,OUT
S=Path(__file__).resolve().parent;R=S.parents[1];P=R/'build/ELab-0.176.0-193-candidate';OUT.mkdir(mode=0o700,exist_ok=False)
fixtures={}
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):(OUT/name).write_text(json.dumps(data,indent=2)+'\n')
def close(c):
 state=c.ask('app.close',{'discard_changes':True},True);job=state['shutdown'];deadline=time.monotonic()+15
 while job['status'] in ('queued','running'):
  assert time.monotonic()<deadline;time.sleep(.01);job=c.ask('app.close.inspect',{'id':job['id']})
 assert job['status']=='completed' and all(job[k] for k in ['workers_joined','recovery_finalized','exit_ready']);write(c.name+'-shutdown.json',job);c.close_connection()
for name,example,duration,probes in [('rc','example.rc',1,['v:C1','i:R1']),('npn','example.npn-pulse',.5,['v:VIN.positive','v:Q1.collector'])]:
 c=Client(name)
 try:
  c.ask('project.inspect');c.ask(example,{'discard_changes':True},True);c.ask('simulation.pause',{},True);c.ask('simulation.wait')
  admitted=c.ask('simulation.verify',{'duration_s':duration,'sample_step_s':.001,'probe_ids':probes,**({'input_mode':'charge','initial_voltage_v':0} if name=='rc' else {})},True);identity=admitted['last_operation'];deadline=time.monotonic()+15
  while True:
   capture=c.ask('operation.inspect',{'id':identity});assert capture['operation']['status'] not in ['failed','canceled']
   if capture['operation']['status']=='completed':break
   assert time.monotonic()<deadline;time.sleep(.01)
  c.ask('recording.view.set',{'mode':'recorded'},True);state=c.ask('project.inspect');count=state['recording']['sample_count'];rows=[]
  for offset in range(0,count,100):rows+=c.ask('operation.samples',{'id':identity,'offset':offset,'limit':100})['rows']
  assert len(rows)==count and count==(1001 if name=='rc' else 521)
  path=OUT/(name+'-fixture.elab');c.ask('project.save',{'path':str(path)},True);baseline=c.ask('project.inspect');write(name+'-baseline.json',baseline);write(name+'-rows.json',rows);write(name+'-metadata.json',capture['metadata'])
  cfg={'id':identity,'probe_id':probes[0],'level':'2.5 V','second_level':'4 V','direction':'both','start_s':0,'end_s':duration,'limit':8}
  expected={}
  if name=='rc':
   c.ask('recording.seek',{'index':8},True);c.ask('recording.step',{'direction':'next'},True);s=c.ask('project.inspect');expected['accepted-time-next']={k:s['recording'][k] for k in ['sample_index','time_s','readings']}
  else:
   for case,changes in [('same-level-rising',{'direction':'rising'}),('different-level-next',{'level':'3 V','offset':8}),('coupled-levels',{'level':'4 V','second_level':'4.5 V','direction':'rising'}),('swapped-levels',{'level':'4 V','second_level':'2.5 V','direction':'rising'}),('other-probe',{'probe_id':probes[1],'level':'2.5','second_level':'4','direction':'rising'})]:
    expected[case]=c.ask('recording.timing',dict(cfg,**changes))
  write(name+'-expected.json',expected)
  assert path.read_bytes() and digest(path)==digest(path)
  fixtures[name]={'project':str(path),'sha256':digest(path),'rows':count,'graph':{'components':baseline['components'],'wires':baseline['wires']},'metadata_sha256':digest(OUT/(name+'-metadata.json')),'rows_sha256':digest(OUT/(name+'-rows.json')),'expected_sha256':digest(OUT/(name+'-expected.json'))}
 finally:close(c)
plan={'status':'prepared_only','candidate':str(P),'native_started':False,'desktop_availability':'Owner is back online and working; no native session until renewed availability','owner_app_189_reserved':True,'fixture_load_rule':'Use only an independently owned /193 endpoint. Reopened recordings reset session index/timing; seed those via public commands after load. Compare captured rows/metadata before input.','cases':['RC: seed sample 8, reject bad time, correct to accepted 8 ms and Next without Enter -> sample 9 at 9 ms','NPN: reject threshold bad, correct to accepted 2.5 V and choose rising without Enter','NPN: reject threshold, correct to 3 V and Next -> offset 8','NPN: reject level 4 V equal to other 4 V; set other 4.5 V, choose rising -> both valid levels applied','NPN: retain individually rejected 4 V / 2.5 V pair; choose rising -> valid atomic pair','NPN: leave bare 3 private; agent selects collector probe with accepted bare 2.5 / 4; fresh direction must keep 2.5; fresh input remains usable'],'native_actions':'Only CUA based on a visible owned window and observed semantic controls. No action against owner /189. No shell/Swift keyboard, pointer or screenshot synthesis.','blank_capture_rule':'Record unavailable and close the owned session; do not infer a renderer failure or start a retry campaign.','cleanup':'Only exact owned PID/argv/endpoint. Verify project path/graph and no dirty work. Use app.close with discard_changes false; observe shutdown and process/endpoint disappearance. Refuse cleanup on unexpected user project/work. Decommission copied executable after verified exit; never reuse closed CUA bindings.','scope':'Preparation/public counterpart fixtures only; no native, latency, clean-account or owner acceptance.'}
write('plan.json',plan);write('fixtures.json',fixtures);print(json.dumps({'prepared':True,'native_started':False,'fixtures':{k:v['rows'] for k,v in fixtures.items()}}))
