from pathlib import Path
import copy,json,math,time
from client import Client,OUT
S=Path(__file__).resolve().parent;R=S.parents[1];B=json.loads((S/'build-result-signed.json').read_text());OUT.mkdir(mode=0o700,exist_ok=False)
records=[];curves=[];checks=[]
def write(name,data):(OUT/name).write_text(json.dumps(data,indent=2)+'\n')
def close(c):
 state=c.ask('app.close',{'discard_changes':True},True);job=state['shutdown'];deadline=time.monotonic()+15
 while job['status'] in ('queued','running'):
  assert time.monotonic()<deadline;time.sleep(.01);job=c.ask('app.close.inspect',{'id':job['id']})
 assert job['status']=='completed' and all(job[k] for k in ['workers_joined','recovery_finalized','exit_ready'])
 write(c.name+'-shutdown.json',job);c.close_connection()
def physics(state):return {k:state.get(k) for k in ['run_id','electrical_revision','components','wires','result','npn','transient','mixed','undo_entry','redo_entry']}
def wait_verify(c,identity):
 deadline=time.monotonic()+15
 while True:
  v=c.ask('operation.inspect',{'id':identity});assert v['operation']['status'] not in ('failed','canceled')
  if v['operation']['status']=='completed':return v
  assert time.monotonic()<deadline;time.sleep(.01)
def rows(c,identity):
 result=[];offset=0
 while True:
  p=c.ask('operation.samples',{'id':identity,'offset':offset,'limit':100});result+=p['rows']
  if p['next_offset']==p['total']:return result
  assert p['next_offset']>offset;offset=p['next_offset']
def wait_sweep(c):
 deadline=time.monotonic()+15
 while True:
  s=c.ask('project.inspect');sweep=s['dc_sweep'];op=next(x for x in sweep['operations'] if x['id']==sweep['selected_operation']);assert op['status'] not in ('failed','canceled')
  if op['status']=='completed':return c.ask('sweep.inspect',{'id':op['id']})
  assert time.monotonic()<deadline;time.sleep(.01)

c=Client('analysis-forms')
try:
 c.ask('project.inspect');c.ask('example.rc',{'discard_changes':True},True);c.ask('simulation.pause',{},True);initial=c.ask('simulation.wait');live=physics(initial)
 parts={x['id']:x for x in initial['components']};voltage=parts['V1']['value'];resistance=parts['R1']['value'];capacitance=parts['C1']['value']
 cfg={'duration_s':.02,'sample_step_s':.001,'input_mode':'charge','initial_voltage_v':0,'capacitor_initials':[]}
 for action in ['verify','startup-reset']:
  for field in ['duration_s','sample_step_s']:
   for correction in ['accepted','different']:
    c.ask('verification.settings.set',cfg,True);before=c.ask('project.inspect');bad=dict(cfg);bad[field]='bad';refusal=c.ask('verification.settings.set',bad,True,expect_error=True);assert c.ask('project.inspect')==before
    corrected=dict(cfg);value=cfg[field]
    if correction=='different':value=.03 if field=='duration_s' else .002
    corrected[field]=('30 ms' if field=='duration_s' else '2 ms') if correction=='different' else ('20 ms' if field=='duration_s' else '1 ms')
    accepted=c.ask('verification.settings.set',corrected,True);expected=dict(cfg);expected[field]=value;assert accepted['verification_settings']==expected
    if action=='startup-reset':
     reset={'duration_s':expected['duration_s'],'sample_step_s':0,'input_mode':'auto','capacitor_initials':[]}
     after=c.ask('verification.settings.set',reset,True);assert after['verification_settings']==reset and len(after['operations'])==len(before['operations'])
    else:
     admitted=c.ask('simulation.verify',{'probe_ids':['v:C1','i:C1']},True);v=wait_verify(c,admitted['last_operation']);data=rows(c,admitted['last_operation']);assert data[-1]['time_s']==expected['duration_s']
     probes=[x['id'] for x in v['metadata']['probes']];vi=probes.index('v:C1');ii=probes.index('i:C1')
     for row in data:
      want=voltage*(1-math.exp(-row['time_s']/(resistance*capacitance)))
      assert abs(row['values'][vi]-want)<1e-9 and abs(row['values'][ii]-(voltage-want)/resistance)<1e-12
     records.append(data);write('verify-'+field+'-'+correction+'.json',{'metadata':v['metadata'],'rows':data});after=c.ask('project.inspect')
    assert physics(after)==live
    checks.append({'kind':'verification','action':action,'field':field,'correction':correction,'refusal':refusal,'snapshot_preserved_on_refusal':True,'live_physics_preserved':True})
 sweep={'component_id':'V1','parameter':'voltage','start':'0 V','stop':'5 V','points':7,'probe_ids':['v:C1','i:C1']}
 for field,bad_value,different in [('start','bad','1 V'),('stop','13 V','4 V'),('points','seven',9),('points',999,9)]:
  for correction in ['accepted','different']:
   c.ask('sweep.settings.set',sweep,True);before=c.ask('project.inspect');bad=dict(sweep);bad[field]=bad_value;refusal=c.ask('sweep.settings.set',bad,True,expect_error=True);assert c.ask('project.inspect')==before
   corrected=dict(sweep)
   if correction=='different':corrected[field]=different
   accepted=c.ask('sweep.settings.set',corrected,True);assert accepted['dc_sweep']['settings']==corrected
   c.ask('sweep.start',{},True);v=wait_sweep(c);curve=v['result'];assert len(curve['points'])==corrected['points']
   for point in curve['points']:
    assert abs(point['values'][0]-point['input'])<1e-10 and abs(point['values'][1])<1e-12
    assert point['kcl_residual_a']<1e-9 and abs(point['power_residual_w'])<1e-8
   assert physics(c.ask('project.inspect'))==live
   curves.append(curve);checks.append({'kind':'sweep','field':field,'bad':bad_value,'correction':correction,'refusal':refusal,'snapshot_preserved_on_refusal':True,'live_physics_preserved':True})
   write('sweep-'+field+'-'+str(bad_value).replace(' ','_')+'-'+correction+'.json',v)
 project=OUT/'analysis-results.elab';c.ask('project.save',{'path':str(project)},True);before=c.ask('project.inspect');assert len(before['operations'])==4 and len(before['dc_sweep']['operations'])==8
finally:close(c)
fresh=Client('fresh-reopen')
try:
 fresh.ask('project.inspect');fresh.ask('project.load',{'path':str(project)},True);restored=fresh.ask('simulation.wait');assert not restored['document']['dirty'] and restored['paused']
 assert len(restored['operations'])==4 and len(restored['dc_sweep']['operations'])==8
 old=sorted(json.dumps(x,sort_keys=True) for x in records);new=sorted(json.dumps(rows(fresh,x['id']),sort_keys=True) for x in restored['operations']);assert old==new
 old=sorted(json.dumps(x,sort_keys=True) for x in curves);new=sorted(json.dumps(fresh.ask('sweep.inspect',{'id':x['id']})['result'],sort_keys=True) for x in restored['dc_sweep']['operations']);assert old==new
 for key in ['components','wires','transient_settings']:assert restored[key]==before[key],key
 assert restored['scope']['selected']==before['scope']['selected']
 assert restored['verification_settings']=={'duration_s':.1,'sample_step_s':0,'input_mode':'auto','capacitor_initials':[]}
finally:close(fresh)
assert len(checks)==16 and len(records)==4 and len(curves)==8
report={'passed':True,'source_commit':B['source_commit'],'native_sha256':B['native_sha256'],'agent_sha256':B['agent_sha256'],'checks':checks,'verification_cases':8,'sweep_cases':8,'verification_captures':4,'sweep_curves':8,'fresh_reopen_exact_rows_and_curves':True,'independent_rc_laws_and_dc_open_capacitor_checks':True,'native_started':False,'release_qualified':False,'promoted':False,'scope':'Matching packaged headless agent. Private native draft correction is established only by the separate mounted offscreen source tests.'}
write('report.json',report);print(json.dumps({k:v for k,v in report.items() if k!='checks'}))
