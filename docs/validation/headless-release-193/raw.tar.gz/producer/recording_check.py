from pathlib import Path
import hashlib,importlib.util,json,sys,time
from client import Client,OUT
ROOT=Path(__file__).resolve().parents[2];S=Path(__file__).resolve().parent
B=json.loads((S/'build-result-signed.json').read_text());PACKAGE=Path(B['review']);AGENT=PACKAGE/'elab-agent'
sys.path.insert(0,str(ROOT/'scripts'))
OUT.mkdir(mode=0o700,exist_ok=False)
exits=[]
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def run_existing(name,filename,arguments):
 module=load(name,ROOT/'scripts'/filename);original=module.helper.Client
 class PackagedClient(original):
  def __init__(self,*args,**kwargs):
   assert not args or args[0] is None, 'No live endpoint'
   kwargs['agent_binary']=AGENT;super().__init__(*args,**kwargs)
  def close(self):
   super().close();assert self.process.returncode==0;exits.append(dict(check=name,exit_code=self.process.returncode))
 module.helper.Client=PackagedClient
 sys.argv=[filename]+arguments;module.main();return module

parity=run_existing('candidate_reference','first-version-parity.py',['--artifacts',str(OUT/'reference')])
run_existing('candidate_recording','recording-viewer-demo.py',['--output',str(OUT/'recording-viewer.json'),'--artifacts',str(OUT/'recording-viewer')])

def close(client):
 state=client.ask('app.close',dict(discard_changes=True),True);job=state['shutdown'];deadline=time.monotonic()+15
 while job['status'] in ('queued','running'):
  assert time.monotonic()<deadline;time.sleep(.01);job=client.ask('app.close.inspect',dict(id=job['id']))
 assert job['status']=='completed' and all(job[k] for k in ('workers_joined','recovery_finalized','exit_ready'))
 (OUT/(client.name+'-shutdown.json')).write_text(json.dumps(job,indent=2)+'\n');client.close_connection()

examples=[]
for filename in ['LED-2k.elab','RC-charge.elab','LED-flasher.elab']:
 original=PACKAGE/'Examples'/filename;before=hashlib.sha256(original.read_bytes()).hexdigest();document=json.loads(original.read_text());c=Client('example-'+filename[:-5])
 try:
  c.ask('project.inspect');c.ask('project.load',dict(path=str(original)),True);loaded=c.ask('simulation.wait')
  assert loaded['paused'] and not loaded['document']['dirty'] and loaded['components']==document['graph']['components'] and loaded['wires']==document['graph']['wires']
  saved=OUT/filename;c.ask('project.save',dict(path=str(saved)),True)
 finally:close(c)
 fresh=Client('reopen-'+filename[:-5])
 try:
  fresh.ask('project.inspect');fresh.ask('project.load',dict(path=str(saved)),True);reopened=fresh.ask('simulation.wait');assert reopened['paused'] and not reopened['document']['dirty']
  for k in ['components','wires','nets','transient_settings','scope_probes']:assert reopened.get(k)==loaded.get(k),(filename,k)
  for k in ['result','transient','mixed','npn']:parity.compare(loaded.get(k),reopened.get(k),filename+'.'+k)
 finally:close(fresh)
 assert hashlib.sha256(original.read_bytes()).hexdigest()==before
 examples.append(dict(example=filename,source_sha256=before,saved_sha256=hashlib.sha256(saved.read_bytes()).hexdigest(),graph_and_results_reopen=True,source_unchanged=True))

c=Client('recorded-positions');checks=[]
try:
 c.ask('project.inspect');c.ask('example.rc',dict(discard_changes=True),True);c.ask('simulation.pause',{},True);c.ask('simulation.wait')
 c.ask('verification.settings.set',dict(duration_s=1,sample_step_s=.001,input_mode='charge',initial_voltage_v=0,capacitor_initials=[],inductor_initials=[]),True)
 admitted=c.ask('simulation.verify',dict(duration_s=1,probe_ids=['v:C1','i:R1']),True);identity=admitted['last_operation'];deadline=time.monotonic()+15
 while True:
  capture=c.ask('operation.inspect',dict(id=identity));status=capture['operation']['status'];assert status not in ('failed','canceled')
  if status=='completed':break
  assert time.monotonic()<deadline;time.sleep(.01)
 c.ask('operation.select',dict(id=identity),True);c.ask('recording.view.set',dict(mode='recorded'),True)
 def rows():
  result=[]
  for offset in range(0,1001,100):result+=c.ask('operation.samples',dict(id=identity,offset=offset,limit=100))['rows']
  return result
 original_rows=rows();assert len(original_rows)==1001
 c.ask('project.save',dict(path=str(OUT/'positions-before.elab')),True);original_bytes=(OUT/'positions-before.elab').read_bytes()
 for action in ['next','previous','play']:
  for field,bad,valid in [('index',{'index':1.5},{'index':8}),('time',{'time_s':'bad'},{'time_s':'8 ms'})]:
   c.ask('recording.seek',{'index':8},True);before=c.ask('project.inspect');refusal=c.ask('recording.seek',bad,True,expect_error=True);assert before==c.ask('project.inspect')
   assert refusal['help']['summary']=='Choose a valid position in the recording.' and '0 to 1000' in refusal['help']['action']
   c.ask('recording.seek',valid,True)
   if action=='play':
    result=c.ask('recording.play',{'seconds_per_wall_second':.001},True);assert result['recording']['playing'] and result['recording']['sample_index']>=8;c.ask('recording.pause',{},True)
   else:
    result=c.ask('recording.step',{'direction':action},True);assert result['recording']['sample_index']==(9 if action=='next' else 7)
   after=c.ask('project.inspect')
   for k in ['run_id','electrical_revision','components','wires','document','transient','mixed','undo_entry','redo_entry']:assert before.get(k)==after.get(k),(action,field,k)
   checks.append(dict(action=action,field=field,refusal=refusal,accepted_index=result['recording']['sample_index'],state_preserved=True))
 assert original_rows==rows() and capture['metadata']==c.ask('operation.inspect',dict(id=identity))['metadata']
 c.ask('project.save',dict(path=str(OUT/'positions-after.elab')),True);assert original_bytes==(OUT/'positions-after.elab').read_bytes()
finally:close(c)
report=dict(passed=True,source_commit=B['source_commit'],native_sha256=B['native_sha256'],agent_sha256=B['agent_sha256'],scope='Matching packaged headless agent only. Native app is not launched. Public correction/transport checks do not establish UI draft settlement or actual native input.',reference_workflows=3,viewer_report='recording-viewer.json',examples=examples,recorded_position_cases=checks,recorded_rows=1001,recorded_rows_and_metadata_unchanged=True,saved_recording_bytes_equal=True,existing_script_process_exits=exits,release_qualified=False,promoted=False)
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['recorded_position_cases','examples','existing_script_process_exits']}))
