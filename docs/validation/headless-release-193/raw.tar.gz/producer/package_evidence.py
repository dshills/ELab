"""Preserve completed headless evidence and summarize its actual scope."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path(__file__).resolve().parents[2]
TOOLS = Path(__file__).resolve().parent
OUT = Path('/private/tmp/elab-headless-release-193')
DEST = ROOT/'docs/validation/headless-release-193'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    result = json.loads((OUT/'report.json').read_text())
    assert result['passed'] and not result['native_started']
    conformance = json.loads((OUT/'conformance/report.json').read_text())
    assert conformance['passed']
    summary = []
    for adapter in conformance['adapters']:
        assert adapter['equivalent_to_in_process']
        assert all(c['passed'] for c in adapter['electrical']['checks'])
        summary.append({'adapter': adapter['name'], 'workflows': len(adapter['workflows']),
                        'project_checks': len(adapter['project_contracts']['checks']),
                        'independent_electrical_checks': len(adapter['electrical']['checks']),
                        'inductor_checks': len(adapter['inductors']['checks']),
                        'opamp_checks': len(adapter['opamps']['checks']),
                        'opamp_storage_checks': len(adapter['opamp_storage']['checks']),
                        'capacity_checks': len(adapter['capacity']['checks'])})
    exits = list((OUT/'conformance').rglob('process-exit.json'))
    for path in exits:
        entry = json.loads(path.read_text())
        assert entry['exit_code'] == 0 and not entry['graceful_wait_timed_out']
        assert not entry.get('context_error') and not entry.get('close_error')
    responses = list((OUT/'conformance').rglob('shutdown-response.json'))
    for path in responses:
        state = json.loads(path.read_text())['response']['result']
        assert state['closed'] and state['shutdown']['status'] == 'completed'
        assert all(state['shutdown'][k] for k in ['workers_joined','recovery_finalized','exit_ready'])
    recording = json.loads((OUT/'recording/report.json').read_text())
    analysis = json.loads((OUT/'analysis/report.json').read_text())
    viewer = json.loads((OUT/'recording/recording-viewer.json').read_text())
    assert recording['passed'] and analysis['passed'] and viewer['passed']
    direct_exits = []
    for folder in ['recording', 'analysis']:
        for path in (OUT/folder).glob('*-bridge-exit.json'):
            entry = json.loads(path.read_text()); assert entry['exit_code'] == 0
            direct_exits.append(entry)
        for path in (OUT/folder).glob('*-shutdown.json'):
            entry = json.loads(path.read_text())
            assert entry['status'] == 'completed' and all(entry[k] for k in ['workers_joined','recovery_finalized','exit_ready'])
    assert all(entry['exit_code'] == 0 for entry in recording['existing_script_process_exits'])
    DEST.mkdir(exist_ok=False)
    files = []
    for base, prefix in [(OUT, 'execution'), (TOOLS, 'producer')]:
        for path in sorted(base.rglob('*')):
            if not path.is_file(): continue
            relative = path.relative_to(base)
            if (base == OUT and relative.as_posix() == 'runtime/elab-agent') or (base == TOOLS and path.name == 'elab-conformance'):
                continue
            files.append((prefix+'/'+relative.as_posix(), path.read_bytes()))
    archive = DEST/'raw.tar.gz'
    with archive.open('xb') as handle:
        with gzip.GzipFile(fileobj=handle, mode='wb', mtime=0, filename='') as compressed:
            with tarfile.open(fileobj=compressed, mode='w|') as tar:
                for name, raw in files:
                    info = tarfile.TarInfo(name); info.size = len(raw); info.mode = 0o600; info.mtime = 0
                    tar.addfile(info, io.BytesIO(raw))
    with tarfile.open(archive) as tar:
        members = tar.getmembers(); assert len(members) == len(files)
        for (name, raw), member in zip(files, members):
            assert member.isfile() and member.name == name and tar.extractfile(member).read() == raw
    quality = json.loads((TOOLS/'source-quality-match.json').read_text())
    report = {'date': '2026-10-20', 'kind': 'final-candidate-headless-release-qualification',
              'candidate': result['candidate'], 'agent_sha256': result['agent_sha256'],
              'controller_sha256': result['controller_sha256'], 'passed': True,
              'source_quality': quality, 'adapters': summary,
              'recording': {'historical_native_reference_workflows': 3, 'viewer_contracts': len(viewer['contracts']),
                            'viewer_refusals': len(viewer['refusals']), 'position_correction_cases': len(recording['recorded_position_cases']),
                            'position_rows_preserved': recording['recorded_rows'],
                            'capture_metadata_and_saved_bytes_preserved': True, 'examples_fresh_reopened': len(recording['examples'])},
              'analysis': {k:analysis[k] for k in ['verification_cases','sweep_cases','verification_captures','sweep_curves','fresh_reopen_exact_rows_and_curves','independent_rc_laws_and_dc_open_capacitor_checks']},
              'shutdown': {'conformance_external_exits_zero':len(exits),'conformance_shutdown_responses_joined_ready':len(responses),
                           'direct_protocol_exits_zero_joined_ready':len(direct_exits),'existing_script_exits_zero':len(recording['existing_script_process_exits']),
                           'no_conformance_graceful_timeout':True},
              'offline': {'file_denial_controls':len(result['controls']['files']),'ip_denial_controls':len(result['controls']['network']),
                          'allowed_control_read_passed':result['controls']['allowed_read'],
                          'sandboxed_clients':'All 68 conformance external processes and nine direct protocol processes.',
                          'unrestricted_clients':'The in-process controller and five historical-workflow/viewer helper processes. These five use the exact copied agent without the sandbox wrapper.',
                          'producer_scope_correction':'The raw orchestrator scope string overstates sandboxing if read as applying to every helper. This report narrows the claim to the observed invocation paths; no check was rerun or output relabeled.'},
              'package_unchanged':result['package_unchanged'],'protected_executables_sdk_unchanged':result['protected_executables_sdk_unchanged'],
              'native_started':False,'desktop_interaction':False,'native_input_accepted':False,'owner_workflow_accepted':False,
              'release_qualified':False,'promoted':False,'elapsed_seconds':result['elapsed_seconds'],
              'raw_archive':{'path':archive.name,'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files)},
              'scope':'Exact copied /193 headless integration, independent numerical checks, protocol corrections and persistence. Existing source quality retained by exact match. Native app, private UI buffers, visible performance, ordinary startup, clean-account installation and owner acceptance remain separate.'}
    (DEST/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    (DEST/'raw-manifest.json').write_text(json.dumps({name:sha(raw) for name,raw in files},indent=2)+'\n')
    print(json.dumps({k: report[k] for k in ['passed','shutdown','recording','analysis','raw_archive']}))


if __name__ == '__main__': main()
