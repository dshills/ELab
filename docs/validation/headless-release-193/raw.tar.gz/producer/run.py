"""Exact /193 headless release checks. Never starts a native app or attaches to a session."""
from pathlib import Path
import importlib.util
import json
import shutil
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
TOOLS = Path(__file__).resolve().parent
OUT = Path('/private/tmp/elab-headless-release-193')
PACKAGE = ROOT/'build/ELab-0.176.0-193-candidate'
sys.path.insert(0, str(ROOT/'scripts'))
from runtime_isolation import (controls, development_canaries, digest,
                               execute_stage, launcher, sandbox_profile)


def write(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n')


def tree(path):
    return {str(p.relative_to(path)): {'sha256': digest(p), 'mode': p.stat().st_mode & 0o777}
            for p in sorted(path.rglob('*')) if p.is_file()}


def main():
    expected_agent = '537c14d6f7075ba6105085660912fe19a3be29ec5be7fc45fe9cab4c9fb083b9'
    assert digest(PACKAGE/'elab-agent') == expected_agent
    assert digest(PACKAGE/'ELab.app/Contents/MacOS/ELab') == 'ee9371715982f5c1c998421a3554efefba214cde8f57367a924a388dca3a0afd'
    OUT.mkdir(mode=0o700, exist_ok=False)
    before = tree(PACKAGE)
    protected = {str(p): digest(p) for p in [
        ROOT/'build/ELab.app/Contents/MacOS/ELab',
        ROOT/'build/ELab-0.172.0-189-alpha/ELab.app/Contents/MacOS/ELab',
        ROOT/'build/ELab-0.172.0-189-alpha/elab-agent',
        ROOT/'third_party/vellum/sdk.lock.json',
        ROOT/'third_party/vellum/vellum-b22478c.tar.gz']}
    write(OUT/'package-before.json', before)
    write(OUT/'protected-before.json', protected)
    spec = importlib.util.spec_from_file_location('owned_child', ROOT/'build/.vellum-sdk-b22478c/scripts/child_process.py')
    child = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(child)
    runtime = OUT/'runtime'
    runtime.mkdir(mode=0o700)
    shutil.copy2(PACKAGE/'elab-agent', runtime/'elab-agent')
    shutil.copytree(PACKAGE/'Examples', runtime/'Examples')
    assert digest(runtime/'elab-agent') == expected_agent
    canaries = development_canaries(ROOT/'build/.vellum-sdk-b22478c')
    profile = OUT/'runtime.sb'
    profile.write_text(sandbox_profile([Path(x['root']) for x in canaries.values()]))
    launcher(runtime/'agent', profile, runtime/'elab-agent', runtime)
    result = {'passed': False, 'candidate': '0.176.0 /193', 'native_started': False,
              'desktop_interaction': False, 'promoted': False, 'agent_sha256': expected_agent,
              'controller_sha256': digest(TOOLS/'elab-conformance'), 'stages': [],
              'scope': 'Owned headless processes only; external agent denies development files and outbound IP. In-process controller is unrestricted. No native binding, visible latency, owner, clean-account or full-MVP acceptance.'}
    save = lambda: write(OUT/'report.json', result)
    save()
    started = time.monotonic()
    try:
        result['controls'] = controls(OUT, profile, canaries, child.run_child)
        write(OUT/'development-canaries.json', canaries)
        execute_stage(result, OUT, runtime, 'three-adapter-conformance', [
            str(TOOLS/'elab-conformance'), '--agent-binary', str(runtime/'agent'),
            '--artifacts', str(OUT/'conformance'), '--project-contract-suite',
            '--electrical-suite', '--inductor-suite', '--opamp-suite',
            '--opamp-storage-suite', '--capacity-suite'], 240, child.run_child, save)
        for name in ['recording', 'analysis']:
            execute_stage(result, OUT, runtime, name, [
                '/usr/bin/env', 'PYTHONDONTWRITEBYTECODE=1', 'ELAB_HEADLESS_CASE='+name,
                sys.executable, '-B', str(TOOLS/(name+'_check.py'))],
                120, child.run_child, save)
        conformance = json.loads((OUT/'conformance/report.json').read_text())
        assert conformance['passed']
        assert [x['name'] for x in conformance['adapters']] == ['in-process', 'headless-stdio', 'headless-socket']
        assert all(x['equivalent_to_in_process'] for x in conformance['adapters'])
        for name in ['recording', 'analysis']:
            assert json.loads((OUT/name/'report.json').read_text())['passed']
        assert before == tree(PACKAGE)
        assert all(digest(Path(p)) == h for p, h in protected.items())
        result.update(passed=True, package_unchanged=True, protected_executables_sdk_unchanged=True,
                      elapsed_seconds=time.monotonic()-started)
    except BaseException as error:
        result['error'] = type(error).__name__+': '+str(error)
        raise
    finally:
        save()
    print(json.dumps({k: result[k] for k in ['passed', 'candidate', 'native_started', 'elapsed_seconds']}))


if __name__ == '__main__':
    main()
