from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent
out=root/'docs/validation/validation-scroll-222';sha=lambda b:hashlib.sha256(b).hexdigest()
report=json.loads((s/'native-report.json').read_text());assert report['passed']
files={}
for p in sorted(s.rglob('*')):
 rel=p.relative_to(s)
 if p.is_file() and 'build' not in rel.parts and p.suffix in {'.py','.json','.txt','.png'}:
  files[rel.as_posix()]=p.read_bytes()
with (out/'native-raw.tar.gz').open('xb') as disk:
 with gzip.GzipFile(fileobj=disk,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name,data in sorted(files.items()):
    info=tarfile.TarInfo(name);info.size,info.mode,info.mtime=len(data),0o644,0
    tar.addfile(info,io.BytesIO(data))
(out/'native-raw-manifest.json').write_text(json.dumps({n:sha(b) for n,b in sorted(files.items())},indent=2)+'\n')
report.update(raw_archive_sha256=sha((out/'native-raw.tar.gz').read_bytes()),raw_members=len(files))
(out/'native-report.json').write_text(json.dumps(report,indent=2)+'\n')
prior=json.loads((root/'docs/validation/native-guidance-221/native-acceptance-pending.json').read_text())
pending=dict(prior)
pending.update(source_commit=report['source_commit'],native_sha256=json.loads((s/'build-result-signed.json').read_text())['native_sha256'],agent_sha256=json.loads((s/'build-result-signed.json').read_text())['agent_sha256'],
 completed_checks_for_copied_runtime=[1,2,4,5,7,16,17,18],remaining_checks_count=10,
 new_native_checks=[7,16],carried_forward_checks=[1,2,4,5,17,18],prior_evidence='../native-guidance-221/README.md',
 evidence='README.md',current_build_fresh_native_checks=[7,16],
 additional_open_issue='Playback step from 0.03 through 0.031 can display 0.031999998 after Up. Accepted numerical behavior is within the existing float32 boundary; display formatting needs a focused repair that preserves tight bounds and private text.')
(out/'native-acceptance-pending.json').write_text(json.dumps(pending,indent=2)+'\n')
with (out/'README.md').open('a') as f:f.write('''

## Native qualification

[Native receipt](native-report.json), [captures and raw checks](native-raw.tar.gz),
[hashes](native-raw-manifest.json), [remaining checks](native-acceptance-pending.json).

The clean 0.181.21 /222 candidate and matching agent are built from `2d3d56fb`.
Its ordinary update retains the existing test installation identity, launcher and
sandbox. Normal CUA Quit and reopen succeed without another owner question.
The tested copy has identical nonempty Mach-O sections to the original sealed
candidate, whose exact bundle bytes remain untouched. /221 is retained as backup.

Native live/recorded start and end fields retain both malformed and out-of-range
text, keep current focus visible and accept the first correction to the accepted
value. Actual 0–20 ms live and 0–1 ms recorded bounds and units are readable in
the Simulate guidance. Accepted physical/document/recording state stays exact;
viewport/revision/actor changes are reported separately. Focused and unfocused
numeric wheel checks leave the complete public snapshots identical. An unfinished
0.25 V draft survives wheel input, scope layout changes and agent repaint.
Deliberate scrolling away stays put; returning shows the same private draft.
Typing, plus and Up still commit through shared state. Their raw float32 step can
show excess digits (`0.031999998`); that cosmetic issue is recorded, not passed.

All 1,001 stored rows match the preceding native fixture. The 2,044 independent
live/recorded voltage references pass, maximum absolute error below 5e-16 V.
Signatures, original saved file, 894 source inputs, candidate and /205 download
remain unchanged. The app is left clean, paused, Light, with scope visible.
Checks 7 and 16 have fresh /222 native evidence; six other accumulated checks
retain their earlier scoped evidence. Ten of the original eighteen remain open,
including the native Save Command-A observation and controlled divider speeds.
This package stays held; it does not replace the qualified /205 download.
''')
p=root/'research/103-validation-scroll-and-drafts.md'
with p.open('a') as f:f.write('''

The clean /222 candidate now passes the affected native checks in the existing
owned installation, without another permission question. Live and recorded
interval syntax/bounds/correction, number-wheel preservation, unfinished drafts
across layout, and deliberate editing all pass. All 1,001 recorded rows and
2,044 independent RC voltages match. The original file, /221 backup and /205
release remain preserved; the final test document is clean and paused.

Eight accumulated checklist items now have scoped evidence, with ten still open.
Fresh /222 checks are specifically 7 and 16. A new cosmetic follow-up is recorded:
playback plus then Up from 0.03 displays 0.031999998. Fix formatting without losing
numeric bounds, authoritative accepted values or private drafts. No new feature
is needed. Native Save Command-A and controlled divider speeds remain distinct
open checks. No release promotion or owner-review wait is introduced.
''')
p=root/'research/34-first-version-plan.md';text=p.read_text();a=text.index('**Current maintenance work:**');b=text.index('\n## Historical plan',a)
text=text[:a]+'''**Current maintenance work:** /222 repairs validation scrolling and unfinished
numeric drafts. [Implementation and native checks](103-validation-scroll-and-drafts.md).
Eight of eighteen accumulated native checks have scoped evidence; ten remain.
Fresh /222 checks cover live/recorded interval correction and numeric wheel/edit
behavior; six unaffected items retain earlier evidence. The native Save
Command-A observation and controlled divider speeds remain open. A cosmetic
numeric-step formatting issue is recorded for a focused repair.

The /221 footer and native Light/Dark inset, /220 manual-step, /219 slider,
/218 Verify endpoint and /217 numeric wheel repairs remain included.
[Electronics reference checks](95-gate-common-mode.md) cover seven RC-driven
MOSFET circuits and active-work preservation. The /207–/222 changes stay held for
the remaining native acceptance and do not replace /205. Owner review remains
deferred. Standing run/desktop authorization is saved in `AGENTS.md`; the /222
ordinary update and reopen proceeded without another owner permission question.
''' +text[b:];p.write_text(text)
p=root/'research/80-overnight-work-plan.md'
with p.open('a') as f:f.write('''

## Checkpoint: native validation layout

The existing test installation has been updated normally through /220, /221 and
/222, preserving identity, sandbox and backups, without a new permission question.
The [latest repair](103-validation-scroll-and-drafts.md) qualifies affected native
interval and number-field behavior; full framework/application checks pass.
Ten original native checks remain open. Next prioritize the newly reproduced
numeric-step display artifact, then the remaining keyboard/state-contract checks.
The /205 download remains preserved. Do not repeat the completed unaffected
source gates for this evidence-only checkpoint.
''')
print(json.dumps({'native_evidence_members':len(files),'remaining_original_native_checks':10,'fresh_native_checks':[7,16]}))
