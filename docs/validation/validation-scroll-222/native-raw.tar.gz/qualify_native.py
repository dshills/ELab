from pathlib import Path
import hashlib,importlib.util,json,math,subprocess,sys
root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda n:json.loads((stage/(n+'.json')).read_text())
ignored={'revision','command_revision','last_actor','viewport'}
for mode in ['live','recorded']:
 baseline=read('native-baseline' if mode=='live' else 'native-recorded-baseline')
 for side in ['start','end']:
  for outcome in ['refused','corrected']:
   state=read(f'native-{mode}-{side}-{outcome}')
   assert {k:v for k,v in baseline.items() if k not in ignored}=={k:v for k,v in state.items() if k not in ignored},(mode,side,outcome)
base=read('native-numeric-baseline')
assert read('native-numeric-unfocused-wheel')==read('native-numeric-focused-wheel')==base
for name,target in [('typed',.03),('button',.031),('arrow',.032)]:
 s=read('native-number-'+name)
 assert math.isclose(s['transient_settings']['seconds_per_wall_second'],target,abs_tol=3e-9),name
 assert s['transient_settings']['initial_voltage_v']==0
 assert s['paused'] and s['document']['dirty']
# Every baseline RC trace is checked against its independent exact equation.
errors=[]
for trace in base['scope']['traces']:
 for point in trace['points']:
  expected=5 if trace['probe']['id']=='v:V1.positive' else 5*-math.expm1(-point['time_s']/.01)
  errors.append(abs(point['value']-expected));assert math.isclose(point['value'],expected,rel_tol=1e-12,abs_tol=1e-12)
spec=importlib.util.spec_from_file_location('client',root/'scripts/persistence-demo.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
c=h.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json',command_preconditions=True,agent_binary=root/'build/ELab-0.181.21-222-candidate/elab-agent')
try:
 final=c.ask('project.inspect');rows=[];offset=0
 while True:
  page=c.ask('operation.samples',{'id':final['selected_operation'],'offset':offset,'limit':200});rows.extend(page['rows'])
  if len(rows)==page['total']:break
  offset=page['next_offset']
 assert rows==json.loads((root/'build/native-acceptance-220-tools/native-recording-rows.json').read_text()) and len(rows)==1001
 for row in rows:
  for actual,target in zip(row['values'],[5*-math.expm1(-row['time_s']/.01),5],strict=True):
   errors.append(abs(actual-target));assert math.isclose(actual,target,rel_tol=1e-12,abs_tol=1e-12)
 (stage/'native-captured-rows.json').write_text(json.dumps(rows,indent=2)+'\n')
 assert not final['document']['dirty'] and final['paused'] and final['transient_settings']['initial_voltage_v']==0
 assert final['transient']['sample']['time_s']==0 and final['theme']=='light' and final['scope_visible']
 (stage/'native-final-state.json').write_text(json.dumps(final,indent=2)+'\n')
finally:c.close()
project=read('preserved-project');assert sha(Path(project['path']))==project['sha256']
inputs=read('source-inputs');assert all(sha(root/p)==h for p,h in inputs.items())
build=read('build-result-signed');installed=read('prepared-update');app=Path(installed['installed'])
assert sha(app/'Contents/MacOS/ELab Cursor Recovery')==installed['native_sha256']
with (stage/'signature-after-native.txt').open('x') as log:subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict','--verbose=2',str(app)],stdout=log,stderr=-2,check=True)
sys.path.insert(0,str(root/'scripts'));from runtime_isolation import bundle_tree
assert bundle_tree(Path(build['review'])/'ELab.app')==build['source_bundle']
assert sha(app.parent/'.ELab Cursor Recovery-221-backup.app/Contents/MacOS/ELab Cursor Recovery')=='aae4ff09d6676c45b49eee5519ae6abbbd195e380812ce11ca971fcabf53a929'
assert sha(root/'build/releases/ELab-0.181.4-macos-arm64.zip')=='d13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
report=dict(passed=True,source_commit=build['source_commit'],version=build['version'],build=build['build'],
 original_candidate_bundle_unchanged=True,exact_original_bundle_launched=False,code_equivalent_copy_native_sha256=installed['native_sha256'],
 normal_cua_launch=True,no_new_permission_question=True,identity_launcher_sandbox_unchanged=True,prior_installation_preserved=True,
 live_recorded_start_end_validation_native_passed=True,syntax_and_bounds_refusals_retained=True,
 first_correction_to_accepted_value_passed=True,actual_bounds_units_visibly_readable=True,
 validation_preserves_accepted_state_except=sorted(ignored),number_wheel_full_public_snapshots_exact=True,
 numeric_draft_preserved_across_wheel_and_scope_layout=True,deliberate_scroll_away_respected=True,
 deliberate_typing_button_key_passed=True,numeric_step_display_precision_followup=True,
 stored_rows_exact=1001,independent_voltage_checks=len(errors),maximum_absolute_error_v=max(errors),
 strict_signature_valid=True,preserved_205_download_unchanged=True,fixture_file_unchanged=True,
 source_inputs_unchanged=len(inputs),final_clean_paused_light_visible_scope=True,
 current_build_native_checks=[7,16],other_native_checks_not_retested=True,release_ready=False)
(stage/'native-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
