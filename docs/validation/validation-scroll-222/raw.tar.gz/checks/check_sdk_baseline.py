from pathlib import Path
import hashlib,json,os,subprocess
root=Path('/Users/dshills/Development/projects/ELab'); sdk=root/'build/vellum-public-e58d405'; stage=Path(__file__).resolve().parent
names=['driver.go','manual_offscreen.go','accessibility.go','controls.go']; current={name:(sdk/'drivers/cogent'/name).read_bytes() for name in names}
helper=sdk/'drivers/cogent/focus_scroll.go'; helper_bytes=helper.read_bytes(); disabled=stage/'focus_scroll.go.disabled.txt'; assert not disabled.exists()
(stage/'repair-inputs').mkdir()
for name,data in current.items():(stage/'repair-inputs'/(name+'.txt')).write_bytes(data)
(stage/'repair-inputs/focus_scroll.go.txt').write_bytes(helper_bytes)
try:
 for name in names:(sdk/'drivers/cogent'/name).write_bytes((stage/(name+'.before.txt')).read_bytes())
 helper.rename(disabled)
 env=dict(os.environ,GOWORK='off',GOPROXY='off',GOTOOLCHAIN='local',GOCACHE=str(root/'build/go-cache'))
 with (stage/'sdk-before-test.txt').open('x') as log:
  result=subprocess.run(['go','test','-p=1','-race','-tags=offscreen','-run','^TestManaged(FocusScrollReveal|NumberFieldDraftSurvivesParentStructureChange)','-count=1','-v','.'],cwd=sdk/'drivers/cogent',env=env,stdout=log,stderr=-2,timeout=120)
 assert result.returncode==1,result.returncode
 text=(stage/'sdk-before-test.txt').read_text(); assert 'inserted content hid the focused editor' in text and 'unrelated parent insertion erased or committed the private number' in text
finally:
 for name,data in current.items():(sdk/'drivers/cogent'/name).write_bytes(data)
 if disabled.exists():disabled.rename(helper)
 assert helper.read_bytes()==helper_bytes
 assert all((sdk/'drivers/cogent'/name).read_bytes()==data for name,data in current.items())
(stage/'sdk-baseline-report.json').write_text(json.dumps({'pre_repair_exit_code':result.returncode,'focused_text_and_number_clipping_reproduced':True,'numeric_draft_reset_reproduced':True,'candidate_source_restored_exactly':True,'verified_sdk_caches_edited':False},indent=2)+'\n')
print('Original SDK reproduces focused-editor clipping and independent numeric draft reset; candidate restored exactly')
