"""Public semantic API for the owned /222 native session; never launches UI."""
from pathlib import Path
import hashlib, importlib.util, json, re, sys
root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
assert len(sys.argv) in [3, 5]
mode, tag = sys.argv[1:3]
assert mode in ['snapshot', 'command', 'setup-pot', 'setup-rc']
assert re.fullmatch(r'[a-z0-9-]+', tag)
path = stage/(tag+'.json')
assert not path.exists()
installed = json.loads((stage/'prepared-update.json').read_text())
native = Path(installed['installed'])/'Contents/MacOS/ELab Cursor Recovery'
assert hashlib.sha256(native.read_bytes()).hexdigest() == installed['native_sha256']
spec = importlib.util.spec_from_file_location('client', root/'scripts/persistence-demo.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
client = helper.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json', command_preconditions=True,
                       agent_binary=root/'build/ELab-0.181.21-222-candidate/elab-agent')
try:
    if mode == 'setup-pot':
        client.ask('project.load', {'path': str(root/'build/inspector-slider-wheel-219-tools/Pot wheel baseline.elab'), 'discard_changes': True}, True)
        client.ask('simulation.pause', {}, True)
        client.ask('simulation.wait')
        client.ask('component.select', {'id': 'Timing'}, True)
        result = client.ask('workspace.inspector.set', {'section': 'component'}, True)
    elif mode == 'setup-rc':
        client.ask('example.rc', {'discard_changes': True}, True)
        client.ask('simulation.pause', {}, True)
        client.ask('simulation.wait')
        result = client.ask('workspace.inspector.set', {'section': 'simulation'}, True)
    elif mode == 'command':
        assert len(sys.argv) == 5
        result = client.ask(sys.argv[3], json.loads(sys.argv[4]), True)
    else:
        result = client.ask('project.inspect')
    path.write_text(json.dumps(result, indent=2)+'\n')
    state = client.ask('project.inspect')
    print(json.dumps(dict(saved=tag, command_revision=state['command_revision'], paused=state['paused'],
                          dirty=state['document']['dirty'], time_s=(state.get('transient') or {}).get('sample', {}).get('time_s'))))
finally:
    client.close()
