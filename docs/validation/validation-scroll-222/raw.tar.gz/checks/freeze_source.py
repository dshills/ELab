"""Freeze the focused repair and verified dependency/application checks."""
import gzip,hashlib,io,json,re,subprocess,tarfile
from pathlib import Path
root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
out=root/'docs/validation/validation-scroll-222'
sha=lambda data:hashlib.sha256(data).hexdigest()
assert not out.exists()
for name in ['quality','sdk-quality']:
 assert (stage/(name+'-exit-code.txt')).read_text().strip()=='0'
inputs=json.loads((stage/'source-inputs.json').read_text())
assert all(sha((root/p).read_bytes())==h for p,h in inputs.items())
prior=json.loads((root/'build/footer-layout-221-tools/source-inputs.json').read_text())
assert all(inputs[p]==h for p,h in prior.items() if p.startswith('workbench/'))
assert all(inputs[p]==h for p,h in prior.items() if p.startswith('desktop/') and p.endswith('.go') and not p.endswith('_test.go'))
lock=json.loads((root/'third_party/vellum/sdk.lock.json').read_text())
assert sha((root/lock['archive']).read_bytes())==lock['sha256']
assert sha((root/lock['compatibility_patch']['path']).read_bytes())==lock['compatibility_patch']['sha256']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root/'build/vellum-public-e58d405').strip()
quality=(stage/'quality.txt').read_text()
assert 'Ran 67 tests' in quality and 'Ran 30 tests' in (stage/'sdk-quality.txt').read_text()
times=re.findall(r'ok\s+github.com/dshills/elab/desktop\s+(\d+\.\d+)s',quality)
assert len(times)==2,times
assert 'PASS\nok ' in (stage/'sdk-focused-final.txt').read_text()
assert 'PASS\nok ' in (stage/'prospective-both-fields-test.txt').read_text()
assert sha((root/'build/releases/ELab-0.181.4-macos-arm64.zip').read_bytes())=='d13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
files={}
for folder,label in [(stage,'checks'),(root/'build/native-intervals-221-tools','native-before')]:
 for p in sorted(folder.rglob('*')):
  rel=p.relative_to(folder)
  if p.is_file() and p.suffix in {'.py','.json','.txt','.png','.mod','.sum'} and 'build' not in rel.parts:
   files[label+'/'+rel.as_posix()]=p.read_bytes()
changed=sorted(p for p,h in inputs.items() if prior.get(p)!=h)
for p in changed:
 if p!=lock['archive']:files['source/'+p]=(root/p).read_bytes()
files['source/AGENTS.md']=(root/'AGENTS.md').read_bytes()
files['source/external-artifacts.json']=(json.dumps({lock['archive']:lock['sha256']},indent=2)+'\n').encode()
out.mkdir(parents=True)
with (out/'raw.tar.gz').open('xb') as disk:
 with gzip.GzipFile(fileobj=disk,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name,data in sorted(files.items()):
    info=tarfile.TarInfo(name);info.size,info.mode,info.mtime=len(data),0o644,0
    tar.addfile(info,io.BytesIO(data))
(out/'raw-manifest.json').write_text(json.dumps({p:sha(d) for p,d in sorted(files.items())},indent=2)+'\n')
(out/'source-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
report=dict(application_quality_passed=True,sdk_quality_passed=True,python_tests=67,sdk_python_tests=30,
 source_parent_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 source_inputs=len(inputs),changed_source_inputs=changed,desktop_race_seconds=float(times[0]),mounted_race_seconds=float(times[1]),
 sdk=lock,sdk_member_comparison=json.loads((stage/'sdk-member-comparison.json').read_text()),
 sdk_baseline=json.loads((stage/'sdk-baseline-report.json').read_text()),
 production_app_go_and_backend_unchanged=True,app_interval_regression_cases=4,
 native_before=dict(version='0.181.20 /221',interval_validation_focus_clipped=True,
  numeric_source_selection_preserved_private_draft=True,numeric_layout_bug_reproduced_offscreen=True,
  divider_default_cua_drag_passed=True,controlled_native_drag_speed_qualified=False),
 native_candidate_acceptance_passed=False,release_ready=False,preserved_download='0.181.4 /205',
 new_features=0,owner_review_required=False,raw_archive_sha256=sha((out/'raw.tar.gz').read_bytes()),raw_members=len(files))
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'README.md').write_text('''# Validation layout and numeric drafts /222

[Receipt](report.json), [frozen inputs](source-inputs.json),
[raw evidence](raw.tar.gz), [member hashes](raw-manifest.json).

The running /221 app reproduces a real inspector defect: rejecting a scope
interval inserts guidance above the scrolled controls and hides the newly
focused field. The production inspector regression fails before repair.
A one-shot post-layout reveal retains the current focus owner while keeping it
visible. Deliberate scrolling away and replaced/disabled editors cancel it.
Four live/recorded start/end production cases pass without changing accepted
state. A separate managed numeric-field regression reproduces lost private text
after a parent structure change; the pinned native updater no longer resets it.
Native source selection already retained the draft on /221 and is not claimed
as a native reproduction of that separate layout bug.

The complete framework normal/offscreen race/vet and preparation checks pass.
The complete application lint/staticcheck, 67 Python checks, root and desktop
race/vet, production mounted race and offscreen vet pass. All frozen inputs and
8,437 SDK member hashes match. Upstream dependency/notices/bootstrap bytes are
unchanged. Historical caches, packages, the /221 installation and /205 download
are preserved. No verified cache is edited. New candidate native qualification
is separate; this report does not promote a release or close all native checks.
''')
(root/'research/103-validation-scroll-and-drafts.md').write_text('''# Validation layout and unfinished numeric values

October 24, 2026. [Evidence](../docs/validation/validation-scroll-222/README.md).

Native testing reproduced focus moving outside the scrolled Simulate inspector
when interval validation adds guidance. The same production inspector fails in
live and recorded mounted checks. The narrow Vellum repair reveals the current
eligible focus once after layout, preserving explicit scrolling and ownership.
A separate framework regression found that native Spinner updates discard an
unfinished number after a parent structure change. Managed synchronization now
owns accepted-value refresh without erasing the private draft.

The four production interval cases and focused framework regressions pass,
along with full framework/application quality. The public command surface,
electronics models and production application Go sources are unchanged.
Native candidate verification remains separate. Default native divider drags
passed; controlled slow/fast input is still unqualified. The standing launch
and desktop authorization remains saved in AGENTS.md; no new question is needed.
''')
with (root/'research/README.md').open('a') as f:
 f.write('\n- [Validation layout and numeric drafts](103-validation-scroll-and-drafts.md): focused interval visibility and retained unfinished values across layout, with unchanged electrical commands and full source checks.\n')
print(json.dumps(report))
