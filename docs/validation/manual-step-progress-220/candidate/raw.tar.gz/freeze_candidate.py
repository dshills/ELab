"""Freeze exact-agent progress/physics checks without claiming new native input."""
from pathlib import Path
import gzip, hashlib, io, json, subprocess, sys, tarfile
root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
out = root/'docs/validation/manual-step-progress-220'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
build = json.loads((stage/'build-result-signed.json').read_text())
protocol = json.loads((stage/'protocol-report.json').read_text())
assert build['passed'] and protocol['passed'] and len(protocol['cases']) == 8
assert protocol['source_commit'] == build['source_commit']
assert all(c['passed'] and c['exit_code'] == 0 and c['shutdown']['workers_joined'] and c['shutdown']['exit_ready'] for c in protocol['cases'])
assert not subprocess.check_output(['git', 'status', '--porcelain']).strip()
inputs = json.loads((out/'source-inputs.json').read_text())
assert len(inputs) == 890 and all(sha(root/p) == h for p, h in inputs.items())
sys.path.insert(0, str(root/'scripts'))
from runtime_isolation import bundle_tree
app = Path(build['review'])/'ELab.app'
assert bundle_tree(app) == build['source_bundle']
assert sha(app/'Contents/MacOS/ELab') == build['native_sha256']
assert sha(Path(build['review'])/'elab-agent') == build['agent_sha256'] == protocol['agent_sha256']
verified = subprocess.run(['/usr/bin/codesign', '--verify', '--deep', '--strict', '--verbose=2', str(app)], capture_output=True)
(stage/'signature-after-agent.txt').write_bytes(verified.stdout+verified.stderr)
verified.check_returncode()
prior = json.loads((root/'docs/validation/slider-wheel-219/candidate-report.json').read_text())
assert sha(Path(prior['candidate'])/'ELab.app/Contents/MacOS/ELab') == prior['native_sha256']
assert sha(Path(prior['candidate'])/'elab-agent') == prior['agent_sha256']
assert sha(root/'build/releases/ELab-0.181.4-macos-arm64.zip') == 'd13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
receipt = dict(version=build['version'], build=build['build'], source_commit=build['source_commit'],
               candidate=build['review'], native_sha256=build['native_sha256'], agent_sha256=build['agent_sha256'],
               clean_build_vcs=True, strict_ad_hoc_signature_valid=True, bundle_unchanged_after_agent_checks=True,
               source_inputs_still_match=890, matching_headless_agent_passed=True, completed_cases=8,
               physical_traces_matching_219=5, independent_rc_readings=16,
               max_voltage_error_v=protocol['max_voltage_error_v'], max_current_error_a=protocol['max_current_error_a'],
               maximum_sample_boundary_passed=True, next_larger_duration_refusal_exact=True,
               discovery_explains_target_count=True, all_owned_headless_workers_joined=True,
               owned_agent_exit_codes=[0]*8, previous_candidate_preserved=True,
               graphical_app_launched=False, native_acceptance_passed=False, promotion_status='held',
               release_ready=False, published=False, owner_review_required=False, preserved_download='0.181.4 /205',
               limitations='Exact-agent checks qualify reporting and unchanged sampled physics. Earlier UI repairs still require their separately listed changed-candidate native acceptance. Ad-hoc integrity is not Developer ID/notarization.')
(out/'candidate-report.json').write_text(json.dumps(receipt, indent=2)+'\n')
pending = json.loads((root/'docs/validation/slider-wheel-219/native-acceptance-pending.json').read_text())
pending.update(source_commit=build['source_commit'], native_sha256=build['native_sha256'], agent_sha256=build['agent_sha256'])
(out/'native-acceptance-pending.json').write_text(json.dumps(pending, indent=2)+'\n')
evidence = out/'candidate'
assert not evidence.exists()
evidence.mkdir()
names = ['build.txt', 'package.txt', 'signature-signed-verify.txt', 'signature-signed-details.txt', 'signature-after-agent.txt',
         'build-result-signed.json', 'source-commit.txt', 'build_candidate.py', 'protocol_check.py', 'protocol-check.txt',
         'protocol-report.json', 'freeze_candidate.py']
files = {p: (stage/p).read_bytes() for p in names}
for p in sorted((stage/'candidate-cases').rglob('*.json')):
    files[p.relative_to(stage).as_posix()] = p.read_bytes()
for p in sorted((stage/'build').glob('*-build-info.txt')):
    files[p.relative_to(stage).as_posix()] = p.read_bytes()
with (evidence/'raw.tar.gz').open('xb') as disk:
    with gzip.GzipFile(fileobj=disk, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(files.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
(evidence/'raw-manifest.json').write_text(json.dumps({p: hashlib.sha256(data).hexdigest() for p, data in sorted(files.items())}, indent=2)+'\n')
(evidence/'README.md').write_text('''# /220 clean package and matching agent

The exact packaged agent completes eight jobs with matching planned/committed
counts: exact, numeric/unit tiny tails, a seeded origin, a normal partial final
interval, an adjacent endpoint, a tail above the snapping threshold and 1,000
samples. The next representable duration beyond the bound still refuses with
an unchanged snapshot. Detailed discovery publishes the actual target policy.

All five original-case physical traces/results exactly match /219, and sixteen
independent analytical RC voltage/current readings pass. Source, dirty state and
history remain unchanged by stepping. All eight headless processes join workers
and exit 0. The complete app bundle remains unchanged with valid strict ad-hoc
integrity; all three built executables identify the clean source revision.

No graphical app is launched. This candidate remains held for the accumulated
UI acceptance checks; /219 and the qualified /205 download stay preserved.
''')
with (out/'README.md').open('a') as stream:
    stream.write('\nThe [clean /220 candidate and matching agent](candidate-report.json) pass\neight complete-count cases, exact physical comparison with five /219 traces,\nsixteen analytical RC readings and unchanged over-bound refusal. All owned\nworkers join and exit 0. The candidate remains held for the unchanged\n[native acceptance list](native-acceptance-pending.json); /205 stays current.\n')
notes = root/'research/99-manual-step-progress.md'
notes.write_text(notes.read_text().replace('Clean package qualification follows.',
    'The clean /220 package and matching agent pass eight count cases, including\nunit input and the 1,000-sample boundary. Five physical traces/results exactly\nmatch /219; sixteen independent RC voltage/current references pass. The next\nlarger duration still refuses without mutation, all owned workers join and\neight processes exit 0. The bundle remains intact. Native acceptance of the\nearlier UI repairs remains separate.'))
plan = root/'research/34-first-version-plan.md'
text = plan.read_text().replace('**Current maintenance work:** /219 prevents scrolling over a potentiometer\nslider from editing the circuit. [Implementation and checks](97-slider-wheel.md).\nThe /218 Verify endpoint and /217 numeric wheel repairs remain included.',
    '**Current maintenance work:** /220 makes completed manual-step counts match\nthe worker’s existing output grid. [Implementation and checks](99-manual-step-progress.md).\nThe /219 slider, /218 Verify endpoint and /217 numeric wheel repairs remain included.')
plan.write_text(text.replace('/207–/219 changes', '/207–/220 changes'))
checklist = root/'research/66-first-version-completion-checklist.md'
checklist.write_text(checklist.read_text().replace('/207–/219 maintenance candidates', '/207–/220 maintenance candidates'))
(out/'MANIFEST.json').write_text(json.dumps({p.relative_to(out).as_posix(): sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p != out/'MANIFEST.json'}, indent=2)+'\n')
print(json.dumps({k: receipt[k] for k in ['version', 'build', 'source_commit', 'native_sha256', 'agent_sha256', 'completed_cases', 'promotion_status']}))
