"""Record count repair, explicit numerical-test clock, and full-gate outcomes."""
from pathlib import Path
import gzip, hashlib, io, json, re, subprocess, tarfile
root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
out = root/'docs/validation/manual-step-progress-220'
sha = lambda data: hashlib.sha256(data).hexdigest()
for name in ['quality', 'regression-after', 'budget-and-progress']:
    assert (stage/(name+'-exit-code.txt')).read_text().strip() == '0'
inputs = json.loads((stage/'source-inputs.json').read_text())
prior = json.loads((root/'docs/validation/slider-wheel-219/source-inputs.json').read_text())
assert len(inputs) == 890 and all(sha((root/p).read_bytes()) == h for p, h in inputs.items())
assert all(inputs[p] == h for p, h in prior.items() if p.startswith('desktop/') and not p.endswith('_test.go'))
assert inputs['workbench/integration_budget.go'] == prior['workbench/integration_budget.go']
lock = json.loads((root/'third_party/vellum/sdk.lock.json').read_text())
assert lock == json.loads((root/'docs/validation/slider-wheel-219/report.json').read_text())['sdk']
before = json.loads((stage/'before-report.json').read_text())
assert before['mismatched_completed_jobs'] == 3 and len(before['cases']) == 5
assert (stage/'regression-before.txt').read_text().count('wrong planned count') == 3
initial = (stage/'quality-initial.txt').read_text()
assert 'FAIL: TestMixedFlasherKernel' in initial and 'elapsed-time limit' in initial
quality = (stage/'quality.txt').read_text()
times = re.findall(r'ok\s+github.com/dshills/elab/desktop\s+(\d+\.\d+)s', quality)
assert len(times) == 2 and 'Ran 67 tests' in quality
assert sha((root/'build/releases/ELab-0.181.4-macos-arm64.zip').read_bytes()) == 'd13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
parent = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
changed = sorted(p for p, h in inputs.items() if prior.get(p) != h)
files = {'checks/'+p.relative_to(stage).as_posix(): p.read_bytes() for p in sorted(stage.rglob('*'))
         if p.is_file() and p.suffix in {'.py', '.json', '.txt'} and 'build' not in p.relative_to(stage).parts}
for name in changed+['docs/manual-step-work.md']:
    files['source/'+name] = (root/name).read_bytes()
    files['source-before/'+name] = subprocess.check_output(['git', 'show', parent+':'+name])
assert not out.exists()
out.mkdir(parents=True)
with (out/'raw.tar.gz').open('xb') as disk:
    with gzip.GzipFile(fileobj=disk, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(files.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
(out/'raw-manifest.json').write_text(json.dumps({p: sha(data) for p, data in sorted(files.items())}, indent=2)+'\n')
(out/'source-inputs.json').write_text(json.dumps(inputs, indent=2)+'\n')
report = dict(kind='manual-step-progress', application_checks_passed=True, source_parent_commit=parent,
              source_inputs=890, changed_source_inputs=changed, sdk_unchanged=True,
              production_desktop_sources_unchanged=126, initial_public_completed_count_mismatches=3,
              initial_source_regressions=3, source_cases=7, focused_race_seconds=1.536,
              budget_flasher_progress_race_seconds=2.398, desktop_race_seconds=float(times[0]),
              mounted_race_seconds=float(times[1]), python_tests=67,
              initial_gate_failure='Numerical TestMixedFlasherKernel hit existing real 100 ms integration budget under race; failure retained, scheduler cause not proven.',
              numerical_flasher_test_uses_existing_test_clock=True, production_integration_budget_unchanged=True,
              production_attempt_limit=512, production_wall_ms=100, manual_sample_limit=1000,
              manual_target_timing_preserved=True, verification_strict_grid_unchanged=True,
              new_commands=0, new_components=0, new_models=0, new_formats=0,
              graphical_app_launched=False, native_acceptance_passed=False, release_ready=False,
              owner_review_required=False, published=False, preserved_download='0.181.4 /205',
              raw_archive_sha256=sha((out/'raw.tar.gz').read_bytes()), raw_members=len(files))
(out/'report.json').write_text(json.dumps(report, indent=2)+'\n')
(out/'README.md').write_text(f'''# Manual-step planned sample counts /220

October 24, 2026. [Receipt](report.json), [source inputs](source-inputs.json),
[raw evidence](raw.tar.gz), [member hashes](raw-manifest.json),
[notes](../../../research/99-manual-step-progress.md).

Three /219 public runs complete with misleading 1/2 or 3/4 counts. Three source
regressions fail at admission. The repair counts the same bounded absolute-time
targets the worker already uses, including its unchanged sub-picosecond final
tail rule. Target calculation is shared; equations, limits and physical timing
remain unchanged. Seven source cases include genuine partial intervals, a
nonzero origin, an adjacent endpoint and the 1,000-sample boundary. They check
counts, exact end time, analytical RC voltage and protected source/history.

The first full gate fails when the existing direct flasher numerical test hits
the production 100 ms work budget after 27 attempts. That path does not invoke
manual stepping. The log is preserved; no scheduler cause is claimed. The
numerical test now uses the existing test clock while retaining its attempt
cap. Production budget code and dedicated time/attempt enforcement tests are
unchanged. Combined focused race checks pass in 2.398 s.

The final full gate passes lint/staticcheck, 67 Python tests, root/desktop race
and vet, configured mounted race and offscreen vet. Desktop race: {times[0]} s;
mounted race: {times[1]} s. All 890 source/check inputs match. The earlier plot
routing regression is included. The SDK and 126 production desktop Go sources
are unchanged. Initial test-fixture command/stale-run mistakes are retained
separately. /219 and /205 stay preserved; clean packaging follows.
''')
notes = root/'research/99-manual-step-progress.md'
notes.write_text(notes.read_text().replace('The full gate rerun and clean package qualification are in progress.',
    f'The [full gate rerun passes](../docs/validation/manual-step-progress-220/README.md):\nlint/staticcheck, 67 Python tests, root/desktop race and vet, configured mounted\nrace and offscreen vet. Desktop race takes {times[0]} s, mounted race {times[1]} s;\nall 890 source/check inputs match. Clean package qualification follows.'))
with (root/'research/README.md').open('a') as stream:
    stream.write('\n- [Manual-step progress counts](99-manual-step-progress.md): match planned totals to the worker’s existing target grid, preserving timing and bounds. Focused and full gates pass; the original flasher wall-budget failure and numerical-test clock adjustment remain explicit.\n')
(out/'MANIFEST.json').write_text(json.dumps({p.name: sha(p.read_bytes()) for p in sorted(out.iterdir()) if p.is_file()}, indent=2)+'\n')
print(json.dumps({k: report[k] for k in ['application_checks_passed', 'source_inputs', 'desktop_race_seconds', 'mounted_race_seconds', 'raw_members']}))
