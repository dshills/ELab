"""Check exact packaged progress counts and unchanged physical results."""
from pathlib import Path
import hashlib, importlib.util, json, math, time
root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
build = json.loads((stage/'build-result-signed.json').read_text())
binary = Path(build['review'])/'elab-agent'
assert hashlib.sha256(binary.read_bytes()).hexdigest() == build['agent_sha256']
spec = importlib.util.spec_from_file_location('client', root/'scripts/persistence-demo.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
folder = stage/'candidate-cases'
assert not folder.exists()
folder.mkdir()
reports = []
maximum_errors = [0., 0.]
original = {p['case']: p for p in json.loads((stage/'before-report.json').read_text())['cases']}
physical_fields = ['components', 'wires', 'nets', 'transient', 'mixed', 'result', 'circuit', 'analysis',
                   'paused', 'run_id', 'electrical_revision', 'scope', 'document', 'undo_entry', 'can_redo']
for label, seed, duration, count, micro in [
    ('exact', 0, .001, 1, False),
    ('tiny-tail', 0, .001+.1e-12, 1, False),
    ('tiny-tail-units', 0, '1.0000000001 ms', 1, False),
    ('seeded-tail', .005, .003+.5e-12, 3, False),
    ('partial-final', 0, .0025, 3, False),
    ('adjacent', 0, math.nextafter(.001, math.inf), 1, False),
    ('above-snap', 0, .001+2e-12, 2, False),
    ('maximum', 0, .001, 1000, True),
]:
    client = helper.Client(command_preconditions=True, agent_binary=binary)
    report = dict(case=label, expected_samples=count)
    try:
        client.ask('example.rc', {'discard_changes': True}, True)
        client.ask('simulation.pause', {}, True)
        client.ask('simulation.wait')
        if micro:
            settings = client.ask('project.inspect')['transient_settings']
            settings['step_s'], settings['seconds_per_wall_second'] = 1e-6, .001
            client.ask('simulation.transient.set', settings, True)
            client.ask('simulation.restart', {}, True)
            client.ask('simulation.wait')
        if seed:
            client.ask('simulation.step', {'duration_s': seed}, True)
        before = client.ask('project.inspect')
        discovery = client.ask('capabilities.list', {'command': 'simulation.step.start'})
        policy = discovery['capabilities'][0]['input_schema']['x-rounding-policy']
        assert '<1 ps' in policy and 'actual start_time' in policy
        assert before == client.ask('project.inspect')
        admitted = client.ask('simulation.step.start', {'duration_s': duration}, True)
        identifier = admitted['step_work']['id']
        assert admitted['step_work']['total_samples'] == count
        deadline = time.monotonic()+10
        while True:
            final = client.ask('project.inspect')
            work = final['step_work']
            assert work['id'] == identifier
            if work['status'] not in ['queued', 'running', 'canceling']:
                break
            assert time.monotonic() < deadline
            time.sleep(.001)
        assert work['status'] == 'completed' and work['progress'] == 1
        assert work['total_samples'] == work['completed_samples'] == count
        sample = final['transient']['sample']
        expected_time = before['transient']['sample']['time_s']+work['duration_s']
        assert sample['time_s'] == expected_time
        expected = [5*-math.expm1(-expected_time/.01), .0005*math.exp(-expected_time/.01)]
        actual = [sample['voltage_v'], sample['current_a']]
        for i, (value, reference) in enumerate(zip(actual, expected)):
            error = abs(value-reference)
            maximum_errors[i] = max(maximum_errors[i], error)
            assert error <= [1e-12, 1e-15][i]
        assert before['components'] == final['components'] and before['wires'] == final['wires']
        assert before['document'] == final['document'] and before['undo_entry'] == final['undo_entry']
        assert final['paused']
        if label in original:
            old = json.loads((stage/(label+'-after.json')).read_text())
            assert all(old.get(k) == final.get(k) for k in physical_fields), [k for k in physical_fields if old.get(k) != final.get(k)]
            report['physical_state_exactly_matches_219'] = True
        if micro:
            before_refusal = client.ask('project.inspect')
            client.ask('simulation.step.start', {'duration_s': math.nextafter(.001, math.inf)}, True, 'invalid-params')
            assert client.ask('project.inspect') == before_refusal
            report['next_larger_duration_refused_without_mutation'] = True
        report.update(passed=True, admitted_work=admitted['step_work'], work=work, sample=sample)
        (folder/(label+'-before.json')).write_text(json.dumps(before, indent=2)+'\n')
        (folder/(label+'-after.json')).write_text(json.dumps(final, indent=2)+'\n')
    finally:
        try:
            job = client.ask('app.close', {'discard_changes': True}, True)['shutdown']
            job = client.wait_for_shutdown_outcome(job)
            assert job['workers_joined'] and job['exit_ready']
            report['shutdown'] = job
        finally:
            client.close()
        report['exit_code'] = client.process.returncode
        (folder/(label+'-report.json')).write_text(json.dumps(report, indent=2)+'\n')
    assert report['exit_code'] == 0
    reports.append(report)
    print(label, str(work['completed_samples'])+'/'+str(work['total_samples']), flush=True)
summary = dict(passed=all(p['passed'] for p in reports), source_commit=build['source_commit'],
               agent_sha256=build['agent_sha256'], cases=reports, scalar_reference_readings=16,
               physical_traces_matching_previous_candidate=5,
               max_voltage_error_v=maximum_errors[0], max_current_error_a=maximum_errors[1],
               graphical_app_launched=False, owner_review_required=False)
(stage/'protocol-report.json').write_text(json.dumps(summary, indent=2)+'\n')
