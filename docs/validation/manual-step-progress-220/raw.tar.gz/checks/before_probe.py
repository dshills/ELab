"""Check public planned/completed manual-step counts on exact /219 bytes."""
from pathlib import Path
import hashlib, importlib.util, json, time
root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
pin = json.loads((root/'docs/validation/slider-wheel-219/candidate-report.json').read_text())
binary = Path(pin['candidate'])/'elab-agent'
assert hashlib.sha256(binary.read_bytes()).hexdigest() == pin['agent_sha256']
spec = importlib.util.spec_from_file_location('client', root/'scripts/persistence-demo.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
cases = []
for label, seed, duration in [
    ('exact', 0, .001),
    ('tiny-tail', 0, .001+.1e-12),
    ('tiny-tail-units', 0, '1.0000000001 ms'),
    ('seeded-tail', .005, .003+.5e-12),
    ('partial-final', 0, .0025),
]:
    client = helper.Client(command_preconditions=True, agent_binary=binary)
    report = dict(case=label, seed_s=seed, requested_duration=duration)
    try:
        client.ask('example.rc', {'discard_changes': True}, True)
        client.ask('simulation.pause', {}, True)
        client.ask('simulation.wait')
        if seed:
            client.ask('simulation.step', {'duration_s': seed}, True)
        before = client.ask('project.inspect')
        admitted = client.ask('simulation.step.start', {'duration_s': duration}, True)
        identifier = admitted['step_work']['id']
        report['admitted_work'] = admitted['step_work']
        deadline = time.monotonic()+10
        while True:
            final = client.ask('project.inspect')
            work = final['step_work']
            assert work['id'] == identifier
            if work['status'] not in ['queued', 'running', 'canceling']:
                break
            assert time.monotonic() < deadline
            time.sleep(.001)
        assert work['status'] == 'completed' and work['progress'] == 1
        assert before['components'] == final['components'] and before['wires'] == final['wires']
        assert not final['document']['dirty'] and final['paused']
        report.update(work=work, sample=final['transient']['sample'],
                      total_matches_completed=work['total_samples'] == work['completed_samples'])
        (stage/(label+'-before.json')).write_text(json.dumps(before, indent=2)+'\n')
        (stage/(label+'-after.json')).write_text(json.dumps(final, indent=2)+'\n')
    finally:
        try:
            job = client.ask('app.close', {'discard_changes': True}, True)['shutdown']
            job = client.wait_for_shutdown_outcome(job)
            assert job['workers_joined'] and job['exit_ready']
            report['shutdown'] = job
        finally:
            client.close()
        report['exit_code'] = client.process.returncode
    assert report['exit_code'] == 0
    cases.append(report)
    print(label, work['status'], str(work['completed_samples'])+'/'+str(work['total_samples']), flush=True)
summary = dict(source_commit=pin['source_commit'], agent_sha256=pin['agent_sha256'],
               cases=cases, mismatched_completed_jobs=sum(not p['total_matches_completed'] for p in cases))
(stage/'before-report.json').write_text(json.dumps(summary, indent=2)+'\n')
