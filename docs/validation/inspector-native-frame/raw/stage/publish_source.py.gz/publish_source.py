from pathlib import Path
import gzip,hashlib,json,shutil,subprocess
ROOT=Path('/Users/dshills/Development/projects/ELab');STAGE=ROOT/'build/inspector-native-frame-work';PROOF=ROOT/'docs/validation/inspector-native-frame';PRIOR=ROOT/'docs/validation/inspector-width'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,data):path.write_text(json.dumps(data,indent=2)+'\n')
q=json.loads((STAGE/'full-quality.json').read_text());assert q['exit_code']==0 and q['sources_unchanged'] and q['source_files']==662
assert all(sha(ROOT/p)==h for p,h in q['source_sha256'].items());assert not PROOF.exists();PROOF.mkdir()
shutil.copyfile(ROOT/'desktop/rail_labels_smoke.go',STAGE/'rail_labels_smoke-final.go.txt')
shutil.copytree(PRIOR,PROOF/'prior-width')
manifest={};dest=PROOF/'raw/stage';dest.mkdir(parents=True)
for p in sorted(STAGE.iterdir()):
 if not p.is_file():continue
 data=p.read_bytes();stored=gzip.compress(data,mtime=0);qpath=dest/(p.name+'.gz');qpath.write_bytes(stored)
 manifest[str(qpath.relative_to(PROOF))]=dict(original_bytes=len(data),original_sha256=hashlib.sha256(data).hexdigest(),stored_sha256=sha(qpath))
write(PROOF/'manifest.json',manifest)
shutil.copyfile(STAGE/'verify.py.txt',PROOF/'verify.py');shutil.copyfile(STAGE/'README.md.txt',PROOF/'README.md')
r=dict(date='2026-10-19',issue='UI-INSPECTOR-WIDTH-01/native-guard',source_parent_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),source_qualified=True,replacement_packaging_pending=True,new_release=False,native_fix_qualified=False,application_sources=659,tool_sources=3,quality_elapsed_seconds=q['elapsed_seconds'],prior_source_checkpoint_sha256=sha(PRIOR/'checkpoint.json'),candidate_manifest_sha256=sha(ROOT/'build/ELab-0.167.0-184-review/CANDIDATE_MANIFEST.json'),failed_native_smoke_exit_code=1,failed_case_kind='Native geometry guard compared natural text allocation rather than bounded wrapping-frame width; actual frame width was not recorded',solver_changed=False,commands_changed=False,sdk_changed=False,owner_acceptance=False,full_mvp_complete=False)
write(PROOF/'report.json',r)
write(PROOF/'checkpoint.json',dict(files={str(p.relative_to(PROOF)):sha(p) for p in sorted(PROOF.rglob('*')) if p.is_file() and p!=PROOF/'checkpoint.json'}))
print(dict(passed=True,evidence_files=len(json.loads((PROOF/'checkpoint.json').read_text())['files']),quality_seconds=q['elapsed_seconds']))
