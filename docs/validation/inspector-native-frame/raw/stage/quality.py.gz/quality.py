from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/Users/dshills/Development/projects/ELab');stage=root/'build/inspector-native-frame-work'
def sources():
 paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','*.go'],cwd=root,text=True).splitlines()
 return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(set(paths))}
before=sources();(stage/'source-before-quality.json').write_text(json.dumps(before,indent=2)+'\n')
started=time.monotonic()
with (stage/'full-quality.log').open('x') as log:
 result=subprocess.run(['./scripts/check.sh'],cwd=root,env=dict(os.environ,GOPROXY='off'),stdout=log,stderr=subprocess.STDOUT)
after=sources()
report=dict(command='./scripts/check.sh',environment_overrides=dict(GOPROXY='off'),exit_code=result.returncode,elapsed_seconds=time.monotonic()-started,source_sha256=after,source_files=len(after),sources_unchanged=before==after)
(stage/'full-quality.json').write_text(json.dumps(report,indent=2)+'\n');assert before==after
print(json.dumps({k:v for k,v in report.items() if k!='source_sha256'}),flush=True)
raise SystemExit(result.returncode)
