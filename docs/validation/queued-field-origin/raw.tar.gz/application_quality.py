from pathlib import Path
import hashlib, importlib.util, json, os, subprocess
root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
assert (stage/'sdk-quality-exit-code.txt').read_text().strip()=='0'
assert not (stage/'quality.txt').exists()
prior=json.loads((root/'docs/validation/number-step-223/source-inputs.json').read_text())
lock=json.loads((root/'third_party/vellum/sdk.lock.json').read_text())
names=set(prior)|{lock['archive'],lock['compatibility_patch']['path'],'third_party/vellum/README.md'}
inputs={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in sorted(names)}
(stage/'source-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('prepare',root/'scripts/prepare-vellum.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
old=json.loads((stage/'previous-sdk.lock.json').read_text())
helper.verify_cache(root/old['cache'],old)
helper.verify_cache(root/lock['cache'],lock)
assert hashlib.sha256((root/'build/releases/ELab-0.181.4-macos-arm64.zip').read_bytes()).hexdigest()=='d13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
env=dict(os.environ,GOWORK='off',GOPROXY='off',GOTOOLCHAIN='local',GOFLAGS='-p=1 -mod=readonly',GOCACHE=str(root/'build/go-cache'),PYTHONDONTWRITEBYTECODE='1')
with (stage/'quality.txt').open('x') as log:
    result=subprocess.run(['./scripts/check.sh'],cwd=root,env=env,stdout=log,stderr=-2)
(stage/'quality-exit-code.txt').write_text(str(result.returncode)+'\n')
assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest for name,digest in inputs.items())
helper.verify_cache(root/old['cache'],old);helper.verify_cache(root/lock['cache'],lock)
print(json.dumps({'application_quality_exit_code':result.returncode,'frozen_inputs_unchanged':len(inputs),'old_sdk_members_preserved':old['files'],'new_sdk_members_verified':lock['files']}))
raise SystemExit(result.returncode)
