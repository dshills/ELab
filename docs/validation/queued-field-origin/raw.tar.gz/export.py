from pathlib import Path
import os, subprocess, sys
root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
sdk=root/'build/vellum-public-e58d405'
assert (stage/'sdk-quality-exit-code.txt').read_text().strip()=='0'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=sdk).strip()
(stage/'sdk-source-commit.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],cwd=sdk,text=True))
env=dict(os.environ,GOWORK='off',GOCACHE=str(root/'build/go-cache'),GOPROXY='off',GOTOOLCHAIN='local',PYTHONDONTWRITEBYTECODE='1')
with (stage/'sdk-export.stdout.txt').open('x') as output, (stage/'sdk-export.stderr.txt').open('x') as error:
    result=subprocess.run([sys.executable,'-B','scripts/release-sdk.py','--output',str(root/'third_party/vellum/vellum-e58d405-elab14.tar.gz')],cwd=sdk,env=env,stdout=output,stderr=error,timeout=180)
print((stage/'sdk-export.stdout.txt').read_text());print((stage/'sdk-export.stderr.txt').read_text())
raise SystemExit(result.returncode)
