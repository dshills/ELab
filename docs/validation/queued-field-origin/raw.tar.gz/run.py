from pathlib import Path
import json, os, subprocess, sys
root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
label=sys.argv[1];assert label in ['before','after','focused']
pattern='^TestQueuedFieldChangeRetainsEventCallbackAcrossRebind$' if label!='focused' else 'Test(QueuedFieldChange|HeldSlider|QueuedSlider|.*FieldSettlement|.*Field.*Context)'
command=['go','test','-race','-count=1','-run',pattern,'.']
env=dict(os.environ,GOWORK='off',GOCACHE=str(root/'build/go-cache'),GOPROXY='off',GOTOOLCHAIN='local',GOFLAGS='-p=1 -mod=readonly',CGO_LDFLAGS_ALLOW='-Wl,-rpath,@executable_path/native')
log=stage/(label+'.txt');assert not log.exists()
with log.open('x') as output:
    result=subprocess.run(command,cwd=root/'build/vellum-public-e58d405/drivers/cogent',env=env,stdout=output,stderr=-2,timeout=180)
(stage/(label+'-result.json')).write_text(json.dumps({'command':command,'exit_code':result.returncode},indent=2)+'\n')
print(json.dumps({'label':label,'exit_code':result.returncode,'log':str(log)}))
print(log.read_text()[-8000:])
