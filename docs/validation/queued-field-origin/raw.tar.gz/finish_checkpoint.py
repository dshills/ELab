"""Archive this completed source repair, then stop at the owner's return."""
from pathlib import Path
import gzip
import hashlib
import importlib.util
import io
import json
import subprocess
import tarfile

root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
out = root / 'docs/validation/queued-field-origin'
sha = lambda data: hashlib.sha256(data).hexdigest()
assert (stage / 'quality-exit-code.txt').read_text().strip() == '0'
assert (stage / 'sdk-quality-exit-code.txt').read_text().strip() == '0'
inputs = json.loads((stage / 'source-inputs.json').read_text())
assert all(sha((root / name).read_bytes()) == digest for name, digest in inputs.items())
lock = json.loads((root / 'third_party/vellum/sdk.lock.json').read_text())
spec = importlib.util.spec_from_file_location('prepare', root / 'scripts/prepare-vellum.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
for pin in [json.loads((stage / 'previous-sdk.lock.json').read_text()), lock]:
    helper.verify_cache(root / pin['cache'], pin)
sdk = root / 'build/vellum-public-e58d405'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=sdk).strip()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=sdk, text=True).strip() == lock['source_commit']
preserved = {
    '/private/tmp/elab-cursor-guidance-206/ELab Cursor Recovery.app/Contents/MacOS/ELab Cursor Recovery': 'e957008f182845572fe39158f4819e5601e28a79ac803e3446071ff9cd56f82d',
    'build/ELab-0.181.22-223-candidate/elab-agent': '0d1195d71774ab98604a57452500c4be93dd080949da8630e3ca8a2d07d2f4a6',
    'build/ELab-0.181.22-223-candidate/ELab.app/Contents/MacOS/ELab': 'c02816486cf9d5140bb7bcda600f970e8d2584aef99dde64520be3452f27a7b5',
    'build/native-acceptance-220-tools/RC native 220.elab': 'b042198f86c9430bc3dd00d0018fa604055bb833fa8d8a7fb9b57a827f8b15cc',
    'build/releases/ELab-0.181.4-macos-arm64.zip': 'd13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b',
}
for name, digest in preserved.items():
    assert sha((root / name).read_bytes()) == digest, name
signature = subprocess.run(['codesign', '--verify', '--deep', '--strict', '/private/tmp/elab-cursor-guidance-206/ELab Cursor Recovery.app'], capture_output=True, text=True)
assert signature.returncode == 0, signature.stderr
(stage / 'preservation.json').write_text(json.dumps({'sha256': preserved, 'installed_strict_signature_exit_code': signature.returncode}, indent=2) + '\n')
progress = json.loads((stage / 'progress.json').read_text())
progress.update(status='Stopped at owner return; source repair and full quality gates pass', application_quality_exec_session_id=None, quality_exec_session_id=None,
    application_quality_exit_code=0, new_candidate_built=False,
    next_steps=[], deferred_work=['New candidate build and affected native acceptance; no autonomous continuation authorized after the owner returned and asked to stop.'])
(stage / 'progress.json').write_text(json.dumps(progress, indent=2) + '\n')
out.mkdir(parents=True, exist_ok=True)
assert {p.name for p in out.iterdir()} == {'README.md'}
raw = {p.name: p.read_bytes() for p in sorted(stage.iterdir()) if p.is_file() and p.suffix in {'.py', '.json', '.txt'}}
for name in ['drivers/cogent/controls.go', 'drivers/cogent/field_change_context_test.go']:
    raw['sdk-after/' + name] = (sdk / name).read_bytes()
manifest = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(raw.items())}
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode='wb', filename='', mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w') as archive:
        for name, data in sorted(raw.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(data))
(out / 'raw.tar.gz').write_bytes(buffer.getvalue())
(out / 'raw-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(out / 'source-inputs.json').write_bytes((stage / 'source-inputs.json').read_bytes())
report = dict(status='source-qualified-stopped-at-owner-return', date='2026-10-24',
    application_source_parent=json.loads((stage / 'baseline.json').read_text())['root_head'],
    sdk_source_commit=lock['source_commit'], sdk_archive=lock['archive'], sdk_archive_sha256=lock['sha256'],
    before_regression_failures=['TextField', 'NumberField'], after_regressions_passed=True,
    related_focused_checks_passed=True, framework_full_quality_exit_code=0, application_full_quality_exit_code=0,
    frozen_input_count=len(inputs), frozen_inputs_preserved=True,
    verified_sdk_members=lock['files'], old_sdk_cache_preserved=True,
    sdk_export_comparison=json.loads((stage / 'sdk-member-comparison.json').read_text()),
    initial_framework_sandbox_failure='Temporary Unix socket bind restriction; retained separately; authorized full rerun passes.',
    preservation=preserved, installed_strict_signature_exit_code=signature.returncode,
    app_production_go_changed=False, backend_go_changed=False, new_features=False,
    new_candidate_built=False, fresh_native_acceptance=False, release_promoted=False,
    original_native_checks_remaining=[3, 6, 9, 11],
    stop_reason='Owner returned and instructed: Finish up what you are working on and stop.',
    raw_archive_sha256=sha(buffer.getvalue()))
(out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'evidence': str(out), 'application_quality_exit_code': 0, 'frozen_inputs': len(inputs), 'status': report['status']}))
