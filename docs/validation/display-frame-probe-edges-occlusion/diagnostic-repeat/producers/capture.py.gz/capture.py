from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

os.umask(0o077)
root = Path('/Users/dshills/Development/projects/ELab')
out = Path('/private/tmp/elab-display-edge-occlusion-173-diagnostic')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
session = json.loads((out / 'report.json').read_text())
inspection = json.loads((out / 'inspect-stdout.json').read_text())
pid = session['owned_pid']
window = session['target_windows'][0]['window_id']
executable = Path(session['registration']['executable_path'])
assert pid == inspection['pid'] and window == inspection['window_id']
assert session['status'] == 'ready_for_controller_binding'
plan = inspection['capture_plan']
assert plan['point_pixel_scale'] == 1
display = root / 'build/display-frame-probe-tools/display-frame-probe'
single = root / 'build/frame-probe-tools/frame-probe'
fixture = root / 'build/display-calibration-fixture-tools/calibration-fixture'
expected = {
    str(display): 'a8cec4e8f9d16b2b5ad6b751f5657b537c5ed6ea956e7695403168b445bb923f',
    str(single): 'dcf06ebefa9ec76002f22f0e67564682b1c429af2f19fc208c504c669ec505e7',
    str(fixture): 'da7cdffae3a3b83c373100bbe0d0872c19af3c4afebeede14f46dcad5b0087c5',
    str(executable): session['native_sha256'],
}
assert all(sha(Path(p)) == digest for p, digest in expected.items())
def write(name, value):
    with (out / name).open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')
write('fixture-target.json', dict(pid=pid, window=window, executable=str(executable),
    sha256=session['native_sha256'], bounds=plan['window_global_points']))
identity = ['--pid', str(pid), '--window', str(window), '--executable', str(executable),
    '--sha256', session['native_sha256']]
crop = plan['source_display_local_points']
crop_text = ','.join(str(crop[k]) for k in ['x','y','width','height'])
commands = {
    'fixture': [str(fixture), '--show', '--target', str(out/'fixture-target.json'),
        '--output', str(out/'fixture'), '--seconds', '15'],
    'display': [str(display), '--capture-display'] + identity + ['--display', str(plan['display_id']),
        '--crop', crop_text, '--output', str(out/'capture'), '--seconds', '3'],
    'window': [str(single), '--capture'] + identity + ['--output', str(out/'window-capture'), '--seconds','3'],
}
record = dict(commands=commands, binaries=expected, attempted=True,
    predeclared_seconds=3, fixture_seconds=15, eligible_latency_observations=0,
    latency_gate_passed=None, input_injected=False)
write('experiment-plan.json', record)
processes = {}
logs = []
def start(name):
    f = (out/(name+'-output.txt')).open('x'); logs.append(f)
    p = subprocess.Popen(commands[name], stdout=f, stderr=subprocess.STDOUT)
    processes[name] = p
    return p
def request_stop(ticks):
    path = out/'fixture/stop.request'
    if path.parent.exists() and not path.exists():
        temporary = out/'fixture/stop.pending'
        temporary.write_text(json.dumps(dict(not_before_mach_ticks=str(ticks))))
        temporary.rename(path)
try:
    helper = start('fixture')
    until = time.monotonic()+5
    while not (out/'fixture/ready.json').exists():
        assert helper.poll() is None, 'Helper exited before readiness'
        assert time.monotonic() < until, 'Helper readiness timeout'
        time.sleep(.02)
    ready = json.loads((out/'fixture/ready.json').read_text())
    assert ready['helper_pid'] == helper.pid and ready['target_pid'] == pid
    assert ready['target_window'] == window and len(ready['patches']) == 5
    d = start('display'); w = start('window')
    d.wait(timeout=12); w.wait(timeout=12)
    record['capture_exit_codes'] = dict(display=d.returncode, window=w.returncode)
    assert helper.poll() is None, 'Fixture ended before capture completion'
    timestamps = []
    for folder in ['capture','window-capture']:
        rows = [json.loads(line) for line in (out/folder/'frames.jsonl').read_text().splitlines()]
        timestamps += [int(r['display_mach_ticks']) for r in rows if r.get('display_mach_ticks')]
    assert timestamps
    request_stop(max(timestamps))
    helper.wait(timeout=5)
    closed = json.loads((out/'fixture/closed.json').read_text())
    assert helper.returncode == 0 and closed['error'] is None
    assert int(closed['closed_mach_ticks']) >= max(timestamps)
    assert d.returncode == w.returncode == 0
    record['status'] = 'captured_pending_independent_pixel_analysis'
except BaseException as error:
    record['status'] = 'failed'
    record['error'] = type(error).__name__+': '+str(error)
    raise
finally:
    request_stop(0)
    for name, p in processes.items():
        if p.poll() is None:
            try: p.wait(timeout=18)
            except subprocess.TimeoutExpired: record[name+'_still_running'] = True
    record['process_exit_codes'] = {name:p.poll() for name,p in processes.items()}
    for f in logs: f.close()
    write('experiment-report.json', record)
    # Finish the owned application through its already running public-session controller.
    with (out/'stop.request').open('x') as f: f.write('calibration recording finished\n')
print(json.dumps(record, indent=2))
