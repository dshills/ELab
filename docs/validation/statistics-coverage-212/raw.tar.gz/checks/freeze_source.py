"""Freeze the bounded statistics-coverage repair after its complete source gate."""
import gzip, hashlib, io, json, re, shutil, subprocess, tarfile
from pathlib import Path

root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
out = root/'docs/validation/statistics-coverage-212'
sha = lambda b: hashlib.sha256(b).hexdigest()
assert (stage/'quality-exit-code.txt').read_text().strip() == '0'
assert not out.exists()
inputs = json.loads((stage/'source-inputs.json').read_text())
assert len(inputs) == 879 and all(sha((root/p).read_bytes()) == h for p, h in inputs.items())
assert not (root/'go.sum').exists()
quality = (stage/'quality.txt').read_text()
times = re.findall(r'ok\s+github.com/dshills/elab/desktop\s+(\d+\.\d+)s', quality)
assert len(times) == 2, times
for name in ['backend-before.txt', 'desktop-before.txt']:
    assert '--- FAIL' in (stage/name).read_text()
baseline = json.loads((stage/'packaged-before.json').read_text())
assert baseline['accepted_import'] and baseline['query_state_unchanged'] and baseline['agent_exit_code'] == 0
assert baseline['result']['time_mean'] == 2.5
original = json.loads((stage/'source.json').read_text())
modified = json.loads((stage/'short-tail.json').read_text())
original['rows'][-1]['time_s'] = modified['rows'][-1]['time_s']
assert original == modified
assert (stage/'short-tail.json').read_bytes() == (root/'workbench/testdata/recorded-statistics-short-tail.json').read_bytes()
lock = json.loads((root/'third_party/vellum/sdk.lock.json').read_text())
previous = root/'docs/validation/recorded-position-211'
assert lock == json.loads((previous/'report.json').read_text())['sdk_unchanged']
assert sha((root/lock['archive']).read_bytes()) == lock['sha256']
download = root/'build/releases/ELab-0.181.4-macos-arm64.zip'
assert sha(download.read_bytes()) == 'd13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
old = json.loads((previous/'source-inputs.json').read_text())
changed = [p for p, h in inputs.items() if old.get(p) != h]
files = {'checks/'+p.name: p.read_bytes() for p in sorted(stage.iterdir()) if p.is_file() and p.suffix in {'.py', '.json', '.txt'}}
absent = []
for name in changed:
    files['source/'+name] = (root/name).read_bytes()
    if name in old:
        files['source-before/'+name] = subprocess.check_output(['git', 'show', base+':'+name], cwd=root)
    else:
        absent.append(name)
files['source-before/absent.json'] = (json.dumps(absent, indent=2)+'\n').encode()
out.mkdir(parents=True)
shutil.copyfile(stage/'source-inputs.json', out/'source-inputs.json')
with (out/'raw.tar.gz').open('xb') as disk:
    with gzip.GzipFile(fileobj=disk, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(files.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
(out/'raw-manifest.json').write_text(json.dumps({p: sha(b) for p, b in sorted(files.items())}, indent=2)+'\n')
report = dict(kind='recorded-statistics-coverage', source_checks_passed=True,
              quality_exit_code=0, source_parent_commit=base, source_inputs=len(inputs),
              absent_source_inputs=['go.sum'], changed_source_inputs=changed,
              python_tests=67, desktop_race_seconds=float(times[0]), mounted_race_seconds=float(times[1]),
              backend_focused_seconds=1.755, desktop_focused_seconds=1.913,
              old_packaged_agent_baseline=baseline,
              inventory_comparison=json.loads((stage/'inventory-comparison.json').read_text()),
              sdk_unchanged=lock, preserved_download_sha256=sha(download.read_bytes()),
              native_app_launched=False, native_acceptance_passed=False,
              release_ready=False, published=False, owner_review_required=False,
              new_commands=0, new_components=0, new_formats=0, download_unchanged='0.181.4 /205',
              raw_archive_sha256=sha((out/'raw.tar.gz').read_bytes()), raw_members=len(files))
(out/'report.json').write_text(json.dumps(report, indent=2)+'\n')
(out/'README.md').write_text(f'''# Recorded statistics coverage /212

October 23, 2026. [Receipt](report.json), [source inputs](source-inputs.json),
[repair notes](../../../research/89-recorded-statistics-coverage.md).

The unchanged /211 packaged agent accepts an imported constant 5 V capture
whose final timestamp precedes its nominal duration within existing import
roundoff. A partially unsupported tiny interval reports 2.5 V mean and
3.5355339059327378 V RMS. Only the final timestamp was changed in the fixture.

The shared statistics path now refuses intervals outside actual saved rows,
preserving prior cached results and the full snapshot. The desktop defaults
to the saved endpoint; external agents can discover it through existing APIs.
Import compatibility, timestamps, commands and formats remain unchanged.

Backend race regressions pass in 1.755 s; desktop callback race regressions
pass in 1.913 s. Covered intervals as narrow as one floating-point step retain
5 V mean/RMS and zero AC RMS. The complete source gate passes lint/staticcheck,
67 Python tests, root/desktop race and vet, mounted race and offscreen vet.
Desktop race takes {times[0]} s; mounted race takes {times[1]} s. All {len(inputs)}
captured inputs match. [Raw checks and producers](raw.tar.gz) include the
baseline failures, exact changed sources, logs and [member hashes](raw-manifest.json).

No new graphical application is launched for this check. The SDK and /205
download remain unchanged. Source/headless checks do not qualify native
acceptance of the changed measurement default or accumulated UI fixes.
Standing desktop/app authorization is saved in AGENTS.md; no new permission
or owner review is requested, and no unattended launch prompt is queued.
''')
notes = root/'research/89-recorded-statistics-coverage.md'
text = notes.read_text()
start = text.index('The full source gate is running;')
end = text.index('\n\nNative acceptance', start)
text = text[:start]+f'''The [full source gate passes](../docs/validation/statistics-coverage-212/README.md):
lint/staticcheck, 67 Python tests, root/desktop race and vet, mounted race and
offscreen vet. Desktop race takes {times[0]} s; mounted race {times[1]} s. All
{len(inputs)} captured source/check inputs remain exact.'''+text[end:]
notes.write_text(text)
manifest = {p.relative_to(out).as_posix(): sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file()}
(out/'MANIFEST.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps({k: report[k] for k in ['source_checks_passed', 'source_inputs', 'desktop_race_seconds', 'mounted_race_seconds', 'raw_members']}))
