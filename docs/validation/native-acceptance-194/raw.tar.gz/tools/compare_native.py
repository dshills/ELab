from pathlib import Path
import copy,importlib.util,json
R=Path('/Users/dshills/Development/projects/ELab');O=Path('/private/tmp/elab-native-194');F=Path('/private/tmp/elab-native-check-193-prepared')
spec=importlib.util.spec_from_file_location('client194',R/'scripts/persistence-demo.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def results(name):return [json.loads(x)['result'] for x in (O/name).read_text().splitlines()]
cases=[('same-level-rising',results('npn-case1-and-case2-seed.jsonl')[0],2.5,4,'v:VIN.positive',0),('next-no-enter',results('npn-case2-and-case3-seed.jsonl')[0],3,4,'v:VIN.positive',8),('paired-correction',results('npn-case3-and-case4-seed.jsonl')[0],4,4.5,'v:VIN.positive',0),('swapped-rejections',results('npn-case4-and-case5-seed.jsonl')[0],4,2.5,'v:VIN.positive',0),('agent-probe-change',results('npn-case5-result.jsonl')[0],2.5,4,'v:Q1.collector',0),('fresh-probe-entry',results('npn-fresh-input-result.jsonl')[0],3,4,'v:Q1.collector',0)]
rc=results('rc-result-npn-seed.jsonl')[0]['recording'];expected=json.loads((F/'rc-expected.json').read_text())['accepted-time-next'];assert all(rc[k]==v for k,v in expected.items())
head=m.Client(agent_binary=Path('/private/tmp/elab-native-194-runtime/agent'),command_preconditions=True)
def semantic(x):
 x=copy.deepcopy(x);x['settings'].pop('id',None);x.pop('origin_id',None);return x
report=dict(status='passed',rc=dict(sample_index=rc['sample_index'],time_s=rc['time_s'],readings=rc['readings'],matches_prepared_exact=True),npn=[])
try:
 state=head.ask('project.load',{'path':str(O/'npn-fixture.elab')},True);identity=state['recording']['id']
 for name,state,level,second,probe,offset in cases:
  timing=state['recording']['timing'];cfg=timing['settings'];assert timing['level_si']==level and cfg['probe_id']==probe and cfg.get('offset',0)==offset
  assert float(cfg['second_level'].split()[0])==second
  assert cfg['direction']==('both' if name=='next-no-enter' else 'rising')
  params=dict(cfg,id=identity);query=head.ask('recording.timing',params);assert semantic(query)==semantic(timing),name
  assert not state['document']['dirty'] and state['paused']
  report['npn'].append(dict(name=name,level_si=level,second_level=second,probe_id=probe,offset=offset,total_crossings=timing['total_crossings'],exact_packaged_headless_match=True))
 job=head.ask('app.close',{'discard_changes':False},True)['shutdown'];job=head.wait_for_shutdown_outcome(job);assert job['status']=='completed' and all(job[k] for k in ('workers_joined','recovery_finalized','exit_ready'));report['headless_shutdown']=job
finally:head.close()
native=m.Client(str(O/'endpoint.json'),command_preconditions=True,agent_binary=Path('/private/tmp/elab-native-194-runtime/agent'))
try:
 rows=[]
 for offset in range(0,521,100):rows+=native.ask('operation.samples',{'id':'record-2','offset':offset,'limit':100})['rows']
 assert rows==json.loads((F/'npn-rows.json').read_text());report['npn_521_rows_preserved']=True
 state=native.ask('project.inspect');base=results('npn-case1-and-case2-seed.jsonl')[1]
 fields=['components','wires','result','npn','mixed','transient','electrical_revision','run_id']
 for _,snapshot,*_ in cases:assert {k:snapshot.get(k) for k in fields}=={k:base.get(k) for k in fields}
 report['all_cases_preserve_live_physics']=True
finally:native.close()
(O/'input-acceptance-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
