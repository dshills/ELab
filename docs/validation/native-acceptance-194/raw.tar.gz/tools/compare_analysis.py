from pathlib import Path
import importlib.util,json,time
R=Path('/Users/dshills/Development/projects/ELab');O=Path('/private/tmp/elab-native-194');run=Path('/private/tmp/elab-native-194-runtime')
spec=importlib.util.spec_from_file_location('analysis194',R/'scripts/persistence-demo.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def rows(c,identity):
 out=[];offset=0
 while True:
  page=c.ask('operation.samples',{'id':identity,'offset':offset,'limit':100});out+=page['rows']
  if page['next_offset']==page['total']:return out
  assert page['next_offset']>offset;offset=page['next_offset']
def finish(c):
 job=c.ask('app.close',{'discard_changes':False},True)['shutdown'];job=c.wait_for_shutdown_outcome(job);assert job['status']=='completed' and all(job[k] for k in ('workers_joined','recovery_finalized','exit_ready'));c.close();return job
def wait(c,identity):
 deadline=time.monotonic()+15
 while True:
  v=c.ask('operation.inspect',{'id':identity});assert v['operation']['status'] not in ('failed','canceled')
  if v['operation']['status']=='completed':return v
  assert time.monotonic()<deadline;time.sleep(.01)
def sweep(c,identity):
 deadline=time.monotonic()+15
 while True:
  v=c.ask('sweep.inspect',{'id':identity});assert v['operation']['status'] not in ('failed','canceled')
  if v['operation']['status']=='completed':return v
  assert time.monotonic()<deadline;time.sleep(.01)
native=m.Client(str(O/'endpoint.json'),command_preconditions=True,agent_binary=run/'agent')
try:
 state=native.ask('project.inspect');(O/'analysis-native-before-save.json').write_text(json.dumps(state,indent=2))
 cfg=state['verification_settings'];assert cfg==dict(duration_s=.1,sample_step_s=0,input_mode='auto',capacitor_initials=[])
 recorded=rows(native,'verify-4');meta=native.ask('operation.inspect',{'id':'verify-4'})['metadata'];assert len(recorded)==105 and recorded[-1]['time_s']==.1
 curves=[sweep(native,'sweep-'+str(n))['result'] for n in range(1,4)];assert all(len(x['points'])==51 and x==curves[0] for x in curves)
 original=rows(native,'record-3');assert original==json.loads(Path('/private/tmp/elab-native-check-193-prepared/rc-rows.json').read_text())
 baseline=json.loads((O/'rc-verify-loaded.jsonl').read_text())['result'];fields=['components','wires','result','npn','mixed','transient','electrical_revision','run_id'];assert {k:state.get(k) for k in fields}=={k:baseline.get(k) for k in fields}
 saved=native.ask('project.save',{'path':str(O/'analysis-results.elab')},True);assert not saved['document']['dirty'];(O/'analysis-native-saved.json').write_text(json.dumps(saved,indent=2))
finally:native.close()
head=m.Client(command_preconditions=True,agent_binary=run/'agent')
try:
 restored=head.ask('project.load',{'path':str(O/'analysis-results.elab')},True);assert not restored['document']['dirty'];all_rows=[rows(head,x['id']) for x in restored['operations']];assert recorded in all_rows and original in all_rows
 fresh_curves=[head.ask('sweep.inspect',{'id':x['id']})['result'] for x in restored['dc_sweep']['operations']];assert fresh_curves==curves
 reopen_job=finish(head);head=None
finally:
 if head:head.close()
head=m.Client(command_preconditions=True,agent_binary=run/'agent')
try:
 head.ask('project.load',{'path':str(O/'rc-fixture.elab')},True);head.ask('verification.settings.set',cfg,True)
 admitted=head.ask('simulation.verify',{'probe_ids':[x['id'] for x in meta['probes']]},True);v=wait(head,admitted['last_operation']);assert rows(head,admitted['last_operation'])==recorded
 # Save the extra capture only to an owned synthetic file, then join normally.
 head.ask('project.save',{'path':str(O/'analysis-headless-counterpart.elab')},True);parity_job=finish(head);head=None
finally:
 if head:head.close()
report=dict(status='passed',native_verify_corrected_duration_without_return=True,native_startup_reset_corrected_sampling_without_return=True,native_sweep_start_stop_count_corrected_without_return=True,verify_sample_count=105,three_identical_51_point_sweeps=True,rc_original_1001_rows_preserved=True,live_physics_preserved=True,saved_results_fresh_reopen_exact=True,verify_rows_match_exact_packaged_agent=True,headless_shutdowns=[reopen_job,parity_job],limitations=['Representative native fields, not all verification startup/initial fields or all rejection branches','Native CUA field focus can settle after a later observation; initial focus-delivery failures retained','No complete four-task physical workflow or minimum-size/both-theme acceptance claimed'])
(O/'analysis-acceptance-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
