"""Inspect the existing owned /206 session without launching an app."""
from pathlib import Path
import importlib.util, json, re, sys
root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
assert len(sys.argv) == 2 and re.fullmatch(r'[a-z0-9-]+', sys.argv[1])
path = stage/(sys.argv[1]+'.json')
assert not path.exists()
spec = importlib.util.spec_from_file_location('client', root/'scripts/persistence-demo.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
client = helper.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json',
                      command_preconditions=True,
                      agent_binary=root/'build/ELab-0.181.5-206-candidate/elab-agent')
try:
    state = client.ask('project.inspect')
    assert state['paused'] and not (state.get('recording') or {}).get('playing')
    path.write_text(json.dumps(state, indent=2)+'\n')
    print(json.dumps(dict(captured=sys.argv[1], revision=state['revision'], command_revision=state['command_revision'])))
finally:
    client.close()
