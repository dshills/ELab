"""Review every exported SDK member before moving the ELab pin to elab11."""
import hashlib
import json
import subprocess
import tarfile
from pathlib import Path

root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
source = root / 'build/vellum-public-e58d405'
lock_path = root / 'third_party/vellum/sdk.lock.json'
old = json.loads(lock_path.read_text())
assert old['cache'].endswith('elab10'), 'do not repin a changed dependency'
assert (stage / 'sdk-quality-exit-code.txt').read_text().strip() == '0'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source).strip()
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()
archive = root / 'third_party/vellum/vellum-e58d405-elab11.tar.gz'
patch = root / 'third_party/vellum/patches/elab-public-e58d405-slider-wheel-compat.patch'
assert archive.is_file() and not patch.exists()
sha = lambda data: hashlib.sha256(data).hexdigest()

def inspect(path):
    with tarfile.open(path) as tar:
        raw = tar.extractfile(old['prefix'] + '/SDK_MANIFEST.json').read()
        manifest = json.loads(raw)
        actual = {}
        for member in tar.getmembers():
            if member.isfile() and member.name != old['prefix'] + '/SDK_MANIFEST.json':
                assert member.name.startswith(old['prefix'] + '/')
                actual[member.name[len(old['prefix'])+1:]] = sha(tar.extractfile(member).read())
        assert actual == manifest['files'], 'member content disagrees with manifest'
        return raw, manifest

assert sha((root / old['archive']).read_bytes()) == old['sha256']
old_raw, before = inspect(root / old['archive'])
raw, after = inspect(archive)
assert after['source'] == {'clean': True, 'commit': commit}
assert not after['untracked_files'] and after['private_build'] is True
assert before['release'] == after['release']
changed = sorted(k for k in before['files'].keys() | after['files'].keys()
                 if before['files'].get(k) != after['files'].get(k))
expected = sorted(['SDK_DOCUMENTATION.md', 'drivers/cogent/controls.go', 'drivers/cogent/slider_wheel_offscreen_test.go'])
assert changed == expected, changed
assert len(after['files']) == old['files'] + 1
assert all(after['files'][name] == digest for name, digest in old['bootstrap'].items())
diff = subprocess.check_output(['git', 'diff', '--binary', old['upstream_commit'], 'HEAD'], cwd=source)
with patch.open('xb') as out:
    out.write(diff)
(stage / 'previous-sdk.lock.json').write_text(json.dumps(old, indent=2)+'\n')
new = dict(old, source_commit=commit, archive=str(archive.relative_to(root)),
           archive_bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()),
           manifest_sha256=sha(raw), cache='build/.vellum-sdk-e58d405-elab11',
           files=len(after['files']), compatibility_patch={
               'path':str(patch.relative_to(root)), 'sha256':sha(diff)})
mod_path = root / 'desktop/go.mod'
mod = mod_path.read_text()
assert mod.count('.vellum-sdk-e58d405-elab10') == 4
mod_path.write_text(mod.replace('.vellum-sdk-e58d405-elab10', '.vellum-sdk-e58d405-elab11'))
lock_path.write_text(json.dumps(new, indent=2)+'\n')
comparison = dict(changed_files=changed, source_commit=commit,
    old_archive_preserved=True, bootstrap_unchanged=True, file_count=new['files'],
    manifests_match_every_member=True, release_metadata_unchanged=True)
(stage / 'sdk-member-comparison.json').write_text(json.dumps(comparison, indent=2)+'\n')
print(json.dumps(comparison))
