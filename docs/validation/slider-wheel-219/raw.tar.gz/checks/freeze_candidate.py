"""Keep packaged public-command checks separate from native wheel acceptance."""
from pathlib import Path
import gzip, hashlib, io, json, subprocess, sys, tarfile
root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
out = root/'docs/validation/slider-wheel-219'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
build = json.loads((stage/'build-result-signed.json').read_text())
protocol = json.loads((stage/'protocol-report.json').read_text())
assert build['passed'] and protocol['passed'] and protocol['reference_readings'] == 90
assert protocol['exit_code'] == 0 and protocol['shutdown']['workers_joined'] and protocol['shutdown']['exit_ready']
assert build['source_commit'] == protocol['source_commit']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root).strip()
inputs = json.loads((out/'source-inputs.json').read_text())
assert len(inputs) == 889 and all(sha(root/p) == h for p, h in inputs.items())
sys.path.insert(0, str(root/'scripts'))
from runtime_isolation import bundle_tree
review = Path(build['review'])
app = review/'ELab.app'
assert sha(app/'Contents/MacOS/ELab') == build['native_sha256']
assert sha(review/'elab-agent') == build['agent_sha256'] == protocol['agent_sha256']
assert bundle_tree(app) == build['source_bundle']
verified = subprocess.run(['/usr/bin/codesign', '--verify', '--deep', '--strict', '--verbose=2', str(app)], capture_output=True)
(stage/'signature-after-agent.txt').write_bytes(verified.stdout+verified.stderr)
verified.check_returncode()
previous = json.loads((root/'docs/validation/verification-output-grid-218/candidate-report.json').read_text())
assert sha(Path(previous['candidate'])/'ELab.app/Contents/MacOS/ELab') == previous['native_sha256']
assert sha(Path(previous['candidate'])/'elab-agent') == previous['agent_sha256']
assert sha(root/'build/releases/ELab-0.181.4-macos-arm64.zip') == 'd13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
receipt = dict(version=build['version'], build=build['build'], source_commit=build['source_commit'],
               candidate=str(review), native_sha256=build['native_sha256'], agent_sha256=build['agent_sha256'],
               clean_build_vcs=True, source_inputs_still_match=889, strict_ad_hoc_signature_valid=True,
               bundle_unchanged_after_agent_checks=True, matching_headless_agent_passed=True,
               reference_readings=90, independent_waveform_readings=84, waveform_rows=21,
               analytic_live_voltage_endpoints=2, instantaneous_current_power_relations=4,
               max_voltage_error_v=protocol['max_voltage_error_v'], max_current_error_a=protocol['max_current_error_a'],
               max_power_error_w=protocol['max_power_error_w'], deliberate_wiper_command_works=True,
               live_charge_and_time_continuous=True, graph_undo_redo=True, dirty_replacement_refusal_exact=True,
               captures_immutable_after_later_live_edit=True, saved_reopen_exact=True,
               shutdown=protocol['shutdown'], agent_exit_code=0, previous_candidate_preserved=True,
               graphical_app_launched=False, native_acceptance_passed=False, promotion_status='held',
               release_ready=False, published=False, owner_review_required=False, preserved_download='0.181.4 /205',
               limitations='The exact agent checks deliberate public actuation/storage, not physical wheel handling. The repaired managed-widget path passes source/offscreen checks; accumulated changed-candidate native acceptance remains separate. Ad-hoc integrity is not Developer ID signing/notarization.')
(out/'candidate-report.json').write_text(json.dumps(receipt, indent=2)+'\n')
pending = json.loads((root/'docs/validation/verification-output-grid-218/native-acceptance-pending.json').read_text())
pending.update(source_commit=build['source_commit'], native_sha256=build['native_sha256'], agent_sha256=build['agent_sha256'])
pending['required_checks'].append('Wheel over focused/unfocused potentiometer slider scrolls the inspector without editing the circuit, while intentional pointer drags and arrow keys retain their shared command/history behavior')
(out/'native-acceptance-pending.json').write_text(json.dumps(pending, indent=2)+'\n')
evidence = out/'candidate'
assert not evidence.exists()
evidence.mkdir()
names = ['build.txt', 'package.txt', 'signature-signed-verify.txt', 'signature-signed-details.txt', 'signature-after-agent.txt',
         'build-result-signed.json', 'source-commit.txt', 'build_candidate.py', 'protocol_check.py',
         'protocol-check.txt', 'protocol-report.json', 'freeze_candidate.py', 'agent-loaded.json',
         'agent-before-wiper.json', 'agent-after-wiper.json', 'agent-advanced.json', 'agent-undone.json',
         'agent-restarted.json', 'agent-operation.json', 'agent-rows.json', 'Pot shared commands and capture.elab']
files = {name: (stage/name).read_bytes() for name in names}
for name in ['elab-build-info.txt', 'elab-agent-build-info.txt', 'elab-conformance-build-info.txt']:
    files['build/'+name] = (stage/'build'/name).read_bytes()
with (evidence/'raw.tar.gz').open('xb') as disk:
    with gzip.GzipFile(fileobj=disk, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(files.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
(evidence/'raw-manifest.json').write_text(json.dumps({p: hashlib.sha256(data).hexdigest() for p, data in sorted(files.items())}, indent=2)+'\n')
(evidence/'README.md').write_text('''# /219 clean package and deliberate actuation checks

The clean 0.181.18 /219 app, matching agent and conformance executable embed
the recorded source revision with vcs.modified=false. The bundle's strict
ad-hoc seal remains valid and its full tree is unchanged after headless checks.

The exact agent changes a paused pot from 50% to 60% at 2 ms with exact charge
and time continuity. Two live voltage endpoints match independent piecewise RC
equations; four instantaneous current/power relations match the accepted voltage.
Graph Undo/Redo works, with stale/fresh states treated explicitly. A separate
21-row startup capture checks 84 independent voltage/current references. The
combined 90 numerical checks use declared tolerances, not a new device model.

A later 70% live edit leaves capture data/metadata exact. Dirty Open refuses
without mutation; explicit Open restores the saved 60% graph and capture. The
original fixture and saved project bytes remain intact. Owned workers join and
the headless process exits 0. These public-command tests do not exercise native
wheel input or qualify the accumulated native acceptance list.

The candidate remains held; the previous /218 package and qualified /205 download
are preserved. No graphical launch or unattended confirmation is queued.
''')
with (out/'README.md').open('a') as stream:
    stream.write('\nThe [clean /219 package and matching agent](candidate-report.json) pass\n90 numerical checks, explicit public actuation with charge continuity, graph\nUndo/Redo, immutable capture, dirty-work refusal and saved reopen. The exact\nbundle stays intact. It remains held for the [native checks](native-acceptance-pending.json);\n/205 is still the download.\n')
notes = root/'research/97-slider-wheel.md'
notes.write_text(notes.read_text().replace('Clean packaging follows.',
    'The clean /219 package and matching agent pass 90 numerical checks: 84\ncaptured waveform readings, two piecewise RC voltage endpoints and four\ninstantaneous current/power relations. Deliberate wiper changes preserve charge\nand time; graph Undo/Redo, immutable captured data, exact dirty-work refusal\nand saved reopen pass. All owned headless workers join and the process exits 0.\nThe app bundle remains intact. The candidate is held for native acceptance.'))
index = root/'research/README.md'
index.write_text(index.read_text().replace('The elab11 pin and full quality pass; fresh native acceptance remains separate.',
    'The elab11 pin, full quality and clean /219 public-actuation/capture checks pass; fresh native acceptance remains separate.'))
plan = root/'research/34-first-version-plan.md'
text = plan.read_text().replace('**Current maintenance work:** /218 repairs false Verify output-limit refusals\nwhile preserving distinct final samples. [Implementation and checks](96-verification-output-grid.md).\nThe /217 numeric wheel repair remains included.',
    '**Current maintenance work:** /219 prevents scrolling over a potentiometer\nslider from editing the circuit. [Implementation and checks](97-slider-wheel.md).\nThe /218 Verify endpoint and /217 numeric wheel repairs remain included.')
plan.write_text(text.replace('/207–/218 changes', '/207–/219 changes'))
checklist = root/'research/66-first-version-completion-checklist.md'
checklist.write_text(checklist.read_text().replace('/207–/218 maintenance candidates', '/207–/219 maintenance candidates'))
(out/'MANIFEST.json').write_text(json.dumps({p.relative_to(out).as_posix(): sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p != out/'MANIFEST.json'}, indent=2)+'\n')
print(json.dumps({k: receipt[k] for k in ['version', 'build', 'source_commit', 'native_sha256', 'agent_sha256', 'reference_readings', 'promotion_status']}))
