"""Preserve the owned RC fixture, then load an owned potentiometer fixture."""
from pathlib import Path
import hashlib, importlib.util, json
root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
baseline = json.loads((stage/'rc-before.json').read_text())
for name in ['rc-after-text-wheel', 'rc-after-inspector', 'rc-after-scope']:
    assert json.loads((stage/(name+'.json')).read_text()) == baseline
spec = importlib.util.spec_from_file_location('client', root/'scripts/persistence-demo.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
binary = root/'build/ELab-0.181.5-206-candidate/elab-agent'
original = root/'build/pot-gesture-ui/Pot-before.elab'
source_sha = sha(original)
fixture = stage/'Pot wheel baseline.elab'
assert not fixture.exists()
document = json.loads(original.read_text())
assert len(document['graph']['components']) == 4
assert next(p for p in document['graph']['components'] if p['id'] == 'Timing')['wiper_position'] == .5
document['paused'] = True
fixture.write_text(json.dumps(document, indent=2)+'\n')
client = helper.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json',
                      command_preconditions=True, agent_binary=binary)
try:
    assert client.ask('project.inspect') == baseline
    backup = stage/'RC before slider checks.elab'
    assert not backup.exists()
    saved = client.ask('project.save', {'path': str(backup)}, True)
    assert not saved['document']['dirty']
    assert saved['document']['recording_count'] == baseline['document']['recording_count']
    assert saved['components'] == baseline['components'] and saved['transient'] == baseline['transient']
    backup_doc = json.loads(backup.read_text())
    assert backup_doc['graph'] == dict(components=baseline['components'], wires=baseline['wires'])
    preserved = []
    for operation in baseline['operations']:
        identifier = operation['id']
        view = client.ask('operation.inspect', {'id': identifier})
        captured = client.ask('operation.samples', {'id': identifier, 'offset': 0, 'limit': 200})
        assert captured['next_offset'] == captured['total']
        preserved.append(dict(metadata=view['metadata'], rows=captured['rows']))
    assert len(backup_doc['recordings']['entries']) == len(preserved)
    assert [p['data'] for p in backup_doc['recordings']['entries']] == preserved
    client.ask('project.load', {'path': str(fixture)}, True)
    client.ask('simulation.pause', {}, True)
    client.ask('simulation.wait')
    client.ask('component.select', {'id': 'Timing'}, True)
    state = client.ask('workspace.inspector.set', {'section': 'component'}, True)
    assert state['paused'] and state['mixed'] and not state['mixed']['stale']
    assert next(p for p in state['components'] if p['id'] == 'Timing')['wiper_position'] == .5
    (stage/'pot-before.json').write_text(json.dumps(state, indent=2)+'\n')
    report = dict(previous_fixture_saved=True, previous_graph_exact=True, previous_captures_exact=len(preserved),
                  previous_file_sha256=sha(backup), source_fixture_sha256=source_sha,
                  pot_fixture_sha256=sha(fixture), source_fixture_unchanged=sha(original) == source_sha,
                  existing_session_reused=True, graphical_app_launched=False)
    (stage/'native-preparation.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report))
finally:
    client.close()
