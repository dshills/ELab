"""Keep old-native evidence distinct from repaired-candidate acceptance."""
from pathlib import Path
import hashlib, json, re, shutil
root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
out = root/'research/ui-audit/slider-wheel-219'
before = json.loads((stage/'rc-before.json').read_text())
for name in ['rc-after-text-wheel', 'rc-after-inspector', 'rc-after-scope']:
    assert json.loads((stage/(name+'.json')).read_text()) == before
restored = json.loads((stage/'native-restoration-report.json').read_text())
reopen = json.loads((stage/'rc-backup-reopen-report.json').read_text())
source = json.loads((stage/'native-source-comparison.json').read_text())
assert restored['native_bug_reproduced'] and restored['pot_readings_restored']
assert reopen['passed'] and reopen['capture_rows'] == 21 and reopen['exit_code'] == 0
assert source['old_and_current_core_slider_equal'] and source['old_and_current_managed_slider_factory_equal']
assert not out.exists()
out.mkdir(parents=True)
observations = [p for p in sorted(stage.iterdir()) if re.match(r'^\d\d-', p.name) and p.suffix in {'.png', '.txt'}]
assert len(observations) == 24
for path in observations:
    shutil.copyfile(path, out/path.name)
report = dict(source=source, native_bug_reproduced=True, candidate_native_fix_qualified=False,
              rc_text_and_selector_wheels_scroll=True, inspector_and_scope_thumb_drag_passed=True,
              rc_full_public_snapshots_exact=True, rc_viewports_returned_to_prior_positions=True,
              scope_top_controls_visible=True, existing_owned_session_reused=True,
              previous_rc_saved_and_fresh_reopened=reopen, restoration=restored,
              graphical_app_launched=False, owner_application_and_projects_changed=False,
              observations=12, scope='Old /206 native observations and current-source equivalence/reproduction. Changed /219 candidate native acceptance remains separate.')
(out/'report.json').write_text(json.dumps(report, indent=2)+'\n')
(out/'README.md').write_text('''# Native scroll and slider baseline /219

The already-running owned /206 session supplies these observations; no new
app is launched. [Receipt](report.json). Current source's original managed
slider factory and entire upstream slider match the old native sources.

1. [RC baseline](01-rc-before.png).
2. [Wheel over the time field](02-text-wheel.png): inspector moves.
3. [Wheel over a probe selector](03-selector-wheel.png): pane moves, choice stays.
4. [Inspector thumb back at the top](04-inspector-thumb-home.png).
5. [Scope thumb at top](05-scope-thumb-top.png): playback controls are reachable.
6. [Scope viewport returned](06-scope-thumb-restored.png).
7. [Owned pot fixture loaded](07-pot-loaded.png), after saving the prior RC.
8. [Pane scrolled past the slider](08-pot-visible.png).
9. [50% slider fully visible](09-pot-control.png), without clicking it.
10. [Wheel changes it to 100%](10-pot-wheel.png), adds user history and dirty state.
11. [One native Undo restores 50%](11-pot-undone.png); the paused result is stale.
12. [Explicit Restart restores fresh readings](12-pot-restored.png), paused at zero.

The first six observations preserve the exact full public snapshot. Pixels show
viewport movement despite an unchanged accessibility tree. The previous RC
graph and its complete 21-row capture/metadata are saved separately and reopen
exactly in a fresh headless agent; its owned workers join and process exits 0.
The pot fixture stays unchanged on disk. The reused session remains on that
disposable pot at 50%, fresh and paused; Undo/restart advance revisions/run/history
and retain completed-work metadata. This is scoped restoration, not full snapshot
equality. Original owner sessions and files are untouched.

The current-source production-control regressions fail with and without focus.
The repaired-source driver/mounted checks are documented separately. These old
native captures do not qualify changed-candidate native behavior.
''')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
(out/'MANIFEST.json').write_text(json.dumps({p.name: sha(p) for p in sorted(out.iterdir()) if p.is_file()}, indent=2)+'\n')
print('Preserved twelve old-native observations with exact RC scrolling state and scoped pot restoration.')
