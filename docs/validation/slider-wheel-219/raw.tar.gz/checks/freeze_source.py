"""Freeze the reviewed slider pin and full quality proof, without native promotion."""
from pathlib import Path
import gzip, hashlib, io, json, re, subprocess, tarfile
root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
out = root/'docs/validation/slider-wheel-219'
sha = lambda data: hashlib.sha256(data).hexdigest()
for name in ['quality', 'sdk-quality', 'sdk-wheel-after', 'mounted-prospective']:
    assert (stage/(name+'-exit-code.txt')).read_text().strip() == '0', name
inputs = json.loads((stage/'source-inputs.json').read_text())
prior = json.loads((root/'docs/validation/verification-output-grid-218/source-inputs.json').read_text())
assert len(inputs) == 889 and all(sha((root/p).read_bytes()) == h for p, h in inputs.items())
desktop = [p for p in inputs if p.startswith('desktop/') and p.endswith('.go') and not p.endswith('_test.go')]
assert len(desktop) == 126 and all(inputs[p] == prior[p] for p in desktop)
assert all(inputs[p] == prior[p] for p in inputs if p.startswith('workbench/'))
lock = json.loads((root/'third_party/vellum/sdk.lock.json').read_text())
old = json.loads((stage/'previous-sdk.lock.json').read_text())
for pin in [lock, old]:
    assert sha((root/pin['archive']).read_bytes()) == pin['sha256']
    assert sha((root/pin['compatibility_patch']['path']).read_bytes()) == pin['compatibility_patch']['sha256']
members = json.loads((stage/'sdk-member-comparison.json').read_text())
assert len(members['changed_files']) == 3 and members['file_count'] == 8435
assert members['bootstrap_unchanged'] and members['manifests_match_every_member']
assert not any('/build/upstream/' in p for p in members['changed_files'])
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root/'build/vellum-public-e58d405').strip()
assert (stage/'sdk-wheel-before.txt').read_text().count('wheel changed the accepted slider value') == 4
assert (stage/'mounted-before.txt').read_text().count('wheel changed circuit state instead of scrolling') == 2
quality = (stage/'quality.txt').read_text()
times = re.findall(r'ok\s+github.com/dshills/elab/desktop\s+(\d+\.\d+)s', quality)
assert len(times) == 2 and 'Ran 67 tests' in quality
assert 'Ran 30 tests' in (stage/'sdk-quality.txt').read_text()
native = json.loads((root/'research/ui-audit/slider-wheel-219/report.json').read_text())
assert native['native_bug_reproduced'] and not native['candidate_native_fix_qualified']
assert native['rc_full_public_snapshots_exact'] and native['restoration']['pot_readings_restored']
previous = json.loads((root/'docs/validation/verification-output-grid-218/candidate-report.json').read_text())
assert sha((Path(previous['candidate'])/'ELab.app/Contents/MacOS/ELab').read_bytes()) == previous['native_sha256']
assert sha((root/'build/releases/ELab-0.181.4-macos-arm64.zip').read_bytes()) == 'd13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
parent = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
changed = sorted(p for p, h in inputs.items() if prior.get(p) != h)
files = {'checks/'+p.relative_to(stage).as_posix(): p.read_bytes()
         for p in sorted(stage.rglob('*')) if p.is_file() and p.suffix in {'.py', '.json', '.txt', '.elab'} and 'build' not in p.relative_to(stage).parts}
absent, external = [], {}
for name in changed:
    if name == lock['archive']:
        external[name] = inputs[name]
        absent.append(name)
        continue
    files['source/'+name] = (root/name).read_bytes()
    if name in prior:
        files['source-before/'+name] = subprocess.check_output(['git', 'show', parent+':'+name], cwd=root)
    else:
        absent.append(name)
files['source/AGENTS.md'] = (root/'AGENTS.md').read_bytes()
files['source-before/absent.json'] = (json.dumps(absent, indent=2)+'\n').encode()
files['source/external-artifacts.json'] = (json.dumps(external, indent=2)+'\n').encode()
assert not out.exists()
out.mkdir(parents=True)
with (out/'raw.tar.gz').open('xb') as disk:
    with gzip.GzipFile(fileobj=disk, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(files.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
(out/'raw-manifest.json').write_text(json.dumps({p: sha(data) for p, data in sorted(files.items())}, indent=2)+'\n')
(out/'source-inputs.json').write_text(json.dumps(inputs, indent=2)+'\n')
report = dict(kind='slider-wheel', application_checks_passed=True, source_parent_commit=parent,
              source_inputs=889, changed_source_inputs=changed, desktop_race_seconds=float(times[0]),
              mounted_race_seconds=float(times[1]), python_tests=67, sdk_python_tests=30,
              sdk_root_driver_normal_and_offscreen_race_vet_passed=True, sdk=lock, previous_sdk=old,
              sdk_member_comparison=members, initial_driver_failures=4, initial_production_control_failures=2,
              focused_driver_seconds=.595, prospective_app_seconds=.710,
              production_desktop_go_sources_unchanged=126, backend_unchanged=True,
              managed_value_sliders_in_application=1, upstream_dependency_bytes_unchanged=True,
              native_baseline=native, graphical_app_launched=False, native_acceptance_passed=False,
              new_commands=0, new_components=0, new_models=0, new_formats=0,
              owner_review_required=False, preserved_download='0.181.4 /205', release_ready=False,
              published=False, raw_archive_sha256=sha((out/'raw.tar.gz').read_bytes()), raw_members=len(files),
              supplemental_core_race_status='Prior /216 full upstream Core race failures remain recorded; these dependency bytes are unchanged. No broad upstream Core pass is claimed.')
(out/'report.json').write_text(json.dumps(report, indent=2)+'\n')
(out/'README.md').write_text(f'''# Slider wheel input /219

October 24, 2026. [Receipt](report.json), [source inputs](source-inputs.json),
[raw evidence](raw.tar.gz), [member hashes](raw-manifest.json),
[native baseline](../../../research/ui-audit/slider-wheel-219/README.md),
[repair notes](../../../research/97-slider-wheel.md).

The owned old /206 native slider changes its potentiometer from 50% to 100%
on wheel input without a click. Model readings and dirty/history state change.
Its original managed slider factory and complete upstream slider match the
current source before repair. Two production-control and four driver cases fail.

The managed value-slider factory drops its wheel handler. Wheel input scrolls
the containing pane without accepted-state changes, while deliberate pointer
clicks/dragging and arrow keys still edit. Framework scrollbars are constructed
directly by their frames and keep their existing handlers. ELab has one managed
value-slider node. No production desktop Go source or backend source changes.

All 8,435 export members match the manifest; only the factory, new driver test
and generated provenance differ from elab10. All upstream dependency bytes,
notices and bootstrap helpers remain unchanged. The full SDK root/driver normal
and offscreen race/vet gates and 30 preparation tests pass. Prior supplemental
full upstream Core race failures remain recorded separately, without a new pass.

The full app gate passes lint/staticcheck, 67 Python tests, root/desktop race and
vet, configured mounted race and offscreen vet. Desktop race takes {times[0]} s;
mounted race {times[1]} s. All 889 frozen source/check inputs match. Original
fixture/import/cwd/native-count mistakes and the restricted local-socket refusal
are retained separately from genuine control regressions.

Native inspector/text/selector/thumb checks preserve the complete RC snapshot.
The prior RC graph and complete captured run are saved and freshly reopened.
The reused session is left on the clean paused pot at 50%, with explicit fresh
readings; its history/run/revision changes are recorded. This old-native proof
does not qualify the changed candidate. /218 and /205 stay preserved; no launch
or unattended permission question is queued. Clean packaging follows.
''')
notes = root/'research/97-slider-wheel.md'
notes.write_text(notes.read_text().replace('October 23, 2026.', 'October 23–24, 2026.').replace(
    'Framework gates, pin review and final application qualification are in\nprogress.',
    f'The [elab11 pin review and full framework/application gates pass](../docs/validation/slider-wheel-219/README.md).\nAll 8,435 SDK members match; upstream dependencies/notices/bootstrap bytes are\nunchanged. Desktop race takes {times[0]} s, mounted race {times[1]} s, and all\n889 frozen source/check inputs match. Clean packaging follows.'))
index = root/'research/README.md'
with index.open('a') as stream:
    stream.write('\n- [Sliders and pane scrolling](97-slider-wheel.md): old-native/current-source reproduction of accidental wiper edits, normal text/selector/thumb checks, and a narrow managed-slider repair. The elab11 pin and full quality pass; fresh native acceptance remains separate.\n')
(out/'MANIFEST.json').write_text(json.dumps({p.name: sha(p.read_bytes()) for p in sorted(out.iterdir()) if p.is_file()}, indent=2)+'\n')
print(json.dumps({k: report[k] for k in ['application_checks_passed', 'source_inputs', 'desktop_race_seconds', 'mounted_race_seconds', 'raw_members']}))
