"""Refresh the disposable pot after its native Undo; preserve fixture files."""
from pathlib import Path
import hashlib, importlib.util, json
root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
before = json.loads((stage/'pot-before.json').read_text())
changed = json.loads((stage/'pot-after-wheel.json').read_text())
prepared = json.loads((stage/'native-preparation.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
spec = importlib.util.spec_from_file_location('client', root/'scripts/persistence-demo.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
client = helper.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json', command_preconditions=True,
                      agent_binary=root/'build/ELab-0.181.5-206-candidate/elab-agent')
try:
    undone = client.ask('project.inspect')
    (stage/'pot-after-undo.json').write_text(json.dumps(undone, indent=2)+'\n')
    assert before['components'] == undone['components'] and before['wires'] == undone['wires']
    assert undone['mixed']['stale'] and not undone['document']['dirty']
    assert changed['undo_entry']['actor'] == 'user'
    assert before['transient']['sample']['time_s'] == changed['transient']['sample']['time_s'] == 0
    charge = lambda state: [(p['id'], p['voltage_v'], p['energy_j']) for p in state['mixed']['capacitors']]
    assert charge(before) == charge(changed)
    client.ask('simulation.restart', {}, True)
    current = client.ask('simulation.wait')
    (stage/'pot-restored.json').write_text(json.dumps(current, indent=2)+'\n')
    assert current['paused'] and not current['mixed']['stale'] and not current['document']['dirty']
    assert current['components'] == before['components'] and current['wires'] == before['wires']
    assert current['mixed']['potentiometers'] == before['mixed']['potentiometers']
    assert current['mixed']['capacitors'] == before['mixed']['capacitors']
    assert current['transient']['sample']['time_s'] == before['transient']['sample']['time_s'] == 0
    assert sha(stage/'RC before slider checks.elab') == prepared['previous_file_sha256']
    assert sha(stage/'Pot wheel baseline.elab') == prepared['pot_fixture_sha256']
    report = dict(native_bug_reproduced=True, wiper_before=.5, wiper_after=1., native_user_history_entries=1,
                  capacitor_charge_and_time_preserved_by_actuation=True, native_undo_restores_graph=True,
                  refresh_after_undo_is_explicit=True, pot_readings_restored=True, previous_rc_file_unchanged=True,
                  pot_fixture_unchanged=True, restored_paused_and_clean=True,
                  whole_snapshot_restored=False,
                  wheel_command_revision_delta=changed['command_revision']-before['command_revision'],
                  changed_snapshot_keys=sorted(k for k in before.keys() | current.keys() if before.get(k) != current.get(k)),
                  scope='The owned test session now holds the saved pot fixture at fresh time zero and 50% wiper. Prior RC graph/capture remains saved separately. Undo/restart advance revision/run/history and retain completed-work metadata; no full-snapshot restoration is claimed.')
    (stage/'native-restoration-report.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report))
finally:
    client.close()
