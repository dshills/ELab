"""Check deliberate agent wiper edits, charge continuity and portable captures."""
from pathlib import Path
import hashlib, importlib.util, json, math, time
root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
build = json.loads((stage/'build-result-signed.json').read_text())
binary = Path(build['review'])/'elab-agent'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(binary) == build['agent_sha256']
fixture = stage/'Pot wheel baseline.elab'
original_sha = sha(fixture)
spec = importlib.util.spec_from_file_location('client', root/'scripts/persistence-demo.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
client = helper.Client(command_preconditions=True, agent_binary=binary)
report = dict(source_commit=build['source_commit'], agent_sha256=sha(binary),
              reference_readings=0, max_voltage_error_v=0., max_current_error_a=0., max_power_error_w=0.)

def snapshot(name):
    value = client.ask('project.inspect')
    (stage/(name+'.json')).write_text(json.dumps(value, indent=2)+'\n')
    return value

def wiper(state):
    return next(p for p in state['components'] if p['id'] == 'Timing')['wiper_position']

def voltage(state):
    return next(p for p in state['mixed']['capacitors'] if p['id'] == 'C1')['voltage_v']

def settle_input():
    deadline = time.monotonic()+10
    while True:
        state = client.ask('project.inspect')
        if (state.get('input_work') or {}).get('status') not in ['queued', 'running', 'canceling']:
            return state
        assert time.monotonic() < deadline
        time.sleep(.001)

def reference(position):
    upper, lower = 1+9998*(1-position), 1+9998*position
    resistance = upper*lower/10000
    return upper, lower, 5*lower/10000, resistance

def check(actual, expected, kind):
    error = abs(actual-expected)
    tolerance = max(1e-8, .005*abs(expected)) if kind != 'voltage' else max(.001, .01*abs(expected))
    report['max_'+kind+'_error_'+dict(voltage='v', current='a', power='w')[kind]] = max(report['max_'+kind+'_error_'+dict(voltage='v', current='a', power='w')[kind]], error)
    assert error <= tolerance, (actual, expected, kind, error, tolerance)
    report['reference_readings'] += 1

try:
    client.ask('project.load', {'path': str(fixture)}, True)
    client.ask('simulation.wait')
    loaded = snapshot('agent-loaded')
    assert loaded['paused'] and wiper(loaded) == .5 and voltage(loaded) == 0
    assert loaded['transient_settings']['high_s'] >= .01
    assert next(p for p in loaded['components'] if p['id'] == 'Timing')['value'] == 10000
    assert next(p for p in loaded['components'] if p['id'] == 'C1')['value'] == 1e-6
    client.ask('simulation.step', {'duration_s': .002}, True)
    before = snapshot('agent-before-wiper')
    _, _, target, resistance = reference(.5)
    reference_before = target*(1-math.exp(-.002/(resistance*1e-6)))
    check(voltage(before), reference_before, 'voltage')
    client.ask('potentiometer.wiper.set', {'id': 'Timing', 'position': .6}, True)
    after = settle_input()
    (stage/'agent-after-wiper.json').write_text(json.dumps(after, indent=2)+'\n')
    assert wiper(after) == .6 and not after['mixed']['stale']
    assert before['run_id'] == after['run_id']
    assert before['transient']['sample']['time_s'] == after['transient']['sample']['time_s'] == .002
    assert voltage(after) == voltage(before)
    result = next(p for p in after['mixed']['potentiometers'] if p['id'] == 'Timing')
    upper, lower, target, resistance = reference(.6)
    assert result['upper_resistance_ohm'] == upper and result['lower_resistance_ohm'] == lower
    current1, current2 = (5-voltage(after))/upper, -voltage(after)/lower
    for key, expected in [('terminal_1_current_a', current1), ('terminal_2_current_a', current2), ('wiper_current_a', -current1-current2)]:
        check(result[key], expected, 'current')
    check(result['power_w'], (5-voltage(after))**2/upper+voltage(after)**2/lower, 'power')
    client.ask('simulation.step', {'duration_s': .002}, True)
    advanced = snapshot('agent-advanced')
    expected = target+(reference_before-target)*math.exp(-.002/(resistance*1e-6))
    check(voltage(advanced), expected, 'voltage')
    client.ask('edit.undo', {}, True)
    undone = snapshot('agent-undone')
    assert wiper(undone) == .5 and undone['mixed']['stale']
    client.ask('edit.redo', {}, True)
    assert wiper(client.ask('project.inspect')) == .6
    client.ask('simulation.restart', {}, True)
    client.ask('simulation.wait')
    baseline = snapshot('agent-restarted')
    identifier = client.ask('simulation.verify', dict(duration_s=.01, sample_step_s=.0005,
                            probe_ids=['v:C1', 'i:C1', 'v:Timing.wiper', 'i:Timing.wiper']), True)['last_operation']
    deadline = time.monotonic()+10
    while True:
        operation = client.ask('operation.inspect', {'id': identifier})
        status = operation['operation']['status']
        if status in ['completed', 'failed', 'canceled']:
            break
        assert time.monotonic() < deadline
        time.sleep(.001)
    assert status == 'completed', operation
    assert operation['metadata']['potentiometer_model']['end_resistance_ohm'] == 1
    page = client.ask('operation.samples', {'id': identifier, 'offset': 0, 'limit': 100})
    assert len(page['rows']) == 21
    for row in page['rows']:
        v = target*(1-math.exp(-row['time_s']/(resistance*1e-6)))
        current = (target-v)/resistance
        for i, expected in enumerate([v, current, v, -current]):
            check(row['values'][i], expected, 'current' if i in [1, 3] else 'voltage')
    (stage/'agent-operation.json').write_text(json.dumps(operation, indent=2)+'\n')
    (stage/'agent-rows.json').write_text(json.dumps(page, indent=2)+'\n')
    inspected = client.ask('project.inspect')
    assert inspected['mixed'] == baseline['mixed'] and inspected['transient'] == baseline['transient']
    client.ask('recording.view.set', {'mode': 'recorded'}, True)
    project = stage/'Pot shared commands and capture.elab'
    assert not project.exists()
    saved = client.ask('project.save', {'path': str(project)}, True)
    assert not saved['document']['dirty']
    saved_sha = sha(project)
    client.ask('potentiometer.wiper.set', {'id': 'Timing', 'position': .7}, True)
    edited = settle_input()
    assert wiper(edited) == .7 and edited['document']['dirty']
    assert client.ask('operation.inspect', {'id': identifier})['metadata'] == operation['metadata']
    assert client.ask('operation.samples', {'id': identifier, 'offset': 0, 'limit': 100})['rows'] == page['rows']
    client.ask('project.load', {'path': str(project)}, True, 'unsaved-changes')
    assert client.ask('project.inspect') == edited
    restored = client.ask('project.load', {'path': str(project), 'discard_changes': True}, True)
    assert wiper(restored) == .6 and not restored['document']['dirty']
    retained = restored['recording']['id']
    assert client.ask('operation.inspect', {'id': retained})['metadata'] == operation['metadata']
    assert client.ask('operation.samples', {'id': retained, 'offset': 0, 'limit': 100})['rows'] == page['rows']
    assert sha(project) == saved_sha and sha(fixture) == original_sha
    report.update(passed=True, deliberate_public_wiper_changes=True, charge_and_time_continuous=True,
                  undo_redo_graph=True, captured_rows=21, capture_readings=84, live_endpoint_references=2,
                  instantaneous_state_relations=4, capture_unchanged_after_later_edit=True,
                  dirty_replacement_refusal_exact=True, saved_reopen_exact=True, saved_sha256=saved_sha,
                  original_fixture_unchanged=True)
finally:
    try:
        job = client.ask('app.close', {'discard_changes': True}, True)['shutdown']
        job = client.wait_for_shutdown_outcome(job)
        assert job['workers_joined'] and job['exit_ready']
        report['shutdown'] = job
    finally:
        client.close()
    report['exit_code'] = client.process.returncode
    (stage/'protocol-report.json').write_text(json.dumps(report, indent=2)+'\n')
assert report['passed'] and report['reference_readings'] == 90 and report['exit_code'] == 0
print(json.dumps({k: report[k] for k in ['passed', 'reference_readings', 'max_voltage_error_v', 'max_current_error_a', 'saved_reopen_exact', 'exit_code']}))
