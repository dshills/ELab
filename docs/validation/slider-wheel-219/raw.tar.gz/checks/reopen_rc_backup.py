"""Prove the preserved RC fixture opens independently with its exact capture."""
from pathlib import Path
import hashlib, importlib.util, json
root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
path = stage/'RC before slider checks.elab'
prepared = json.loads((stage/'native-preparation.json').read_text())
document = json.loads(path.read_text())
digest = hashlib.sha256(path.read_bytes()).hexdigest()
assert digest == prepared['previous_file_sha256']
spec = importlib.util.spec_from_file_location('client', root/'scripts/persistence-demo.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
client = helper.Client(command_preconditions=True, agent_binary=root/'build/ELab-0.181.5-206-candidate/elab-agent')
report = dict(passed=False, saved_sha256=digest, graphical_app_launched=False)
try:
    state = client.ask('project.load', {'path': str(path)}, True)
    assert dict(components=state['components'], wires=state['wires']) == document['graph']
    assert state['document']['recording_count'] == len(document['recordings']['entries']) == 1
    expected = document['recordings']['entries'][0]['data']
    identifier = state['recording']['id']
    operation = client.ask('operation.inspect', {'id': identifier})
    page = client.ask('operation.samples', {'id': identifier, 'offset': 0, 'limit': 200})
    assert operation['metadata'] == expected['metadata'] and page['rows'] == expected['rows']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
    report.update(passed=True, graph_exact=True, capture_metadata_and_rows_exact=True,
                  capture_rows=len(page['rows']), file_unchanged=True)
finally:
    try:
        job = client.ask('app.close', {'discard_changes': True}, True)['shutdown']
        job = client.wait_for_shutdown_outcome(job)
        assert job['workers_joined'] and job['exit_ready']
        report['shutdown'] = job
    finally:
        client.close()
    report['exit_code'] = client.process.returncode
    (stage/'rc-backup-reopen-report.json').write_text(json.dumps(report, indent=2)+'\n')
assert report['passed'] and report['exit_code'] == 0
print('Fresh headless reopen preserves the RC graph and all 21 captured rows/metadata.')
