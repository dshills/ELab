from pathlib import Path
import importlib.util, json
root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('client',root/'scripts/persistence-demo.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
client=helper.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json',command_preconditions=True,
                     agent_binary=root/'build/ELab-0.181.22-223-candidate/elab-agent')
assert not (stage/'setup.json').exists()
try:
    before=client.ask('project.inspect');assert before['paused'] and not before['document']['dirty']
    client.ask('example.reset',{'discard_changes':True},True)
    client.ask('simulation.pause',{},True);client.ask('simulation.wait')
    selected=client.ask('component.select',{'id':'R1'},True)
    part=next(part for part in selected['components'] if part['id']=='R1')
    original=dict(part['position']);moved=dict(original,x=original['x']+10)
    client.ask('component.move',{'id':'R1','position':moved},True)
    after=client.ask('workspace.inspector.set',{'section':'component'},True)
    assert after['drawing']['value']=='1 kΩ'
    (stage/'setup.json').write_text(json.dumps(dict(before=before,original_position=original,moved_position=moved,after=after),indent=2)+'\n')
    print(json.dumps({'command_revision':after['command_revision'],'draft':after['drawing']['value'],'original_position':original,'moved_position':moved}))
finally:client.close()
