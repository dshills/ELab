from pathlib import Path
import datetime, hashlib, importlib.util, json, subprocess, sys
root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
read=lambda name:json.loads((stage/(name+'.json')).read_text())
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
base=read('value-baseline');setup=read('setup')
value_private=['empty-history','value-private-edit','value-local-undo','value-local-redo',
               'value-oldest-boundary','value-branch-boundary','value-editing-keys']
for name in value_private:assert read(name)==base,name
search=read('search-baseline')
for name in ['search-local-undo','search-editing-keys']:assert read(name)==search,name
assert read('undo-walk')==['47','4','1 kΩ']
for name in ['01-initial-selection','02-empty-undo','03-empty-redo','07-undo-walk-3',
             '08-oldest-boundary-1','08-oldest-boundary-2','08-oldest-boundary-3',
             '09-oldest-selection-before','10-oldest-selected-boundary-1',
             '10-oldest-selected-boundary-2','10-oldest-selected-boundary-3']:
    text=(stage/(name+'.txt')).read_text()
    assert 'Value: 1 kΩ, ID: node:dmFsdWUtZW50cnk' in text and 'Position 10, -110' in text
assert 'Value: 47k, ID: node:dmFsdWUtZW50cnk' in (stage/'04-selection-replaced.txt').read_text()
for name in ['11-selected-boundary-replaced','12-branch-redo-boundary']:
    assert 'Value: 3.3k, ID: node:dmFsdWUtZW50cnk' in (stage/(name+'.txt')).read_text()
for prefix,field in [('14-value-key-','Component value'),('21-search-key-','Search components')]:
    files=sorted(stage.glob(prefix+'*.txt'));assert len(files)==6
    for path in files:
        text=path.read_text();assert 'Position 10, -110' in text,path.name
        assert 'focused UI element' in text and field in text.split('focused UI element')[-1],path.name
assert 'focused UI element is 60 button Apply value' in (stage/'15-value-tab-to-button.txt').read_text()
assert 'focused UI element is 23 row (settable, boolean) DC source' in (stage/'22-search-tab-to-list.txt').read_text()
excluded={'example','undo_entry','redo_entry','undo_name','redo_name','document','command_revision','revision','components','can_redo'}
for before_name,after_name,position in [
    ('value-baseline','value-application-undo',setup['original_position']),
    ('value-application-undo','search-baseline',setup['moved_position']),
    ('search-baseline','search-application-undo',setup['original_position']),
    ('search-application-undo','search-application-redo',setup['moved_position'])]:
    before,after=read(before_name),read(after_name)
    assert after['command_revision']==before['command_revision']+1
    assert {k:v for k,v in after.items() if k not in excluded}=={k:v for k,v in base.items() if k not in excluded}
    for original,part in zip(base['components'],after['components'],strict=True):
        expected=dict(original)
        if part['id']=='R1':expected['position']=position
        assert part==expected
    assert after['document']['dirty']==(position==setup['moved_position'])
    assert after['redo_entry' if position==setup['original_position'] else 'undo_entry']==base['undo_entry']
for name in ['search-baseline','search-application-redo']:
    assert {k:v for k,v in read(name).items() if k not in {'command_revision','revision'}}=={k:v for k,v in base.items() if k not in {'command_revision','revision'}}

spec=importlib.util.spec_from_file_location('client',root/'scripts/persistence-demo.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
client=helper.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json',command_preconditions=True,
                     agent_binary=root/'build/ELab-0.181.22-223-candidate/elab-agent')
try:
    assert client.ask('project.inspect')==read('search-application-redo')
    client.ask('project.load',{'path':str(root/'build/native-acceptance-220-tools/RC native 220.elab'),'discard_changes':True},True)
    final=client.ask('recording.speed.set',{'seconds_per_wall_second':.1},True)
    assert final['paused'] and not final['document']['dirty'] and final['transient']['sample']['time_s']==0
    assert final['theme']=='light' and final['recording']['sample_index']==0
    (stage/'final-state.json').write_text(json.dumps(final,indent=2)+'\n')
finally:client.close()
inputs=json.loads((root/'docs/validation/number-step-223/source-inputs.json').read_text())
assert all(sha(root/name)==digest for name,digest in inputs.items())
project=json.loads((root/'build/number-step-223-tools/preserved-project.json').read_text())
assert sha(Path(project['path']))==project['sha256']
update=read('prepared-update');app=Path(update['installed'])
assert sha(app/'Contents/MacOS/ELab Cursor Recovery')==update['native_sha256']
with (stage/'signature-after-checks.txt').open('w') as log:
    subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict','--verbose=2',str(app)],stdout=log,stderr=-2,check=True)
sys.path.insert(0,str(root/'scripts'));from runtime_isolation import bundle_tree
build=json.loads((root/'build/number-step-223-tools/build-result-signed.json').read_text())
assert bundle_tree(Path(build['review'])/'ELab.app')==build['source_bundle']
assert sha(root/'build/releases/ELab-0.181.4-macos-arm64.zip')=='d13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
report=dict(passed=True,native_checks_completed=[14,15],empty_undo_redo_initial_text_preserved=True,
 initial_selection_proved_by_replacement=True,real_text_undo_sequence=read('undo-walk'),
 repeated_oldest_undo_count=6,explicit_oldest_selection_proved_by_replacement=True,
 local_character_undo_redo_passed=True,new_edit_invalidates_old_redo=True,
 native_editing_key_cases=12,value_private_full_state_equalities=len(value_private),
 search_private_full_state_equalities=2,application_history_positive_controls=4,
 actual_noneditor_focus_routes=['Apply value button','component list row'],
 application_history_each_one_command=True,electrical_result_and_other_state_exact=True,
 harness_assumptions_corrected=['CUA typeText delivered individual character edits: first Undo of 47k yields 47. Retained original assertion/capture; no product defect or code change.', 'Verifier initially omitted optional redo_entry from expected history metadata. It is now included and asserted exactly equal to the original move history entry. Initial verification stopped before socket access/restoration.'],
 source_inputs_unchanged=len(inputs),saved_fixture_unchanged=True,installed_signature_valid=True,
 original_candidate_unchanged=True,preserved_205_unchanged=True,final_clean_paused_at_zero=True,
 production_changes=0,full_source_suites_repeated=False,remaining_original_native_checks=4,
 source_commit=build['source_commit'],native_sha256=update['native_sha256'],observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(stage/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
