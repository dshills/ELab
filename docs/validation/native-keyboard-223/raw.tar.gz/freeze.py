from pathlib import Path
import gzip, hashlib, io, json, tarfile
root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
dest=root/'docs/validation/native-keyboard-223';assert not dest.exists()
report=json.loads((stage/'report.json').read_text());assert report['passed']
(stage/'native-method.txt').write_text('''All native input used the documented cua_repl API in the existing current223App.
setup.py prepares one reversible agent resistor move and a fresh 1 kΩ value field.
Click value; super+a; capture; super+z; capture; super+shift+z; capture.
typeText(47k) replaces the selection. First super+z yields 47, not the assumed
whole baseline; this is character-granularity input, not a failed text undo.
super+shift+z restores 47k. Walk Undo through 47, 4, 1 kΩ; repeat at oldest three
times. Select all explicitly at oldest, repeat Undo three times, typeText(3.3k)
without reselecting; exact 3.3k proves selection preservation. Redo stays 3.3k.
Replace private value with 123; Left/Delete/Left/Right/BackSpace/Escape, capturing
each state. Tab focuses Apply; super+z undoes actual component move; super+shift+z
replays it. Search receives private 123; super+z gives 12; redo restores 123;
the same deletion/arrow/Escape sequence remains local. Tab focuses a component
list row; application Undo/Redo again moves the resistor back/forward exactly.
Public snapshots verify exact private-state boundaries and each history command.
qualify.py verifies preserved source/release files and restores the owned fixture.
No alternate input technology, new app launch, hardware timing or native Save-panel
shortcut acceptance is inferred from these custom-editor/native-scene checks.
''')
files={p.relative_to(stage).as_posix():p.read_bytes() for p in stage.rglob('*') if p.is_file() and p.suffix in {'.py','.json','.txt','.jpg'}}
for name,data in files.items():
    assert Path(name).name!='endpoint.json'
    if name.endswith('.jpg'):assert data.startswith(b'\xff\xd8\xff')
dest.mkdir(parents=True)
with (dest/'raw.tar.gz').open('xb') as disk:
    with gzip.GzipFile(fileobj=disk,mode='wb',filename='',mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for name,data in sorted(files.items()):
                info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
                tar.addfile(info,io.BytesIO(data))
sha=lambda data:hashlib.sha256(data).hexdigest()
manifest={name:sha(data) for name,data in sorted(files.items())}
(dest/'raw-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
report.update(raw_members=len(files),raw_archive_sha256=sha((dest/'raw.tar.gz').read_bytes()))
(dest/'report.json').write_text(json.dumps(report,indent=2)+'\n')
pending=json.loads((root/'docs/validation/native-comparison-223/native-acceptance-pending.json').read_text())
pending.update(completed_checks_for_copied_runtime=[1,2,4,5,7,8,10,12,13,14,15,16,17,18],remaining_checks_count=4,
               new_native_checks=[14,15],carried_forward_checks=[1,2,4,5,7,8,10,12,13,16,17,18],
               current_build_fresh_native_checks=[14,15],evidence='README.md',
               prior_evidence='../native-comparison-223/README.md',
               current_build_fresh_native_scope='Fresh and oldest text-history boundaries with selection replacement proofs, native text Undo/Redo, value/search editing keys, and actual button/list application Undo/Redo routing')
(dest/'native-acceptance-pending.json').write_text(json.dumps(pending,indent=2)+'\n')
(dest/'README.md').write_text('''# Native keyboard and text history /223

[Receipt](report.json), [captures and checks](raw.tar.gz), [hashes](raw-manifest.json),
[remaining checklist](native-acceptance-pending.json).

Original native items 14 and 15 pass on the unchanged code-equivalent /223 copy.
The same owned session is reused. No product change, new feature or app launch.

## Text history and selection

A fresh `1 kΩ` component-value field has available circuit history from one agent
move. Command-Z and Shift-Command-Z preserve its initial text. An explicit Select
All remains visible across those empty-history shortcuts; typing `47k` without
reselecting replaces the whole value exactly, proving selection preservation.

Native text Undo changes `47k` to `47`; Redo restores `47k`. Walking the actual
character-level history gives `47`, `4`, then `1 kΩ`. Three further Undos preserve
that boundary. Select All is explicitly established at the oldest entry, then
three additional Undos preserve it. Typing `3.3k` without reselecting again replaces
the whole initial value exactly. A new edit invalidates the previous Redo branch.
This does not claim that Undo itself restores a pre-edit full selection: the
oldest-entry selection is deliberately established before testing its preservation.

The first harness assertion incorrectly expected one Undo to reverse a complete
CUA typeText call. Actual input creates individual character edits; that retained
capture shows a successful local character Undo. No product repair is inferred.

## Editor ownership and positive application controls

Both value and search editors handle Left, Delete, Left, Right, Backspace and
Escape locally. Real deletions produce the expected strings, and Escape restores
the accepted field text without changing focus or circuit state. Search text
Undo/Redo consumes its own character edit while circuit Undo remains available.
Seven value-phase and two search-phase public snapshots equal their respective
accepted baselines completely, including command revisions. Native captures also
retain component position and editor focus after every individual editing key.

After Tab leaves the value editor for Apply, Command-Z restores the resistor's
original position and Shift-Command-Z restores the move. Tab out of search focuses
the component list; the same two shortcuts again undo and redo the circuit move.
All four positive controls deliver exactly one shared command each. Exact history
entry identity, component geometry and dirty-state restoration are checked. After
each Redo, the entire accepted state equals baseline except revisions. Electrical
results, net connectivity, values and unrelated state are exact throughout.

An initial verifier omitted optional `redo_entry` from its allowed history fields.
It stopped before socket access; the corrected verifier asserts that entry's exact
identity rather than weakening electrical/state checks. Both harness corrections
are recorded in the receipt; no observed application defect is hidden.

## Preservation and remaining scope

All 897 frozen source/check inputs, saved fixture, strict installed signature,
original candidate and /205 download remain unchanged. Existing full source
gates still apply; no redundant full suite. The owned disposable fixture is
restored clean, paused at zero, Light, with playback speed 0.1. Raw JPEG bytes
are retained with matching extensions.

Fourteen of eighteen original native checks now have scoped evidence; four remain:
3, 6, 9 and 11. These custom-editor/native-scene checks do not qualify the separate
AppKit Save-panel Command-A issue, controlled slow/fast divider drags, or exact
pre-agent callback queue origins. /223 stays held and /205 remains the preserved
download. Continue remaining form/parser ownership and investigate those distinct
native routes under the saved authorization, without owner-review or launch waits.
''')
(root/'research/109-native-keyboard-history.md').write_text('''# Native keyboard and history acceptance

October 24, 2026. [Evidence and checklist](../docs/validation/native-keyboard-223/README.md).

Native items 14 and 15 pass. Fresh and oldest text-history boundaries preserve
initial value and explicit selection, proved by replacement typing. Actual native
text Undo/Redo works with CUA's character-level edits. Search and value deletion,
arrows and Escape stay local. After Tab reaches actual Apply/list controls,
Command-Z and Shift-Command-Z correctly undo/redo a reversible circuit move.

Private public snapshots remain exact; each of four application-history actions
delivers one command, restores the expected history entry/geometry/dirty state,
and preserves electrical results. Two harness assumptions were corrected openly:
typeText is not one coalesced Undo record, and `redo_entry` is optional history
metadata whose exact identity must be asserted after Undo. No product change.

Source, signature, saved fixture and /205 remain exact; the owned app is restored
clean and paused at zero. Fourteen original native checks are complete. Remaining:
3, 6, 9 and 11. AppKit Save shortcuts and exact native queue/rate qualification
remain separate. Continue those routes and current form/parser ownership under
standing authorization without waiting for owner review or another launch prompt.
''')
with (root/'research/README.md').open('a') as out:
    out.write('\n- [Native keyboard and text history](109-native-keyboard-history.md): initial/boundary selection, local text editing, actual application-history routing, exact state preservation and four remaining native checks.\n')
with (root/'research/80-overnight-work-plan.md').open('a') as out:
    out.write('''

## Checkpoint: native keyboard and text history

[Native items 14 and 15](109-native-keyboard-history.md) pass: empty/oldest text
history and explicit selection preservation, real local Undo/Redo, search/value
editing keys, and application Undo/Redo after Tab to actual Apply/list controls.
Fourteen original checks are complete; 3, 6, 9 and 11 remain. Source, electrical
state, signatures, fixture and /205 stay exact. Current evidence does not qualify
the separate AppKit Save route, controlled drag rates or exact callback queue
origins. Continue remaining form/parser and native-route checks in the existing
owned session; no owner-review or launch-permission wait.
''')
plan=root/'research/34-first-version-plan.md';text=plan.read_text()
start=text.index('**Current maintenance work:**');end=text.index('\n## Historical plan',start)
text=text[:start]+'''**Current maintenance work:** /223's decimal-step repair and the
[latest native keyboard/history checks](109-native-keyboard-history.md) pass
within scope. Fourteen of eighteen original native items now have evidence;
four remain: 3, 6, 9 and 11. AppKit Save Command-A, controlled divider drag rates
and exact pre-agent callback queue origins remain distinct. Item 9 is partial.
Native value/search editing and actual application Undo/Redo routing are qualified.

Earlier validation-scroll, private-draft, footer/theme, manual-step, slider,
Verify endpoint, numeric-wheel and captured-measurement/comparison repairs remain
included. [Electronics reference checks](95-gate-common-mode.md) cover seven
RC-driven MOSFET circuits and active work preservation. The earlier exit follows
a native Quit-menu request whose initiator is unknown; no spontaneous crash or
broad lifecycle pass is claimed. /207–/223 stay held for remaining native acceptance
and do not replace /205. Owner review remains deferred. Standing run/desktop
authorization is saved in `AGENTS.md` and must not be requested again.
'''+text[end:];plan.write_text(text)
with tarfile.open(dest/'raw.tar.gz','r:gz') as tar:
    assert {m.name:sha(tar.extractfile(m).read()) for m in tar.getmembers()}==manifest
print(json.dumps({'archived_members':len(files),'completed_checks':[14,15],'remaining_original_checks':4}))
