# ELab 0.172.0 /189 · unqualified candidate rehearsal

This folder contains the clean app, matching external agent, three editable
examples and framework/dependency notices. No account or development tools are
needed to run the app or agent. The original candidate and installed app remain
separate from this local archive rehearsal.

Native recorded-time acceptance is still open: /188 refused one first-click
`3 ms` → Previous edit. /189 contains a source repair, but blank ordinary window
images prevented its visible recheck. Internal canvas smoke and tested public
commands pass; they do not close that native gate. This is not a qualified
replacement, promotion or public distribution package.

## Reference tasks

1. Draw an LED loop, change resistance, undo/redo and repair a disconnected wire.
2. Load RC-charge.elab; inspect charge/discharge, pause/step and scope cursors.
3. Load LED-flasher.elab; inspect both transistor branches and measure timing.
4. Save/reopen a copy, then export the schematic and scope data.

The matching `elab-agent` accepts newline-delimited JSON requests on stdin.
Begin with `capabilities.list` to discover the same shared circuit commands.
Native field buffers and physical focus/typing remain separate acceptance work.

Owner walkthrough has not been tried. Default-startup/clean-account checks are
owner-deferred for private alpha only. Reader/IME, broader environments,
performance and the hobbyist study remain open. The local ad-hoc signature is
not Developer ID signing, notarization, Gatekeeper or Finder acceptance.
