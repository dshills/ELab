# Keep existing work

This rehearsal does not replace the installed app or earlier review folders.
Save and quit an active app before switching app binaries. Keep original project
files when trying a newer build; reverting a binary does not convert saved files
to an older project format. Existing canonical /120 remains untouched.
