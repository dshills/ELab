from pathlib import Path
import copy,hashlib,importlib.util,json,sys,time
from client import Client,OUT
R=Path(__file__).resolve().parents[2];S=Path(__file__).resolve().parent;B=json.loads((S/'build-result-signed.json').read_text());P=Path(B['review']);OUT.mkdir(mode=0o700,exist_ok=False);sys.path.insert(0,str(R/'scripts'))
exits=[]
def write(name,data):(OUT/name).write_text(json.dumps(data,indent=2)+'\n')
def run_existing(label,filename):
 spec=importlib.util.spec_from_file_location(label,R/'scripts'/filename);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);base=m.helper.Client
 class PackagedClient(base):
  def __init__(self,*args,**kwargs):
   assert not args or args[0] is None
   kwargs['agent_binary']=P/'elab-agent';super().__init__(*args,**kwargs)
  def close(self):
   result=self.ask('app.close',{'discard_changes':True},True);job=self.wait_for_shutdown_outcome(result['shutdown'])
   assert job['status']=='completed' and all(job[k] for k in ['workers_joined','recovery_finalized','exit_ready'])
   super().close();assert self.process.returncode==0;exits.append({'label':label,'exit_code':self.process.returncode,'shutdown':job})
 m.helper.Client=PackagedClient;sys.argv=[filename,'--output',str(OUT/(label+'.json')),'--artifacts',str(OUT/label)];m.main()
run_existing('arrivals','recording-timing-demo.py')
run_existing('transitions','transition-timing-demo.py')

def close(c):
 state=c.ask('app.close',{'discard_changes':True},True);job=state['shutdown'];deadline=time.monotonic()+15
 while job['status'] in ('queued','running'):
  assert time.monotonic()<deadline;time.sleep(.01);job=c.ask('app.close.inspect',{'id':job['id']})
 assert job['status']=='completed' and all(job[k] for k in ['workers_joined','recovery_finalized','exit_ready']);write(c.name+'-shutdown.json',job);c.close_connection()
def semantic(result):
 value=copy.deepcopy(result);value['settings'].pop('id');value.pop('origin_id',None);return value
def physics(state):return {k:state.get(k) for k in ['components','wires','document','run_id','electrical_revision','result','npn','mixed','transient','undo_entry','redo_entry']}
def rows(c,identity,total):
 result=[]
 for offset in range(0,total,100):result+=c.ask('operation.samples',{'id':identity,'offset':offset,'limit':100})['rows']
 return result
c=Client('coupled-settings');cases=[]
try:
 c.ask('project.inspect');c.ask('example.npn-pulse',{'discard_changes':True},True);c.ask('simulation.pause',{},True);c.ask('simulation.wait')
 state=c.ask('simulation.verify',{'duration_s':.5,'probe_ids':['v:VIN.positive','v:Q1.collector']},True);identity=state['last_operation'];deadline=time.monotonic()+15
 while True:
  capture=c.ask('operation.inspect',{'id':identity});status=capture['operation']['status'];assert status not in ['failed','canceled']
  if status=='completed':break
  assert time.monotonic()<deadline;time.sleep(.01)
 c.ask('recording.view.set',{'mode':'recorded'},True);state=c.ask('project.inspect');total=state['recording']['sample_count'];original_rows=rows(c,identity,total)
 c.ask('verification.export',{'id':identity,'format':'json','path':str(OUT/'original-capture.json')},True);original_bytes=(OUT/'original-capture.json').read_bytes()
 cfg={'id':identity,'probe_id':'v:VIN.positive','level':'2.5 V','second_level':'4 V','direction':'both','start_s':0,'end_s':.5,'limit':8}
 for name,base,bad,corrected in [
  ('level',{}, {'level':'4 V'}, {'level':'4 V','second_level':'4.5 V'}),
  ('second',{}, {'second_level':'2.5 V'}, {'level':'2 V','second_level':'2.5 V'}),
  ('start',{'end_s':.3}, {'start_s':'400 ms'}, {'start_s':'400 ms','end_s':'500 ms'}),
  ('end',{'start_s':.2}, {'end_s':'100 ms'}, {'start_s':0,'end_s':'100 ms'}),
  ('swapped',{}, {'level':'4 V'}, {'level':'4 V','second_level':'2.5 V'}),
  ('probe',{}, {'probe_id':'v:Q1.collector','level':'2 mA'}, {'probe_id':'v:Q1.collector','level':'2.5 V'}),
 ]:
  current=dict(cfg,**base);c.ask('recording.timing.set',current,True);before=c.ask('project.inspect');refusal=c.ask('recording.timing.set',dict(current,**bad),True,expect_error=True);assert c.ask('project.inspect')==before
  params=dict(current,**corrected);result=c.ask('recording.timing',params);assert c.ask('project.inspect')==before
  after=c.ask('recording.timing.set',params,True);assert after['recording']['timing']==result and physics(after)==physics(before)
  params['direction']='rising';after=c.ask('recording.timing.set',params,True);assert after['recording']['timing']==c.ask('recording.timing',params)
  cases.append({'name':name,'refusal':refusal,'timing':after['recording']['timing'],'refusal_snapshot_preserved':True,'query_pure':True,'configuration_matches_query':True})
 assert original_rows==rows(c,identity,total) and capture['metadata']==c.ask('operation.inspect',{'id':identity})['metadata']
 c.ask('verification.export',{'id':identity,'format':'json','path':str(OUT/'after-timing-capture.json')},True);assert (OUT/'after-timing-capture.json').read_bytes()==original_bytes
 project=OUT/'timed-result.elab';c.ask('project.save',{'path':str(project)},True);saved=project.read_bytes()
finally:close(c)
fresh=Client('fresh-reopen')
try:
 fresh.ask('project.inspect');fresh.ask('project.load',{'path':str(project)},True);state=fresh.ask('simulation.wait');assert state['paused'] and not state['document']['dirty'] and 'timing' not in state['recording']
 restored_id=state['recording']['id'];assert rows(fresh,restored_id,total)==original_rows
 params=dict(params,id=restored_id);restored=fresh.ask('recording.timing',params);assert semantic(restored)==semantic(cases[-1]['timing'])
 fresh.ask('verification.export',{'id':restored_id,'format':'json','path':str(OUT/'fresh-capture.json')},True);assert (OUT/'fresh-capture.json').read_bytes()==original_bytes and project.read_bytes()==saved
finally:close(fresh)
arrivals=json.loads((OUT/'arrivals.json').read_text());transitions=json.loads((OUT/'transitions.json').read_text());assert arrivals['passed'] and transitions['passed']
report={'passed':True,'source_commit':B['source_commit'],'native_sha256':B['native_sha256'],'agent_sha256':B['agent_sha256'],'arrivals_cases':len(arrivals['cases']),'transition_cases':len(transitions['cases']),'atomic_settings_cases':cases,'captured_rows':total,'captured_metadata_rows_and_bytes_preserved':True,'fresh_reopen_rows_timing_and_raw_export_equal':True,'source_project_bytes_preserved':True,'existing_script_exits':exits,'native_started':False,'release_qualified':False,'promoted':False,'scope':'Exact matching packaged headless agent, existing RC/NPN/flasher timing workflows and atomic settings. Private buffers and probe ownership remain separately qualified by mounted source tests; no fresh native window/input claim.'}
write('report.json',report);print(json.dumps({k:v for k,v in report.items() if k not in ['atomic_settings_cases','existing_script_exits']}))
