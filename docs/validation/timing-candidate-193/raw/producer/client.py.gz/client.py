"""Public fixture/observation only; native input is performed exclusively by CUA."""
from pathlib import Path
import hashlib,json,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path('/private/tmp/elab-candidate-193-checks');AGENT=ROOT/'build/ELab-0.176.0-193-candidate/elab-agent'
class Client:
 def __init__(self,name,connect=False):
  self.name,self.sequence,self.revision=name,0,None;self.connect=connect
  self.log=(OUT/(name+'-protocol.jsonl')).open('x')
  assert connect is False, 'No native endpoint in this check'
  args=[str(AGENT)]
  self.process=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=(OUT/(name+'-stderr.txt')).open('x'),text=True)
 def ask(self,command,params=None,mutate=False,expect_error=False):
  self.sequence+=1;request=dict(version=1,id=f'{self.name}-{self.sequence}',command=command,params={} if params is None else params)
  if mutate:
   assert self.revision is not None
   request.update(key=f'{self.name}-{self.sequence}',expected_command_revision=self.revision)
  self.log.write(json.dumps(dict(request=request))+'\n');self.log.flush();self.process.stdin.write(json.dumps(request)+'\n');self.process.stdin.flush()
  line=self.process.stdout.readline();assert line,('EOF',command);response=json.loads(line);self.log.write(json.dumps(dict(response=response))+'\n');self.log.flush();assert response['id']==request['id']
  if 'error' in response:
   if expect_error:
    assert response['error']['code']=='invalid-params';return response
   raise RuntimeError(json.dumps(response))
  assert not expect_error,command
  result=response.get('result')
  if isinstance(result,dict) and 'components' in result and 'command_revision' in result:self.revision=result['command_revision']
  return result
 def close_connection(self):
  self.process.stdin.close();code=self.process.wait(timeout=10);self.log.close();assert code==0
  (OUT/(self.name+'-bridge-exit.json')).write_text(json.dumps(dict(exit_code=code,requests=self.sequence,connection_only=self.connect),indent=2)+'\n')
