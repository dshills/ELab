"""Offline validation of the two native admission cases; no input/capture."""
from pathlib import Path
import hashlib,importlib.util,json,sys
from PIL import Image
if sys.flags.optimize:raise SystemExit('Assertions required')
ROOT=Path('/Users/dshills/Development/projects/ELab');STAGE=Path(__file__).resolve().parent;OUT=Path('/private/tmp/elab-native-baseline-admission-173');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('independent_rc',STAGE/'reference.py');ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref)
plan=json.loads((STAGE/'declaration.json').read_text());assert all(sha(Path(n))==h for n,h in plan['pinned_files'].items())
profile=json.loads((ROOT/'tools/baseline-admission/profiles/rc.json').read_text());session=json.loads((OUT/'report.json').read_text());integration=json.loads((OUT/'integration-result.json').read_text());assert integration['passed'] and integration['eligible_latency_observations']==0 and integration['timing_percentile'] is None
assert session['owned_process_absent'] and session['endpoint_removed'] and not session['forced_cleanup'] and session['open_exit_code']==0 and session['native_exit_status'] is None
for k in ('shared_geometry_unchanged','review_unchanged','copied_bundle_unchanged','canonical_unchanged','baseline_file_unchanged'):assert session[k]
current=json.loads((ROOT/'research/ui-audit/first-version/inspector-width-review-checkpoint.json').read_text());assert len(current['quality']['source_sha256'])==659 and all(sha(ROOT/n)==h for n,h in current['quality']['source_sha256'].items())
results=[]
for case in plan['cases']:
 folder=OUT/'trials'/case['id'];capture=folder/'capture';read=lambda n:json.loads((folder/n).read_text());admission=read('admission.json');action=read('capture-action.json');before=read('before-apply.json');after=read('after-apply.json');outcome=read('outcome.json');report=read('capture/report.json');bind=read('independent-bindings.json')
 assert admission['admitted']==case['expected_admitted'] and action['case_passed'] and outcome['status']=='native_guard_passed' and outcome['recorder_exit_code']==0
 assert action['marker_calls']==action['apply_calls']==int(case['expected_admitted']) and action['input_call_completed']==case['expected_admitted']
 assert admission['attempt_id']==action['attempt_id']==bind['attempt_id'] and admission['trial_id']==case['id']==bind['trial_id']
 assert read('accepted-handshake.json')['attempt_id']==admission['attempt_id']
 rows=[json.loads(line) for line in (capture/'frames.jsonl').read_text().splitlines()];frames=[v for v in rows if v.get('png')];markers=[v for v in rows if v['event']=='marker'];assert len(markers)==int(case['expected_admitted'])
 first=frames[0];assert first['index']==admission['frame_index']==bind['frame_index'] and first['png_sha256']==admission['png_sha256']==bind['png_sha256']
 assert first['width_pixels']==profile['width'] and first['height_pixels']==profile['height']
 for key in ('frame_geometry_validated','target_geometry_matches_at_receipt','presentation_matches_converted_display_time'):assert first[key] is True
 image=Image.open(capture/first['png']).convert('RGBA');regions=[]
 for region in profile['regions']:
  crop=image.crop(region['rect']);assert crop.getchannel('A').getextrema()==(255,255);digest=hashlib.sha256(crop.convert('RGB').tobytes()).hexdigest();regions.append(dict(name=region['name'],rgb_sha256=digest,matches=digest==region['rgb_sha256']))
 assert regions==admission['result']['regions'];assert all(v['matches'] for v in regions)==case['expected_admitted']
 if not case['expected_admitted']:assert [v['name'] for v in regions if not v['matches']]==['accepted-capacitor'] and action['refusal']=='Error: Baseline was not admitted' and action['stale_receipt_refusal']=='Error: Admission binding differs: trial_id'
 else:
  assert [v['name'] for v in action['events']]==['capture_start_requested','baseline_image_received','marker_requested','complete_acknowledgment_validated','input_call_will_invoke','input_call_completed','after_input_ax_observed']
  assert markers[0]==action['marker_acknowledgment']
  assert int(markers[0]['mach_ticks'])>=int(first['received_mach_ticks'])
 files={p.name:dict(sha256=sha(p),bytes=p.stat().st_size) for p in capture.glob('frame-*.png')};assert len(files)==report['unique_images']
 for name,v in files.items():assert name=='frame-'+v['sha256']+'.png'
 for frame in frames:assert frame['png'] in files and files[frame['png']]['sha256']==frame['png_sha256']
 assert len(frames)==report['complete_frames'] and sum(v['bytes'] for v in files.values())==report['image_bytes']<=64<<20
 assert report['capture_started'] and report['collector_error'] is None and report['command_error'] is None and report['geometry_rechecked_after_stop'] and report['eligible_latency_observations']==0
 delta=int(case['expected_admitted']);assert after['electrical_revision']==before['electrical_revision']+delta and after['run_id']==before['run_id']+delta and before['wires']==after['wires']
 a={p['id']:p for p in before['components']};b={p['id']:p for p in after['components']};assert a['Storage']['value']==case['public_before_f'] and b['Storage']['value']==2e-6
 for name in a:
  x,y=dict(a[name]),dict(b[name])
  if name=='Storage':x.pop('value');y.pop('value')
  assert x==y
 assert not after['transient']['stale'];matched=read('agent-matched-time.json');native_laws=ref.independent(after);agent_laws=ref.independent(matched)
 for key in ('time_s','input_v','voltage_v','current_a','energy_j'):assert abs(after['transient']['sample'][key]-matched['transient']['sample'][key])<1e-10
 results.append(dict(id=case['id'],admitted=admission['admitted'],first_png=first['png'],first_frame_index=first['index'],complete_frames=len(frames),unique_images=len(files),image_bytes=report['image_bytes'],markers=len(markers),apply_calls=action['apply_calls'],controller_events=len(action['events']),pillow_go_regions_equal=True,regions=regions,late_presentation_frames=report['frames_outside_presentation_window'],future_at_receipt_frames=report['frames_with_display_time_after_receipt'],native_laws=native_laws,agent_laws=agent_laws,image_manifest=files))
result=dict(passed=True,cases=results,complete_frames=sum(v['complete_frames'] for v in results),unique_images=sum(v['unique_images'] for v in results),image_bytes=sum(v['image_bytes'] for v in results),independent_decoder='Pillow',guard_decoder='Go image/png',eligible_latency_observations=0,timing_percentile=None,full_recording_visibility_qualified=False,new_cohort=False,current_application_go_sources_unchanged=659,current_review='0.168.0 /185',tested_native='0.156.0 /173',native_exit_status=None,open_exit_code=0,session_controller_exit_code=0,worker_exit_code=0)
(OUT/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='cases'}))
