from pathlib import Path
import hashlib,json
r=Path('/Users/dshills/Development/projects/ELab');s=r/'build/native-baseline-admission-173-work';p=json.loads((s/'declaration.json').read_text());assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in p['pinned_files'].items())
a=json.loads((r/'docs/validation/baseline-content-admission-173/artifacts.json').read_text())
for n,h in a['source_sha256'].items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
old=json.loads((r/'research/39-led-rc-followup-plan.json').read_text());assert p['native_sha256']==old['native_sha256'] and p['agent_sha256']==old['agent_sha256']
print('declaration and unchanged admission implementation/recorder/app pins verified')
