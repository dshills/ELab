async function runNativeAdmission173(appHandle, root, plan) {
 const fs=await import('node:fs/promises'),crypto=await import('node:crypto');
 const {withAdmittedBaseline}=await import('/Users/dshills/Development/projects/ELab/tools/baseline-admission/controller.mjs');
 const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
 for(const [path,digest] of Object.entries(plan.pinned_files)) if(hash(await fs.readFile(path))!==digest)throw Error('Pinned file changed: '+path);
 const profilePath='/Users/dshills/Development/projects/ELab/tools/baseline-admission/profiles/rc.json';const profile=JSON.parse(await fs.readFile(profilePath,'utf8'));
 const toolPath='/Users/dshills/Development/projects/ELab/build/baseline-admission-tools/baseline-admission';
 async function read(path){try{return JSON.parse(await fs.readFile(path,'utf8'));}catch(e){if(e.code==='ENOENT'||e instanceof SyntaxError)return null;throw e;}}
 async function wait(path,seconds=25,alternative){const end=Date.now()+seconds*1000;while(Date.now()<end){const v=await read(path);if(v)return v;if(alternative){const failed=await read(alternative);if(failed)throw Error('Worker finished before readiness: '+JSON.stringify(failed));}await new Promise(r=>setTimeout(r,3));}throw Error('Deadline: '+path);}
 async function write(path,value){await fs.writeFile(path,JSON.stringify(value,null,2)+'\n',{flag:'wx',mode:0o600});}
 const results=[];let positiveReceipt=null;
 for(const intent of plan.cases){
  const folder=root+'/trials/'+intent.id;const action={id:intent.id,input_call_invoked:false,input_call_completed:false,marker_calls:0,apply_calls:0,events:[],eligible_latency_observations:0,timing_percentile:null};
  const persist=async()=>{await fs.writeFile(folder+'/capture-action.next',JSON.stringify(action,null,2)+'\n',{mode:0o600});await fs.rename(folder+'/capture-action.next',folder+'/capture-action.json');};
  const event=async(name,detail={})=>{action.events.push({sequence:action.events.length+1,name,wall_time_utc:new Date().toISOString(),...detail});await persist();};
  let created=false;
  try{
   const ready=await wait(folder+'/ready.json',30,folder+'/done.json');if(ready.id!==intent.id||ready.owned_pid!==plan.owned_pid||ready.expected_admitted!==intent.expected_admitted)throw Error('Wrong current native case');
   await write(folder+'/capture-action.json',action);created=true;
   let ax=await appHandle.getAXState({emit:false,disableDiffing:true});
   if(!ax.includes('Storage')||!ax.includes(intent.expected_admitted?'τ = 10 ms':'τ = 20 ms'))throw Error('Wrong native baseline');
   let apply;
   if(intent.expected_admitted){
    const sidebar=ax.match(/^\s*(\d+) scroll area node:c2lkZWJhcg$/m);if(!sidebar)throw Error('Inspector absent');
    await appHandle.scroll(Number(sidebar[1]),'up',100);await appHandle.scroll(Number(sidebar[1]),'down',0.5);
    ax=await appHandle.getAXState({emit:false,disableDiffing:true});await fs.writeFile(folder+'/before-draft.ax.txt',ax,{flag:'wx',mode:0o600});
    const field=ax.match(/^\s*(\d+) text field \(settable\) Component value,/m);if(!field)throw Error('Value field absent');
    await appHandle.click(Number(field[1]));await appHandle.pressKey('super+a');await appHandle.typeText('2uF');
    ax=await appHandle.getAXState({emit:false,disableDiffing:true});
    const line=ax.split('\n').find(l=>l.includes('text field (settable) Component value,'));if(!line?.includes('Value: 2uF'))throw Error('Private draft absent');
   }
   await fs.writeFile(folder+'/before-apply.ax.txt',ax,{flag:'wx',mode:0o600});
   await write(folder+'/draft-ready.json',{id:intent.id,typed:intent.expected_admitted?'2uF':null});await wait(folder+'/armed.json',15,folder+'/done.json');
   ax=await appHandle.getAXState({emit:false,disableDiffing:true});await fs.writeFile(folder+'/armed-draft.ax.txt',ax,{flag:'wx',mode:0o600});
   if(!ax.includes(intent.expected_admitted?'τ = 10 ms':'τ = 20 ms'))throw Error('Accepted state changed');
   if(intent.expected_admitted){const line=ax.split('\n').find(l=>l.includes('text field (settable) Component value,'));if(!line?.includes('Value: 2uF'))throw Error('Private draft changed');apply=ax.match(/^\s*(\d+) button Apply value,/m);if(!apply)throw Error('Apply absent');}
   const attempt=crypto.randomUUID();action.attempt_id=attempt;await write(folder+'/capture-start.request',{id:intent.id,attempt_id:attempt});await event('capture_start_requested');
   const receipt=await wait(folder+'/admission.json',3,folder+'/done.json');
   const raw=(await fs.readFile(folder+'/capture/frames.jsonl','utf8')).split('\n').slice(0,-1);let first;
   for(const line of raw){const row=JSON.parse(line);if(row.event==='marker')throw Error('Marker preceded baseline admission');if(row.status===0){if(!row.png)throw Error('Complete row without PNG');first=row;break;}}
   if(!first||first.event!=='frame'||!Number.isSafeInteger(first.index)||first.index<1||first.index>300||first.width_pixels!==profile.width||first.height_pixels!==profile.height)throw Error('Invalid independent first frame');
   for(const key of ['frame_geometry_validated','target_geometry_matches_at_receipt','presentation_matches_converted_display_time'])if(first[key]!==true)throw Error('Missing recorder validation: '+key);
   for(const key of ['display_mach_ticks','received_mach_ticks'])if(typeof first[key]!=='string'||!/^\d+$/.test(first[key])||BigInt(first[key])<=0n)throw Error('Invalid frame timestamp');
   if(first.display_time_after_receipt!==(BigInt(first.display_mach_ticks)>BigInt(first.received_mach_ticks)))throw Error('Inconsistent receipt ordering flag');
   if(!/^[a-f0-9]{64}$/.test(first.png_sha256)||first.png!=='frame-'+first.png_sha256+'.png'||hash(await fs.readFile(folder+'/capture/'+first.png))!==first.png_sha256)throw Error('Frame identity differs');
   const expected={trial_id:intent.id,attempt_id:attempt,frame_index:first.index,png:first.png,png_sha256:first.png_sha256,tool_sha256:plan.pinned_files[toolPath],profile_sha256:plan.pinned_files[profilePath],width:profile.width,height:profile.height,regions:profile.regions.map(r=>r.name)};
   await write(folder+'/independent-bindings.json',expected);action.admission=receipt;await event('baseline_image_received',{frame_index:first.index,png:first.png});
   const marker=intent.id.replaceAll('-','_');
   const requestMarker=async()=>{action.marker_calls++;if(!intent.expected_admitted)throw Error('Unexpected marker entry for refused case');await fs.writeFile(folder+'/capture/marker.next',marker,{flag:'wx',mode:0o600});await fs.rename(folder+'/capture/marker.next',folder+'/capture/marker.request');await event('marker_requested',{id:marker});const ack=await wait(folder+'/capture/marker-'+marker+'.json',2);if(ack.id!==marker||typeof ack.mach_ticks!=='string'||BigInt(ack.mach_ticks)<=0n||ack.frame_count_before<1)throw Error('Invalid marker acknowledgment');action.marker_acknowledgment=ack;await event('complete_acknowledgment_validated',{id:marker});};
   const applyValue=async()=>{action.apply_calls++;if(!intent.expected_admitted)throw Error('Unexpected Apply entry for refused case');action.input_call_invoked=true;await event('input_call_will_invoke',{api:'CUA App.click',apply_index:Number(apply[1])});await appHandle.click(Number(apply[1]));action.input_call_completed=true;await event('input_call_completed');};
   let refused=null;
   try{await withAdmittedBaseline(receipt,expected,requestMarker,applyValue);}catch(e){refused=String(e);if(intent.expected_admitted)throw e;}
   if(intent.expected_admitted){if(!action.input_call_completed||action.marker_calls!==1||action.apply_calls!==1)throw Error('Missing admitted native input');positiveReceipt=receipt;}
   else{
    if(!refused||action.marker_calls!==0||action.apply_calls!==0||receipt.admitted!==false)throw Error('Negative admission did not stop both callbacks');action.refusal=refused;
    let staleRefused=false;try{await withAdmittedBaseline(positiveReceipt,expected,async()=>{throw Error('Stale receipt entered marker');},async()=>{throw Error('Stale receipt entered Apply');});}catch(e){staleRefused=String(e).includes('Admission binding differs:');action.stale_receipt_refusal=String(e);}if(!staleRefused)throw Error('Stale admission binding did not refuse');
   }
   const after=await appHandle.getAXState({emit:false,disableDiffing:true});await fs.writeFile(folder+'/after-apply.ax.txt',after,{flag:'wx',mode:0o600});if(!after.includes('τ = 20 ms'))throw Error('Accepted native target absent');
   if(intent.expected_admitted)await event('after_input_ax_observed');action.case_passed=true;
  }catch(e){action.error=String(e);action.case_passed=false;if(created)await fs.writeFile(folder+'/abort.request',String(e),{flag:'wx',mode:0o600});}
  finally{if(created)await persist();await write(folder+'/controller.finished',{id:intent.id,case_passed:action.case_passed??false,marker_calls:action.marker_calls,apply_calls:action.apply_calls,input_call_completed:action.input_call_completed,error:action.error??null});}
  const done=await wait(folder+'/done.json',25);results.push({id:intent.id,status:done.status,case_passed:action.case_passed,error:action.error??null});
  if(done.status!=='native_guard_passed')break;
  if(intent!==plan.cases[plan.cases.length-1])await write(folder+'/next.request',{id:intent.id});
 }
 return results;
}
