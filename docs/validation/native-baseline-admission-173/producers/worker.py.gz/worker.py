"""Two predeclared native admission integration cases; never a timing cohort."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,re,subprocess,sys,time,traceback
from reference import seed,independent,compare_at_time
if sys.flags.optimize:raise SystemExit('Assertions are required')
os.umask(0o077)
ROOT=Path('/Users/dshills/Development/projects/ELab');STAGE=Path(__file__).resolve().parent;OUT=Path('/private/tmp/elab-native-baseline-admission-173');RUNTIME=Path('/private/tmp/elab-first-version-173-signed-runtime')
PLAN=json.loads((STAGE/'declaration.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
prepare=load('baseline_prepare',ROOT/'tools/baseline-admission/prepare.py');helper=load('owned_client',ROOT/'scripts/persistence-demo.py')
for name,h in PLAN['pinned_files'].items():assert sha(Path(name))==h,name
host={k:subprocess.check_output(v,text=True).strip() for k,v in {'model':['/usr/sbin/sysctl','-n','hw.model'],'os_version':['/usr/bin/sw_vers','-productVersion'],'os_build':['/usr/bin/sw_vers','-buildVersion']}.items()};assert all(host[k]==PLAN['expected_host'][k] for k in host)
session=json.loads((OUT/'report.json').read_text());assert session['status']=='ready_for_controller_binding';pid=session['owned_pid'];window=session['target_windows'][0]['window_id']
recorder_tool=ROOT/'build/display-frame-probe-tools/display-frame-probe';tool=ROOT/'build/baseline-admission-tools/baseline-admission';profile=ROOT/'tools/baseline-admission/profiles/rc.json'
identity=['--pid',str(pid),'--window',str(window),'--executable',session['registration']['executable_path'],'--sha256',PLAN['native_sha256']]
def write(folder,name,value):
 with (folder/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def wait(folder,name,seconds=120):
 end=time.monotonic()+seconds
 while not (folder/name).exists():
  assert time.monotonic()<end,'Controller deadline: '+name
  if (folder/'abort.request').exists():raise RuntimeError((folder/'abort.request').read_text())
  time.sleep(.003)
 return json.loads((folder/name).read_text())
client=helper.Client(str(OUT/'endpoint.json'),command_preconditions=True,agent_binary=RUNTIME/'agent');outcomes=[];(OUT/'trials').mkdir(mode=0o700)
try:
 for case in PLAN['cases']:
  folder=OUT/'trials'/case['id'];folder.mkdir(mode=0o700);result=dict(id=case['id'],status='started',eligible_latency_observations=0,marker_calls_expected=int(case['expected_admitted']),input_calls_expected=int(case['expected_admitted']));recorder=None
  write(folder,'intent.json',case)
  try:
   if case['expected_admitted']:
    seed(client);client.ask('view.fit',dict(follow_viewport=True),True)
   else:client.ask('simulation.resume',{},True);client.ask('simulation.wait')
   client.ask('project.save',dict(path=str(folder/'baseline.elab')),True);before_file=sha(folder/'baseline.elab')
   baseline=client.ask('project.inspect');write(folder,'baseline.json',baseline)
   value=next(p['value'] for p in baseline['components'] if p['id']=='Storage');assert value==(1e-6 if case['expected_admitted'] else 2e-6)
   independent(baseline)
   inspection=subprocess.run([str(recorder_tool),'--inspect-target']+identity,capture_output=True,text=True,check=True,timeout=15);write(folder,'inspection.json',dict(stdout=inspection.stdout,stderr=inspection.stderr,exit_code=inspection.returncode))
   config=json.loads(inspection.stdout);capture=config['capture_plan'];assert capture['window_global_points']==PLAN['expected_host']['window_global_points'];assert capture['display_id']==PLAN['expected_host']['display_id'] and config['display_mode']==PLAN['expected_host']['display_mode'] and capture['point_pixel_scale']==PLAN['expected_host']['point_pixel_scale']
   write(folder,'ready.json',dict(id=case['id'],expected_admitted=case['expected_admitted'],owned_pid=pid,window_id=window))
   draft=wait(folder,'draft-ready.json');assert draft['id']==case['id']
   before=client.ask('project.inspect');write(folder,'before-apply.json',before);assert next(p['value'] for p in before['components'] if p['id']=='Storage')==value and not before['transient']['stale'];assert before['electrical_revision']==baseline['electrical_revision'];independent(before)
   crop=capture['source_display_local_points'];command=[str(recorder_tool),'--capture-display']+identity+['--display',str(capture['display_id']),'--crop',','.join(str(crop[k]) for k in ('x','y','width','height')),'--output',str(folder/'capture'),'--seconds','3']
   write(folder,'armed.json',dict(command=command));start=wait(folder,'capture-start.request',30);assert start['id']==case['id'] and re.fullmatch(r'[a-zA-Z0-9-]{16,80}',start['attempt_id']);write(folder,'accepted-handshake.json',start)
   with (folder/'recorder-stdout.txt').open('x') as stdout,(folder/'recorder-stderr.txt').open('x') as stderr:
    recorder=subprocess.Popen(command,stdout=stdout,stderr=stderr);result['recorder_pid']=recorder.pid
    receipt=prepare.wait_and_admit(folder/'capture',folder/'admission.json',trial_id=case['id'],attempt_id=start['attempt_id'],tool=tool,tool_sha256=PLAN['pinned_files'][str(tool)],profile=profile,profile_sha256=PLAN['pinned_files'][str(profile)])
    recorder.wait(timeout=15);result['recorder_exit_code']=recorder.returncode
   controller=wait(folder,'controller.finished',15);write(folder,'controller-result.json',controller)
   assert recorder.returncode==0 and receipt['admitted']==case['expected_admitted'] and controller['case_passed'],(receipt,controller)
   client.ask('simulation.pause',{},True);after=client.ask('simulation.wait');write(folder,'after-apply.json',after);assert next(p['value'] for p in after['components'] if p['id']=='Storage')==2e-6 and not after['transient']['stale']
   delta=int(case['expected_admitted']);assert after['electrical_revision']==before['electrical_revision']+delta and after['run_id']==before['run_id']+delta
   assert after['wires']==before['wires'];assert (after['undo_entry']!=before['undo_entry'])==case['expected_admitted']
   matching=helper.Client(command_preconditions=True,agent_binary=RUNTIME/'agent')
   try:
    seed(matching);matching.ask('component.set',dict(id='Storage',value='2uF'),True);matching.ask('simulation.wait');matched=compare_at_time(after,matching);write(folder,'agent-matched-time.json',matched);write(folder,'independent.json',dict(native=independent(after),agent=independent(matched)))
   finally:matching.close()
   client.ask('project.save',dict(path=str(folder/'final.elab')),True);assert sha(folder/'baseline.elab')==before_file
   result.update(status='native_guard_passed',admitted=receipt['admitted'],controller=controller,baseline_unchanged=True)
  except BaseException:
   result.update(status='unavailable',error=traceback.format_exc())
  finally:
   if recorder is not None and recorder.poll() is None:
    recorder.wait(timeout=15);result['recorder_exit_code']=recorder.returncode
   write(folder,'outcome.json',result);write(folder,'done.json',dict(id=case['id'],status=result['status']));outcomes.append(result)
  if result['status']!='native_guard_passed':break
  if case!=PLAN['cases'][-1]:wait(folder,'next.request',120)
finally:
 write(OUT,'integration-result.json',dict(passed=len(outcomes)==2 and all(v['status']=='native_guard_passed' for v in outcomes),outcomes=outcomes,scheduled=PLAN['cases'],eligible_latency_observations=0,timing_percentile=None))
 client.close();(OUT/'stop.request').write_text('Native admission integration ended; no timing cohort.\n')
assert len(outcomes)==2 and all(v['status']=='native_guard_passed' for v in outcomes)
print(json.dumps(dict(passed=True,native_admission_cases=2,eligible_latency_observations=0)))
