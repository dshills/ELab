from pathlib import Path
import json,hashlib,shutil,subprocess
R=Path(__file__).resolve().parents[2];S=Path(__file__).resolve().parent;P=R/'docs/validation/recorded-playback-settlement'
q=json.loads((S/'full-quality.json').read_text());assert q['exit_code']==0
terminal=json.loads((S/'terminal-results.json').read_text());terminal['full_quality']=dict(session=4889,exit_code=0);(S/'terminal-results.json').write_text(json.dumps(terminal,indent=2)+'\n')
subprocess.run(['python3','-B',str(S/'publish_source.py')],cwd=R,check=True)
shutil.copyfile(S/'verify_source.py.txt',P/'verify.py')
body=f'''# Recorded Play entry settlement · source repair

October 20, 2026. **RECORD-PLAY-01 (P2)** is reproduced and repaired in source. On /186's original binding, a private sample-index, seek-time or playback-speed edit commits on focus loss, then the first Play click fails against the old command revision. Invalid index/time edits can instead lose their error and play from the old position. Activation without focus loss skips private input altogether.

Play now settles index, time and speed in order through the existing shared **`recording.seek`**, **`recording.speed.set`** and **`recording.play`** commands. Only exact accepted responses from this form and the owner-published viewport response may continue the pending action. Invalid-entry feedback survives other successful field edits; fresh correction recovers. Unrelated agent/user changes, capture/document replacement, failed settlement and duplicate callbacks cannot overwrite work or dispatch Play twice.

Ten final mounted regression leaves fail against the original production `recording.go`: three valid and two invalid entries, each through pointer activation and direct activation without focus loss. They pass with the repair; the no-edit pointer control passes too. Mounted refusal cases also recover through freshly focused corrected text and one Play click. Deferred owner tests cover field order, duplicates, exact accepted speed, stale work and viewport ownership. A real managed widget with private input refuses a retained Play action after agent work. Accepted state, live physics, graph/settings/history and captured data stay unchanged on refusal. The mounted fixtures use SDK manual software input and actual text/number settlement barriers; **this is not new physical macOS typing or a packaged-runtime test**.

Full default `scripts/check.sh` passes in **{q['elapsed_seconds']:.3f} seconds**: lint/imports/Staticcheck, 65 Python tests, root/native race tests and vet, configured mounted race checks and offscreen vet. All **664 application Go sources plus three existing tool files** remain exact during this gate. No new command, model, solver, numerical tolerance/budget, file format or SDK change.

The reviewed inventory has **73 production native sources /401 sites /164 public commands /132 routed IDs**. Five production source identities change, including the new helper. Seven non-line site records are replaced by eight reviewed records, accounting for relocated literal dispatches and the new callback factory/activation. The parser explicitly recognizes the factory without inventing routes. Public commands, aliases, coverage sets and limitations stay exact. Inventory presence does not close runtime binding acceptance.

Preserved collector failures are separate: the first diagnostic incorrectly rejected disabled Play after a successful start; the corrected original diagnostic exposes five product failures. The first full-toolbar fixture stacked fields outside its small window, so some pointer clicks missed Play. A two-row fixture fixes that clipping and retains the no-edit control; no product defect is inferred from the harness layout. The inventory test initially refuses the intentionally unreviewed ledger, then passes after a fresh parser and reviewed candidate. The fresh audit build's module-cache write warning is retained. Original source, failed outputs and final test sources are preserved.

[Report](report.json), [original mounted failures](raw/stage/original-regression-final-output.txt.gz), [final regressions](raw/stage/focused-final-output.txt.gz), [full quality](raw/stage/full-quality.json.gz), [outcomes](raw/stage/terminal-results.json.gz), [byte manifest](manifest.json).

```sh
python3 -B docs/validation/recorded-playback-settlement/verify.py
```

This read-only replay verifies archived bytes, exact current source and ledger, original/final outcomes, canonical /120, SDK and the /186 release receipt. It starts no app or tests. **A clean replacement review app/agent and copied-runtime qualification remain required.** /186 stays immutable with its original affected Play binding. Existing /185 and /173 latency receipts remain scoped; no new percentile is claimed. Owner walkthrough remains Not tried yet, P0 17 implemented /10 partial, and broader binding/reader/IME/environment/study/MVP gates stay open. No promotion.
'''
(P/'README.md').write_text(body)
(R/'research/57-recorded-playback-entry-settlement.md').write_text(f'''# Recorded Play: commit the entry before playback

October 20, 2026. **RECORD-PLAY-01 (P2)**: /186's first Play click after a private index, time or speed edit can fail against the old revision; invalid index/time input can lose its error and start from the previous position. Activation that keeps field focus can ignore private input.

Play now settles its three fields in order, then uses the existing shared seek/speed/Play commands. Exact own responses continue the action; unrelated user/agent/document/capture work still refuses it. Invalid entries remain stopped with feedback, and fresh correction recovers. Duplicate callbacks do not start playback twice. No new model, solver, format, command ID or SDK change.

Ten final mounted leaves fail against original production source and pass with the fix, through pointer and no-focus-loss activation. Deferred and mounted tests cover correction, full accepted-state preservation, agent interleavings, duplicate barriers and viewport ownership. Full default quality passes in **{q['elapsed_seconds']:.3f} s** on **664 application Go files plus three tools**, including lint/imports/Staticcheck, 65 Python tests, root/native race/vet and configured mounted UI checks. The reviewed source inventory is 73 native sources /401 sites /164 commands /132 routed IDs, with public commands/aliases/coverage unchanged.

The [source proof](../docs/validation/recorded-playback-settlement/README.md) retains original product failures and separate harness/inventory mistakes, final source/logs and a read-only byte/source replay. These are mounted SDK software-input checks, not new physical OS typing or reader/IME acceptance. A clean replacement review and exact copied-runtime qualification remain next; /186, canonical /120 and earlier evidence remain unchanged. Owner walkthrough remains Not tried yet and broader MVP gates remain open.
''')
# Keep the qualified review distinct from the newer source-only repair.
plan=R/'research/34-first-version-plan.md';text=plan.read_text();needle='Keep the app/model/format/SDK scope frozen'
pos=text.index(needle);text=text[:pos]+f'''**Newer source repair, replacement pending:** [RECORD-PLAY-01](57-recorded-playback-entry-settlement.md) fixes first-click Play after unfinished index/time/speed entry and preserves invalid-entry refusals. Ten original mounted failures become passing pointer/no-focus-loss regressions, and full {q['elapsed_seconds']:.3f} s lint/race/vet/mounted quality passes. /186 remains the latest qualified package until a clean replacement passes exact copied-runtime/signature/archive checks. No new physical input or latency claim.

'''+text[pos:];plan.write_text(text)
def checkpoint():
 files={str(p.relative_to(P)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(P.rglob('*')) if p.is_file() and p!=P/'checkpoint.json'}
 (P/'checkpoint.json').write_text(json.dumps(dict(files=files),indent=2)+'\n')
checkpoint()
with (S/'source-replay-output.txt').open('x') as log:subprocess.run(['python3','-B',str(P/'verify.py')],cwd=R,stdout=log,stderr=-2,check=True)
print((S/'source-replay-output.txt').read_text())
