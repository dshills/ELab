from pathlib import Path
import subprocess,hashlib,json,time,os
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[2];P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def sources():
 return {n:sha(R/n) for n in sorted(subprocess.check_output(['rg','--files','-g','*.go'],cwd=R,text=True).splitlines())}
prior=R/'research/ui-audit/first-version/recorded-index-review-checkpoint.json'
canonical=R/'build/ELab.app/Contents/MacOS/ELab';lock=R/'third_party/vellum/sdk.lock.json'
before=dict(started_utc=datetime.now(timezone.utc).isoformat(),command=['./scripts/check.sh'],go_sources=sources(),canonical_sha256=sha(canonical),sdk_lock_sha256=sha(lock),prior_release_receipt_sha256=sha(prior))
(P/'quality-before.json').write_text(json.dumps(before,indent=2)+'\n')
env=dict(os.environ,GOWORK='off',GOPROXY='off',GOTOOLCHAIN='local',PYTHONDONTWRITEBYTECODE='1')
t=time.monotonic()
with (P/'quality-output.txt').open('x') as log:
 result=subprocess.run(['./scripts/check.sh'],cwd=R,env=env,stdout=log,stderr=-2)
elapsed=time.monotonic()-t
unchanged=before['go_sources']==sources()
quality=dict(exit_code=result.returncode,elapsed_seconds=elapsed,sources_unchanged=unchanged,source_sha256=before['go_sources'])
(P/'full-quality.json').write_text(json.dumps(quality,indent=2)+'\n')
result=dict(exit_code=result.returncode,elapsed_seconds=elapsed,all_go_sources_unchanged=unchanged,sdk_lock_unchanged=sha(lock)==before['sdk_lock_sha256'],canonical_unchanged=sha(canonical)==before['canonical_sha256'],prior_release_receipt_unchanged=sha(prior)==before['prior_release_receipt_sha256'])
(P/'quality-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
assert result['exit_code']==0 and all(v for k,v in result.items() if k.endswith('_unchanged'))
