from pathlib import Path
import gzip,hashlib,io,json,tarfile
r=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent;o=r/'docs/validation/number-step-223'
sha=lambda b:hashlib.sha256(b).hexdigest()
report=json.loads((s/'native-report.json').read_text());assert report['numeric_step_checks_passed'] and not report['native_lifecycle_qualified']
(s/'native-log-after-reopen.txt').write_bytes(Path('/private/tmp/elab-cursor-guidance-206/native.log').read_bytes())
files={}
for p in sorted(s.rglob('*')):
 rel=p.relative_to(s)
 if p.is_file() and 'build' not in rel.parts and p.suffix in {'.py','.json','.txt','.png','.mod','.sum'}:files[rel.as_posix()]=p.read_bytes()
with (o/'native-raw.tar.gz').open('xb') as disk:
 with gzip.GzipFile(fileobj=disk,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name,data in sorted(files.items()):
    info=tarfile.TarInfo(name);info.size,info.mode,info.mtime=len(data),0o644,0
    tar.addfile(info,io.BytesIO(data))
(o/'native-raw-manifest.json').write_text(json.dumps({n:sha(b) for n,b in sorted(files.items())},indent=2)+'\n')
report.update(raw_archive_sha256=sha((o/'native-raw.tar.gz').read_bytes()),raw_members=len(files),diagnostic_report_search={'directory':'/Users/dshills/Library/Logs/DiagnosticReports','filename_pattern':'*ELab*','matching_files_found':False})
(o/'native-report.json').write_text(json.dumps(report,indent=2)+'\n')
pending=json.loads((r/'docs/validation/validation-scroll-222/native-acceptance-pending.json').read_text())
build=json.loads((s/'build-result-signed.json').read_text())
pending.update(source_commit=build['source_commit'],native_sha256=build['native_sha256'],agent_sha256=build['agent_sha256'],
 new_native_checks=[],carried_forward_checks=[1,2,4,5,7,16,17,18],current_build_fresh_native_checks=[],
 current_build_fresh_native_scope='Decimal step buttons/keys and focused numeric draft/wheel paths, not a complete retest of the original eighteen checks',
 prior_evidence='../validation-scroll-222/README.md',evidence='README.md',numeric_step_display_issue_repaired=True,
 additional_open_issue='One unexplained native process exit after restoration. Endpoint and process were absent; no panic in the retained log and no matching ELab filename in the searched user DiagnosticReports directory. Clean-private and dirty-private/scrolling restoration repeats did not reproduce it; same reopened PID/executable observed live at checkpoints 296.8 seconds apart. Cause and broader lifecycle remain unqualified.')
(o/'native-acceptance-pending.json').write_text(json.dumps(pending,indent=2)+'\n')
with (o/'README.md').open('a') as f:f.write('''

## Native affected-control results and open lifecycle issue

[Native receipt](native-report.json), [raw captures/checks](native-raw.tar.gz),
[hashes](native-raw-manifest.json), [remaining checks](native-acceptance-pending.json).

The clean 0.181.22 /223 app/agent are built from `4356b8fb`. Normal Quit and an
ordinary update/reopen retain the owned installation's identity, launcher and
sandbox, with /222 saved as backup. CUA first required refreshing its stale app
binding; that tooling state was resolved without a permission question. Tests
use a separately sealed copy whose nonempty Mach-O sections match the unchanged
original candidate. Exact original-bundle-byte launch is not claimed.

The native plus button followed by Up now reaches 0.031 then 0.032 in both live
and recorded playback. Their public snapshots contain exactly the corresponding
native float32 values, with one command per step. Both live endpoints and wraps
work. An unfinished 0.035 survives wheel input in the Simulate rail and scope
dock; complete accepted snapshots remain identical. External-agent speed set is
visibly reflected in the same native control. One initial coordinate click after
Return hit help because focus reveal had scrolled the inspector; it changed
nothing and is excluded from button qualification.

After the first restore, the owned process and endpoint disappeared unexpectedly.
The retained native log has no panic; a filename search found no ELab report in
the user's DiagnosticReports directory. This does not prove a crash or its cause.
The same installation reopened normally. Clean/private and dirty/private/scroll
restoration repeats did not reproduce the exit. The same reopened PID/executable
was live at explicit checkpoints 296.8 seconds apart; this is a bounded
observation, not general lifecycle acceptance. The issue stays open.

All 1,001 saved rows remain exact after reopening and the 2,002 independent RC
voltage references pass, maximum error below 5e-16 V. The saved fixture, 897 source
inputs, strict signatures, original candidate, /222 backup and /205 ZIP remain
unchanged. The final fixture is clean, paused at zero, Light, with original live
and recorded speeds restored through public commands. The arithmetic defect is
repaired; lifecycle and the remaining ten original native checks stay held.
No owner-review wait, new permission question, publication or release promotion.
''')
p=r/'research/104-decimal-number-steps.md'
with p.open('a') as f:f.write('''

The clean /223 app now passes the affected native numeric checks in the existing
owned installation. Both plus/Up sequences display 0.032, exact native float32
state matches, declared endpoints/wraps work, and wheel input preserves private
0.035 text in both panes with full public-snapshot equality. The same external
agent command updates the visible viewer preference. All 1,001 saved samples and
2,002 independent RC references remain exact; the final fixture is restored.

One unexplained native exit occurred after the first restoration. The process
and endpoint were absent; no panic was logged and the searched user diagnostic
folder had no ELab report filename. Two bounded restoration repeats did not
reproduce it, and the same reopened PID/executable was observed live almost five
minutes apart. Do not call this a lifecycle pass or assume the cause. Preserve
that open issue alongside the ten original native checks; keep /223 held and
/205 unchanged. Next investigate the exit, then continue the native state-contract
checklist. Standing launch/desktop authorization was used without another question.
''')
p=r/'research/34-first-version-plan.md';text=p.read_text();a=text.index('**Current maintenance work:**');b=text.index('\n## Historical plan',a)
text=text[:a]+'''**Current maintenance work:** /223 repairs repeated decimal numeric steps;
[implementation and affected native checks](104-decimal-number-steps.md) pass.
The /222 validation-scroll/private-draft repair remains included. Eight original
native checklist items retain scoped evidence and ten remain open. One additional
unexplained native exit after restoration is recorded; two repeats did not
reproduce it. Its cause/lifecycle acceptance stays open, so /223 remains held.

Earlier footer/theme, manual-step, slider, Verify endpoint and numeric-wheel
repairs remain included. [Electronics reference checks](95-gate-common-mode.md)
cover seven RC-driven MOSFET circuits and active-work preservation. The held
/207–/223 changes do not replace /205. Owner review remains deferred. Standing
run/desktop authorization is saved in `AGENTS.md`; ordinary updates and reopens
proceeded without another owner permission question.
''' +text[b:];p.write_text(text)
p=r/'research/80-overnight-work-plan.md'
with p.open('a') as f:f.write('''

## Checkpoint: decimal numeric steps

The [decimal-step repair](104-decimal-number-steps.md) passes focused and full
framework/application checks and affected native plus/arrow/bounds/draft checks.
It preserves typed/agent values and the existing float32 control boundary. All
1,001 stored samples and the /205 download stay intact. /222 is backed up.

A single unexplained native exit after the first restore is preserved, not
claimed fixed or dismissed. No panic or matching user-directory crash report
was found. Two restoration repeats did not reproduce it; the reopened process
survived the recorded almost-five-minute checkpoints. Next investigate that
lifecycle observation, then continue the ten remaining original native checks.
Do not ask for launch/desktop authorization again or repeat unrelated successful
source gates for this evidence-only update. The arithmetic repair is qualified
within scope; /223 is held and broader release acceptance remains separate.
''')
print(json.dumps({'native_members':len(files),'numeric_checks_passed':True,'lifecycle_qualified':False,'remaining_original_checks':10,'release_promoted':False}))
