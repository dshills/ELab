"""Archive the decimal-step reproductions and exact verified source inputs."""
from pathlib import Path
import gzip,hashlib,io,json,re,subprocess,tarfile
root=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent
out=root/'docs/validation/number-step-223';sha=lambda b:hashlib.sha256(b).hexdigest()
assert not out.exists()
for n in ['quality','sdk-quality','app-prospective']:
 assert (s/(n+'-exit-code.txt')).read_text().strip()=='0',n
assert (s/'app-before-final-exit-code.txt').read_text().strip()=='1'
assert (s/'sdk-before.txt').read_text().count('accepted=')==2
assert (s/'app-before-final.txt').read_text().count('step 1 did not reach shared playback state exactly')==2
inputs=json.loads((s/'source-inputs.json').read_text());prior=json.loads((root/'build/validation-scroll-222-tools/source-inputs.json').read_text())
assert all(sha((root/p).read_bytes())==h for p,h in inputs.items())
production=[p for p in prior if p.startswith('desktop/') and p.endswith('.go') and not p.endswith('_test.go')]
assert all(inputs[p]==prior[p] for p in production)
assert all(inputs[p]==h for p,h in prior.items() if p.startswith('workbench/'))
quality=(s/'quality.txt').read_text();sdk_quality=(s/'sdk-quality.txt').read_text()
assert 'Ran 67 tests' in quality and 'Ran 30 tests' in sdk_quality
seconds=re.findall(r'ok\s+github.com/dshills/elab/desktop\s+(\d+\.\d+)s',quality);assert len(seconds)==2,seconds
lock=json.loads((root/'third_party/vellum/sdk.lock.json').read_text())
assert sha((root/lock['archive']).read_bytes())==lock['sha256']
assert sha((root/lock['compatibility_patch']['path']).read_bytes())==lock['compatibility_patch']['sha256']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root/'build/vellum-public-e58d405').strip()
assert sha((root/'build/releases/ELab-0.181.4-macos-arm64.zip').read_bytes())=='d13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
files={}
for p in sorted(s.rglob('*')):
 rel=p.relative_to(s)
 if p.is_file() and 'build' not in rel.parts and p.suffix in {'.py','.txt','.json','.png','.mod','.sum'}:
  files['checks/'+rel.as_posix()]=p.read_bytes()
changed=sorted(p for p,h in inputs.items() if prior.get(p)!=h)
for p in changed:
 if p!=lock['archive']:files['source/'+p]=(root/p).read_bytes()
files['source/AGENTS.md']=(root/'AGENTS.md').read_bytes()
files['source/external-artifacts.json']=(json.dumps({lock['archive']:lock['sha256']},indent=2)+'\n').encode()
out.mkdir(parents=True)
with (out/'raw.tar.gz').open('xb') as disk:
 with gzip.GzipFile(fileobj=disk,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name,data in sorted(files.items()):
    info=tarfile.TarInfo(name);info.size,info.mode,info.mtime=len(data),0o644,0
    tar.addfile(info,io.BytesIO(data))
(out/'raw-manifest.json').write_text(json.dumps({p:sha(b) for p,b in sorted(files.items())},indent=2)+'\n')
(out/'source-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
report=dict(source_parent_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 application_quality_passed=True,sdk_quality_passed=True,python_tests=67,sdk_prepare_tests=30,
 source_inputs=len(inputs),changed_source_inputs=changed,production_desktop_go_sources_unchanged=len(production),backend_unchanged=True,
 desktop_race_seconds=float(seconds[0]),mounted_race_seconds=float(seconds[1]),
 sdk=lock,sdk_member_comparison=json.loads((s/'sdk-member-comparison.json').read_text()),
 baseline_driver_failures=2,baseline_production_control_failures=2,driver_step_cases=7,
 numeric_boundary='existing float32 native controls and existing float64 public parameters; no migration or shortening of supplied values',
 preserved_cache_and_native=json.loads((s/'preservation-check.json').read_text()),
 new_components=0,new_commands=0,new_models=0,new_formats=0,
 native_candidate_acceptance_passed=False,release_ready=False,preserved_download='0.181.4 /205',
 raw_archive_sha256=sha((out/'raw.tar.gz').read_bytes()),raw_members=len(files))
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'README.md').write_text('''# Decimal number steps /223

[Receipt](report.json), [frozen inputs](source-inputs.json),
[raw evidence](raw.tar.gz), [member hashes](raw-manifest.json).

The /222 native playback control displays 0.031999998 after typing 0.03,
clicking plus and pressing Up. Existing binary addition has accumulated into a
different float32, so lowering text precision would hide a stored-value mismatch.
Two framework and two real live/recorded playback regressions reproduce it.
The initial live test's conflicting isolated minimum width is a retained harness
failure, corrected to fit the production maximum before the genuine baseline.

Managed steps now add the displayed value/increment as exact decimals and round
once to the existing native float32. The accepted native value and round-trip
text agree. The public command types remain unchanged; supplied high-precision
values and old saved values are not shortened or migrated. Seven driver cases
cover repeated positive/negative steps, off-grid values, page steps, both wraps
and a tight finite boundary. Both production playback cases pass with single
shared-command delivery and unchanged circuit topology.

Focused draft/wheel/precision checks and complete framework/application gates
pass. Every one of 8,439 SDK members matches its manifest; only the factory line,
helper, test and generated provenance change. Dependency, notices and bootstrap
bytes are unchanged. All 8,437 previous SDK cache members, native /222 bytes and
the /205 download are preserved. Source checks do not qualify a fresh native
candidate; changed-candidate native acceptance follows separately.
''')
(root/'research/104-decimal-number-steps.md').write_text('''# Decimal number steps

October 24, 2026. [Evidence](../docs/validation/number-step-223/README.md).

The native /222 observation is an arithmetic defect, not merely text formatting:
0.03 plus 0.001 twice lands on the neighboring float32, 0.031999998. Hiding those
digits would disagree with the stored native value. The compatibility repair
steps the displayed decimal values exactly, then rounds once to float32. It
retains full round-trip display precision, off-grid entries, wrap limits, tight
bounds, private drafts and wheel behavior. Existing typed/agent/saved values are
not normalized; the public float64 command boundary is unchanged.

Two framework failures and both real production playback failures are repaired.
Seven stepping scenarios, ownership/draft/wheel/precision checks and full
framework/application quality pass. No production ELab Go code or electronics
model changes. The previous SDK cache, /222 app and /205 download remain intact.
Fresh candidate native checks are separate. Continue the remaining native
state-contract checklist after qualifying this repair, without another owner
launch or desktop permission question.
''')
with (root/'research/README.md').open('a') as f:f.write('\n- [Decimal number steps](104-decimal-number-steps.md): keep stepped values and displayed decimals consistent, with bounded arithmetic and unchanged public command types.\n')
print(json.dumps(report))
