from pathlib import Path
import datetime,hashlib,importlib.util,json,math,struct,subprocess,sys
r=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent
read=lambda n:json.loads((s/(n+'.json')).read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f32=lambda v:struct.unpack('f',struct.pack('f',v))[0]
for kind in ['live','recorded']:
 for action,target in [('plus',.031),('arrow',.032)]:
  state=read('native-'+kind+'-'+action)
  value=state['transient_settings']['seconds_per_wall_second'] if kind=='live' else state['recording']['seconds_per_wall_second']
  assert value==f32(target),(kind,action,value)
 assert read('native-'+kind+'-arrow')['command_revision']==read('native-'+kind+'-plus')['command_revision']+1
 assert read('native-'+kind+'-wheel')==read('native-'+kind+'-arrow')
assert read('native-recorded-wheel-returned')==read('native-recorded-arrow')
assert read('native-live-minimum')['transient_settings']['seconds_per_wall_second']==.001
assert read('native-live-maximum')['transient_settings']['seconds_per_wall_second']==1
assert read('native-recorded-typed')['transient_settings']['seconds_per_wall_second']==.001
baseline=read('native-baseline')
for n in ['native-live-plus','native-live-arrow','native-recorded-plus','native-recorded-arrow']:
 state=read(n);assert state['components']==baseline['components'] and state['wires']==baseline['wires'] and state['paused']
for n in ['native-recorded-plus','native-recorded-arrow']:
 a=read('native-recorded-typed');b=read(n)
 for state in [a,b]:
  for key in ['revision','command_revision','last_actor']:state.pop(key,None)
  state['recording'].pop('seconds_per_wall_second')
 assert a==b
p=read('reopened-process');proc=subprocess.run(['/bin/ps','-p',str(p['pid']),'-o','comm='],text=True,capture_output=True)
assert proc.returncode==0 and proc.stdout.strip()==p['executable']
first=read('repeat-process-now');observed=datetime.datetime.now(datetime.timezone.utc)
checkpoints=dict(pid=p['pid'],same_recorded_pid_and_executable_live=True,observed_utc=observed.isoformat(),
 seconds_between_survival_observations=(observed-datetime.datetime.fromisoformat(first['utc'])).total_seconds(),
 claim='Same PID/executable alive at explicit checkpoints; not a general lifecycle or stability pass')
(s/'repeat-process-later.json').write_text(json.dumps(checkpoints,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('client',r/'scripts/persistence-demo.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
c=h.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json',command_preconditions=True,agent_binary=r/'build/ELab-0.181.22-223-candidate/elab-agent')
try:
 final=c.ask('project.inspect');rows=[];offset=0
 while True:
  page=c.ask('operation.samples',{'id':final['selected_operation'],'offset':offset,'limit':200});rows.extend(page['rows'])
  if len(rows)==page['total']:break
  offset=page['next_offset']
 assert rows==json.loads((r/'build/native-acceptance-220-tools/native-recording-rows.json').read_text()) and len(rows)==1001
 errors=[]
 for row in rows:
  for value,target in zip(row['values'],[5*-math.expm1(-row['time_s']/.01),5],strict=True):
   errors.append(abs(value-target));assert math.isclose(value,target,rel_tol=1e-12,abs_tol=1e-12)
 assert final['paused'] and not final['document']['dirty'] and final['theme']=='light' and final['scope_visible']
 assert final['transient']['sample']['time_s']==0 and final['transient_settings']['seconds_per_wall_second']==.02
 assert final['recording']['seconds_per_wall_second']==.1 and not final['recording']['playing']
 (s/'native-captured-rows.json').write_text(json.dumps(rows,indent=2)+'\n')
 (s/'native-final-state.json').write_text(json.dumps(final,indent=2)+'\n')
finally:c.close()
project=read('preserved-project');assert sha(Path(project['path']))==project['sha256']
inputs=read('source-inputs');assert all(sha(r/name)==digest for name,digest in inputs.items())
build=read('build-result-signed');update=read('prepared-update');app=Path(update['installed'])
assert sha(app/'Contents/MacOS/ELab Cursor Recovery')==update['native_sha256']
assert sha(app.parent/'.ELab Cursor Recovery-222-backup.app/Contents/MacOS/ELab Cursor Recovery')=='9e06ccdbf8d515c7d1c9aae54ea67af8011cc9253e98ac7ad5c1044a3ab792ec'
with (s/'signature-after-native.txt').open('x') as log:subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict','--verbose=2',str(app)],stdout=log,stderr=-2,check=True)
sys.path.insert(0,str(r/'scripts'));from runtime_isolation import bundle_tree
assert bundle_tree(Path(build['review'])/'ELab.app')==build['source_bundle']
assert sha(r/'build/releases/ELab-0.181.4-macos-arm64.zip')=='d13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
report=dict(numeric_step_checks_passed=True,native_lifecycle_qualified=False,release_ready=False,
 source_commit=build['source_commit'],version=build['version'],build=build['build'],
 native_copy_sha256=update['native_sha256'],exact_original_bundle_launched=False,code_equivalent_sections_verified=True,
 normal_cua_update_and_reopen=True,no_new_owner_permission_question=True,identity_launcher_sandbox_unchanged=True,
 live_recorded_button_then_arrow_display=['0.031','0.032'],shared_native_float32_values_exact=True,
 native_min_max_and_both_wraps_passed=True,live_recorded_wheel_full_public_snapshots_exact=True,
 retained_unfinished_text='0.035',agent_control_change_visibly_reflected=True,
 numeric_step_display_issue_repaired=True,unexplained_native_exit=read('native-exit-observation'),
 restoration_repeats={'clean_private':True,'dirty_private_and_scrolling':True,'exit_reproduced':False,'survival':checkpoints},
 initial_pointer_attempt='After Return, focus reveal scrolled the inspector. One stale coordinate click hit help and changed nothing; the observed visible plus button was then used. Only the latter is qualified.',
 final_document_clean_paused=True,final_live_time_s=0,final_live_playback=.02,final_recorded_playback=.1,
 captured_rows_exact=1001,independent_voltage_checks=len(errors),max_absolute_error_v=max(errors),
 fixture_file_unchanged=True,source_inputs_unchanged=len(inputs),strict_signature_valid=True,
 original_candidate_bundle_unchanged=True,prior_native_backup_preserved=True,preserved_205_download_unchanged=True)
(s/'native-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
