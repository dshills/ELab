"""Run the owned framework gates without launching any graphical app."""
from pathlib import Path
import os,subprocess,sys
r=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent;sdk=r/'build/vellum-public-e58d405'
assert 'ok  \tgithub.com/dshills/vellum/drivers/cogent' in (s/'sdk-after.txt').read_text()
env=dict(os.environ,GOWORK='off',GOPROXY='off',GOTOOLCHAIN='local',GOFLAGS='-p=1 -mod=readonly',GOCACHE=str(r/'build/go-cache'),CGO_LDFLAGS_ALLOW='-Wl,-rpath,@executable_path/native',PYTHONDONTWRITEBYTECODE='1')
checks=[(sdk,[sys.executable,'-B','drivers/cogent/prepare_test.py'])]
for directory in [sdk,sdk/'drivers/cogent']:
 checks += [(directory,['go','test','-race','./...']),(directory,['go','vet','./...'])]
checks += [(sdk/'drivers/cogent',['go','test','-race','-tags=offscreen','./...']),(sdk/'drivers/cogent',['go','vet','-tags=offscreen','./...'])]
rc=0
with (s/'sdk-quality.txt').open('w') as log:
 for cwd,cmd in checks:
  log.write(str(cwd.relative_to(sdk) or '.')+': '+' '.join(cmd)+'\n');log.flush()
  rc=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
  if rc:break
(s/'sdk-quality-exit-code.txt').write_text(str(rc)+'\n');print('SDK quality:',rc)
raise SystemExit(rc)
