from pathlib import Path
import json, os, subprocess, sys
root=Path('/Users/dshills/Development/projects/ELab'); stage=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'scripts')); from runtime_isolation import bundle_tree
record=json.loads((stage/'prepared-update.json').read_text())
installed=Path(record['installed']); prepared=Path(record['prepared']); backup=installed.parent/'.ELab Cursor Recovery-222-backup.app'
assert not backup.exists()
assert not (installed.parent/'endpoint.json').exists(),'owned endpoint still live'
processes=subprocess.check_output(['/bin/ps','-axo','pid=,command='],text=True)
assert str(installed/'Contents/MacOS/ELab Cursor Recovery') not in processes,'owned native process still live'
assert bundle_tree(installed)==record['original_installed_bundle']
assert bundle_tree(prepared)==record['prepared_bundle']
os.rename(installed,backup)
try: os.rename(prepared,installed)
except BaseException:
 os.rename(backup,installed); raise
with (stage/'signature-installed.txt').open('x') as log:
 subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict','--verbose=2',str(installed)],stdout=log,stderr=-2,check=True)
assert bundle_tree(installed)==record['prepared_bundle']
result=dict(version=record['version'],build=record['build'],source_commit=record['source_commit'],installed=str(installed),backup=str(backup),old_endpoint_removed=True,owned_native_process_absent=True,normal_cua_quit_observed=True,identity_unchanged=True,sandbox_unchanged=True,app_launched=False)
(stage/'installed-update.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
