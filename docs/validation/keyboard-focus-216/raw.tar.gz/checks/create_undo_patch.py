"""Create a hash-pinned dependency stage in the owned Vellum checkout."""
import difflib,hashlib,json
from pathlib import Path

root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
driver=root/'build/vellum-public-e58d405/drivers/cogent'
old=(driver/'build/upstream/core/textfield.go').read_text()
assert old.encode()==(stage/'core-textfield-before.go.txt').read_bytes()
assert (root/'build/.vellum-sdk-e58d405-elab8/drivers/cogent/build/upstream/core/textfield.go').read_bytes()==old.encode()
needle='if us.pos <= 0 || n == 0 {\n\t\treturn &textFieldUndoRecord{}\n\t}'
assert old.count(needle)==1
new=old.replace(needle,'if us.pos <= 0 || n == 0 {\n\t\t// The initial field value is the history boundary, not an implicit\n\t\t// empty edit. Preserve its text and selection when there is no Undo.\n\t\treturn nil\n\t}')
test=(stage/'core-undo-test.go.txt').read_text()
directory=driver/'native/patches/textundoboundary';assert not directory.exists();directory.mkdir()
patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/core/textfield.go',tofile='b/core/textfield.go'))
patch+=''.join(difflib.unified_diff([],test.splitlines(True),fromfile='/dev/null',tofile='b/core/textfield_undo_boundary_vellum_test.go'))
name='0109-text-undo-boundary.patch';(directory/name).write_text(patch)
sha=lambda text:hashlib.sha256(text.encode()).hexdigest()
inputs={'core/textfield.go':sha(old),'core/textfield_undo_boundary_vellum_test.go':None}
outputs={'core/textfield.go':sha(new),'core/textfield_undo_boundary_vellum_test.go':sha(test)}
for name,data in [('original-hashes.json',inputs),('output-hashes.json',outputs)]:
    (directory/name).write_text(json.dumps(data,indent=2)+'\n')
(directory/'README.md').write_text('''# Text field Undo boundary

ELab compatibility stage 0109 after the existing native stages. No public API
or model changes. Empty/exhausted text Undo returns no record instead of an
implicit empty field, preserving its accepted baseline and selection. Normal
undo/redo, repeated boundary calls, Unicode and branch-after-undo are tested.

Original and output hashes pin the exact prepared dependency. The patch adds
its regression alongside the implementation. Previous stages are unchanged.
''')
manifest_path=driver/'native/dependencies.json';manifest=json.loads(manifest_path.read_text())
upstream=next(d for d in manifest['dependencies'] if d['name']=='upstream')
assert upstream['stages'][-1]['patches'][0]['file'].endswith('0108-scrollbar-wheel-direction.patch')
upstream['stages'].append(dict(origin='ELab text field Undo boundary compatibility',
    inputs='native/patches/textundoboundary/original-hashes.json',outputs='native/patches/textundoboundary/output-hashes.json',
    patches=[dict(file='native/patches/textundoboundary/0109-text-undo-boundary.patch',sha256=sha(patch))]))
(stage/'native-dependencies-before.json').write_bytes(manifest_path.read_bytes())
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
(stage/'core-textfield-after.go.txt').write_text(new)
print(json.dumps(dict(patch_sha256=sha(patch),inputs=inputs,outputs=outputs)))
