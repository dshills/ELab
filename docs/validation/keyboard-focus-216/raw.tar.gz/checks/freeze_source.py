"""Freeze source and bounded qualification for the existing text Undo repair."""
import gzip,hashlib,io,json,re,shutil,subprocess,tarfile
from pathlib import Path
r=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent
out=r/'docs/validation/keyboard-focus-216';sha=lambda b:hashlib.sha256(b).hexdigest()
assert not out.exists()
for name in ['quality','focused-final','sdk-quality-final','prepare-clean-owned-sdk']:
 assert (s/(name+'-exit-code.txt')).read_text().strip()=='0',name
inputs=json.loads((s/'source-inputs.json').read_text());prior=json.loads((r/'docs/validation/comparison-entry-215/source-inputs.json').read_text())
assert len(inputs)==887 and all(sha((r/p).read_bytes())==h for p,h in inputs.items())
assert not (r/'go.sum').exists()
lock=json.loads((r/'third_party/vellum/sdk.lock.json').read_text());oldlock=json.loads((s/'previous-sdk.lock.json').read_text())
assert sha((r/lock['archive']).read_bytes())==lock['sha256']
assert sha((r/oldlock['archive']).read_bytes())==oldlock['sha256']
assert sha((r/oldlock['compatibility_patch']['path']).read_bytes())==oldlock['compatibility_patch']['sha256']
assert sha((r/'build/releases/ELab-0.181.4-macos-arm64.zip').read_bytes())=='d13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
oldcandidate=json.loads((r/'docs/validation/comparison-entry-215/candidate-report.json').read_text())
assert sha((Path(oldcandidate['candidate'])/'ELab.app/Contents/MacOS/ELab').read_bytes())==oldcandidate['native_sha256']
assert sha((Path(oldcandidate['candidate'])/'elab-agent').read_bytes())==oldcandidate['agent_sha256']
native=[p for p in inputs if p.startswith('desktop/') and p.endswith('.go') and not p.endswith('_test.go')]
assert len(native)==126 and all(inputs[p]==prior[p] for p in native)
assert all(inputs[p]==prior[p] for p in inputs if p.startswith('workbench/'))
quality=(s/'quality.txt').read_text();times=re.findall(r'ok\s+github.com/dshills/elab/desktop\s+(\d+\.\d+)s',quality)
assert len(times)==2,times
assert '"1 kΩ" → ""' in (s/'focused-mac-profile.txt').read_text()
assert (s/'core-before.txt').read_text().count('FAIL: TestVellumTextUndo')>=2
assert 'ok ' in (s/'core-focused.txt').read_text()
assert (s/'inventory-check.txt').read_text().strip()==(r/'build/comparison-entry-215-tools/inventory-check.txt').read_text().strip()
comparison=json.loads((s/'sdk-member-comparison.json').read_text());assert len(comparison['changed_files'])==9
assert comparison['file_count']==8433 and comparison['bootstrap_unchanged']
sdk_source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r/'build/vellum-public-e58d405',text=True).strip()
assert sdk_source==lock['source_commit'] and not subprocess.check_output(['git','status','--porcelain'],cwd=r/'build/vellum-public-e58d405').strip()
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
changed=sorted(p for p,h in inputs.items() if prior.get(p)!=h)
files={'checks/'+p.name:p.read_bytes() for p in sorted(s.iterdir()) if p.is_file() and p.suffix in {'.py','.json','.txt'}}
absent=[];external={}
for name in changed:
 if name==lock['archive']:
  external[name]=inputs[name];absent.append(name);continue
 files['source/'+name]=(r/name).read_bytes()
 if name in prior:files['source-before/'+name]=subprocess.check_output(['git','show',base+':'+name],cwd=r)
 else:absent.append(name)
files['source-before/absent.json']=(json.dumps(absent,indent=2)+'\n').encode()
files['source/external-artifacts.json']=(json.dumps(external,indent=2)+'\n').encode()
out.mkdir(parents=True);shutil.copyfile(s/'source-inputs.json',out/'source-inputs.json')
with (out/'raw.tar.gz').open('xb') as disk:
 with gzip.GzipFile(fileobj=disk,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name,data in sorted(files.items()):
    info=tarfile.TarInfo(name);info.size,info.mode,info.mtime=len(data),0o644,0
    tar.addfile(info,io.BytesIO(data))
(out/'raw-manifest.json').write_text(json.dumps({p:sha(b) for p,b in sorted(files.items())},indent=2)+'\n')
report=dict(kind='text-undo-boundary-and-keyboard-routing',application_checks_passed=True,quality_exit_code=0,
 source_parent_commit=base,source_inputs=len(inputs),changed_source_inputs=changed,absent_source_inputs=['go.sum'],
 desktop_race_seconds=float(times[0]),mounted_race_seconds=float(times[1]),python_tests=67,
 focused_keyboard_race_seconds=4.908,focused_core_race_seconds=1.564,sdk_python_tests=30,
 sdk_root_driver_race_vet_passed=True,supplemental_upstream_core_race_passed=False,
 supplemental_core_comparison=json.loads((s/'core-supplemental-comparison.json').read_text()),
 sdk_member_comparison=comparison,sdk=lock,previous_sdk=oldlock,
 production_native_sources_unchanged=126,inventory_sources_unchanged=79,backend_source_unchanged=True,public_commands=166,source_routes=134,sites=404,
 native_app_launched=False,native_acceptance_passed=False,release_ready=False,published=False,
 owner_review_required=False,new_commands=0,new_components=0,new_formats=0,download_unchanged='0.181.4 /205',
 previous_candidate_preserved='0.181.14 /215',raw_archive_sha256=sha((out/'raw.tar.gz').read_bytes()),raw_members=len(files))
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'README.md').write_text(f'''# Text editing and application shortcuts /216

October 23, 2026. [Receipt](report.json), [source inputs](source-inputs.json),
[repair notes](../../../research/93-text-undo-boundary.md).

Command-Z in an unedited `1 kΩ` value field erased its initial private text.
The original macOS-profile retained-widget failure and direct Core boundary
failures are preserved. Compatibility stage 0109 returns no history record
at the boundary, preserving initial text and selection. Focused text/IME/native
edit tests pass in 1.564 s. The final routed application keyboard tests pass in
4.908 s, including local Undo/Redo and positive application Undo/Redo after Tab.

The supported-control fixture uses production search/value nodes and the real
ELab command registry. It does not mount the custom schematic extension or a
new native event loop. Earlier constant/layout/profile errors and the refused
custom-canvas fixture are kept as harness evidence. Modifier masks and the
explicit MacStandard profile correct the old offscreen Control-A substitution.

SDK source `{lock['source_commit']}` is clean. All 30 preparation tests and
framework root/driver normal/offscreen race and vet checks pass. The archive
comparison verifies all 8,433 members: nine change, five are new; six bootstrap
sources and all other members match elab8. The complete patch and new archive
are checked in under third_party/vellum. Old archives/caches remain preserved.

The supplemental full upstream Core race run is **not green**. A read-only old
textfield overlay also reports render/menu races; 26 failing names overlap and
one differs on each run. Counts, individual failures and output are retained.
No claim is made that every race is attributed or repaired. The export guard
also rejected 300 generated golden PNGs before the lock changed. Re-preparing
owned dependencies produced the final minimal SDK delta. The rejected archive
is retained locally in build/keyboard-focus-216-tools; its receipt is archived.

The full ELab gate passes lint/staticcheck, 67 Python tests, root/desktop race
and vet, mounted race and offscreen vet. Desktop race takes {times[0]} s;
mounted race {times[1]} s. All 887 source/check inputs match. All 126 non-test desktop
Go files, the 79-source route inventory, backend sources and the public command/route inventory remain
unchanged. [Raw evidence](raw.tar.gz), [member hashes](raw-manifest.json).

Fresh changed-candidate native acceptance remains separate. The qualified /205
download, previous /215 package, user projects and the existing owned test app
are preserved. No graphical launch or unattended launch approval is queued.
''')
notes=r/'research/93-text-undo-boundary.md';text=notes.read_text().replace('Broader checks and packaging are in progress.',f'The [full application gate passes](../docs/validation/keyboard-focus-216/README.md),\nincluding desktop race ({times[0]} s), mounted race ({times[1]} s), lint, vet and\n67 Python tests. All 887 source/check inputs match. The final routed keyboard\nchecks pass in 4.908 s. Clean packaging is next.')
notes.write_text(text)
index=r/'research/README.md';text=index.read_text().replace('New compatibility pin and application qualification are in progress.','The elab9 compatibility pin, focused checks and full application quality gate pass; native acceptance remains separate.')
index.write_text(text)
manifest={p.relative_to(out).as_posix():sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file()}
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['application_checks_passed','source_inputs','desktop_race_seconds','mounted_race_seconds','raw_members']}))
