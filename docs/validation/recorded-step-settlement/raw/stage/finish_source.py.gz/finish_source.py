from pathlib import Path
import hashlib,json,shutil,subprocess
R=Path(__file__).resolve().parents[2];S=Path(__file__).resolve().parent;P=R/'docs/validation/recorded-step-settlement'
q=json.loads((S/'full-quality.json').read_text());assert q['exit_code']==0 and q['sources_unchanged']
terminal=json.loads((S/'terminal-results.json').read_text());terminal['full_quality']=dict(session=79330,exit_code=0);(S/'terminal-results.json').write_text(json.dumps(terminal,indent=2)+'\n')
subprocess.run(['python3','-B',str(S/'publish_source.py')],cwd=R,check=True)
shutil.copyfile(S/'verify_source.py.txt',P/'verify.py')
(P/'README.md').write_text(f'''# Recorded Previous/Next entry settlement · source repair

October 20, 2026. **RECORD-STEP-01 (P2)** is reproduced and repaired in source. On /187, a private sample-index, seek-time or speed edit commits on focus loss and the first Previous/Next click fails against the old command revision. Invalid position input can instead move the viewer from the old row and clear its refusal. At an accepted end position, a disabled step button commits a new private position but requires a second click. Direct activation without focus loss ignores private input.

Previous, Next and Play now share one guarded settlement path for index, time and speed. The final action uses existing **`recording.seek`**, **`recording.speed.set`**, **`recording.step`** and **`recording.play`** commands. Only exact own field responses and the owner-published viewport can continue the action; unrelated user/agent/capture/document work still refuses it. Invalid input stays stopped with its error until corrected. Duplicate admissions/completions cannot replace the first pending action or step twice. Internal helper names now describe the whole playback family; there is no parallel step-only state machine.

Transient Previous/Next remain available while a new position may be private in a field, even if the accepted position is at an end. Shared validation reports an unchanged boundary without moving/wrapping or changing accepted state. The controls explain this behavior through accessibility help. Single-row DC navigation remains disabled. A step may also continue through the normal viewer ticker after its own accepted speed response, including natural playback end; a later agent speed still refuses it. Play keeps its stricter paused-value check.

The initial unmodified-source mounted diagnostics reproduce **14 leaf failures** (ten interior/invalid-entry failures plus four boundary drafts), with both no-edit interior controls passing. The final **24 mounted regression leaves** fail against the byte-identical original production `recording.go` and pass with the repair: ten pointer cases, ten no-focus-loss cases, four boundary drafts. Test-only adapters bridge renamed internal field/Play methods; the original step bindings remain unchanged, and the original helper source is retained and pinned to /187. This proves the affected original binding, not a complete original-app rebuild.

Final mounted checks include fresh invalid-entry correction, both unchanged boundary refusals, and retained private actions after agent changes. Deferred tests cover all three fields, cross-button duplicate admissions, agent/user/capture/document interleavings, wrong-field delivery, and invalid-position persistence after a successful speed edit. Real public events observe natural ticker completion without a new command revision, then exact stepping from the final stored row; the agent-after-ticker control refuses. Existing Play, single-row DC and native/agent picker parity regressions pass. Accepted state, live physics, document and history remain exact in refusal controls. These use actual SDK manual software input/settlement barriers, **not new physical macOS typing, reader/IME acceptance or a packaged-runtime test**.

Full default `scripts/check.sh` passes in **{q['elapsed_seconds']:.3f} s**: lint/imports/Staticcheck, 65 Python tests, root/native race/vet and configured mounted race/offscreen vet. All **666 application Go files plus three existing tool files** remain exact during the gate. Five production source identities change; two new files add tests, and prior Play tests only rename private bookkeeping references. No model, solver, numerical budget/tolerance, format, public command or SDK change.

The reviewed ledger has **73 native sources /402 sites /164 public commands /132 routed IDs**. Nine non-line site records become ten: the renamed family/factory, its literal Step dispatch and the Previous/Next call site account for the difference. Public commands, aliases, coverage sets and limitations remain exact. The parser recognizes both Play and Step factory calls without inventing routes; source presence does not close runtime binding acceptance. The fresh audit build passes with a nonfatal module-cache warning observed in tool output. No failed collector run or new product defect is inferred from that warning.

[Report](report.json), [original diagnostics](raw/stage/original-diagnostic-output.txt.gz), [original boundary failures](raw/stage/original-boundary-output.txt.gz), [final original regressions](raw/stage/original-regression-final-output.txt.gz), [fixed race checks](raw/stage/second-focused-output.txt.gz), [full gate](raw/stage/full-quality.json.gz), [outcomes](raw/stage/terminal-results.json.gz), [byte manifest](manifest.json).

```sh
python3 -B docs/validation/recorded-step-settlement/verify.py
```

The read-only replay checks evidence bytes, exact current source/ledger, original/fixed outcomes, SDK, canonical /120 and the /187 receipt. It starts no app or tests. **A clean replacement review app/agent and copied-runtime/signature/archive qualification remain required.** /187 stays sealed with its original step binding. Existing /185 and /173 timing keeps its scope; no new percentile. Owner walkthrough remains Not tried yet, P0 17 implemented /10 partial, and broader binding/accessibility/environment/study/MVP gates remain open. No promotion.
''')
(R/'research/59-recorded-step-entry-settlement.md').write_text(f'''# Recorded Previous/Next: apply the entry before stepping

October 20, 2026. **RECORD-STEP-01 (P2)**: /187's first Previous/Next click after private index/time/speed input can fail against the old revision, while invalid input can move from the old row and clear its error. Boundary-disabled controls require a second click after a newly typed position; activation without blur ignores private input.

Previous, Next and Play now share the guarded field-settlement path and existing shared commands. Valid entries apply before one step; invalid entries retain feedback until corrected. Transient boundaries permit settling a new position, while unchanged boundaries refuse without moving/wrapping. DC navigation stays disabled. Own accepted speed can continue through normal viewer ticks/end; unrelated user/agent/capture/document work remains guarded. No model, solver, format, command-ID or SDK change.

Fourteen original diagnostic leaves and 24 final mounted regression leaves fail on the original step binding. Fixed pointer/no-focus-loss/boundary/correction tests pass, along with deferred ownership/duplicate controls, real ticker completion and an agent-after-ticker refusal. Existing Play, DC and native/agent picker checks pass. Full default quality passes in **{q['elapsed_seconds']:.3f} s** on **666 application Go files plus three tools**, including lint/imports/Staticcheck, 65 Python tests, root/native race/vet and configured mounted UI checks. The ledger is 73 sources /402 sites /164 commands /132 routed IDs, with public routes/aliases/coverage sets unchanged.

The [source proof](../docs/validation/recorded-step-settlement/README.md) retains original source/logs, exact test-only private-name adapters, final source and a read-only replay. These are mounted software-input checks, not physical OS typing or a packaged app. A clean replacement review remains next; /187 and canonical /120 remain untouched. Owner walkthrough and broader MVP acceptance stay pending.
''')
p=R/'research/34-first-version-plan.md';s=p.read_text();a=s.index('Keep the app/model/format/SDK scope frozen');s=s[:a]+f'''**Newer source repair, replacement pending:** [RECORD-STEP-01](59-recorded-step-entry-settlement.md) fixes Previous/Next after private index/time/speed entry and at accepted boundaries. Twenty-four original mounted regression leaves become passing pointer/no-focus-loss/boundary checks; full {q['elapsed_seconds']:.3f} s lint/race/vet/mounted quality passes. /187 remains the latest qualified package until the separate clean replacement passes copied-runtime/signature/archive checks. No new physical input or latency claim.

'''+s[a:];p.write_text(s)
files={str(p.relative_to(P)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(P.rglob('*')) if p.is_file() and p!=P/'checkpoint.json'}
(P/'checkpoint.json').write_text(json.dumps(dict(files=files),indent=2)+'\n')
with (S/'source-replay-output.txt').open('x') as log:subprocess.run(['python3','-B',str(P/'verify.py')],cwd=R,stdout=log,stderr=-2,check=True)
print((S/'source-replay-output.txt').read_text())
