from pathlib import Path
import gzip,hashlib,json,shutil
R=Path(__file__).resolve().parents[2];S=Path(__file__).resolve().parent;P=R/'docs/validation/recorded-step-settlement'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
quality=json.loads((S/'full-quality.json').read_text());assert quality['exit_code']==0 and quality['sources_unchanged']
assert len(quality['source_sha256'])==669 and sum(not n.startswith('tools/') for n in quality['source_sha256'])==666
assert all(sha(R/n)==h for n,h in quality['source_sha256'].items())
original=(S/'original-regression-final-output.txt').read_text();final=(S/'second-focused-output.txt').read_text()
leaves=[v.strip() for v in original.splitlines() if '--- FAIL: ' in v and '/' in v.split('--- FAIL: ',1)[1]]
assert len(leaves)==24 and '--- FAIL:' not in final and '\nPASS\n' in final
assert not P.exists();P.mkdir(parents=True)
manifest={}
for source in sorted(S.iterdir()):
 if not source.is_file() or source.name=='elab-ui-audit':continue
 target=P/'raw/stage'/(source.name+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 data=source.read_bytes();target.write_bytes(gzip.compress(data,mtime=0));manifest[str(target.relative_to(P))]=dict(original_bytes=len(data),original_sha256=hashlib.sha256(data).hexdigest(),stored_sha256=sha(target))
for name in ['desktop/main.go','desktop/recording.go','desktop/view.go','desktop/viewport.go','desktop/recorded_playback_actions.go','desktop/recorded_playback_actions_test.go','desktop/recorded_playback_offscreen_test.go','desktop/recorded_step_actions_test.go','desktop/recorded_step_offscreen_test.go','internal/uiaudit/audit.go','internal/uiaudit/audit_test.go','research/13-native-command-inventory.json']:
 dest=P/'sources'/(name+'.txt');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/name,dest)
prior=R/'research/ui-audit/first-version/recorded-playback-review-checkpoint.json';previous=json.loads(prior.read_text())
for name in ('recording.go','recorded_playback_actions.go'):
 assert sha(S/(name+'-original.txt'))==previous['quality']['source_sha256']['desktop/'+name]
report=dict(issue='RECORD-STEP-01',priority='P2',source_qualified=True,clean_replacement_required=True,scope='Recorded Previous/Next field settlement and boundary drafting; original production binding with test-only private-name adapters. Mounted software input, not new physical OS typing or a packaged runtime',original_diagnostic_leaf_failures=14,original_final_leaf_failures=24,quality=dict(elapsed_seconds=quality['elapsed_seconds'],application_go_sources=666,all_go_sources=669),native_inventory=dict(sources=73,sites=402,public_commands=164,source_routes=132),canonical_sha256=sha(R/'build/ELab.app/Contents/MacOS/ELab'),sdk_lock_sha256=sha(R/'third_party/vellum/sdk.lock.json'),prior_release_receipt_sha256=sha(prior),original_production_source_sha256={name:sha(S/(name+'-original.txt')) for name in ('recording.go','recorded_playback_actions.go')})
(P/'report.json').write_text(json.dumps(report,indent=2)+'\n');(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(report))
