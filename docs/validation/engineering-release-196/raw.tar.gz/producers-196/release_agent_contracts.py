from pathlib import Path
import hashlib,importlib.util,json,traceback
R=Path('/Users/dshills/Development/projects/ELab');O=Path('/private/tmp/elab-release-196/agent-contracts')
spec=importlib.util.spec_from_file_location('contracts195',R/'scripts/persistence-demo.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
c=m.Client(command_preconditions=True,agent_binary=Path('/private/tmp/elab-release-196-runtime/agent'));log=[];report={'passed':False,'checks':[]}
def ask(command,params=None,mutate=False,expect=None):
    v=c.ask(command,params,mutate,expect);log.append(dict(command=command,params=params,expect=expect,result=v));return v
def raw(request):
    c.process.stdin.write(json.dumps(request)+'\n');c.process.stdin.flush();v=json.loads(c.process.stdout.readline());log.append(dict(request=request,response=v));c.revision=v['revision']
    if 'command_revision' in v.get('result',{}):c.command_revision=v['result']['command_revision']
    return v
try:
    before=ask('project.inspect');catalog=ask('capabilities.list')['capabilities'];ledger=json.loads((R/'research/13-native-command-inventory.json').read_text())
    assert {x['id'] for x in catalog}==set(ledger['public_commands'])
    for name in ('project.save','project.save.start'):
        schema=ask('capabilities.list',{'command':name})['capabilities'][0]['input_schema'];contract=schema['x-command-contract']
        assert 'No active analysis' not in str(contract) and 'partial results' in str(contract) and 'Later completed kept results remain unsaved/dirty' in str(contract)
    assert ask('project.inspect')==before;report['checks'].append('Current catalog, both Save aliases and pure discovery agree with runtime scope')
    ask('example.flasher',{},True);ask('simulation.pause',{},True);ask('simulation.restart',{},True);ask('simulation.wait')
    unchanged_c2=next(x['value'] for x in ask('project.inspect')['components'] if x['id']=='C2')
    state=ask('component.set',{'id':'C1','value':'2.2uF'},True)
    assert next(x['value'] for x in state['components'] if x['id']=='C1')==2.2e-6
    assert next(x['value'] for x in state['components'] if x['id']=='C2')==unchanged_c2
    for command,params in [('component.set',{'id':'C2','value':'10 us'}),('scope.probes.set',{'ids':['v:missing']}),('scope.probes.set',{'ids':['i:D2','i:D2']})]:
        prior=ask('project.inspect');ask(command,params,True,'invalid-params');assert ask('project.inspect')==prior
    state=ask('scope.probes.set',{'ids':['v:Q1.collector','i:D2']},True);assert state['scope']['selected']==['v:Q1.collector','i:D2']
    report['checks'].append('Dynamic capacitor identity/units and voltage/current probe IDs; wrong units/unknown/duplicate probes preserve state')
    prior=ask('project.inspect');refused=raw(dict(version=1,id='stale',command='component.set',params={'id':'C1','value':'3.3uF'},expected_command_revision=0,key='stale'))
    assert refused['error']['code']=='conflict' and ask('project.inspect')==prior
    req=dict(version=1,id='edit-once',command='component.set',params={'id':'C1','value':'3.3uF'},expected_command_revision=c.command_revision,key='edit-once')
    first=raw(req);assert 'error' not in first
    retried=raw(dict(req,id='retry-edit'));assert retried['duplicate'] and retried['result']==first['result']
    mismatch=raw(dict(req,id='wrong-retry',params={'id':'C1','value':'4.7uF'}));assert mismatch['error']['code']=='key-reused'
    report['checks'].append('Stale revision, idempotent edit retry and conflicting retry key preserve the intended target/history')
    path=O/'agent-contract.elab';req=dict(version=1,id='save-once',command='project.save.start',params={'path':str(path)},expected_command_revision=c.command_revision,key='save-once')
    first=raw(req);assert 'error' not in first;state=ask('simulation.wait');assert state['project_work']['status']=='completed'
    original=path.read_bytes();retried=raw(dict(req,id='retry-save'));assert retried['duplicate'] and retried['result']['project_work']['id']==first['result']['project_work']['id'] and path.read_bytes()==original
    report['checks'].append('Async Save returns an inspectable job; retry keeps the original job and file bytes')
    report['passed']=True
except BaseException:
    report['failure']=traceback.format_exc();raise
finally:
    try:
        state=ask('project.inspect')
        if state['document']['dirty']:ask('project.save',{'path':str(O/'agent-contract-final.elab')},True)
        job=ask('app.close',{'discard_changes':False},True)['shutdown'];job=c.wait_for_shutdown_outcome(job);assert job['status']=='completed' and all(job[k] for k in ('workers_joined','recovery_finalized','exit_ready'));report['shutdown']=job
    finally:
        c.close();report['exit_code']=c.process.returncode;assert c.process.returncode==0
        (O/'agent-contract-report.json').write_text(json.dumps(report,indent=2)+'\n');(O/'agent-contract-protocol.json').write_text(json.dumps(log,indent=2)+'\n')
    print(json.dumps(dict(passed=report['passed'],checks=len(report['checks']))))
