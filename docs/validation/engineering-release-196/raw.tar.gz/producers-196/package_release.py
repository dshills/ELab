from pathlib import Path
import hashlib,importlib.util,json,shlex,shutil,stat,subprocess,sys,zipfile
R=Path('/Users/dshills/Development/projects/ELab');S=Path(__file__).resolve().parent;O=Path('/private/tmp/elab-release-196');P=R/'build/ELab-0.179.0-196-alpha';A=O/'package';A.mkdir()
sys.path.insert(0,str(R/'scripts'));from package_review import members,verify_archive
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();b=json.loads((S/'build-result-signed.json').read_text());candidate=Path(b['review'])
assert json.loads((O/'session.json').read_text())['status']=='closed'
assert json.loads((O/'quality-report.json').read_text())['passed']
assert json.loads((O/'workflows/report.json').read_text())['status']=='passed'
assert json.loads((O/'conformance/report.json').read_text())['passed']
assert not P.exists();P.mkdir()
shutil.copytree(candidate/'ELab.app',P/'ELab.app');shutil.copy2(candidate/'elab-agent',P/'elab-agent');shutil.copytree(R/'build/ELab-0.178.0-195-candidate/Examples',P/'Examples')
assert sha(P/'ELab.app/Contents/MacOS/ELab')==b['native_sha256'] and sha(P/'elab-agent')==b['agent_sha256']
licenses=P/'Licenses/Vellum';licenses.mkdir(parents=True);sdk=R/'build/.vellum-sdk-e58d405-elab1'
for name in ['LICENSE','PRIVATE_BUILD.txt','THIRD_PARTY_INVENTORY.json']:shutil.copyfile(sdk/name,licenses/name)
shutil.copytree(sdk/'THIRD_PARTY_NOTICES',licenses/'THIRD_PARTY_NOTICES');shutil.copyfile(R/'third_party/vellum/sdk.lock.json',licenses/'sdk.lock.json')
(P/'README.md').write_text('''# ELab 0.179.0 /196 - first engineering alpha

Open ELab.app for the native hobbyist editor. Use Examples for LED, RC and flasher
circuits, or open the three paused, editable projects in the Examples folder.
Use Save As for a working copy. The paired elab-agent supports the same semantic
commands through newline-delimited JSON on stdin/stdout; capabilities.list and
project.inspect are read-only starting points. AGENT_PROTOCOL.md documents
revision guards, retries, units, jobs and connection to an owned native session.

This is the designated local private macOS engineering alpha. Owner walkthrough
is deferred by instruction and is not required to use it. The earlier /189 app,
all review candidates and their original files are preserved. No installation,
canonical app replacement or public publication was performed.

The sole product repair since /195 permits schematic saving during independent
Verify/sweep work. Only completed kept results enter a save; later completion
correctly leaves unsaved results. No new feature, device, model, format or SDK
upgrade is included. Full source quality, native/agent reference parity, native
Save during running Verify, keyboard core tasks, and local schematic output
passed the recorded engineering scope. See RELEASE_NOTES.md and RELEASE_STATUS.json.

Tested on macOS 26.6.2 arm64. Local ad-hoc signature, not notarized. Ordinary
clean-account/default-startup qualification remains explicitly deferred for the
private alpha. This is not a public distribution or full PRD MVP acceptance.
Generic educational models are not device-rating or general SPICE qualification.
''')
(P/'RELEASE_NOTES.md').write_text('''# Engineering qualification - October 22, 2026

Built from clean source 885af1ad3c2a130092e532e8ffe966a5c6789889. The signed
candidate app and matching agent were copied unchanged into this release.
The embedded app manifest records build-time distribution/runtime audit status;
the external release receipt records subsequent private engineering checks.

Save remains available during independent analysis. Active partial captures are
omitted. Existing completed captures remain exact; later Verify/sweep completion
marks results dirty even when it races file publication. Original file conflict,
retry, overwrite, file-job and cancellation protections are retained.

Checks: all 672 tracked Go source hashes match the full check.sh pass, including
race tests, vet, staticcheck, goimports, mounted controls and 67 Python tests.
Exact native/agent LED, RC and flasher numerical references agree. Native Save
succeeds while the same flasher Verify advances from 50% to 57%; its later result
remains unsaved until explicitly saved. Project contracts and independent
frozen electrical references pass through in-process, stdio and socket adapters.
Blank LED placement/wiring, value error recovery, Save/Open and RC voltage/current
probe/cursor entry work with keyboard input. Letter/A4 fitted PDF/PNG and SVG
are complete; all 12 fixed-scale tile previews/exports preserve geometry and
captured bytes. No additional physical printer job was submitted.

Limitations: owner first-use feedback, broad accessibility/IME and exhaustive
command/event coverage are unobserved. Invalid cursor Return reports generic
refusal and resets that rejected draft; refocusing and entering a valid time
works, and accepted cursor times commit on Tab. Native file panels can append a
second .elab suffix if an extension is entered in their selected basename.
Sparse explicit-scale tiles and text split across tile boundaries are expected;
use overlap for assembly or Fit to page for a single complete page.

The interrupted first /196 test session lacks an orderly-shutdown receipt.
Its saved artifacts are retained. A separate final owned /196 session and all
final counterpart agents completed joined shutdown and exited normally.
No visible-latency campaign, hobbyist study, clean-account install, quarantine,
notarization, wider OS/CPU or public-distribution acceptance is inferred.
''')
(P/'ROLLBACK.md').write_text('''Save your project, close ELab, then open the preserved 0.172.0 /189 alpha or a
previous candidate with a separate project copy. No owner or canonical package
was overwritten. Keep original project files: saving kept recordings or sweeps
can use newer format versions. Do not run two apps against the same project.
''')
(P/'AGENT_PROTOCOL.md').write_text('''# Agent protocol - version 1

Run ./elab-agent for an independent headless session. Send one JSON request per
line and read its response before issuing dependent work. Begin with:

```json
{"version":1,"id":"catalog","command":"capabilities.list","params":{}}
{"version":1,"id":"state","command":"project.inspect","params":{}}
```

The catalog supplies current command IDs, descriptions, JSON input/output
schemas, units, ranges, dynamic-target discovery and completion/error contracts.
Use the catalog rather than guessing command names. Widget callbacks, keyboard
shortcuts, built-in Go clients, headless stdio and native socket forwarding use
the same workbench dispatch. No external AI service or API key is required.

Mutation requests also require a unique key and an expected_revision or
expected_command_revision obtained from the latest snapshot. Reuse the exact
key and intent to retry uncertain admission; use a new key after correcting
intent. Never silently retry a conflict against a new target. JSON rejects
unknown/duplicate fields. Inspect components, terminals, models and available
probe IDs before editing. Values use the catalog's accepted SI quantities.

An asynchronous start returns admission, not completion. Observe its exact job
or operation ID until completed, failed or canceled; use its documented cancel
command. A caller disconnect does not cancel admitted work. Save captures only
completed kept results; later analysis completion can leave unsaved results.

For an explicitly owned native app session, launch ELab.app/Contents/MacOS/ELab
with --agent-endpoint /absolute/private/path/endpoint.json, then run
./elab-agent --connect /absolute/private/path/endpoint.json. Protect the descriptor:
it contains a bearer token. This is a local Unix socket, not a TCP listener.
Use --no-recovery --no-appearance for isolated tests; ordinary sessions may use
local appearance and recovery storage. Do not connect experiments to another
person's active endpoint or run two apps against the same project file.

Save work before app.close. Observe its shutdown ID until workers_joined,
recovery_finalized and exit_ready are true before acknowledging shutdown using
the command's discovered contract. Retain original projects and use Save As for
experiments. Educational model and engineering-alpha limitations apply equally
to user and agent operations; these commands do not add general SPICE support.
''')
status=dict(kind='first-private-macos-engineering-alpha',version=b['version'],build=b['build'],source_commit=b['source_commit'],native_sha256=b['native_sha256'],agent_sha256=b['agent_sha256'],engineering_release_qualified=True,source_quality_passed=True,go_source_inputs=672,reference_workflows_passed=True,output_qualified=True,owner_review='deferred by instruction; not accepted',clean_account_startup='deferred for private alpha',public_distribution_qualified=False,full_prd_mvp_accepted=False,canonical_app_replaced=False,preserved_owner_alpha='0.172.0 /189',sdk_upstream_commit='e58d40581fe21d1de53fd54cab1bcf6acf11c163',sdk_compatibility_commit='96e22bf25809148b9a28169baf1b24cba72af475')
(P/'RELEASE_STATUS.json').write_text(json.dumps(status,indent=2)+'\n');(P/'RELEASE_MANIFEST.json').write_text(json.dumps(dict(status=status,files=members(P)),indent=2)+'\n');expected=members(P)
archive=P.parent/(P.name+'.zip');assert not archive.exists()
with archive.open('xb') as f:
 archive.chmod(0o600)
 with zipfile.ZipFile(f,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,v in expected.items():
   e=zipfile.ZipInfo(P.name+'/'+name,date_time=(1980,1,1,0,0,0));e.create_system=3;e.external_attr=(stat.S_IFREG|int(v['mode'],8))<<16;e.compress_type=zipfile.ZIP_DEFLATED;z.writestr(e,(P/name).read_bytes(),compresslevel=9)
verify_archive(archive,P.name,expected);extract=A/'Extracted alpha µ with spaces';r=subprocess.run(['/usr/bin/ditto','-x','-k',str(archive),str(extract)],capture_output=True,timeout=120);(A/'ditto.txt').write_bytes(r.stdout+r.stderr);r.check_returncode();extracted=extract/P.name;assert members(extracted)==expected==members(P)
r=subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict','--verbose=2',str(extracted/'ELab.app')],capture_output=True,timeout=30);(A/'signature.txt').write_bytes(r.stdout+r.stderr);r.check_returncode()
wrapper=A/'agent';wrapper.write_text('#!/bin/sh\nexec /usr/bin/sandbox-exec -f '+shlex.quote('/private/tmp/elab-release-196-runtime/runtime.sb')+' '+shlex.quote(str(extracted/'elab-agent'))+' "$@"\n');wrapper.chmod(0o755)
spec=importlib.util.spec_from_file_location('release196',R/'scripts/persistence-demo.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);examples=[]
for file in sorted((extracted/'Examples').glob('*.elab')):
 c=m.Client(command_preconditions=True,agent_binary=wrapper)
 try:
  saved=json.loads(file.read_text());c.ask('project.load',{'path':str(file)},True);state=c.ask('simulation.wait');assert not state['document']['dirty'] and state['paused'] and state['components']==saved['graph']['components'] and state['wires']==saved['graph']['wires']
  job=c.ask('app.close',{'discard_changes':False},True)['shutdown'];job=c.wait_for_shutdown_outcome(job);assert job['status']=='completed' and all(job[k] for k in ('workers_joined','recovery_finalized','exit_ready'));examples.append(dict(file=file.name,sha256=sha(file),graph_preserved=True,paused_and_clean=True,shutdown=job))
 finally:c.close();assert c.process.returncode==0
assert len(examples)==3 and members(extracted)==expected==members(P)
protected=json.loads((S/'preservation-before.json').read_text());assert all(sha(R/n)==v for n,v in protected.items());prior=json.loads((S/'prior-candidates-before.json').read_text());assert all(members(R/'build'/n)==v for n,v in prior.items())
assert members(candidate)=={n:v for n,v in members(P).items() if n.startswith('ELab.app/') or n=='elab-agent'}
report=dict(passed=True,source_commit=b['source_commit'],release=str(P),archive=str(archive),archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,verified_files=len(expected),strict_extracted_signature_valid=True,extracted_bytes_and_modes_match=True,examples=examples,current_sdk_notices_included=True,protected_files_preserved=protected,prior_candidate_trees_preserved=list(prior),candidate_pair_unchanged=True,engineering_release_qualified=True,public_distribution_qualified=False)
(A/'report.json').write_text(json.dumps(report,indent=2)+'\n');Path(str(archive)+'.sha256').write_text(sha(archive)+'  '+archive.name+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['protected_files_preserved','examples']},indent=2))
