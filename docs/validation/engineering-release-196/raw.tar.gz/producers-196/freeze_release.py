from pathlib import Path
import hashlib,json,tarfile
R=Path('/Users/dshills/Development/projects/ELab');S=R/'build/first-version-196-tools';O=Path('/private/tmp/elab-release-196');D=R/'docs/validation/engineering-release-196';D.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();entries={};suffixes={'.py','.swift','.txt','.json','.jsonl','.md','.go','.csv','.svg','.pdf','.png','.jpg','.elab','.sb'}
roots={'attempts-195':Path('/private/tmp/elab-next-five-195'),'native-output-196':Path('/private/tmp/elab-next-five-196'),'final-196':O,'producers-next-five':R/'build/next-five-tools','producers-196':S}
for prefix,root in roots.items():
 for p in sorted(root.rglob('*')):
  if not p.is_file() or p.is_symlink() or p.suffix not in suffixes:continue
  rel=p.relative_to(root)
  if any(x.endswith('.app') or x in ['swift-cache','package','__pycache__'] for x in rel.parts):continue
  if p.name=='endpoint.json':continue
  entries[prefix+'/'+rel.as_posix()]=p
for name in ['report.json','signature.txt','ditto.txt']:entries['final-196/package/'+name]=O/'package'/name
for p in [Path('/private/tmp/elab-release-196-controller.txt'),Path('/private/tmp/elab-release-196-runtime/runtime.sb')]:entries['runtime/'+p.name]=p
for n in ['workbench/project_save.go','workbench/project_save_analysis_test.go','workbench/project_file_capabilities.go','workbench/project_recordings.go','workbench/project_recordings_test.go','workbench/project_capabilities_test.go','scripts/check.sh','scripts/lint.sh','scripts/first-version-parity.py','scripts/tiled-output-demo.py','scripts/check-tiled-pdfs.py','scripts/persistence-demo.py','scripts/package_review.py','third_party/vellum/sdk.lock.json']:entries['source/'+n]=R/n
manifest={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in entries.items()}
with tarfile.open(D/'raw.tar.gz','w:gz') as tar:
 for n,p in entries.items():tar.add(p,arcname=n,recursive=False)
with tarfile.open(D/'raw.tar.gz','r:gz') as tar:
 assert set(tar.getnames())==set(manifest)
 for x in tar:
  f=tar.extractfile(x);assert f and hashlib.sha256(f.read()).hexdigest()==manifest[x.name]['sha256']
(D/'raw-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
quality=json.loads((O/'quality-report.json').read_text());package=json.loads((O/'package/report.json').read_text());session=json.loads((O/'session.json').read_text());parity=json.loads((O/'workflows/report.json').read_text());conformance=json.loads((O/'conformance/report.json').read_text())
assert quality['passed'] and package['passed'] and session['status']=='closed' and session['open_exit_code']==0 and parity['status']=='passed' and conformance['passed']
report=dict(date='2026-10-22',kind='first-private-macos-engineering-alpha',passed=True,source_commit=quality['source_commit'],version='0.179.0',build='196',release=package['release'],archive=package['archive'],archive_sha256=package['archive_sha256'],native_sha256=session['native_sha256'],agent_sha256=session['agent_sha256'],quality=quality,package=package,native_session=session,reference_parity=parity,adapters=[dict(name=x['name'],equivalent_to_in_process=x['equivalent_to_in_process'],reference_workflows=len(x['workflows']),project_contracts_passed=True,independent_electrical_references_passed=True) for x in conformance['adapters']],native_save=json.loads((O/'native-save-report.json').read_text()),keyboard=dict(blank_led_placement_wiring=True,invalid_resistance_preserves_accepted_circuit=True,corrected_2k_current_mA=1.477,native_save_open=True,rc_voltage_current_probes=True,cursor_a_ms=1,cursor_b_ms=10,delta_ms=9,capacitor_voltage_at_10ms_V=3.161,limits=['An automation timeout and unintended Save panel were dismissed without writing','Rejected cursor Return resets its draft and gives generic refusal; valid correction commits on Tab','Native file-panel extension entry produced a double .elab suffix in one owned test artifact','Not exhaustive keyboard/IME/accessibility acceptance']),output=dict(fitted_letter_a4=True,margin_mm=12,svg_components_wires_present=True,tiled_pages_reviewed=12,explicit_scale=1,tile_overlap_mm=5,all_page_png_bytes_match_captured_preview=True,visual_review_passed=True,physical_print_submitted=False),owner_review='deferred by instruction; unobserved',engineering_release_qualified=True,full_prd_mvp_accepted=False,public_distribution_qualified=False,clean_account_startup='deferred for private alpha',raw_archive_sha256=sha(D/'raw.tar.gz'),raw_files=len(manifest),scope_limits=['Single macOS 26.6.2 arm64 workstation; local ad-hoc signature, not notarized','Source/SDK/toolchain/cache/shared geometry/outbound IP denied for isolated copied test runtime; this does not prove OS privacy or clean-account installation','Earlier interrupted /196 session has no normal-shutdown proof; saved artifacts retained and processes verified absent; final native session has separate joined shutdown','Owner study, exhaustive commands/events/accessibility, broader performance and public distribution remain outside this engineering alpha'])
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(passed=True,raw_files=len(manifest),archive_sha256=package['archive_sha256'],raw_archive_sha256=report['raw_archive_sha256'])))
