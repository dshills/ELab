from pathlib import Path
import importlib.util,json,time,hashlib,base64
R=Path('/Users/dshills/Development/projects/ELab');O=Path('/private/tmp/elab-next-five-196');A=O/'output';A.mkdir()
spec=importlib.util.spec_from_file_location('client',R/'scripts/persistence-demo.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
c=m.Client(str(O/'endpoint.json'),command_preconditions=True,agent_binary=Path('/private/tmp/elab-next-five-196-runtime/agent'));log=[]
def ask(command,params=None,mutate=False,expect=None):
 v=c.ask(command,params,mutate,expect);log.append(dict(command=command,params=params,expect=expect,result=v));return v
try:
 s=ask('project.inspect');assert s['schematic_page']==dict(paper='a4',orientation='landscape',margin_mm=12)
 ask('project.load',{'path':str(O/'Untitled.elab')},True);ask('simulation.wait')
 for paper,orientation in [('letter','landscape'),('a4','portrait')]:
  ask('export.page.set',dict(paper=paper,orientation=orientation,margin_mm=12),True)
  ask('export.schematic.pdf',{'path':str(A/f'fit-{paper}.pdf')},True)
  ask('export.schematic.png',{'path':str(A/f'fit-{paper}.png')},True)
 ask('export.schematic.svg',{'path':str(A/'keyboard-led.svg')},True)
 before=ask('project.inspect');ask('export.page.set',dict(margin_mm=41),True,'invalid-params');assert ask('project.inspect')==before
 (A/'fit-report.json').write_text(json.dumps(dict(passed=True,native_a4_settings_match=True,invalid_margin_preserves_state=True),indent=2)+'\n')
finally:
 (A/'fit-protocol.json').write_text(json.dumps(log,indent=2)+'\n');c.close()
