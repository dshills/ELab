from pathlib import Path
import subprocess,json,hashlib,xml.etree.ElementTree as ET
from pypdf import PdfReader
import pdfplumber
from PIL import Image,ImageChops,ImageDraw
O=Path('/private/tmp/elab-next-five-196/output');reports=[]
for paper,size in [('letter',(792,612)),('a4',(210*72/25.4,297*72/25.4))]:
 p=O/f'fit-{paper}.pdf';reader=PdfReader(p);assert len(reader.pages)==1
 with pdfplumber.open(p) as doc:
  page=doc.pages[0];assert abs(page.width-size[0])<.001 and abs(page.height-size[1])<.001
  text=page.extract_text();assert all(label in text for label in ['V1','R1','D1','GND1','2 k','5 V'])
  assert all(0<=x['x0']<=x['x1']<=size[0] and 0<=x['top']<=x['bottom']<=size[1] for x in page.chars)
 subprocess.run(['pdftoppm','-r','100','-singlefile','-png',str(p),str(O/f'fit-{paper}-render')],check=True,capture_output=True)
 im=Image.open(O/f'fit-{paper}-render.png').convert('RGB');margin=int(12/25.4*100)-2
 for crop in [(0,0,im.width,margin),(0,0,margin,im.height),(im.width-margin,0,im.width,im.height),(0,im.height-margin,im.width,im.height)]:
  assert ImageChops.difference(im.crop(crop),Image.new('RGB',(crop[2]-crop[0],crop[3]-crop[1]),'white')).getbbox() is None
 reports.append(dict(paper=paper,pages=1,size_pt=size,labels_present=True,text_inside_page=True,margin_mm=12,outer_margin_white=True))
svg=ET.parse(O/'keyboard-led.svg').getroot();ids={x.get('id') for x in svg.iter()};assert {'V1','R1','D1','GND1','W1','W2','W3','W4'}<=ids
for paper in ['letter','a4']:
 paths=sorted((O/'tiled-renders').glob(paper+'-*.png'));canvas=Image.new('RGB',(1500,1000),'#ddd');d=ImageDraw.Draw(canvas)
 for i,path in enumerate(paths):
  im=Image.open(path).convert('RGB');im.thumbnail((490,465));x=(i%3)*500;y=(i//3)*500;canvas.paste(im,(x,y+25));d.text((x+10,y+6),path.name,fill='black')
 canvas.save(O/f'{paper}-all-pages.png')
(O/'fit-geometry.json').write_text(json.dumps(dict(passed=True,pdfs=reports,svg_components_and_wires_present=True,visual_review='pending'),indent=2)+'\n')
print('fit geometry and SVG identities pass; montages ready')
