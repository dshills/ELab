#!/usr/bin/env python3
"""Verify portable schematic persistence across sessions and desktop/headless APIs."""
import argparse
import json
import math
from pathlib import Path
import subprocess
import tempfile
import time


ROOT = Path(__file__).resolve().parents[1]

class Client:
    def __init__(self, endpoint=None, command_preconditions=False, agent_binary=None):
        argv = [str(agent_binary if agent_binary is not None else ROOT / 'build/elab-agent')]
        if endpoint:
            argv += ['--connect', endpoint]
        self.process = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
        self.revision = 0
        self.command_revision = 0
        self.command_preconditions = command_preconditions
        self.sequence = 0
        self.ask('project.inspect')

    def ask(self, command, params=None, mutate=False, expect=None):
        self.sequence += 1
        request = dict(version=1, id=f'persist-{self.sequence}', command=command, params=params or {})
        if mutate:
            guard = 'expected_command_revision' if self.command_preconditions else 'expected_revision'
            request.update({guard: self.command_revision if self.command_preconditions else self.revision, 'key': f'persist-{time.time_ns()}'})
        for attempt in range(8):
            self.process.stdin.write(json.dumps(request) + '\n')
            self.process.stdin.flush()
            line = self.process.stdout.readline()
            assert line, f'agent terminated during {command}'
            response = json.loads(line)
            self.revision = response['revision']
            result = response.get('result')
            snapshot = result.get('snapshot') if command == 'events.poll' and isinstance(result, dict) else result
            if isinstance(snapshot, dict) and 'components' in snapshot and 'document' in snapshot and 'command_revision' in snapshot:
                self.command_revision = snapshot['command_revision']
            # Native layout may legitimately advance the command revision.
            # Refresh only an unexpected conflict, keeping exact intent/key/ID;
            # an intentionally tested conflict must remain observable.
            if (mutate and response.get('error', {}).get('code') == 'conflict'
                    and expect != 'conflict' and attempt < 7):
                self.ask('project.inspect')
                request[guard] = self.command_revision if self.command_preconditions else self.revision
                continue
            if expect:
                assert response.get('error', {}).get('code') == expect, response
            else:
                assert 'error' not in response, response
            return response.get('result')

    def wait_for_shutdown_outcome(self, work, *, timeout_s=15,
                                  poll_interval_s=.05, cancel_event=None):
        """Observe completed/failed work without acknowledging or closing it.

        Closed-session events.poll returns immediately, even before exit is
        ready. Inspect the captured shutdown ID instead and pace pending reads.
        A failed result is terminal, not permission to acknowledge it. Timeout
        and cancellation are cooperative between synchronous RPCs; the caller
        must separately bound transport IO and retain ownership of its client.
        """
        for name, value, positive in [('timeout_s', timeout_s, False),
                                      ('poll_interval_s', poll_interval_s, True)]:
            try:
                valid = (not isinstance(value, bool) and isinstance(value, (int, float))
                         and math.isfinite(value) and value >= 0
                         and (not positive or value > 0))
            except OverflowError:
                valid = False
            if not valid:
                raise ValueError(name+' must be finite and '+('positive' if positive else 'nonnegative'))
        if not isinstance(work, dict) or not isinstance(work.get('id'), str) or not work['id']:
            raise ValueError('A captured shutdown job ID is required')
        identifier = work['id']
        deadline = time.monotonic()+timeout_s

        def canceled():
            if cancel_event is not None and cancel_event.is_set():
                raise InterruptedError('Shutdown observation canceled; accepted close continues')

        def terminal(value):
            if (not isinstance(value, dict) or value.get('id') != identifier
                    or value.get('status') not in ('queued', 'running', 'completed', 'failed')):
                raise ValueError('Shutdown observation returned an incompatible job')
            return value['status'] in ('completed', 'failed')

        canceled()
        if terminal(work):
            return work
        while True:
            canceled()
            if time.monotonic() >= deadline:
                raise TimeoutError('Shutdown observation timed out; accepted close continues')
            work = self.ask('app.close.inspect', {'id': identifier})
            canceled()
            if time.monotonic() >= deadline:
                raise TimeoutError('Shutdown observation timed out; accepted close continues')
            if terminal(work):
                return work
            delay = min(poll_interval_s, deadline-time.monotonic())
            if delay <= 0:
                raise TimeoutError('Shutdown observation timed out; accepted close continues')
            if cancel_event is None:
                time.sleep(delay)
            elif cancel_event.wait(delay):
                raise InterruptedError('Shutdown observation canceled; accepted close continues')

    def close(self):
        self.process.stdin.close()
        self.process.wait(timeout=5)


def main():
    from demo_session import connect_demo_client

    parser = argparse.ArgumentParser()
    parser.add_argument('--connect')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--fixture', type=Path)
    args = parser.parse_args()
    first = connect_demo_client(Client, args.connect)
    second = None
    try:
        first.ask('example.reset', {'discard_changes': True}, True)
        first.ask('simulation.wait')
        first.ask('component.set', {'id': 'R1', 'value': '2.2k'}, True)
        first.ask('component.move', {'id': 'R1', 'position': {'x': 40, 'y': -130}}, True)
        first.ask('component.rotate', {'id': 'R1'}, True)
        first.ask('view.pan', {'dx': 80, 'dy': 40}, True)
        original = first.ask('simulation.wait')
        with tempfile.TemporaryDirectory(prefix='elab-persistence-') as directory:
            path = str(Path(directory) / 'My LED.elab')
            saved = first.ask('project.save', {'path': path}, True)
            assert not saved['document']['dirty']
            document = json.loads(Path(path).read_text())
            assert document['format'] == 'elab.schematic' and document['version'] == 4
            first.ask('component.set', {'id': 'R1', 'value': '1k'}, True)
            first.ask('simulation.wait')
            first.ask('project.load', {'path': path}, True, 'unsaved-changes')
            first.ask('project.load', {'path': path, 'discard_changes': True}, True)
            loaded = first.ask('simulation.wait')
            assert loaded['components'] == original['components']
            assert loaded['wires'] == original['wires'] and loaded['view'] == original['view']
            assert loaded['result']['current_a'] == original['result']['current_a']
            assert not loaded['document']['dirty'] and not loaded['result']['stale']
            second = Client()
            second.ask('project.load', {'path': path}, True)
            restarted = second.ask('simulation.wait')
            assert restarted['components'] == original['components']
            assert restarted['result']['current_a'] == original['result']['current_a']
            Path(path).write_text('invalid outside edit')
            first.ask('project.save', {}, True, 'file-conflict')
            first.ask('project.load', {'path': path}, True, 'invalid-document')
            first.ask('project.save', {'overwrite': True}, True)
            if args.fixture:
                first.ask('project.save', {'path': str(args.fixture.resolve()), 'overwrite': True}, True)
            else:
                first.ask('project.clear', {}, True)
        report = dict(passed=True, transport='desktop-socket' if args.connect else 'headless-stdio',
                      format='elab.schematic', version=4,
                      checks=['exact graph/value/rotation round trip', 'saved viewport', 'live recomputation',
                              'new process reload', 'unsaved change protection', 'external file conflict',
                              'invalid file refusal', 'explicit overwrite'],
                      resistance_ohm=2200, current_a=original['result']['current_a'])
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps(report, indent=2))
    finally:
        first.close()
        if second:
            second.close()

if __name__ == '__main__':
    main()
