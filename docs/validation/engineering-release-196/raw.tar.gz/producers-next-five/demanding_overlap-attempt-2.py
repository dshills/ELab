from pathlib import Path
import hashlib, importlib.util, json, time, traceback

R=Path('/Users/dshills/Development/projects/ELab');O=Path('/private/tmp/elab-next-five-195/demanding-attempt-2')
spec=importlib.util.spec_from_file_location('owned195',R/'scripts/persistence-demo.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
log=[];report={'passed':False,'scope':'Real headless Verify overlap; no visible latency or universal solve claim','observations':[]}
c=m.Client(command_preconditions=True,agent_binary=Path('/private/tmp/elab-walkthrough-195-runtime/agent'))
def ask(command,params=None,mutate=False,expect=None):
    start=time.monotonic();v=c.ask(command,params,mutate,expect)
    log.append(dict(command=command,params=params,mutate=mutate,expect=expect,elapsed_s=time.monotonic()-start,result=v))
    return v
def terminal(identifier):
    deadline=time.monotonic()+35
    while True:
        v=ask('operation.inspect',{'id':identifier})
        if v['operation']['status'] in ('completed','canceled','failed'):return v
        assert time.monotonic()<deadline
        time.sleep(.01)
def rows(identifier):
    out=[];offset=0
    while True:
        page=ask('operation.samples',dict(id=identifier,offset=offset,limit=200));out+=page['rows']
        if page['next_offset']==page['total']:return out
        offset=page['next_offset']
def save():
    (O/'demanding-report.json').write_text(json.dumps(report,indent=2)+'\n')
try:
    ask('example.flasher',{},True);ask('simulation.pause',{},True);ask('simulation.restart',{},True);ask('simulation.wait')
    v=ask('simulation.verify',dict(duration_s=.02,sample_step_s=.001,probe_ids=['v:Q1.collector','v:Q2.collector','i:D1','i:D2']),True)
    reference=v['last_operation'];assert terminal(reference)['operation']['status']=='completed';reference_rows=rows(reference)
    for cap in ('C1','C2'):ask('component.set',{'id':cap,'value':'1uF'},True)
    ask('simulation.restart',{},True);base=ask('simulation.wait');assert not base['mixed']['stale']
    project=O/'demanding-baseline.elab';ask('project.save',{'path':str(project)},True);original=project.read_bytes()
    (O/'baseline.json').write_text(json.dumps(base,indent=2)+'\n')
    v=ask('simulation.verify',dict(duration_s=10,sample_step_s=.01,probe_ids=['v:Q1.collector','v:Q2.collector']),True)
    active=v['last_operation'];deadline=time.monotonic()+10
    while True:
        v=ask('operation.inspect',{'id':active})
        if v['operation']['status'] not in ('queued','running') or v['operation']['completed_steps']>0:break
        assert time.monotonic()<deadline
        time.sleep(.01)
    assert v['operation']['status']=='running' and v['operation']['completed_steps']>0, v
    def overlap(command,params):
        before=ask('operation.inspect',{'id':active})
        result=ask(command,params,True)
        after=ask('operation.inspect',{'id':active})
        eligible=before['operation']['status']=='running' and after['operation']['status']=='running'
        report['observations'].append(dict(command=command,before=before['operation'],after=after['operation'],eligible=eligible))
        assert eligible,(command,before,after)
        return result
    overlap('view.pan',{'dx':10,'dy':0})
    part=next(p for p in base['components'] if p['id']=='RB1')
    moved=overlap('component.move',dict(id='RB1',position=dict(part['position'],x=part['position']['x']+10)))
    overlap('edit.undo',{'expected_entry_revision':moved['undo_entry']['command_revision']})
    overlap('project.save',{'path':str(O/'saved-during-verify.elab')})
    changed=overlap('component.set',{'id':'RB1','value':'48k'})
    assert changed['paused'] and changed['mixed']['stale']
    overlap('edit.undo',{'expected_entry_revision':changed['undo_entry']['command_revision']})
    overlap('simulation.pause',{})
    before=ask('operation.inspect',{'id':active});assert before['operation']['status']=='running'
    ask('operation.cancel',{'id':active},True);canceled=terminal(active)
    assert canceled['operation']['status']=='canceled' and canceled['metadata']['sample_count']==0
    state=ask('project.inspect');assert state['components']==base['components'] and state['wires']==base['wires']
    assert state['mixed']['time_s']==base['mixed']['time_s'] and state['mixed']['stale']
    assert rows(reference)==reference_rows and project.read_bytes()==original
    restored=json.loads((O/'saved-during-verify.elab').read_text())
    assert restored['graph']['components']==base['components'] and restored['graph']['wires']==base['wires']
    ask('simulation.restart',{},True);fresh=ask('simulation.wait');assert not fresh['mixed']['stale']
    ask('project.save',{'path':str(O/'demanding-final.elab')},True)
    report.update(passed=True,canceled=canceled,original_capture_rows=len(reference_rows),baseline_sha256=hashlib.sha256(original).hexdigest(),original_file_and_recording_preserved=True,paused_electrical_edit_truthfully_stale=True,restart_fresh=True)
except BaseException:
    report['failure']=traceback.format_exc();raise
finally:
    try:
        state=ask('project.inspect')
        if state['document']['dirty']:ask('project.save',{'path':str(O/'owned-final.elab')},True)
        job=ask('app.close',{'discard_changes':False},True)['shutdown'];job=c.wait_for_shutdown_outcome(job)
        assert job['status']=='completed' and all(job[k] for k in ('workers_joined','recovery_finalized','exit_ready'));report['shutdown']=job
    finally:
        c.close();report['agent_exit_code']=c.process.returncode
        (O/'demanding-protocol.json').write_text(json.dumps(log,indent=2)+'\n');save()
    print(json.dumps(dict(passed=report['passed'],eligible_overlaps=len(report['observations']),exit_code=c.process.returncode)))
