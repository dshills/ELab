async function runNPNTiming185(appHandle, root, plan, firstNumber, lastNumber) {
 const fs=await import('node:fs/promises'),crypto=await import('node:crypto');
 const {withAdmittedBaseline}=await import('/Users/dshills/Development/projects/ELab/tools/baseline-admission/controller.mjs');
 const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
 for(const [path,digest] of Object.entries(plan.pinned_files))if(hash(await fs.readFile(path))!==digest)throw Error('Pinned file changed: '+path);
 const profilePath='/Users/dshills/Development/projects/ELab/tools/baseline-admission/profiles/npn.json';const profile=JSON.parse(await fs.readFile(profilePath,'utf8'));
 const toolPath='/Users/dshills/Development/projects/ELab/build/baseline-admission-tools/baseline-admission';
 async function read(path){try{return JSON.parse(await fs.readFile(path,'utf8'));}catch(e){if(e.code==='ENOENT'||e instanceof SyntaxError)return null;throw e;}}
 async function wait(path,seconds=25,alternative){const end=Date.now()+seconds*1000;while(Date.now()<end){const value=await read(path);if(value)return value;if(alternative){const failed=await read(alternative);if(failed)throw Error('Worker ended before readiness: '+JSON.stringify(failed));}await new Promise(r=>setTimeout(r,3));}throw Error('Deadline: '+path);}
 async function write(path,value){await fs.writeFile(path,JSON.stringify(value,null,2)+'\n',{flag:'wx',mode:0o600});}
 const results=[];
 if(!Number.isInteger(firstNumber)||!Number.isInteger(lastNumber)||firstNumber<1||lastNumber>20||firstNumber>lastNumber)throw Error('Invalid declared range');
 for(let n=firstNumber;n<=lastNumber;n++){
  const id='npn2-'+String(n).padStart(2,'0');const folder=root+'/trials/'+id;
  const action={id,input_call_invoked:false,input_call_completed:false,marker_calls:0,apply_calls:0,events:[],eligible_latency_observations:0,latency_gate_passed:null,controller_clock_scope:'Ordered wall time only; no OS event/acceptance timestamp'};
  const persist=async()=>{await fs.writeFile(folder+'/capture-action.next',JSON.stringify(action,null,2)+'\n',{mode:0o600});await fs.rename(folder+'/capture-action.next',folder+'/capture-action.json');};
  const event=async(name,detail={})=>{action.events.push({sequence:action.events.length+1,name,wall_time_utc:new Date().toISOString(),...detail});await persist();};
  let created=false;
  try{
   const ready=await wait(folder+'/ready.json',30,folder+'/done.json');if(ready.id!==id||ready.owned_pid!==plan.owned_pid||ready.part!=='Drive'||ready.target!=='5 V')throw Error('Wrong owned trial');
   await write(folder+'/capture-action.json',action);created=true;
   let ax=await appHandle.getAXState({emit:false,disableDiffing:true});if(!ax.includes('Drive')||!ax.includes('0.000 mA'))throw Error('Wrong accepted NPN baseline');
   const sidebar=ax.match(/^\s*(\d+) scroll area node:c2lkZWJhcg$/m);if(!sidebar)throw Error('Inspector absent');
   await appHandle.scroll(Number(sidebar[1]),'up',100);
   ax=await appHandle.getAXState({emit:false,disableDiffing:true});await fs.writeFile(folder+'/before-draft.ax.txt',ax,{flag:'wx',mode:0o600});
   const field=ax.match(/^\s*(\d+) text field \(settable\) Component value,/m);if(!field)throw Error('Value field absent');
   await appHandle.click(Number(field[1]));await appHandle.pressKey('super+a');await appHandle.typeText('5 V');
   ax=await appHandle.getAXState({emit:false,disableDiffing:true});const line=ax.split('\n').find(l=>l.includes('text field (settable) Component value,'));if(!line?.includes('Value: 5 V'))throw Error('Private target draft absent');
   await fs.writeFile(folder+'/before-apply.ax.txt',ax,{flag:'wx',mode:0o600});await write(folder+'/draft-ready.json',{id,typed:'5 V'});await wait(folder+'/armed.json',15,folder+'/done.json');
   ax=await appHandle.getAXState({emit:false,disableDiffing:true});await fs.writeFile(folder+'/armed-draft.ax.txt',ax,{flag:'wx',mode:0o600});
   if(!ax.includes('0.000 mA')||!ax.split('\n').find(l=>l.includes('text field (settable) Component value,'))?.includes('Value: 5 V'))throw Error('Accepted state or private draft changed');
   const apply=ax.match(/^\s*(\d+) button Apply value,/m);if(!apply)throw Error('Apply absent after before-state observation');
   const attempt=crypto.randomUUID();action.attempt_id=attempt;await write(folder+'/capture-start.request',{id,attempt_id:attempt});await event('capture_start_requested');
   const receipt=await wait(folder+'/admission.json',3,folder+'/done.json');
   const raw=(await fs.readFile(folder+'/capture/frames.jsonl','utf8')).split('\n').slice(0,-1);let baseline;
   for(const line of raw){const row=JSON.parse(line);if(row.event==='marker')throw Error('Marker preceded admission');if(row.status===0){if(!row.png)throw Error('Complete frame without PNG');baseline=row;break;}}
   if(!baseline||baseline.event!=='frame'||!Number.isSafeInteger(baseline.index)||baseline.index<1||baseline.index>300||baseline.width_pixels!==profile.width||baseline.height_pixels!==profile.height)throw Error('Invalid independent first frame');
   for(const key of ['frame_geometry_validated','target_geometry_matches_at_receipt','presentation_matches_converted_display_time'])if(baseline[key]!==true)throw Error('Missing recorder validation: '+key);
   for(const key of ['display_mach_ticks','received_mach_ticks'])if(typeof baseline[key]!=='string'||!/^\d+$/.test(baseline[key])||BigInt(baseline[key])<=0n)throw Error('Invalid frame timestamp');
   if(baseline.display_time_after_receipt!==(BigInt(baseline.display_mach_ticks)>BigInt(baseline.received_mach_ticks)))throw Error('Inconsistent receipt ordering flag');
   if(!/^[a-f0-9]{64}$/.test(baseline.png_sha256)||baseline.png!=='frame-'+baseline.png_sha256+'.png'||hash(await fs.readFile(folder+'/capture/'+baseline.png))!==baseline.png_sha256)throw Error('Baseline PNG identity differs');
   const expected={trial_id:id,attempt_id:attempt,frame_index:baseline.index,png:baseline.png,png_sha256:baseline.png_sha256,tool_sha256:plan.pinned_files[toolPath],profile_sha256:plan.pinned_files[profilePath],width:profile.width,height:profile.height,regions:profile.regions.map(r=>r.name)};
   await write(folder+'/independent-bindings.json',expected);action.admission=receipt;await event('baseline_image_received',{frame_index:baseline.index,png:baseline.png});
   const marker=id.replaceAll('-','_');
   await withAdmittedBaseline(receipt,expected,async()=>{
    action.marker_calls++;await fs.writeFile(folder+'/capture/marker.next',marker,{flag:'wx',mode:0o600});await fs.rename(folder+'/capture/marker.next',folder+'/capture/marker.request');await event('marker_requested',{id:marker});
    const ack=await wait(folder+'/capture/marker-'+marker+'.json',2);if(ack.id!==marker||typeof ack.mach_ticks!=='string'||BigInt(ack.mach_ticks)<=0n||ack.frame_count_before<baseline.index)throw Error('Invalid marker acknowledgment');
    action.marker_acknowledgment=ack;await event('complete_acknowledgment_validated',{id:marker});
   },async()=>{
    action.apply_calls++;action.input_call_invoked=true;await event('input_call_will_invoke',{api:'CUA App.click',apply_index:Number(apply[1])});await appHandle.click(Number(apply[1]));action.input_call_completed=true;await event('input_call_completed');
   });
   const after=await appHandle.getAXState({emit:false,disableDiffing:true});await fs.writeFile(folder+'/after-apply.ax.txt',after,{flag:'wx',mode:0o600});action.after_ax_has_expected_readout=after.includes('4.930 mA')&&after.includes('● Live · DC simulation');await event('after_input_ax_observed');
   if(!action.after_ax_has_expected_readout||action.marker_calls!==1||action.apply_calls!==1)throw Error('Admitted input did not establish fresh NPN state');
  }catch(e){action.error=String(e);if(created)await fs.writeFile(folder+'/abort.request',String(e),{flag:'wx',mode:0o600});}
  finally{if(created)await persist();await write(folder+'/controller.finished',{id,input_call_completed:action.input_call_completed,error:action.error??null,marker_calls:action.marker_calls,apply_calls:action.apply_calls});}
  const done=await wait(folder+'/done.json',35);results.push({id,status:done.status,input_completed:action.input_call_completed,error:action.error??null});
  if(done.status!=='available')break;
  if(n<lastNumber)await write(folder+'/next.request',{id});
 }
 return results;
}
