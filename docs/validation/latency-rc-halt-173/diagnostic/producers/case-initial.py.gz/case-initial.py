from pathlib import Path
import importlib.util,json,sys
root=Path('/Users/dshills/Development/projects/ELab');out=Path('/private/tmp/elab-rc-apply-diagnostic-173');name,mode=sys.argv[1:]
assert name in ['live-index','live-coordinate','paused-index'] and mode in ['prepare','inspect']
spec=importlib.util.spec_from_file_location('client',root/'scripts/persistence-demo.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
c=m.Client(str(out/'endpoint.json'),command_preconditions=True,agent_binary=Path('/private/tmp/elab-first-version-173-signed-runtime/agent'))
try:
 if mode=='prepare':
  c.ask('project.load',dict(path='/private/tmp/elab-latency-cohort-rc-173/trials/rc-01/rc-01-baseline.elab',discard_changes=True),True)
  c.ask('component.select',dict(id='Storage'),True);c.ask('simulation.resume',{},True);c.ask('view.fit',dict(follow_viewport=True),True)
  if name=='paused-index':c.ask('simulation.pause',{},True)
 state=c.ask('project.inspect')
 with (out/(name+'-'+mode+'.json')).open('x') as f:json.dump(state,f,indent=2);f.write('\n')
 print(json.dumps(dict(case=name,mode=mode,storage_f=next(p['value'] for p in state['components'] if p['id']=='Storage'),paused=state['paused'],run_id=state['run_id'],command_revision=state['command_revision'],tau_s=state['transient']['time_constant_s'],stale=state['transient']['stale'])))
finally:c.close()
