from pathlib import Path
import importlib.util,json,math,sys
root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
sys.path.insert(0,str(stage));from reference import seed,independent,reference_voltage,compare_at_time
spec=importlib.util.spec_from_file_location('client',root/'scripts/persistence-demo.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
agent=Path('/private/tmp/elab-first-version-173-signed-runtime/agent')
a=m.Client(command_preconditions=True,agent_binary=agent);b=m.Client(command_preconditions=True,agent_binary=agent)
report=dict(native_started=False,capture_executed=False,ui_input=False,cases=[])
try:
 seed(a);seed(b)
 for c in [a,b]:c.ask('component.set',dict(id='Storage',value='2uF'),True);c.ask('simulation.wait');c.ask('simulation.pause',{},True)
 assert abs(reference_voltage(.01,10000,1e-6)-3.1606027941427883)<1e-14
 assert abs(reference_voltage(.01,10000,2e-6)-1.967346701436833)<1e-14
 for duration in [.01,.05,.051,.1,.1337]:
  a.ask('simulation.restart',{},True);a.ask('simulation.wait');a.ask('simulation.step',dict(duration_s=duration),True);state=a.ask('simulation.wait')
  other=compare_at_time(state,b);report['cases'].append(dict(requested_s=duration,actual_s=state['transient']['sample']['time_s'],native_equivalent=independent(state),matched_reference=independent(other)))
 report['passed']=True
finally:a.close();b.close()
with (stage/'preflight.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps(report,indent=2))
