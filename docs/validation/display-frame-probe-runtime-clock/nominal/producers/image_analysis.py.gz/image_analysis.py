from pathlib import Path
import hashlib,json
from PIL import Image,ImageChops,ImageStat
out=Path('/private/tmp/elab-display-probe-calibration-173-third');folder=out/'capture'
rows=[json.loads(s) for s in (folder/'frames.jsonl').read_text().splitlines()];names=list(dict.fromkeys(row['png'] for row in rows if 'png' in row));first=Image.open(folder/names[0]).convert('RGB')
assert first.size==(1053,802)
bounds=[]
for name in names:
 with Image.open(folder/name) as im:
  assert im.size==first.size
  difference=ImageChops.difference(first,im.convert('RGB')).getbbox()
  if difference:bounds.append(difference)
union=[min(b[0] for b in bounds),min(b[1] for b in bounds),max(b[2] for b in bounds),max(b[3] for b in bounds)] if bounds else None
baseline=Image.open(out/'cua-baseline.png').convert('RGB');assert baseline.size==first.size
rois={'title':[30,72,78,102],'resistor':[450,330,535,366],'led':[602,391,666,451],'current':[28,714,160,750],'inspector':[747,283,908,316]}
alignment={}
for label,box in rois.items():
 ref=baseline.crop(tuple(box));candidates=[]
 for dy in range(-2,3):
  for dx in range(-2,3):
   shifted=first.crop((box[0]+dx,box[1]+dy,box[2]+dx,box[3]+dy))
   score=sum(ImageStat.Stat(ImageChops.difference(ref,shifted)).mean)/3
   candidates.append(dict(dx=dx,dy=dy,mean_absolute_rgb_difference=score))
 alignment[label]=dict(reference_window_box=box,best=min(candidates,key=lambda x:x['mean_absolute_rgb_difference']),zero=next(c for c in candidates if c['dx']==0 and c['dy']==0))
r=dict(frame_rows=len(rows),unique_pngs=len(names),dimensions=[1053,802],differences_from_first_union_box=union,alignment_to_independent_CUA_window_snapshot=alignment,scope='Five existing static UI features only; no edge markers or owned occluder. This is not full pixel/visibility/clock calibration or an eligible latency observation.',eligible_latency_observations=0)
(out/'image-analysis.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
