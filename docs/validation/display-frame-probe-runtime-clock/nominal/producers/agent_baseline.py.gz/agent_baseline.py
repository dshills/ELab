from pathlib import Path
import importlib.util,json,sys
root=Path('/Users/dshills/Development/projects/ELab');out=Path('/private/tmp/elab-display-probe-calibration-173-third');sys.path.insert(0,str(root/'scripts'))
spec=importlib.util.spec_from_file_location('helper',root/'scripts/persistence-demo.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
client=helper.Client(command_preconditions=True,agent_binary=Path('/private/tmp/elab-first-version-173-signed-runtime/agent'))
try:
 client.ask('example.reset',{'discard_changes':True},True);client.ask('component.select',{'id':'R1'},True);client.ask('simulation.resume',{},True);reference=client.ask('simulation.wait')
 native=json.loads((out/'final.json').read_text());initial=json.loads((out/'initial.json').read_text())
 for key in ['components','wires','nets','result']:
  assert native[key]==initial[key]==reference[key],key
 report=dict(passed=True,scope='Static 1 kOhm LED baseline and final native snapshot match a separate protected packaged agent; no edit or latency trial',resistance_ohm=reference['circuit']['resistance_ohm'],current_a=reference['result']['current_a'],live_graph_and_physics_unchanged=True)
 (out/'nominal-agent-reference.json').write_text(json.dumps(reference,indent=2)+'\n');(out/'nominal-agent-match.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
finally:client.close()
