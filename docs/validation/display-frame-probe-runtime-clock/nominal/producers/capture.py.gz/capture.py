from pathlib import Path
import hashlib,json,os,subprocess,time
os.umask(0o077)
root=Path('/Users/dshills/Development/projects/ELab');out=Path('/private/tmp/elab-display-probe-calibration-173-third')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((out/'report.json').read_text());assert r['exact_target_identity_established'] and len(r['target_windows'])==1 and r['owned_pid']==87513
recorder=root/'build/display-frame-probe-tools/display-frame-probe'
assert sha(recorder)=='a8cec4e8f9d16b2b5ad6b751f5657b537c5ed6ea956e7695403168b445bb923f'
identity=['--pid',str(r['owned_pid']),'--window',str(r['target_windows'][0]['window_id']),'--executable',r['registration']['executable_path'],'--sha256',r['native_sha256']]
p=subprocess.run([str(recorder),'--inspect-target',*identity],capture_output=True,text=True,timeout=20)
(out/'display-inspect-stdout.json').write_text(p.stdout);(out/'display-inspect-stderr.txt').write_text(p.stderr);p.check_returncode()
plan=json.loads(p.stdout)['capture_plan'];rect=plan['source_display_local_points'];crop=','.join(str(int(rect[k])) for k in ['x','y','width','height'])
assert not (out/'capture').exists()
sources={str(p.relative_to(root)):sha(p) for p in sorted((root/'tools/display-frame-probe').iterdir()) if p.suffix in ['.swift','.sh']}
(out/'recorder-source-identities.json').write_text(json.dumps(dict(source_sha256=sources,binary_sha256=sha(recorder),source_record_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),clean_source_claim=False),indent=2)+'\n')
args=[str(recorder),'--capture-display',*identity,'--display',str(plan['display_id']),'--crop',crop,'--output',str(out/'capture'),'--seconds','3']
start=time.monotonic()
with (out/'capture-stdout.txt').open('x') as stdout,(out/'capture-stderr.txt').open('x') as stderr:
 worker=subprocess.Popen(args,stdout=stdout,stderr=stderr)
 (out/'capture-worker-started.json').write_text(json.dumps(dict(pid=worker.pid,command=args,tool_sha256=sha(recorder)),indent=2)+'\n')
 try:worker.wait(timeout=15)
 except subprocess.TimeoutExpired:worker.terminate();worker.wait(timeout=5);raise
report=dict(exit_code=worker.returncode,wall_elapsed_s=time.monotonic()-start,source_sha256_unchanged=all(sha(root/n)==d for n,d in sources.items()),eligible_latency_observations=0)
(out/'capture-worker.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
