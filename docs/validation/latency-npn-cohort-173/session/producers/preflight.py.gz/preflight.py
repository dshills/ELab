from pathlib import Path
import importlib.util,json
from reference import seed,independent
root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('client',root/'scripts/persistence-demo.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
clients=[];rows=[]
try:
 for n in range(2):
  c=m.Client(command_preconditions=True,agent_binary=Path('/private/tmp/elab-first-version-173-signed-runtime/agent'));clients.append(c)
  before=seed(c);c.ask('component.set',dict(id='Drive',value='5 V'),True);after=c.ask('simulation.wait')
  rows.append(dict(before=before,after=after,reference_before=independent(before),reference_after=independent(after)))
 assert rows[0]['after']['npn']==rows[1]['after']['npn']
 with (stage/'preflight.json').open('x') as f:json.dump(dict(passed=True,native_started=False,capture_executed=False,ui_input=False,sessions=rows),f,indent=2);f.write('\n')
 print(json.dumps(dict(passed=True,state=rows[0]['after']['npn']['state'],current_a=rows[0]['after']['npn']['collector_current_a'],vce_v=rows[0]['after']['npn']['vce_v'])))
finally:
 for c in clients:c.close()
