"""Losslessly preserve the terminal NPN collection and its exact producers."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path('/Users/dshills/Development/projects/ELab');src=Path('/private/tmp/elab-latency-cohort-npn-173');stage=Path(__file__).resolve().parent;proof=root/'docs/validation/latency-npn-cohort-173';target=proof/'session';target.mkdir(exist_ok=True)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
originals={}
for p in sorted(src.rglob('*')):
 if not p.is_file() or '.app' in str(p.relative_to(src)) or p.suffix=='.png' and 'capture' in p.parts:continue
 name=p.relative_to(src);raw=p.read_bytes();originals[str(name)]=dict(sha256=sha(raw),bytes=len(raw));q=target/name;q.parent.mkdir(parents=True,exist_ok=True)
 if p.suffix=='.png':q.write_bytes(raw)
 else:q.with_name(q.name+'.gz').write_bytes(gzip.compress(raw,mtime=0))
(target/'original-file-manifest.json').write_text(json.dumps(originals,indent=2)+'\n')
producers=target/'producers';producers.mkdir(exist_ok=True)
for p in sorted(stage.iterdir()):
 if p.is_file() and p.suffix in ['.py','.swift','.plist','.json','.txt','.gz']:
  if p.suffix=='.gz':(producers/p.name).write_bytes(p.read_bytes())
  else:(producers/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for capture in src.glob('trials/*/capture'):
 images=sorted(capture.glob('*.png'));cap=target/capture.relative_to(src);manifest={}
 with tarfile.open(cap/'frames.tar.xz','w:xz',preset=6) as tar:
  for p in images:
   raw=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(raw);info.mode=0o600;tar.addfile(info,io.BytesIO(raw));manifest[p.name]=dict(sha256=sha(raw),bytes=len(raw))
 (cap/'image-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('NPN session preserved',flush=True)
