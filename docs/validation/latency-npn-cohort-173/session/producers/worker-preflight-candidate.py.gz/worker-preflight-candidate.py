"""Collect the declared NPN block; all UI input is supplied separately by CUA."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,math,os,subprocess,time

os.umask(0o077)
root=Path('/Users/dshills/Development/projects/ELab');out=Path('/private/tmp/elab-latency-cohort-npn-173')
runtime=Path('/private/tmp/elab-first-version-173-signed-runtime')
plan=json.loads((root/'research/37-visible-latency-cohort-plan.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tool=root/'build/display-frame-probe-tools/display-frame-probe'
assert sha(tool)==plan['recorder_sha256'] and sha(runtime/'elab-agent')==plan['agent_sha256']
assert sha(runtime/'ELab.app/Contents/MacOS/ELab')==plan['native_sha256']
assert sha(root/plan['reference_source'])==plan['reference_source_sha256']
host={key:subprocess.check_output(args,text=True,timeout=5).strip() for key,args in {
    'model':['/usr/sbin/sysctl','-n','hw.model'],'os_version':['/usr/bin/sw_vers','-productVersion'],
    'os_build':['/usr/bin/sw_vers','-buildVersion']}.items()}
assert all(host[key]==plan['expected_host'][key] for key in host)
def write(folder,name,value):
    with (folder/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
write(out,'host-before.json',host)
session=json.loads((out/'report.json').read_text());assert session['status']=='ready_for_controller_binding'
pid=session['owned_pid'];window=session['target_windows'][0]['window_id']
identity=['--pid',str(pid),'--window',str(window),'--executable',session['registration']['executable_path'],'--sha256',plan['native_sha256']]
spec=importlib.util.spec_from_file_location('owned_client',root/'scripts/persistence-demo.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
client=module.Client(str(out/'endpoint.json'),command_preconditions=True,agent_binary=runtime/'agent')
from reference import seed as seed_npn,independent
canonical=out/'seed-project.elab'
def seed(target,reuse=False):return seed_npn(target,canonical if reuse else None)
def wait_for(folder,name,seconds):
    deadline=time.monotonic()+seconds
    while not (folder/name).exists():
        if (folder/'abort.request').exists():raise RuntimeError('CUA aborted: '+(folder/'abort.request').read_text())
        assert time.monotonic()<deadline,'Controller signal timed out: '+name
        time.sleep(.003)
    return (folder/name).read_text()
trials=[trial for trial in plan['trials'] if trial['reference']=='npn']
assert [t['id'] for t in trials]==[f'npn-{i:02}' for i in range(1,21)]
(out/'trials').mkdir(mode=0o700)
outcomes=[]
try:
    for trial in trials:
        folder=out/'trials'/trial['id'];folder.mkdir(mode=0o700)
        result=dict(id=trial['id'],attempted_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            status='started',recorder_sha256=sha(tool),input_timing='CUA controller only',eligible_latency_observations=0,latency_gate_passed=None)
        write(folder,'intent.json',trial)
        recorder=None
        try:
            seed(client,reuse=True);client.ask('view.fit',dict(follow_viewport=True),True)
            client.ask('project.save',dict(path=str(folder/(trial['id']+'-baseline.elab'))),True)
            result['baseline_sha256']=sha(folder/(trial['id']+'-baseline.elab'))
            baseline=client.ask('project.inspect');write(folder,'baseline.json',baseline)
            reference=module.Client(command_preconditions=True,agent_binary=runtime/'agent')
            try:
                ref_before=seed(reference);reference.ask('component.set',dict(id='Drive',value='5 V'),True)
                expected=reference.ask('simulation.wait');write(folder,'agent-before.json',ref_before);write(folder,'agent-expected.json',expected)
                write(folder,'independent-reference.json',dict(before=independent(ref_before),after=independent(expected)))
            finally:reference.close()
            inspection=subprocess.run([str(tool),'--inspect-target']+identity,capture_output=True,text=True,timeout=15)
            write(folder,'inspection.json',dict(exit_code=inspection.returncode,stdout=inspection.stdout,stderr=inspection.stderr))
            assert inspection.returncode==0
            config=json.loads(inspection.stdout);capture_plan=config['capture_plan']
            assert capture_plan['window_global_points']==plan['expected_host']['window_global_points']
            assert capture_plan['display_id']==plan['expected_host']['display_id'] and config['display_mode']==plan['expected_host']['display_mode']
            assert capture_plan['point_pixel_scale']==plan['expected_host']['point_pixel_scale']
            write(folder,'ready.json',dict(owned_pid=pid,window_id=window,part='Drive',target='5 V'))
            wait_for(folder,'draft-ready.json',120)
            before=client.ask('project.inspect');write(folder,'before-apply.json',before)
            assert next(p['value'] for p in before['components'] if p['id']=='Drive')==0 and not before['npn']['stale']
            assert before['electrical_revision']==baseline['electrical_revision']
            crop=capture_plan['source_display_local_points']
            command=[str(tool),'--capture-display']+identity+['--display',str(capture_plan['display_id']),
                '--crop',','.join(str(crop[k]) for k in ['x','y','width','height']),
                '--output',str(folder/'capture'),'--seconds',str(plan['capture_seconds'])]
            write(folder,'armed.json',dict(command=command))
            wait_for(folder,'capture-start.request',30)
            with (folder/'recorder-stdout.txt').open('x') as stdout,(folder/'recorder-stderr.txt').open('x') as stderr:
                recorder=subprocess.Popen(command,stdout=stdout,stderr=stderr);result['recorder_pid']=recorder.pid
                recorder.wait(timeout=15);result['recorder_exit_code']=recorder.returncode
            wait_for(folder,'controller.finished',15)
            assert recorder.returncode==0
            after=client.ask('simulation.wait');write(folder,'after-apply.json',after)
            assert next(p['value'] for p in after['components'] if p['id']=='Drive')==5 and not after['npn']['stale']
            assert after['electrical_revision']==before['electrical_revision']+1 and after['run_id']==before['run_id']+1
            for key in ['components','nets','npn_model']:assert after[key]==expected[key],key
            assert after['wires']==before['wires'], 'Native wire identities changed during value edit'
            wire_semantics=lambda values:[{k:v for k,v in wire.items() if k!='id'} for wire in values]
            assert wire_semantics(after['wires'])==wire_semantics(expected['wires']), 'Wire endpoint/connected semantics differ'
            actual=dict(after['npn']);anticipated=dict(expected['npn'])
            for key in ['run_id','electrical_revision']:actual.pop(key);anticipated.pop(key)
            assert actual==anticipated
            independent(after)
            client.ask('project.save',dict(path=str(folder/(trial['id']+'-final.elab'))),True)
            assert sha(folder/(trial['id']+'-baseline.elab'))==result['baseline_sha256']
            result['status']='collected_pending_pixel_analysis'
        except BaseException as error:
            result['status']='unavailable';result['reason']=type(error).__name__+': '+str(error)
            if recorder is not None and recorder.poll() is None:
                try:recorder.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    result['recorder_still_running']=True
                    raise
        finally:
            result['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
            write(folder,'outcome.json',result);outcomes.append(result)
            write(folder,'done.json',dict(id=trial['id'],status=result['status']))
        if result['status']=='unavailable':raise RuntimeError('NPN block stopped after unavailable '+trial['id'])
        if trial!=trials[-1]:wait_for(folder,'next.request',120)
    write(out,'npn-collection.json',dict(outcomes=outcomes,scheduled=20,replacements=0))
finally:
    client.close()
    with (out/'stop.request').open('x') as f:f.write('NPN block finished or worker stopped.\n')
print(json.dumps(dict(npn_outcomes=len(outcomes),statuses=dict((s,sum(r['status']==s for r in outcomes)) for s in {r['status'] for r in outcomes}))))
