from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path(__file__).resolve().parents[2]; out=Path(__file__).resolve().parent
paths=subprocess.check_output(['rg','--files','-g','*.go','-g','!build/**','-g','!third_party/**'],cwd=root,text=True).splitlines()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={name:sha(root/name) for name in sorted(paths)}
env=dict(os.environ,GOPROXY='off',GOWORK='off')
start=time.monotonic()
with (out/'quality-stdout.txt').open('x') as stdout,(out/'quality-stderr.txt').open('x') as stderr:
 result=subprocess.run(['./scripts/check.sh'],cwd=root,env=env,stdout=stdout,stderr=stderr)
after={name:sha(root/name) for name in sorted(paths)}
report=dict(exit_code=result.returncode,elapsed_s=time.monotonic()-start,source_sha256=after,sources_unchanged=before==after,scope='Full check.sh for verification/sweep rejected-entry correction; no packaged/native UI qualification inferred')
(out/'quality.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:value for key,value in report.items() if key!='source_sha256'}),flush=True)
raise SystemExit(result.returncode if before==after else 1)
