from pathlib import Path
import datetime, hashlib, importlib.util, json, math, subprocess, sys

root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
read = lambda name: json.loads((stage / (name + '.json')).read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
excluded = {'scope', 'recording', 'viewport', 'command_revision', 'revision', 'last_actor'}
physical = lambda state: {k: v for k, v in state.items() if k not in excluded}
base = read('baseline')
for name in ['index-refused', 'index-corrected', 'time-refused', 'time-corrected',
             'time-range-refused', 'time-range-corrected', 'cursor-10-after',
             'cursor-0-after', 'fresh-next']:
    state = read(name)
    assert physical(state) == physical(base), name
    assert state['paused'] and not state['document']['dirty']
assert read('index-refused')['recording'] == base['recording']
corrected = read('index-corrected')['recording']
assert corrected['sample_index'] == 3 and corrected['time_s'] == 3e-6
for name in ['time-refused', 'time-corrected', 'time-range-refused', 'time-range-corrected']:
    assert read(name)['recording'] == corrected
for name, value in [('02-index-refused', '1.5'), ('04-time-refused', 'oops'),
                    ('06-time-range-refused', '2 ms')]:
    text = (stage / (name + '.txt')).read_text()
    assert value in text and '1000' in text and 'Your circuit is unchanged' in text
races = {}
for name in ['cursor-10', 'cursor-0']:
    agent = json.loads((stage / name / 'agent.json').read_text())
    after = read(name + '-after')
    assert after['recording'] == agent['accepted']['recording']
    assert physical(after) == physical(agent['accepted'])
    differences = [k for k in after if after[k] != agent['accepted'].get(k)]
    if name == 'cursor-10':
        assert not differences
    else:
        assert set(differences) == {'viewport', 'command_revision', 'revision', 'last_actor'}
    races[name] = {'accepted_recording_preserved': True, 'snapshot_differences': differences,
                   'native_queue_origin_proven': False}
next_state = read('fresh-next')
assert next_state['command_revision'] == read('cursor-0-after')['command_revision'] + 1
assert next_state['recording']['sample_index'] == 4
assert read('protocol-report')['passed']

spec = importlib.util.spec_from_file_location('client', root / 'scripts/persistence-demo.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
client = helper.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json',
                       command_preconditions=True,
                       agent_binary=root / 'build/ELab-0.181.22-223-candidate/elab-agent')
errors = []
try:
    current = client.ask('project.inspect')
    rows, offset = [], 0
    while True:
        page = client.ask('operation.samples', {'id': current['selected_operation'], 'offset': offset, 'limit': 200})
        rows.extend(page['rows'])
        if len(rows) == page['total']:
            break
        offset = page['next_offset']
    assert rows == json.loads((root / 'build/native-acceptance-220-tools/native-recording-rows.json').read_text())
    assert len(rows) == 1001
    for row in rows:
        for value, target in zip(row['values'], [5 * -math.expm1(-row['time_s'] / .01), 5], strict=True):
            errors.append(abs(value - target))
            assert math.isclose(value, target, abs_tol=1e-12, rel_tol=1e-12)
    (stage / 'native-recorded-rows.json').write_text(json.dumps(rows, indent=2) + '\n')
    client.ask('project.load', {'path': str(root / 'build/native-acceptance-220-tools/RC native 220.elab')}, True)
    client.ask('recording.speed.set', {'seconds_per_wall_second': .1}, True)
    final = client.ask('project.inspect')
    assert final['paused'] and not final['document']['dirty'] and final['transient']['sample']['time_s'] == 0
    assert final['recording']['sample_index'] == 0 and final['recording']['seconds_per_wall_second'] == .1
    assert final['theme'] == 'light'
    (stage / 'final-state.json').write_text(json.dumps(final, indent=2) + '\n')
finally:
    client.close()
inputs = json.loads((root / 'docs/validation/number-step-223/source-inputs.json').read_text())
assert all(sha(root / name) == digest for name, digest in inputs.items())
project = json.loads((root / 'build/number-step-223-tools/preserved-project.json').read_text())
assert sha(Path(project['path'])) == project['sha256']
update = read('prepared-update')
app = Path(update['installed'])
assert sha(app / 'Contents/MacOS/ELab Cursor Recovery') == update['native_sha256']
with (stage / 'signature-after-checks.txt').open('w') as log:
    subprocess.run(['/usr/bin/codesign', '--verify', '--deep', '--strict', '--verbose=2', str(app)], stdout=log, stderr=-2, check=True)
sys.path.insert(0, str(root / 'scripts'))
from runtime_isolation import bundle_tree
build = json.loads((root / 'build/number-step-223-tools/build-result-signed.json').read_text())
assert bundle_tree(Path(build['review']) / 'ELab.app') == build['source_bundle']
assert sha(root / 'build/releases/ELab-0.181.4-macos-arm64.zip') == 'd13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
report = dict(current_native_refusals_passed=True, first_corrections_passed=3,
              public_protocol_passed=True, bounded_interleavings=races,
              exact_native_queued_parser_origin_qualified=False, native_check9_complete=False,
              fresh_next_one_command=True, stored_rows_exact=len(rows),
              independent_voltage_references=len(errors), max_absolute_error_v=max(errors),
              source_inputs_unchanged=len(inputs), saved_fixture_unchanged=True,
              installed_signature_valid=True, original_candidate_unchanged=True, preserved_205_unchanged=True,
              final_clean_paused_at_zero=True, production_changes=0, full_source_suites_repeated=False,
              remaining_original_native_checks=9, source_commit=build['source_commit'],
              native_sha256=update['native_sha256'], observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(stage / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
