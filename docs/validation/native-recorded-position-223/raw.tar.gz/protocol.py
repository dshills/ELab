from pathlib import Path
import importlib.util,json,time
r=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('client',r/'scripts/persistence-demo.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
c=h.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json',command_preconditions=True,agent_binary=r/'build/ELab-0.181.22-223-candidate/elab-agent')
try:
 before=c.ask('project.inspect');changed=c.ask('recording.speed.set',{'seconds_per_wall_second':.25},True)
 def malformed(origin,tag):
  request=dict(version=1,id=tag,command='recording.seek',params={'time_s':'oops'},expected_command_revision=origin['command_revision'],expected_document_generation=origin['document']['generation'],key=tag+'-'+str(time.time_ns()))
  c.process.stdin.write(json.dumps(request)+'\n');c.process.stdin.flush();line=c.process.stdout.readline();assert line
  reply=json.loads(line);assert reply['error']['code']=='invalid-params'
  after=c.ask('project.inspect');assert after==changed
  (s/(tag+'.json')).write_text(json.dumps({'request':request,'response':reply,'before_agent':before,'after_agent':changed,'after_refusal':after},indent=2)+'\n')
  return reply
 stale=malformed(before,'protocol-stale');current=malformed(changed,'protocol-current')
 assert '1000' not in stale['help']['action'] and '1000' in current['help']['action']
 assert not stale['help']['object_ids'] and not stale['help']['terminal_refs'] and not stale['help']['wire_ids']
 corrected=c.ask('recording.seek',{'time_s':'4 us'},True)
 assert corrected['recording']['sample_index']==4 and corrected['recording']['seconds_per_wall_second']==.25
 assert corrected['recording']['scope']==changed['recording']['scope']
 (s/'protocol-corrected.json').write_text(json.dumps(corrected,indent=2)+'\n')
 result=dict(passed=True,stale_parser_code_preserved='invalid-params',stale_range_specialization_suppressed=True,current_capture_range_specialization_present=True,full_state_preserved_on_refusals=True,fresh_correction_preserves_agent_speed_and_cursor=True,scope='Exact public agent protocol against running native /223; not proof of a particular native UI callback queue origin')
 (s/'protocol-report.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
finally:c.close()
