from pathlib import Path
import importlib.util,json,sys,time
r=Path('/Users/dshills/Development/projects/ELab');s=Path(__file__).resolve().parent
name,delay=sys.argv[1],float(sys.argv[2]);assert name in ['cursor-0','cursor-10','speed-10','cursor-30','speed-30'] and 0<=delay<=.1
trial=s/name;assert not trial.exists();trial.mkdir()
spec=importlib.util.spec_from_file_location('client',r/'scripts/persistence-demo.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
c=h.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json',command_preconditions=True,agent_binary=r/'build/ELab-0.181.22-223-candidate/elab-agent')
try:
 base=c.ask('project.inspect');(trial/'ready.json').write_text(json.dumps({'ready_wall_ms':time.time_ns()/1e6,'baseline':base},indent=2)+'\n')
 deadline=time.monotonic()+45
 while not (trial/'trigger.json').exists():
  if time.monotonic()>deadline:raise TimeoutError('no trigger; no agent edit sent')
  time.sleep(.001)
 time.sleep(delay);before=c.ask('project.inspect');start=time.time_ns()/1e6
 command,params=('recording.cursor.set',{'cursor':'b','time_s':.0005}) if name.startswith('cursor') else ('recording.speed.set',{'seconds_per_wall_second':.5})
 state=c.ask(command,params,True);end=time.time_ns()/1e6
 (trial/'agent.json').write_text(json.dumps({'delay_s':delay,'command_start_wall_ms':start,'command_end_wall_ms':end,'command':command,'params':params,'before':before,'accepted':state},indent=2)+'\n')
 print(json.dumps({'command':command,'revision':state['command_revision'],'start_wall_ms':start,'end_wall_ms':end}))
finally:c.close()
