"""Preserve metadata in Git and raw images in the declared ignored local store."""
from pathlib import Path
import gzip,hashlib,io,json,os,tarfile,sys
root=Path('/Users/dshills/Development/projects/ELab');kind=sys.argv[1];assert kind in ['led','rc']
src=Path(f'/private/tmp/elab-latency-{kind}2-173');stage=root/f'build/latency-{kind}2-173-work';proof=root/'docs/validation/latency-followup-173';target=proof/kind/'session';target.mkdir(exist_ok=True)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
originals={}
for p in sorted(src.rglob('*')):
 if not p.is_file() or '.app' in str(p.relative_to(src)) or p.suffix=='.png' and 'capture' in p.parts:continue
 name=p.relative_to(src);raw=p.read_bytes();originals[str(name)]=dict(sha256=sha(raw),bytes=len(raw));q=target/name;q.parent.mkdir(parents=True,exist_ok=True)
 if p.suffix=='.png':q.write_bytes(raw)
 else:q.with_name(q.name+'.gz').write_bytes(gzip.compress(raw,mtime=0))
(target/'original-file-manifest.json').write_text(json.dumps(originals,indent=2)+'\n')
producers=target/'producers';producers.mkdir(exist_ok=True)
for p in sorted(stage.iterdir()):
 if p.is_file() and p.suffix in ['.py','.swift','.plist','.json','.txt','.gz']:
  if p.suffix=='.gz':(producers/p.name).write_bytes(p.read_bytes())
  else:(producers/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
os.umask(0o077)
for capture in src.glob('trials/*/capture'):
 images=sorted(capture.glob('*.png'));cap=target/capture.relative_to(src);manifest={}
 store=root/'build/validation-evidence/latency-followup-173'/kind/capture.parent.name;store.mkdir(parents=True,exist_ok=False);archive=store/'frames.tar.xz'
 with tarfile.open(archive,'x:xz',preset=6) as tar:
  for p in images:
   raw=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(raw);info.mode=0o600;tar.addfile(info,io.BytesIO(raw));manifest[p.name]=dict(sha256=sha(raw),bytes=len(raw))
 (cap/'image-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 (cap/'frame-store.json').write_text(json.dumps(dict(archive_path=archive.relative_to(root).as_posix(),archive_sha256=sha(archive.read_bytes()),archive_bytes=archive.stat().st_size,member_count=len(manifest),image_bytes=sum(r['bytes'] for r in manifest.values()),policy='Ignored local archive; exact original PNG bytes and modes. Restore this archive if absent; never regenerate a trial.'),indent=2)+'\n')
print('Preserved',kind,flush=True)
