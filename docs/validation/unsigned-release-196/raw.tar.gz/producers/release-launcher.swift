import Darwin
if "/private/tmp/elab-unsigned-native-196/stop.request".withCString({ access($0, F_OK) }) == 0 { exit(75) }
let markerPath = "/private/tmp/elab-unsigned-native-196/launcher.pid"
let descriptor = markerPath.withCString { Darwin.open($0, O_WRONLY | O_CREAT | O_EXCL, mode_t(0o600)) }
guard descriptor >= 0 else { perror("create owned launcher PID"); exit(73) }
let bytes = Array("\(getpid())\n".utf8)
let written = bytes.withUnsafeBytes { Darwin.write(descriptor, $0.baseAddress, $0.count) }
guard written == bytes.count, Darwin.close(descriptor) == 0 else { perror("write owned launcher PID"); exit(74) }
let arguments: [String] = ["/usr/bin/sandbox-exec", "-f", "/private/tmp/elab-unsigned-native-196-runtime/runtime.sb", "/private/tmp/elab-unsigned-release-196/Extracted download µ with spaces/ELab-0.179.0-macos-arm64/ELab.app/Contents/MacOS/ELab", "--agent-endpoint", "/private/tmp/elab-unsigned-native-196/endpoint.json", "--no-recovery", "--no-appearance"]
var pointers = arguments.map { strdup($0) }
pointers.append(nil)
_ = pointers.withUnsafeMutableBufferPointer { execv("/usr/bin/sandbox-exec", $0.baseAddress!) }
perror("enter owned native sandbox")
exit(127)
