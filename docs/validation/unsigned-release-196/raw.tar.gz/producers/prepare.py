from pathlib import Path
import hashlib,json,shutil,stat,subprocess,sys,zipfile
R=Path('/Users/dshills/Development/projects/ELab');O=Path('/private/tmp/elab-unsigned-release-196');O.mkdir(mode=0o700);P=R/'build/releases/ELab-0.179.0-macos-arm64';P.parent.mkdir(exist_ok=True)
sys.path.insert(0,str(R/'scripts'));from package_review import members,verify_archive
source=R/'build/ELab-0.179.0-196-alpha';expected_source=members(source);assert not P.exists();shutil.copytree(source,P)
for name in ['RELEASE_MANIFEST.json','RELEASE_STATUS.json']: (P/name).unlink()
(P/'README.md').write_text('''# ELab 0.179.0 - macOS arm64

A local electronics workbench for hobbyists. Draw a circuit, watch it simulate,
edit values, measure waveforms, undo changes and save your experiment. The
matching elab-agent exposes the same application commands to authorized agents.

## Requirements and installation

Apple Silicon Mac. The app binary requires macOS 26.0 or later; this release is
verified on macOS 26.6.2 arm64. Intel Macs and earlier macOS versions are not
supported by this package. No Go, Xcode, Vellum checkout, cloud account or model
provider is required for the packaged app and agent.

1. Verify the ZIP against its supplied .sha256 checksum file.
2. Unzip it and keep this folder's documentation, examples and notices.
3. Move ELab.app to a writable Applications folder, or run it from the extracted
   folder. Keep any previous version separately; do not overwrite it while open.
4. Open ELab.app and choose an example, or start placing components.

This is an unsigned release in the Developer ID sense. The app retains an
ad-hoc integrity seal; it has no Apple-issued Developer ID and is not notarized.
A downloaded copy can be blocked by Gatekeeper. The release does not change
macOS security settings or remove download quarantine. If macOS blocks it,
consult Apple's official guidance and make any trust decision yourself:
https://support.apple.com/102445
An administrator-managed Mac may not permit opening it.

## First circuit

Open Examples/LED-2k.elab or draw a 5 V source, resistor, red LED and ground in a
loop. At 1 kΩ the LED current is about 2.917 mA; at 2 kΩ it is about 1.477 mA.
Search accepts aliases such as battery. Connect by name supports keyboard wiring.
Component values accept units such as 2.2k or 1 uF. Simulation updates live when
the circuit is valid. Read diagnostics and model assumptions before interpreting
a result. Generic educational models are not physical-device certification.

Try Examples/RC-charge.elab for charging/discharging, and LED-flasher.elab for
both transistor outputs. Scope probes select voltages or currents; cursor times
accept 10 ms. Use Tab to commit a cursor time. All bundled examples are editable,
paused projects; Save As creates your own copy.

## Save, export and agents

Save/Open preserves your schematic, settings and kept completed results. A save
during Verify or sweep omits unfinished captures; later completion is unsaved
until you save again. Fit to page exports the complete schematic as a single
Letter/A4 PDF or PNG. SVG is also available. Preview explicit-scale tiling before
printing or assembling pages. The paired agent runs independently with
./elab-agent, or connects to an explicitly owned native endpoint. Begin with
capabilities.list and project.inspect. See AGENT_PROTOCOL.md for framing,
revision guards, units, retries, jobs and shutdown.

See RELEASE_NOTES.md for qualification and known limitations, and ROLLBACK.md
before switching versions. This package is ready for the approved unsigned
release channel. Owner review and a separate clean-account installation test
remain deferred; broader PRD MVP, accessibility study and additional platforms
are not asserted. No public hosting or upload is included in local preparation.
''')
notes=(P/'RELEASE_NOTES.md').read_text();notes=notes.replace('# Engineering qualification - October 22, 2026','# Release notes - October 22, 2026');notes+='''
## Unsigned release designation

The owner selected an unsigned downloadable release on October 22. App and
agent bytes are identical to the qualified /196 engineering alpha. Packaging
adds installation/requirements/Gatekeeper instructions; it adds no features.
The app's actual deployment target is macOS 26.0 and architecture is arm64.
Testing on 26.6.2 does not establish compatibility with every later or earlier OS.
Developer ID/notarization are not requirements for this owner-selected channel;
Gatekeeper approval and clean-account installation are not passed by implication.
The embedded manifest's build-time audit fields remain unchanged. Consult the
external unsigned-release receipt for subsequent packaging/runtime observations.
''';(P/'RELEASE_NOTES.md').write_text(notes)
status=dict(kind='unsigned-macos-arm64-release',version='0.179.0',build='196',source_commit='885af1ad3c2a130092e532e8ffe966a5c6789889',owner_authorized_channel='Prepare an unsigned release',architecture='arm64',binary_minimum_macos='26.0',tested_macos='26.6.2',developer_id_signed=False,ad_hoc_integrity_seal=True,notarized=False,engineering_evidence='docs/validation/engineering-release-196/report.json',owner_review='deferred',clean_account_installation='deferred; not tested',full_prd_mvp_accepted=False,published=False)
(P/'RELEASE_STATUS.json').write_text(json.dumps(status,indent=2)+'\n');(P/'RELEASE_MANIFEST.json').write_text(json.dumps(dict(status=status,files=members(P)),indent=2)+'\n')
expected=members(P);archive=P.parent/(P.name+'.zip');assert not archive.exists()
with archive.open('xb') as f:
 archive.chmod(0o644)
 with zipfile.ZipFile(f,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,v in expected.items():
   e=zipfile.ZipInfo(P.name+'/'+name,date_time=(1980,1,1,0,0,0));e.create_system=3;e.external_attr=(stat.S_IFREG|int(v['mode'],8))<<16;e.compress_type=zipfile.ZIP_DEFLATED;z.writestr(e,(P/name).read_bytes(),compresslevel=9)
verify_archive(archive,P.name,expected);extract=O/'Extracted download µ with spaces';r=subprocess.run(['/usr/bin/ditto','-x','-k',str(archive),str(extract)],capture_output=True,timeout=120);(O/'ditto.txt').write_bytes(r.stdout+r.stderr);r.check_returncode();extracted=extract/P.name;assert members(extracted)==expected and members(source)==expected_source
for name in ['ELab.app/Contents/MacOS/ELab','elab-agent']:
 assert (extracted/name).read_bytes()==(source/name).read_bytes()
r=subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict','--verbose=2',str(extracted/'ELab.app')],capture_output=True,timeout=30);(O/'signature.txt').write_bytes(r.stdout+r.stderr);r.check_returncode()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=dict(status='packaged_runtime_check_pending',release=str(P),archive=str(archive),archive_sha256=sha(archive),extracted=str(extracted),files_verified=len(expected),bytes_and_modes_match=True,app_agent_bytes_unchanged=True,strict_ad_hoc_signature_valid=True,source_alpha_unchanged=True,source_alpha_members=expected_source,owner_authorized_channel=status['owner_authorized_channel'])
(O/'package-report.json').write_text(json.dumps(report,indent=2)+'\n');Path(str(archive)+'.sha256').write_text(sha(archive)+'  '+archive.name+'\n');print(json.dumps({k:v for k,v in report.items() if k!='source_alpha_members'},indent=2))
