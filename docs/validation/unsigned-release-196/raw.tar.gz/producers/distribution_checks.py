from pathlib import Path
import hashlib,json,shutil,subprocess,time,sys
R=Path('/Users/dshills/Development/projects/ELab');O=Path('/private/tmp/elab-unsigned-release-196');n=Path('/private/tmp/elab-unsigned-native-196');p=json.loads((O/'package-report.json').read_text());E=Path(p['extracted']);sys.path.insert(0,str(R/'scripts'));from package_review import members,verify_archive
session=json.loads((n/'session.json').read_text());assert session['status']=='closed' and session['open_exit_code']==0 and session['endpoint_removed'] and session['owned_process_absent']
assert members(E)==members(Path(p['release']));verify_archive(Path(p['archive']),E.name,members(E))
results=[]
for name in ['ELab.app/Contents/MacOS/ELab','elab-agent']:
 binary=E/name;libs=subprocess.check_output(['/usr/bin/otool','-L',str(binary)],text=True);(O/(Path(name).name+'-dependencies.txt')).write_text(libs)
 deps=[x.strip().split(' (',1)[0] for x in libs.splitlines()[1:]];assert deps and all(x.startswith(('/System/Library/','/usr/lib/')) for x in deps)
 load=subprocess.check_output(['/usr/bin/otool','-l',str(binary)],text=True);(O/(Path(name).name+'-load-commands.txt')).write_text(load)
 arch=subprocess.check_output(['/usr/bin/lipo','-archs',str(binary)],text=True).strip();assert arch=='arm64'
 results.append(dict(file=name,architecture=arch,dependencies_system_only=True,sha256=hashlib.sha256(binary.read_bytes()).hexdigest()))
q=O/'Quarantined assessment.app';shutil.copytree(E/'ELab.app',q)
quarantine='0083;'+format(int(time.time()),'x')+';ELabReleaseQualification;'
subprocess.run(['/usr/bin/xattr','-w','com.apple.quarantine',quarantine,str(q)],check=True)
verified=subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict',str(q)],capture_output=True,text=True,timeout=30);assert verified.returncode==0
start=time.monotonic()
try:
 assessment=subprocess.run(['/usr/sbin/spctl','--assess','--type','execute','--verbose=4',str(q)],capture_output=True,text=True,timeout=30)
 assessment_record=dict(exit_code=assessment.returncode,output=assessment.stdout+assessment.stderr,elapsed_s=time.monotonic()-start)
except subprocess.TimeoutExpired as error:
 assessment_record=dict(status='unavailable-timeout',elapsed_s=time.monotonic()-start)
(O/'gatekeeper.txt').write_text(json.dumps(assessment_record,indent=2)+'\n')
assert assessment_record.get('exit_code')==3 and 'rejected' in assessment_record['output'].lower(),assessment_record
report=dict(passed=True,scope='Owner-authorized unsigned macOS arm64 release readiness',archive_sha256=p['archive_sha256'],archive_members_preserved_after_extracted_native_use=True,exact_extracted_native_started_and_rendered=True,extracted_native_reference_workflows=3,all_final_sessions_shutdown_normally=True,system_dependencies=results,quarantine_assessment=assessment_record,expected_gatekeeper_rejection_observed=True,security_overrides_performed=False,quarantined_app_launched=False,developer_id_signed=False,notarized=False,clean_account_installation_tested=False,owner_review='deferred by instruction',known_issues_disposition='Invalid cursor Return and file-panel basename suffix behavior remain recoverable, state-preserving documented limitations; no new source repair or feature added',ready_for_unsigned_release=True,published=False)
(O/'distribution-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
