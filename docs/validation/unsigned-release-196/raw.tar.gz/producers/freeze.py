from pathlib import Path
import hashlib,json,tarfile
R=Path('/Users/dshills/Development/projects/ELab');O=Path('/private/tmp/elab-unsigned-release-196');N=Path('/private/tmp/elab-unsigned-native-196');S=R/'build/unsigned-release-196-tools';D=R/'docs/validation/unsigned-release-196';D.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();files={}
for prefix,root in [('packaging',O),('extracted-native',N),('producers',S)]:
 for p in sorted(root.rglob('*')):
  if not p.is_file() or p.is_symlink():continue
  rel=p.relative_to(root)
  if any(x in ['swift-cache','__pycache__'] or x.endswith('.app') or x.startswith('Extracted download') for x in rel.parts):continue
  if p.name=='endpoint.json' or p.suffix not in {'.py','.swift','.json','.jsonl','.txt','.jpg','.elab'}:continue
  files[prefix+'/'+rel.as_posix()]=p
files['native-controller.txt']=Path('/private/tmp/elab-unsigned-native-196-controller.txt');files['runtime.sb']=Path('/private/tmp/elab-unsigned-native-196-runtime/runtime.sb')
manifest={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in files.items()}
with tarfile.open(D/'raw.tar.gz','w:gz') as t:
 for n,p in files.items():t.add(p,arcname=n,recursive=False)
with tarfile.open(D/'raw.tar.gz','r:gz') as t:
 assert set(t.getnames())==set(files)
 for entry in t:
  assert hashlib.sha256(t.extractfile(entry).read()).hexdigest()==manifest[entry.name]['sha256']
(D/'raw-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
report=json.loads((O/'distribution-report.json').read_text());package=json.loads((O/'package-report.json').read_text());report.update(date='2026-10-22',version='0.179.0',build='196',release=package['release'],archive=package['archive'],source_commit='885af1ad3c2a130092e532e8ffe966a5c6789889',owner_authorization='Prepare an unsigned release',source_alpha_qualification='docs/validation/engineering-release-196/report.json',archive_files=package['files_verified'],raw_files=len(files),raw_archive_sha256=sha(D/'raw.tar.gz'),native_session=json.loads((N/'session.json').read_text()),native_workflows=json.loads((N/'workflows/report.json').read_text()),no_new_runtime_source_or_feature=True,security_policy='quarantined test copy assessed and rejected; no quarantine removal or Gatekeeper override',minimum_macos='26.0',tested_macos='26.6.2')
assert report['passed'] and report['ready_for_unsigned_release'];(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(passed=True,ready_for_unsigned_release=True,raw_files=len(files),archive_sha256=report['archive_sha256'])))
