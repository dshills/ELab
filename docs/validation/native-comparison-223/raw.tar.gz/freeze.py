from pathlib import Path
import gzip, hashlib, io, json, tarfile
root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
dest=root/'docs/validation/native-comparison-223';assert not dest.exists()
report=json.loads((stage/'report.json').read_text());assert report['passed']
(stage/'native-method.txt').write_text('''Native input used the documented cua_repl API exclusively, reusing current223App.
Fresh full AX state located Requested comparison time before each edit. click(index),
pressKey(super+a), typeText(value), pressKey(Return), getAXState and a fresh full
getAXStateAndScreenshot produced each retained capture. No added event technology.
Native menu selected verify-9; native checkboxes enabled overlay then whole-run stats.
Current edits: oops -> 0 s, -1 ms -> 0 s, 30 ms -> 0 s; snapshot each boundary.
Then oops; actions.py preferences; native capture retained rejection with both flags
off; first native 0 s correction; native 9 ms; private 4 ms without Return;
actions.py private-switch; capture cleared draft; native focus/Return no-op;
native 2 ms; oops; actions.py rejected-switch; capture cleared rejection;
oops again; reselect same verify-9 through native menu; cleared at accepted zero;
fresh native 2 ms; qualify.py validates all states/public queries and restores fixture.
No exact native callback queue-origin or hardware latency claim is made.
''')
files={p.relative_to(stage).as_posix():p.read_bytes() for p in stage.rglob('*') if p.is_file() and p.suffix in {'.py','.json','.txt','.jpg'}}
for name,data in files.items():
    assert Path(name).name!='endpoint.json'
    if name.endswith('.jpg'):assert data.startswith(b'\xff\xd8\xff')
dest.mkdir(parents=True)
with (dest/'raw.tar.gz').open('xb') as disk:
    with gzip.GzipFile(fileobj=disk,mode='wb',filename='',mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for name,data in sorted(files.items()):
                info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
                tar.addfile(info,io.BytesIO(data))
sha=lambda data:hashlib.sha256(data).hexdigest()
manifest={name:sha(data) for name,data in sorted(files.items())}
(dest/'raw-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
report.update(raw_members=len(files),raw_archive_sha256=sha((dest/'raw.tar.gz').read_bytes()))
(dest/'report.json').write_text(json.dumps(report,indent=2)+'\n')
pending=json.loads((root/'docs/validation/native-measurement-223/native-acceptance-pending.json').read_text())
pending.update(completed_checks_for_copied_runtime=[1,2,4,5,7,8,10,12,13,16,17,18],remaining_checks_count=6,
               new_native_checks=[13],carried_forward_checks=[1,2,4,5,7,8,10,12,16,17,18],
               current_build_fresh_native_checks=[13],evidence='README.md',
               prior_evidence='../native-measurement-223/README.md',
               current_build_fresh_native_scope='Native comparison menu/checkboxes, three refusal/first-correction cases, agent preferences/draft retention, private/rejected reference ownership, same-reference zero reset, independent saved RC/whole-run statistics checks')
(dest/'native-acceptance-pending.json').write_text(json.dumps(pending,indent=2)+'\n')
(dest/'README.md').write_text('''# Native captured comparison /223

[Receipt](report.json), [captures and checks](raw.tar.gz), [hashes](raw-manifest.json),
[remaining checklist](native-acceptance-pending.json).

Original native item 13 passes on the unchanged code-equivalent /223 copy. The
same owned session is reused. No production change, new feature or launch prompt.

## Native correction and independent preferences

The native menu selects reference B; separate native checkboxes enable overlay
and whole-run statistics. Malformed, negative and beyond-duration times retain
their exact text and identify the last accepted comparison. Each first correction
to the accepted 0 s clears the refusal. Accepted comparison, circuit and history
state remain exact except viewport, revisions and actor; guidance changes height.

An agent changes both display preferences to off and writes an independent editor
draft while a current refusal exists. The rejected time and cached-result notice
remain visible. Its first native correction preserves those new preferences and
the agent's draft. Recorded plot window and cursors are unchanged throughout.

## Reference ownership

After a valid 9 ms request, an unfinished native 4 ms draft remains private. The
agent chooses a shorter reference and restarts the comparison at zero. The old
draft is cleared; native focus/Return leaves the complete agent snapshot exact.
A fresh 2 ms request targets the new reference with exactly one shared command.

A rejected time is then cleared by a real agent reference change. Explicitly
reselecting that same reference through the native menu also clears a new refusal
when its accepted time is already zero. Fresh editing then succeeds. All three
measured fresh time changes deliver one shared command apiece. The explicit menu
reset also restores guidance layout; its total revision delta includes viewport.

## Electrical references and preservation

A uses R=20 kohm, C=1 uF, 1 ms saved steps over 20 ms. B uses R=10 kohm and 2 ms
steps; the short reference uses A's settings over 10 ms. The live resistor is
subsequently 30 kohm, making capture/live identity distinct. All 43 saved rows and
metadata remain exact after that edit and the UI tests.

Six cached native results equal their pure public queries exactly, with the live
snapshot unchanged by each query. Independent RC references cover all saved
voltages/currents, 36 comparison values/deltas and 16 whole-run scalar statistics:
138 scalars total. Maximum errors are below 9e-16 V and 9e-20 A. Whole-run means/RMS
use all saved rows rather than the narrower 2–18 ms plot interval. The native
9 ms request uses A's actual 0.009000000000000001 s and B's 0.008 s; public row
distances confirm those selections. No identical-timestamp assumption is made.

All 897 frozen source/check inputs, saved fixture, strict installed signature,
original candidate and /205 download remain unchanged. Existing full source
gates still apply; no redundant full suite. The disposable fixture is restored
clean, paused at zero, Light, with original playback speed. Raw JPEG capture bytes
are preserved. This qualification does not prove exact queued callback origin or
hardware timing for the separate open checks.

Twelve of eighteen original native checks now have scoped evidence; six remain:
3, 6, 9, 11, 14 and 15. /223 stays held; /205 remains the preserved download. Next
test native local text undo/redo and application-history routing, then remaining
form ownership and input-route qualification. Owner review is deferred and standing
run/desktop authorization remains in force; no permission question is pending.
''')
(root/'research/108-native-captured-comparison.md').write_text('''# Native captured comparison acceptance

October 24, 2026. [Evidence and checklist](../docs/validation/native-comparison-223/README.md).

Native item 13 passes: reference menu and independent checkboxes, three current
refusal/first-correction cases, cached-result identity, preference/draft retention
after agent work, private/rejected time scoped to the capture pair, and explicit
same-reference reset at accepted zero. Fresh requests target the new reference;
recorded plot window, cursors and live state stay preserved.

Different saved RC rates/resistances and a later live resistor edit establish
capture identity. All 43 rows/metadata are exact; six native cached results match
pure public queries and 138 independent scalar references pass. Source, signatures,
fixtures and /205 are unchanged. No product change or full-suite repetition.
The existing owned app is restored clean and paused at zero. Twelve original
native checks are complete and six remain. Continue native text/history routing
and remaining form ownership without owner review or another launch permission.
''')
with (root/'research/README.md').open('a') as out:
    out.write('\n- [Native captured comparison](108-native-captured-comparison.md): reference ownership, refusal/correction, independent preferences, same-reference reset, and 138 RC/statistics references; six native checks remain.\n')
with (root/'research/80-overnight-work-plan.md').open('a') as out:
    out.write('''

## Checkpoint: native captured comparison acceptance

[Native item 13](108-native-captured-comparison.md) passes with native menu and
checkboxes, current refusal/correction, agent preferences/draft retention,
reference-scoped private/rejected text and explicit same-reference reset. Six
native cached/public results and 138 independent electrical/statistical references
pass; all rows, metadata, source, signatures, saved fixture and /205 stay exact.
Twelve original native items are complete; six remain. Next local text Undo/Redo
and application history, then remaining form/input ownership. Reuse the owned
session under saved authorization; no owner-review or permission wait.
''')
plan=root/'research/34-first-version-plan.md';text=plan.read_text()
start=text.index('**Current maintenance work:**');end=text.index('\n## Historical plan',start)
text=text[:start]+'''**Current maintenance work:** /223's decimal-step repair and the
[latest native captured-comparison checks](108-native-captured-comparison.md)
pass within scope. Twelve of eighteen original native items now have evidence;
six remain: 3, 6, 9, 11, 14 and 15. Item 9 remains partial; bounded races do not
establish exact native callback queue origin. Captured measurement/default and
comparison recovery, independent preferences and draft ownership are qualified.

Earlier validation-scroll, private-draft, footer/theme, manual-step, slider,
Verify endpoint and numeric-wheel repairs remain included. [Electronics reference
checks](95-gate-common-mode.md) cover seven RC-driven MOSFET circuits and active
work preservation. The earlier exit follows a native Quit-menu request whose
initiator is unknown; no spontaneous crash or broad lifecycle pass is claimed.
/207–/223 stay held for remaining native acceptance and do not replace /205.
Owner review remains deferred. Standing run/desktop authorization is saved in
`AGENTS.md` and must not be requested again.
'''+text[end:];plan.write_text(text)
with tarfile.open(dest/'raw.tar.gz','r:gz') as tar:
    assert {m.name:sha(tar.extractfile(m).read()) for m in tar.getmembers()}==manifest
print(json.dumps({'archived_members':len(files),'completed_check':13,'remaining_original_checks':6}))
