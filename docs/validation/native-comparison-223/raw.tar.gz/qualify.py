from pathlib import Path
import datetime, hashlib, importlib.util, json, math, subprocess, sys
root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
read=lambda name:json.loads((stage/(name+'.json')).read_text())
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
base=read('native-baseline');exclude={'viewport','command_revision','revision','last_actor'}
stable=lambda state:{k:v for k,v in state.items() if k not in exclude}
for name in ['malformed','malformed-corrected','negative','negative-corrected','out-of-range','range-corrected']:
    assert stable(read(name))==stable(base),name
for name,value in [('03-malformed','oops'),('05-negative','-1 ms'),('07-out-of-range','30 ms')]:
    text=(stage/(name+'.txt')).read_text()
    assert 'Value: '+value in text and 'Showing the last accepted comparison.' in text
for name in ['04-malformed-corrected','06-negative-corrected','08-range-corrected','11-agent-preferences-corrected','14-private-cleared','17-rejected-cleared','19-same-reference-reset']:
    text=(stage/(name+'.txt')).read_text()
    assert 'Value: 0 s' in text and 'Showing the last accepted comparison.' not in text,name
assert 'Value: oops' in (stage/'10-agent-preferences.txt').read_text()
assert 'Showing the last accepted comparison.' in (stage/'10-agent-preferences.txt').read_text()
assert stable(read('preferences-corrected'))==stable(read('preferences')['after'])
assert read('private-switch')['before']==read('different-rate-time')
assert read('private-cleared-noop')==read('private-switch')['after']
records=read('captured-rc');by_id={r['id']:r for r in records.values()}
for name,before in [('different-rate-time','preferences-corrected'),('fresh-short-reference','private-cleared-noop'),('fresh-changed-reference','same-reference-reset')]:
    assert read(name)['command_revision']==read(before)['command_revision']+1
assert read('same-reference-before')['recording']==read('same-reference-reset')['recording']
assert read('fresh-short-reference')['recording']['comparison']['settings']['reference_id']==records['short']['id']
assert read('fresh-changed-reference')['recording']['comparison']['settings']['reference_id']==records['b']['id']
for name in ['preferences-corrected','different-rate-time','private-cleared-noop','fresh-short-reference','same-reference-reset','fresh-changed-reference']:
    state=read(name);cfg=state['recording']['comparison']['settings']
    assert not cfg.get('show_overlay',False) and not cfg.get('show_statistics',False)
    assert state['drawing']['value']=='agent comparison draft'
    assert state['recording']['scope']==base['recording']['scope']
physical=lambda state:{k:v for k,v in state.items() if k not in exclude|{'drawing','recording'}}
for path in stage.glob('*.json'):
    data=json.loads(path.read_text())
    for state in [data]+([data['before'],data['after']] if isinstance(data,dict) and 'before' in data else []):
        if isinstance(state,dict) and 'command_revision' in state and state.get('last_operation')==base['last_operation']:
            assert physical(state)==physical(base),path.name
spec=importlib.util.spec_from_file_location('client',root/'scripts/persistence-demo.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
client=helper.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json',command_preconditions=True,
                     agent_binary=root/'build/ELab-0.181.22-223-candidate/elab-agent')
voltage_errors=[];current_errors=[];comparison_scalars=0;whole_statistics=0;queries=[]
def expected(record,probe,at):
    resistance=next(p for p in record['metadata']['graph']['components'] if p['id']=='R1')['value']
    assert resistance in [10000,20000]
    return 5*-math.expm1(-at/(resistance*1e-6)) if probe=='v:C1' else 5/resistance*math.exp(-at/(resistance*1e-6))
def close(actual,target,probe):
    error=abs(actual-target)
    (voltage_errors if probe=='v:C1' else current_errors).append(error)
    assert math.isclose(actual,target,rel_tol=1e-11,abs_tol=1e-12 if probe=='v:C1' else 1e-15),(actual,target,probe)
try:
    for record in records.values():
        assert client.ask('operation.inspect',{'id':record['id']})['metadata']==record['metadata']
        page=client.ask('operation.samples',dict(id=record['id'],offset=0,limit=200))
        assert page==record['page']
        for row in page['rows']:
            for probe,value in zip(['v:C1','i:C1'],row['values'],strict=True):close(value,expected(record,probe,row['time_s']),probe)
    for name in ['native-baseline','preferences-corrected','different-rate-time','fresh-short-reference','same-reference-reset','fresh-changed-reference']:
        cached=read(name)['recording']['comparison'];params=cached['settings']
        before=client.ask('project.inspect');result=client.ask('recording.compare',params)
        assert before==client.ask('project.inspect') and result==cached and result['available']
        actual={}
        for side in ['a','b']:
            record=by_id[result[side]['id']];rows=record['page']['rows'];at=params['time_s']
            index=min(range(len(rows)),key=lambda i:(abs(rows[i]['time_s']-at),-i))
            assert result[side]['sample_index']==index and result[side]['time_s']==rows[index]['time_s']
            actual[side]=rows[index]['time_s']
        for reading in result['readings']:
            probe=reading['probe']['id'];assert probe in ['v:C1','i:C1']
            av=expected(by_id[result['a']['id']],probe,actual['a']);bv=expected(by_id[result['b']['id']],probe,actual['b'])
            for field,target in [('a',av),('b',bv),('b_minus_a',bv-av)]:close(reading[field],target,probe);comparison_scalars+=1
            if params.get('show_statistics'):
                for side in ['a','b']:
                    record=by_id[result[side]['id']];values=[expected(record,probe,row['time_s']) for row in record['page']['rows']]
                    stat=reading['whole_record_'+side]
                    assert stat['count']==len(values)
                    for field,target in [('min',min(values)),('max',max(values)),('sample_mean',math.fsum(values)/len(values)),('sample_rms',math.sqrt(math.fsum(v*v for v in values)/len(values)))]:
                        close(stat[field],target,probe);whole_statistics+=1
        queries.append({'native_state':name,'requested_s':params['time_s'],'actual_saved_times_s':actual})
    assert next(p for p in client.ask('project.inspect')['components'] if p['id']=='R1')['value']==30000
    client.ask('project.load',{'path':str(root/'build/native-acceptance-220-tools/RC native 220.elab'),'discard_changes':True},True)
    final=client.ask('recording.speed.set',{'seconds_per_wall_second':.1},True)
    assert final['paused'] and not final['document']['dirty'] and final['transient']['sample']['time_s']==0
    assert final['theme']=='light' and final['recording']['sample_index']==0
    (stage/'final-state.json').write_text(json.dumps(final,indent=2)+'\n')
finally:client.close()
inputs=json.loads((root/'docs/validation/number-step-223/source-inputs.json').read_text())
assert all(sha(root/name)==digest for name,digest in inputs.items())
project=json.loads((root/'build/number-step-223-tools/preserved-project.json').read_text())
assert sha(Path(project['path']))==project['sha256']
update=read('prepared-update');app=Path(update['installed'])
assert sha(app/'Contents/MacOS/ELab Cursor Recovery')==update['native_sha256']
with (stage/'signature-after-checks.txt').open('w') as log:
    subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict','--verbose=2',str(app)],stdout=log,stderr=-2,check=True)
sys.path.insert(0,str(root/'scripts'));from runtime_isolation import bundle_tree
build=json.loads((root/'build/number-step-223-tools/build-result-signed.json').read_text())
assert bundle_tree(Path(build['review'])/'ELab.app')==build['source_bundle']
assert sha(root/'build/releases/ELab-0.181.4-macos-arm64.zip')=='d13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
report=dict(passed=True,native_check_completed=13,current_first_corrections=3,
 agent_preferences_and_draft_preserved_on_correction=True,private_and_rejected_time_clear_on_reference_change=True,
 private_return_noop_exact=True,same_reference_zero_reset_passed=True,fresh_native_edits_one_command=3,
 native_queries_equal_pure_public_queries=len(queries),queries=queries,comparison_scalar_references=comparison_scalars,
 whole_run_scalar_statistics=whole_statistics,captured_rows_exact=sum(len(r['page']['rows']) for r in records.values()),
 total_scalar_references=len(voltage_errors)+len(current_errors),max_voltage_error_v=max(voltage_errors),max_current_error_a=max(current_errors),
 captured_metadata_unchanged_after_live_30k_edit=True,scope_window_and_cursors_preserved=True,
 source_inputs_unchanged=len(inputs),saved_fixture_unchanged=True,installed_signature_valid=True,
 original_candidate_unchanged=True,preserved_205_unchanged=True,final_clean_paused_at_zero=True,
 production_changes=0,full_source_suites_repeated=False,remaining_original_native_checks=6,
 source_commit=build['source_commit'],native_sha256=update['native_sha256'],observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(stage/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
