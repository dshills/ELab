from pathlib import Path
import importlib.util, json, sys, time
root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('client',root/'scripts/persistence-demo.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
client=helper.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json',command_preconditions=True,
                     agent_binary=root/'build/ELab-0.181.22-223-candidate/elab-agent')
mode=sys.argv[1];assert mode in ['setup','preferences','private-switch','rejected-switch']
output=stage/(mode+'.json');assert not output.exists()
def capture(duration,step):
    identifier=client.ask('simulation.verify',dict(duration_s=duration,sample_step_s=step,input_mode='charge',probe_ids=['v:C1','i:C1']),True)['last_operation']
    deadline=time.monotonic()+5
    while True:
        operation=client.ask('operation.inspect',{'id':identifier})
        status=operation['operation']['status']
        if status=='completed':break
        assert status not in ['failed','canceled'] and time.monotonic()<deadline,operation
        time.sleep(.01)
    page=client.ask('operation.samples',dict(id=identifier,offset=0,limit=operation['metadata']['sample_count']))
    return dict(id=identifier,metadata=operation['metadata'],page=page)
try:
    before=client.ask('project.inspect')
    if mode=='setup':
        assert before['paused'] and not before['document']['dirty']
        client.ask('example.rc',{'discard_changes':True},True)
        client.ask('simulation.pause',{},True);client.ask('simulation.wait')
        b=capture(.02,.002)
        client.ask('component.set',dict(id='R1',value='20k'),True);client.ask('simulation.wait')
        a=capture(.02,.001);short=capture(.01,.001)
        (stage/'captured-rc.json').write_text(json.dumps(dict(a=a,b=b,short=short),indent=2)+'\n')
        client.ask('component.set',dict(id='R1',value='30k'),True);client.ask('simulation.wait')
        client.ask('operation.select',{'id':a['id']},True)
        client.ask('recording.view.set',{'mode':'recorded'},True)
        client.ask('recording.window.set',dict(start_s=.002,end_s=.018),True)
        for cursor,at in [('a',.005),('b',.015)]:client.ask('recording.cursor.set',dict(cursor=cursor,time_s=at),True)
        client.ask('workspace.inspector.set',{'section':'simulation'},True)
        after=client.ask('project.inspect')
    else:
        records=json.loads((stage/'captured-rc.json').read_text())
        params=dict(before['recording']['comparison']['settings'])
        if mode=='preferences':
            params['show_statistics']=False;params['show_overlay']=False
            client.ask('editor.value.set',{'value':'agent comparison draft'},True)
        else:
            params['reference_id']=records['short' if mode=='private-switch' else 'b']['id']
            params['time_s']=0
        after=client.ask('recording.compare.set',params,True)
    output.write_text(json.dumps(dict(before=before,after=after),indent=2)+'\n')
    print(json.dumps({'mode':mode,'command_revision':after['command_revision'],
                      'comparison':(after['recording'].get('comparison') or {}).get('settings')}))
finally:client.close()
