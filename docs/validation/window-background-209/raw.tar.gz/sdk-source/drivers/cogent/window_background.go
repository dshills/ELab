package cogent

import (
	"image"
	"image/color"

	"cogentcore.org/core/styles"
	"github.com/dshills/vellum/ui"
)

// A window's scene inset belongs to its managed surface. Keep the accepted
// color immutable for native styling, without reading mutable records there.
type windowBackground struct {
	color color.NRGBA
	fill  *image.Uniform
}

func bindWindowBackground(w *nativeWindow) {
	w.body.Scene.Styler(func(s *styles.Style) {
		if accepted := w.background.Load(); accepted != nil {
			s.Background = accepted.fill
		}
	})
}

// Called under root ownership, after successful reconciliation. Translucent
// root paint is applied by the root widget once, over the configured host or
// the native default; it must not also tint the scene underneath itself.
func syncWindowBackground(w *nativeWindow) {
	if w.root == nil {
		return
	}
	value, err := ui.ResolveStyle(w.root.node, w.root.theme)
	if err != nil {
		return
	}
	wanted := value.Background
	if !wanted.Set || wanted.Value.A != 255 {
		wanted = w.root.theme.Default.Background
	}
	old := w.background.Load()
	if wanted.Set && wanted.Value.A == 255 {
		if old != nil && old.color == wanted.Value {
			return
		}
		w.background.Store(&windowBackground{color: wanted.Value, fill: image.NewUniform(wanted.Value)})
	} else {
		if old == nil {
			return
		}
		w.background.Store(nil)
	}
	w.body.Scene.Style()
	w.body.Scene.NeedsRender()
}
