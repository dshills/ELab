//go:build offscreen

package cogent

import (
	"image"
	"math"
	"testing"

	"cogentcore.org/core/events"
	"github.com/dshills/vellum/ui"
)

func TestSplitManualClickAndOffCenterGripPreserveAcceptedFraction(t *testing.T) {
	for _, orientation := range []ui.Orientation{ui.Horizontal, ui.Vertical} {
		t.Run(string(orientation), func(t *testing.T) {
			fraction, changes := float32(.35), 0
			m, _ := simpleManual(t, manualConfig(t, 7), func() ui.Node {
				return ui.Node{ID: "panes", Kind: ui.SplitPane, Grow: true, Orientation: orientation, Number: fraction, Change: func(e ui.ChangeEvent) { fraction = e.Number; changes++ }, Children: []ui.Node{
					{ID: "first", Kind: ui.Column, Grow: true}, {ID: "second", Kind: ui.Column, Grow: true},
				}}
			})
			unitSettle(t, m)
			w := m.implementation.find("one")
			r := w.state.root
			c := r.control.split
			start := c.handle.Geom.TotalBBox.Min.Add(c.handle.Geom.TotalBBox.Size().Div(2))
			if orientation == ui.Horizontal {
				start.X++
			} else {
				start.Y++
			}
			send := func(kind events.Types, x, y int) {
				t.Helper()
				if err := m.Input(testContext, ManualInput{Window: "one", WindowIncarnation: w.incarnation, Type: kind, Button: events.Left, Position: start.Add(image.Pt(x, y))}); err != nil {
					t.Fatal(err)
				}
				unitSettle(t, m)
			}
			send(events.MouseDown, 0, 0)
			send(events.MouseUp, 0, 0)
			if fraction != .35 || changes != 0 {
				t.Fatal("focus click changed the accepted split", fraction, changes)
			}
			span := c.handle.Max - c.handle.Min
			beforePane := c.panes[0].Geom.TotalBBox.Dx()
			if orientation == ui.Vertical {
				beforePane = c.panes[0].Geom.TotalBBox.Dy()
			}
			delta := int(span / 5)
			x, y := delta, 0
			if orientation == ui.Vertical {
				x, y = 0, delta
			}
			send(events.MouseDown, 0, 0)
			send(events.MouseMove, x, y)
			send(events.MouseUp, x, y)
			want := float32(.35) + float32(delta)/span
			if math.Abs(float64(fraction-want)) > 1e-6 || changes != 1 {
				t.Fatal("drag jumped from the off-center grip", fraction, want, changes)
			}
			afterPane := c.panes[0].Geom.TotalBBox.Dx()
			if orientation == ui.Vertical {
				afterPane = c.panes[0].Geom.TotalBBox.Dy()
			}
			if math.Abs(float64(afterPane-beforePane-delta)) > 1 {
				t.Fatal("pane movement differs from physical pointer movement", beforePane, afterPane, delta)
			}
		})
	}
}
