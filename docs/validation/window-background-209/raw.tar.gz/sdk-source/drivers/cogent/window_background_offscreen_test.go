//go:build offscreen

package cogent

import (
	"image"
	"image/color"
	"testing"

	"cogentcore.org/core/colors"
	"github.com/dshills/vellum/app"
	"github.com/dshills/vellum/ui"
)

func TestManualWindowBackgroundRestoresNativeFallback(t *testing.T) {
	config := manualConfig(t, 7)
	config.Theme.Default.Background = ui.Some(color.NRGBA{})
	background := ui.Some(color.NRGBA{R: 30, G: 30, B: 32, A: 255})
	m, a := simpleManual(t, config, func() ui.Node {
		return ui.Node{ID: "root", Kind: ui.Column, Grow: true, Style: ui.Style{Background: background}}
	})
	unitSettle(t, m)
	for _, replacement := range []ui.Optional[color.NRGBA]{
		{},
		ui.Some(color.NRGBA{R: 242, G: 242, B: 247, A: 255}),
		ui.Some(color.NRGBA{B: 255, A: 128}),
	} {
		if err := a.Do(func() { background = replacement; a.Invalidate("one") }); err != nil {
			t.Fatal(err)
		}
		unitSettle(t, m)
		im, err := m.Capture(testContext, "one")
		if err != nil {
			t.Fatal(err)
		}
		want := color.NRGBAModel.Convert(colors.Scheme.Surface.At(0, 0)).(color.NRGBA)
		if replacement.Set && replacement.Value.A == 255 {
			want = replacement.Value
		}
		if got := color.NRGBAModel.Convert(im.At(0, 0)).(color.NRGBA); got != want {
			t.Fatal("old root color leaked into native fallback", got, want)
		}
	}
}

func TestManualWindowBackgroundFollowsRootWithoutMovingContent(t *testing.T) {
	config := manualConfig(t, 7)
	base := color.NRGBA{R: 220, G: 222, B: 224, A: 255}
	config.Theme.Default.Background = ui.Some(base)
	colors := []color.NRGBA{{R: 30, G: 30, B: 32, A: 255}, {R: 242, G: 242, B: 247, A: 255}}
	phase := 0
	a, err := app.New(app.Config{})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(a.Close)
	for index, id := range []string{"first", "second"} {
		if err := a.Open(app.Window{ID: id, Title: id, Width: 200, Height: 120, View: func() ui.Node {
			background := ui.Some(colors[(index+phase)%2])
			if phase == 2 {
				if index == 0 {
					background = ui.Some(color.NRGBA{B: 255, A: 128})
				} else {
					background = ui.Style{}.Background
				}
			}
			return ui.Node{ID: "root", Kind: ui.Column, Grow: true, Style: ui.Style{Background: background}}
		}}); err != nil {
			t.Fatal(err)
		}
	}
	m, err := NewManual(testContext, a, config)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = m.Close(testContext) })
	for current := 0; current < 3; current++ {
		if current > 0 {
			if err := a.Do(func() { phase = current; a.Invalidate("first"); a.Invalidate("second") }); err != nil {
				t.Fatal(err)
			}
		}
		unitSettle(t, m)
		for index, id := range []string{"first", "second"} {
			w := m.implementation.find(id)
			bounds := w.state.root.widget.AsWidget().Geom.TotalBBox
			t.Logf("%s phase %d content bounds %v", id, phase, bounds)
			if bounds != image.Rect(8, 8, 192, 112) {
				t.Fatal("background update changed the existing content inset", bounds)
			}
			im, err := m.Capture(testContext, id)
			if err != nil {
				t.Fatal(err)
			}
			want := colors[(index+phase)%2]
			if phase == 2 {
				want = base // Clear or translucent roots use the host theme once.
			}
			for _, p := range []image.Point{{0, 0}, {199, 0}, {0, 119}, {199, 119}} {
				if got := color.NRGBAModel.Convert(im.At(p.X, p.Y)).(color.NRGBA); got != want {
					t.Fatalf("host border ignores %s phase %d palette at %v: got %v want %v", id, phase, p, got, want)
				}
			}
		}
	}
}
