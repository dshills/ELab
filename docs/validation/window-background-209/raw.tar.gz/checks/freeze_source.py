"""Freeze the bounded /209 source and validation record without a GUI launch."""
import gzip
import hashlib
import io
import json
import re
import shutil
import subprocess
import tarfile
from pathlib import Path

root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
out = root / 'docs/validation/window-background-209'
assert (stage/'quality-exit-code.txt').read_text().strip() == '0'
assert (stage/'sdk-quality-complete-exit-code.txt').read_text().strip() == '0'
assert not out.exists()
inputs = json.loads((stage/'source-inputs.json').read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
assert all(sha((root/p).read_bytes()) == digest for p,digest in inputs.items())
assert not (root/'go.sum').exists()
out.mkdir(parents=True)
for name in ['source-inputs.json','preservation.json']:
    shutil.copyfile(stage/name, out/name)
raw = {}
for path in sorted(stage.rglob('*')):
    if path.is_file() and 'build' not in path.relative_to(stage).parts and path.suffix in {'.txt','.json','.py','.png'}:
        raw['checks/'+path.relative_to(stage).as_posix()] = path.read_bytes()
for name in ['desktop/window_background_offscreen_test.go','desktop/go.mod','scripts/check.sh','AGENTS.md']:
    raw['source/'+name] = (root/name).read_bytes()
source = root/'build/vellum-public-e58d405'
for name in ['driver.go','manual_offscreen.go','window_background.go','window_background_offscreen_test.go',
             'split.go','split_grip_offscreen_test.go','split_offscreen_test.go',
             'cmd/gallery/structure_catalogue_offscreen_test.go']:
    raw['sdk-source/drivers/cogent/'+name] = (source/'drivers/cogent'/name).read_bytes()
with (out/'raw.tar.gz').open('xb') as disk:
    with gzip.GzipFile(fileobj=disk, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name,data in sorted(raw.items()):
                info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
                tar.addfile(info,io.BytesIO(data))
(out/'raw-manifest.json').write_text(json.dumps({name:sha(data) for name,data in sorted(raw.items())},indent=2)+'\n')
quality=(stage/'quality.txt').read_text()
times=re.findall(r'ok\s+github.com/dshills/elab/desktop\s+(\d+\.\d+)s',quality)
assert len(times)==2, times
report=dict(kind='window-background-and-divider-grip',source_checks_passed=True,
    release_ready=False,quality_exit_code=0,sdk_quality_exit_code=0,
    source_parent_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    source_inputs=len(inputs),absent_source_inputs=['go.sum'],python_tests=67,
    source_quality_command="GOFLAGS='-p=1' GOPROXY=off PYTHONDONTWRITEBYTECODE=1 ./scripts/check.sh",
    desktop_race_seconds=float(times[0]),mounted_race_seconds=float(times[1]),
    sdk=json.loads((root/'third_party/vellum/sdk.lock.json').read_text()),
    sdk_member_comparison=json.loads((stage/'sdk-member-comparison.json').read_text()),
    sdk_checks=['go test -race ./...','go test -race -tags=offscreen ./...','go vet -tags=offscreen ./...'],
    sdk_check_directory='drivers/cogent in the clean derived Vellum source',
    native_baseline=dict(binary='owned /206 fixture, unchanged old code',
        launch_required=False,dark_white_host_inset_observed=True,
        divider_click_before=.65,divider_click_after=.66611844,divider_restored=.65),
    mounted_checks=dict(background_before_failed_both_themes=True,background_after_passed_both_themes=True,
        four_scene_corners=True,root_bounds_unchanged=True,accepted_snapshot_preserved=True,
        scope='320x180 offscreen root-style probe with schematic children omitted'),
    framework_regressions=dict(independent_window_palettes=True,post_mount_replacement=True,
        configured_and_native_fallback=True,translucency_applied_once=True,
        zero_motion_click_unchanged=True,off_center_grip_preserved=True,
        measured_pane_motion_matches_pointer_delta=True,both_orientations=True),
    native_acceptance='Pending for /207 guidance/file menus, /208 disclosure and /209 backdrop/divider repairs.',
    raw_archive_sha256=sha((out/'raw.tar.gz').read_bytes()),raw_members=len(raw),
    new_components=0,new_commands=0,owner_review_required=False,download_unchanged='0.181.4 /205')
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'README.md').write_text(f'''# Host background and divider grip /209

October 23, 2026. [Receipt](report.json), [source/check inputs](source-inputs.json),
[native baseline and paint probes](../../../research/ui-audit/window-background-209/README.md),
[repair notes](../../../research/86-window-background-and-divider-grip.md).

The already-running owned /206 fixture independently shows a white inset in
Dark and a divider focus click changing 0.65 to 0.66611844. Light and 0.65 are
restored afterward. No graphical application is launched for these checks.

The framework repair synchronizes each host background with its accepted
opaque root surface, preserving the existing inset and native/configured
fallback. Split resizing now applies physical movement relative to its press
position and accepted fraction. A plain focus click submits no resize.

The full framework normal/offscreen race suites and offscreen vet pass. The
complete ELab gate passes lint/staticcheck, 67 Python tests, root and desktop
race/vet, mounted UI race and offscreen vet. Desktop race takes
{times[0]} s; mounted race takes {times[1]} s. Focused root probes check
both palettes, all four corners, unchanged geometry and accepted snapshots.
These are offscreen probes with schematic children omitted, not full native
app screenshots. Framework tests additionally exercise both divider axes and
compare actual pane movement to pointer movement.

The broad framework run also exposed a gallery metric left over from elab7's
shadow-free disclosure action. It reproduces on the unchanged elab7 SDK; the
metric correction retains the exact geometry and enablement assertions.
Earlier failures, the initial fixture compile correction and final passes are
preserved separately in [the raw archive](raw.tar.gz) with
[member hashes](raw-manifest.json). Source snapshots and producers are included;
their original absolute workspace paths require reviewed relocation elsewhere.

The elab8 archive is exported from clean derived source
`{report['sdk']['source_commit']}`. Every member matches its manifest; only the
nine reviewed source/test/provenance members differ from elab7. Dependencies,
notices and all six bootstrap sources remain unchanged. The old archive/cache
and /205 download verify unchanged. The native command ledger is byte-identical:
166 commands, 134 source routes, 404 sites and 76 production Go files.

Fresh native acceptance of this repair and the accumulated /207 guidance/file
menus and /208 disclosure changes remains pending. No candidate is promoted by
this source record. The current download remains /205. Standing launch and
desktop authorization is saved in `AGENTS.md`; no further owner review is
required and no new launch approval prompt is left waiting.
''')
notes=root/'research/86-window-background-and-divider-grip.md'
text=notes.read_text(); marker='## Current work and next steps'
assert marker in text
notes.write_text(text.partition(marker)[0]+f'''## Validated dependency and application source

The private framework source is committed cleanly at
`{report['sdk']['source_commit']}`. ELab's active elab8 pin includes the
complete patch against the same public e58d405 base. All 8,428 SDK members are
verified; the nine changed members contain only the reviewed implementation,
regressions, gallery correction and generated provenance note. Dependencies,
notices and all six bootstrap sources are byte-identical. Previous archives
and caches remain preserved and verified.

The [full source gate passes](../docs/validation/window-background-209/README.md):
lint/staticcheck, 67 Python tests, complete root/desktop race and vet, required
mounted UI race and offscreen vet. Desktop race takes {times[0]} s and mounted
race {times[1]} s. The full framework normal/offscreen race suites and offscreen
vet pass as well. ELab's Light/Dark root probes pass after failing with elab7;
accepted service state and the exact existing content inset are preserved.
The native command ledger remains byte-identical with 166 public commands.

Fresh native acceptance of the accumulated /207 guidance/file editing, /208
disclosure and /209 background/grip changes remains separate. The existing
owned /206 session remains available; no unattended fresh-launch prompt is
queued and no further owner permission or review is requested. Preserve the
qualified /205 download until those changed native paths pass. No component,
model, command or format is added by this work.
''')
manifest={p.relative_to(out).as_posix():sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file()}
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['source_checks_passed','source_inputs','desktop_race_seconds','mounted_race_seconds','raw_members']}))
