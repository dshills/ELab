from pathlib import Path
import hashlib, json, math
stage=Path(__file__).resolve().parent
def read(n): return json.loads((stage/(n+'.json')).read_text())
for a,b in [('pot-220-wheel-baseline','pot-220-wheel-unfocused'),('pot-220-wheel-baseline','pot-220-slider-focused'),('pot-220-wheel-baseline','pot-220-wheel-focused'),('rc-220-number-baseline','rc-220-number-unfocused'),('rc-220-number-baseline','rc-220-number-focused-private'),('rc-220-recorded-wheel-baseline','rc-220-recorded-wheel-unfocused'),('rc-220-recorded-wheel-baseline','rc-220-recorded-wheel-private')]:
 assert read(a)==read(b),(a,b)
def pot(name): return next(x for x in read(name)['components'] if x['id']=='Timing')['wiper_position']
assert pot('pot-220-arrow')==.51
assert .51<pot('pot-220-drag')<1
assert pot('pot-220-undo-drag')==.51 and pot('pot-220-undo-arrow')==.5
for name in ['pot-220-arrow','pot-220-drag']:
 s=read(name); assert s['last_actor']=='user' and s['undo_entry']['name']=='Adjust wiper'
 assert s['transient']['sample']['time_s']==0
s=read('rc-220-number-committed'); assert s['transient_settings']['initial_voltage_v']==.25
b=read('rc-220-verify-before'); c=read('rc-220-verify-completed')
assert c['transient']==b['transient'] and c['components']==b['components'] and c['wires']==b['wires']
op=c['operations'][0]; assert op['status']=='completed' and op['completed_steps']==op['total_steps']==1000
b=read('rc-220-verify-above-before'); c=read('rc-220-verify-above-refused')
assert [k for k in b if b[k]!=c[k]]==['viewport','command_revision','revision']
rows=read('native-recording-rows'); assert len(rows)==1001 and rows==read('native-recording-reopened-rows')
errors=[]
for i,row in enumerate(rows):
 assert row['time_s']==min(float(i)*1e-6,.001)
 wanted=[5*-math.expm1(-row['time_s']/.01),5]
 for actual,target in zip(row['values'],wanted,strict=True):
  errors.append(abs(actual-target)); assert math.isclose(actual,target,rel_tol=1e-12,abs_tol=1e-12)
end=read('rc-220-final-state'); assert not end['document']['dirty'] and end['paused'] and end['transient']['sample']['time_s']==0
prepared=read('prepared-update'); native=Path(prepared['installed'])/'Contents/MacOS/ELab Cursor Recovery'
assert hashlib.sha256(native.read_bytes()).hexdigest()==prepared['native_sha256']
result=dict(passed=True,exact_snapshot_pairs=7,native_verify_intervals=1000,captured_rows=1001,independent_voltage_checks=len(errors),maximum_absolute_voltage_error=max(errors),over_limit_preserved_all_state_except=['viewport','command_revision','revision'],final_document_clean=True,final_live_paused_at_zero=True,installed_native_hash_unchanged=True)
(stage/'checks.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result))
