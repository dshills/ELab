from pathlib import Path
import importlib.util, json, math
root=Path('/Users/dshills/Development/projects/ELab'); stage=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('client',root/'scripts/persistence-demo.py'); h=importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
c=h.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json',command_preconditions=True,agent_binary=root/'build/ELab-0.181.19-220-candidate/elab-agent')
def save(name,value):
 p=stage/name; assert not p.exists(); p.write_text(json.dumps(value,indent=2)+'\n')
def samples(identifier):
 rows=[]; offset=0
 while True:
  page=c.ask('operation.samples',{'id':identifier,'offset':offset,'limit':200}); rows.extend(page['rows'])
  if len(rows)==page['total']: break
  assert page['next_offset']>offset; offset=page['next_offset']
 return rows
try:
 before=c.ask('project.inspect'); save('recording-persistence-before.json',before)
 rows=samples('verify-1'); save('native-recording-rows.json',rows)
 print('row keys',list(rows[0]))
 meta=c.ask('operation.inspect',{'id':'verify-1'}); save('native-recording-operation.json',meta)
 assert len(rows)==1001
 output=stage/'RC native 220.elab'; assert not output.exists()
 saved=c.ask('project.save',{'path':str(output)},True); save('recording-save.json',saved)
 loaded=c.ask('project.load',{'path':str(output)},True); save('recording-reopen.json',loaded)
 assert not loaded['document']['dirty'] and loaded['components']==before['components'] and loaded['wires']==before['wires']
 identifier=loaded['selected_operation']; reopened=samples(identifier); save('native-recording-reopened-rows.json',reopened); assert rows==reopened
 save('recording-persistence-report.json',{'passed':True,'rows':len(rows),'exact_rows_preserved':True,'reopened_operation':identifier,'path':str(output),'native_dialog_save_qualified':False})
 print('Saved and reopened exact',len(rows),'native-recorded rows; disposable document clean')
finally: c.close()
