"""Prepare an ordinary update of the existing isolated test installation.

Does not stop, replace or launch the running app. Keeps its identifier, name,
launcher and sandbox policy, while replacing only the qualified application code.
"""
from pathlib import Path
import hashlib, json, os, plistlib, shutil, struct, subprocess, sys
root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
installed = Path('/private/tmp/elab-cursor-guidance-206/ELab Cursor Recovery.app')
prepared = Path('/private/tmp/elab-cursor-guidance-206/.update-221/ELab Cursor Recovery.app')
build = json.loads((root/'build/footer-layout-221-tools/build-result-signed.json').read_text())
raw = root/'build/footer-layout-221-tools/build/elab'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(raw) == build['source_native_sha256']
assert not prepared.exists()
info = plistlib.loads((installed/'Contents/Info.plist').read_bytes())
assert info['CFBundleIdentifier'] == 'com.dshills.elab.cursor-guidance206'
assert info['CFBundleExecutable'] == 'Launcher'
launcher = (installed/'Contents/MacOS/Launcher').read_bytes()
policy = Path('/private/tmp/elab-cursor-guidance-206/runtime.sb')
policy_sha = sha(policy)
old_binary = installed/'Contents/MacOS/ELab Cursor Recovery'
assert sha(old_binary) == 'a7c1d90759d85af4011b0c7984053f96866f40897c6efbe7dc49adfac25e110c'
sys.path.insert(0, str(root/'scripts'))
from runtime_isolation import pinned_child_runner, bundle_tree
sdk, run_child = pinned_child_runner()
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', GOPROXY='off', GOTOOLCHAIN='local')
with (stage/'prepare-package.txt').open('x') as log:
    run_child([sys.executable, '-B', str(sdk/'scripts/package-app.py'), '--binary', str(raw),
               '--output', str(prepared), '--name', info['CFBundleName'], '--identifier', info['CFBundleIdentifier'],
               '--version', build['version'], '--build-version', build['build'], '--sign-identity', '-'],
              cwd=root, env=env, stdout=log, stderr=-2, timeout=90, check=True)
new_info = plistlib.loads((prepared/'Contents/Info.plist').read_bytes())
native_name = new_info['CFBundleExecutable']
assert native_name == 'ELab Cursor Recovery'
new_info['CFBundleExecutable'] = 'Launcher'
(prepared/'Contents/Info.plist').write_bytes(plistlib.dumps(new_info))
(prepared/'Contents/MacOS/Launcher').write_bytes(launcher)
(prepared/'Contents/MacOS/Launcher').chmod(0o755)
with (stage/'signature-prepared.txt').open('x') as log:
    subprocess.run(['/usr/bin/codesign', '--force', '--deep', '--sign', '-', str(prepared)], check=True, stdout=log, stderr=-2)
    subprocess.run(['/usr/bin/codesign', '--verify', '--deep', '--strict', '--verbose=2', str(prepared)], check=True, stdout=log, stderr=-2)

def sections(path):
    data = path.read_bytes()
    assert struct.unpack_from('<I', data)[0] == 0xfeedfacf
    ncmds = struct.unpack_from('<I', data, 16)[0]
    offset, result = 32, {}
    for _ in range(ncmds):
        cmd, size = struct.unpack_from('<II', data, offset)
        if cmd == 0x19:
            for i in range(struct.unpack_from('<I', data, offset+64)[0]):
                at = offset+72+80*i
                name = data[at:at+16].split(b'\0')[0].decode()
                segment = data[at+16:at+32].split(b'\0')[0].decode()
                length = struct.unpack_from('<Q', data, at+40)[0]
                start = struct.unpack_from('<I', data, at+48)[0]
                if start and length:
                    assert start+length <= len(data)
                    result[segment+'/'+name] = dict(bytes=length, sha256=hashlib.sha256(data[start:start+length]).hexdigest())
        offset += size
    assert '__TEXT/__text' in result and result
    return result

candidate = Path(build['review'])/'ELab.app/Contents/MacOS/ELab'
new_native = prepared/'Contents/MacOS'/native_name
assert sections(raw) == sections(candidate) == sections(new_native)
version = subprocess.check_output(['go', 'version', '-m', str(new_native)], text=True)
assert 'vcs.revision='+build['source_commit'] in version and 'vcs.modified=false' in version
(stage/'prepared-build-info.txt').write_text(version)
assert sha(policy) == policy_sha
assert (prepared/'Contents/MacOS/Launcher').read_bytes() == launcher
report = dict(prepared=str(prepared), installed=str(installed), version=build['version'], build=build['build'],
              source_commit=build['source_commit'], native_sha256=sha(new_native),
              candidate_native_sha256=build['native_sha256'], mach_o_sections=sections(new_native),
              code_sections_match_qualified_candidate=True, clean_build_vcs=True,
              bundle_identifier=new_info['CFBundleIdentifier'], identity_unchanged=True,
              launcher_unchanged=True, sandbox_policy_sha256=policy_sha, sandbox_policy_unchanged=True,
              strict_ad_hoc_signature_valid=True, original_installed_bundle=bundle_tree(installed),
              prepared_bundle=bundle_tree(prepared), running_app_replaced=False, app_launched=False,
              scope='Prepared code-equivalent update of the existing owned test installation, with identical identity/launcher/sandbox. Metadata/resource sealing differs from the original candidate; exact candidate bytes stay untouched.')
(stage/'prepared-update.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({k: report[k] for k in ['prepared', 'version', 'build', 'source_commit', 'native_sha256', 'identity_unchanged', 'code_sections_match_qualified_candidate', 'running_app_replaced', 'app_launched']}))
