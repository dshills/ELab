from pathlib import Path
import json
from PIL import Image
stage=Path(__file__).resolve().parent
points=[(4,400),(1049,400),(524,798),(800,785),(20,200),(500,496)]
results={}
for name in ['native-long-light.png','native-long-dark.png','native-long-light-restored.png']:
 im=Image.open(stage/name).convert('RGBA'); values=[im.getpixel(point) for point in points]
 assert im.size==(1053,802)
 assert all(values[i]==values[3] for i in [0,1,2,5]),'outer inset differs from captured root surface'
 results[name]=dict(size=list(im.size),points=[list(x) for x in points],rgba=[list(x) for x in values])
assert results['native-long-light.png']['rgba']==results['native-long-light-restored.png']['rgba']
assert results['native-long-dark.png']['rgba']!=results['native-long-light.png']['rgba']
report=dict(passed=True,method='Compare inset pixels with root surface pixels in the same color-managed native capture; do not compare screenshot RGB with unconverted source constants',observations=results)
(stage/'native-inset-pixels.json').write_text(json.dumps(report,indent=2)+'\n')
print('Native Light/Dark inset matches the root surface; restoring Light restores all sampled colors')
