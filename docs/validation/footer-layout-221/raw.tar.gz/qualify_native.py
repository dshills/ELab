from pathlib import Path
import hashlib,importlib.util,json,math,subprocess,sys
root=Path('/Users/dshills/Development/projects/ELab'); stage=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('client',root/'scripts/persistence-demo.py'); h=importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
c=h.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json',command_preconditions=True,agent_binary=root/'build/ELab-0.181.20-221-candidate/elab-agent')
try:
 state=c.ask('project.inspect'); rows=[]; offset=0
 while True:
  page=c.ask('operation.samples',{'id':state['selected_operation'],'offset':offset,'limit':200}); rows.extend(page['rows'])
  if len(rows)==page['total']: break
  offset=page['next_offset']
 (stage/'native-captured-rows.json').write_text(json.dumps(rows,indent=2)+'\n')
 prior=json.loads((root/'build/native-acceptance-220-tools/native-recording-rows.json').read_text()); assert rows==prior and len(rows)==1001
 errors=[]
 for row in rows:
  for actual,target in zip(row['values'],[5*-math.expm1(-row['time_s']/.01),5],strict=True):
   errors.append(abs(actual-target)); assert math.isclose(actual,target,rel_tol=1e-12,abs_tol=1e-12)
 dark=json.loads((stage/'native-dark-state.json').read_text()); light=json.loads((stage/'native-light-restored-state.json').read_text())
 assert set(k for k in dark if dark[k]!=light[k])=={'theme','command_revision','revision'}
 assert dark['theme']=='dark' and light['theme']=='light'
 original=json.loads((stage/'preserved-project.json').read_text()); assert hashlib.sha256(Path(original['path']).read_bytes()).hexdigest()==original['sha256']
 final=c.ask('project.load',{'path':original['path']},True); assert final['components']==state['components'] and final['wires']==state['wires']
 assert not final['document']['dirty'] and final['paused'] and final['theme']=='light'
 (stage/'native-final-state.json').write_text(json.dumps(final,indent=2)+'\n')
 installed=json.loads((stage/'prepared-update.json').read_text()); app=Path(installed['installed']); assert hashlib.sha256((app/'Contents/MacOS/ELab Cursor Recovery').read_bytes()).hexdigest()==installed['native_sha256']
 with (stage/'signature-after-native.txt').open('x') as log:subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict','--verbose=2',str(app)],stdout=log,stderr=-2,check=True)
 sys.path.insert(0,str(root/'scripts')); from runtime_isolation import bundle_tree
 build=json.loads((stage/'build-result-signed.json').read_text()); assert bundle_tree(Path(build['review'])/'ELab.app')==build['source_bundle']
 assert hashlib.sha256((root/'build/releases/ELab-0.181.4-macos-arm64.zip').read_bytes()).hexdigest()=='d13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
 inputs=json.loads((stage/'source-inputs.json').read_text()); assert len(inputs)==891 and all(hashlib.sha256((root/k).read_bytes()).hexdigest()==v for k,v in inputs.items())
 result=dict(passed=True,normal_cua_launch=True,no_new_owner_permission_question=True,unchanged_test_identity_and_sandbox=True,original_candidate_bundle_unchanged=True,preserved_205_zip_unchanged=True,stored_rows_exact_to_220=1001,independent_voltage_checks=len(errors),maximum_absolute_error_v=max(errors),theme_switch_preserves_all_state_except=['theme','command_revision','revision'],original_saved_project_unchanged=True,final_document_clean=True,final_live_paused_at_zero=True,final_theme='light',strict_installed_signature_valid=True,source_inputs_match=891,exact_original_candidate_bundle_launched=False)
 (stage/'native-report.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result))
finally:c.close()
