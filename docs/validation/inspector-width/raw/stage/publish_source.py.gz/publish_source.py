from pathlib import Path
import gzip,hashlib,json,shutil,subprocess
ROOT=Path('/Users/dshills/Development/projects/ELab');STAGE=ROOT/'build/inspector-width-work';PROOF=ROOT/'docs/validation/inspector-width'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,data):path.write_text(json.dumps(data,indent=2)+'\n')
quality=json.loads((STAGE/'full-quality.json').read_text());assert quality['exit_code']==0 and quality['sources_unchanged'] and quality['source_files']==662
assert all(sha(ROOT/p)==h for p,h in quality['source_sha256'].items())
assert not PROOF.exists();PROOF.mkdir()
for name in ('view.go','layout.go','rail_labels_smoke.go','inspector_width_offscreen_test.go'):
 shutil.copyfile(ROOT/'desktop'/name,STAGE/(name.removesuffix('.go')+'-final.go.txt'))
(STAGE/'rail_labels_smoke-original.go.txt').write_bytes(subprocess.check_output(['git','show','HEAD:desktop/rail_labels_smoke.go'],cwd=ROOT))
shutil.copyfile(ROOT/'scripts/check.sh',STAGE/'check-final.sh.txt')
(STAGE/'check-original.sh.txt').write_bytes(subprocess.check_output(['git','show','HEAD:scripts/check.sh'],cwd=ROOT))
manifest={};dest=PROOF/'raw/stage';dest.mkdir(parents=True)
for p in sorted(STAGE.iterdir()):
 if not p.is_file():continue
 data=p.read_bytes();stored=gzip.compress(data,mtime=0);q=dest/(p.name+'.gz');q.write_bytes(stored)
 manifest[str(q.relative_to(PROOF))]=dict(original_bytes=len(data),original_sha256=hashlib.sha256(data).hexdigest(),stored_sha256=sha(q))
shutil.copyfile(STAGE/'verify.py.txt',PROOF/'verify.py')
shutil.copyfile(STAGE/'README.md.txt',PROOF/'README.md')
write(PROOF/'manifest.json',manifest)
previous=ROOT/'research/ui-audit/first-version/recorded-dc-review-checkpoint.json'
report=dict(date='2026-10-19',issue='UI-INSPECTOR-WIDTH-01',severity='P2 readability',source_parent_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),source_qualified=True,replacement_packaging_pending=True,new_release=False,native_fix_qualified=False,original_subcase_failures=6,fixed_subcases=6,examples=['rc','nmos','pmos','cmos'],repaint_passes_per_example=2,available_label_frame_px=236,constrained_rail_widths=[152,248],application_sources=659,tool_sources=3,quality_elapsed_seconds=quality['elapsed_seconds'],prior_receipt_sha256=sha(previous),solver_changed=False,commands_changed=False,sdk_changed=False,owner_acceptance=False,full_mvp_complete=False,scope='Mounted production circuit groups and native geometry smoke source; corrected native binary still requires copied runtime qualification',fixture_history=['Initial manual theme missing explicit background/font failed before meaningful rendering','Group minimum alone corrected outer width but left inner text frames narrow','Initial natural-text-width threshold was too strict for short shaped lines; final regression checks frame allocation and containment instead'])
write(PROOF/'report.json',report)
print(dict(passed=True,files=len(manifest),quality_seconds=quality['elapsed_seconds']))
write(PROOF/'checkpoint.json',dict(files={str(p.relative_to(PROOF)):sha(p) for p in sorted(PROOF.rglob('*')) if p.is_file() and p.name!='checkpoint.json'}))
