"""Freeze captured-measurement entry and ownership checks."""
import gzip, hashlib, io, json, re, shutil, subprocess, tarfile
from pathlib import Path

root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
out=root/'docs/validation/statistics-entry-214';sha=lambda b:hashlib.sha256(b).hexdigest()
assert (stage/'quality-exit-code.txt').read_text().strip()=='0' and not out.exists()
inputs=json.loads((stage/'source-inputs.json').read_text())
assert len(inputs)==883 and all(sha((root/p).read_bytes())==h for p,h in inputs.items())
assert not (root/'go.sum').exists()
quality=(stage/'quality.txt').read_text();times=re.findall(r'ok\s+github.com/dshills/elab/desktop\s+(\d+\.\d+)s',quality)
assert len(times)==2,times
baseline=(stage/'mounted-before-all.txt').read_text()
assert baseline.count('disappeared before correction')==3 and 'old private measurement entry followed the newly selected channel 4 ms' in baseline
assert 'ok ' in (stage/'desktop-final-reviewed.txt').read_text()
native=json.loads((stage/'native-baseline-report.json').read_text())
assert native['measurements_restored_off'] and set(native['full_snapshot_changed_keys'])=={'revision','command_revision'}
assert native['negative_start_text_replaced_by_accepted_value'] and native['baseline_correction_succeeded']
native_dir=root/'research/ui-audit/statistics-entry-214'
assert all(sha((native_dir/p).read_bytes())==h for p,h in native['evidence_files'].items())
previous=root/'docs/validation/analysis-field-context-213'
lock=json.loads((root/'third_party/vellum/sdk.lock.json').read_text())
assert lock==json.loads((previous/'report.json').read_text())['sdk_unchanged']
assert sha((root/lock['archive']).read_bytes())==lock['sha256']
download=root/'build/releases/ELab-0.181.4-macos-arm64.zip'
assert sha(download.read_bytes())=='d13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
old=json.loads((previous/'source-inputs.json').read_text());changed=[p for p,h in inputs.items() if old.get(p)!=h]
assert not any(p.startswith('workbench/') for p in changed)
files={'checks/'+p.name:p.read_bytes() for p in sorted(stage.iterdir()) if p.is_file() and p.suffix in {'.py','.json','.txt'}}
absent=[]
for name in changed:
    files['source/'+name]=(root/name).read_bytes()
    if name in old:files['source-before/'+name]=subprocess.check_output(['git','show',base+':'+name],cwd=root)
    else:absent.append(name)
files['source-before/absent.json']=(json.dumps(absent,indent=2)+'\n').encode()
out.mkdir(parents=True);shutil.copyfile(stage/'source-inputs.json',out/'source-inputs.json')
with (out/'raw.tar.gz').open('xb') as disk:
    with gzip.GzipFile(fileobj=disk,mode='wb',filename='',mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for name,data in sorted(files.items()):
                info=tarfile.TarInfo(name);info.size,info.mode,info.mtime=len(data),0o644,0
                tar.addfile(info,io.BytesIO(data))
(out/'raw-manifest.json').write_text(json.dumps({p:sha(b) for p,b in sorted(files.items())},indent=2)+'\n')
report=dict(kind='captured-statistics-entry-recovery',source_checks_passed=True,quality_exit_code=0,
    source_parent_commit=base,source_inputs=len(inputs),changed_source_inputs=changed,absent_source_inputs=['go.sum'],
    desktop_race_seconds=float(times[0]),mounted_race_seconds=float(times[1]),python_tests=67,
    mounted_focused_seconds=2.563,final_focused_seconds=4.360,mounted_baseline_failures=4,
    stale_callback_cases=5,owner_pruning_cases=6,rejected_peer_preserved=True,
    backend_source_unchanged=True,inventory_comparison=json.loads((stage/'inventory-comparison.json').read_text()),
    sdk_unchanged=lock,preserved_download_sha256=sha(download.read_bytes()),old_native_baseline=native,
    native_app_launched=False,native_acceptance_passed=False,release_ready=False,published=False,
    owner_review_required=False,new_commands=0,new_components=0,new_formats=0,download_unchanged='0.181.4 /205',
    raw_archive_sha256=sha((out/'raw.tar.gz').read_bytes()),raw_members=len(files))
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'README.md').write_text(f'''# Captured measurement entries /214

October 23, 2026. [Receipt](report.json), [source inputs](source-inputs.json),
[repair notes](../../../research/91-statistics-entry-recovery.md).

The mounted baseline loses three rejected time entries and lets an old private
start follow an agent's channel selection. The existing [native /206 baseline](../../../research/ui-audit/statistics-entry-214/README.md)
also replaces `-1 ms` with `0 s`; re-entering `0 s` succeeds there. No stuck
native correction is claimed. Its restored full snapshot differs only in
revision counters. The owned app remains open; no graphical app was launched.

Rejected measurement endpoints now retain their own text, accepted endpoint,
capture/channel and document owner. Ordinary invalid and uncovered-time entries
are correctable; one correction preserves its unchanged rejected peer. A note
identifies last accepted results. Private widget state is scoped to the measured
channel. Stale callbacks cannot install new entries after agent work.

Four mounted repairs pass in 2.563 s. Final focused race checks pass in 4.360 s,
including five stale callbacks, six pruning cases, peer preservation and existing
shared-command equality. A success-only helper initially rejected the tests'
deliberately invalid input; that harness error is preserved and corrected without
relaxing application validation. [Raw checks and producers](raw.tar.gz),
[member hashes](raw-manifest.json), and native captures retain the failures.

The complete gate passes lint/staticcheck, 67 Python tests, root/desktop race and
vet, mounted race and offscreen vet. Desktop race takes {times[0]} s; mounted
race {times[1]} s. All {len(inputs)} source/check inputs match. Inventory retains
166 commands, 134 routes and 404 sites; one existing ingress moves to the owned
entry helper and native sources become 78. Backend source, SDK and /205 remain
unchanged. Fresh native acceptance of the changed candidate remains separate;
no unattended launch prompt or owner review is requested.
''')
notes=root/'research/91-statistics-entry-recovery.md'
text=notes.read_text().replace('The complete quality gate is running.',f'The [complete quality gate passes](../docs/validation/statistics-entry-214/README.md):\nlint/staticcheck, 67 Python tests, root/desktop race and vet, mounted race and\noffscreen vet. Desktop race takes {times[0]} s; mounted race {times[1]} s. All\n{len(inputs)} source/check inputs remain exact.')
notes.write_text(text)
manifest={p.relative_to(out).as_posix():sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file()}
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['source_checks_passed','source_inputs','desktop_race_seconds','mounted_race_seconds','raw_members']}))
