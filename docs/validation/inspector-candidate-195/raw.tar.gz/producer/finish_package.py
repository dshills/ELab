from pathlib import Path
import hashlib,importlib.util,json,shlex,shutil,stat,subprocess,sys,zipfile
R=Path('/Users/dshills/Development/projects/ELab');S=Path(__file__).resolve().parent;N=Path('/private/tmp/elab-native-195');O=Path('/private/tmp/elab-candidate-195-archive');O.mkdir(mode=0o700)
sys.path.insert(0,str(R/'scripts'));from package_review import members,verify_archive
b=json.loads((S/'build-result-signed.json').read_text());p=Path(b['review']);sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
assert json.loads((N/'session.json').read_text())['status']=='closed';native=json.loads((N/'repair-acceptance-report.json').read_text());assert native['inspector_transition_verified']
workflows=json.loads((N/'workflows/report.json').read_text());assert workflows['status']=='passed'
quality=json.loads((R/'docs/validation/inspector-scroll-ownership/report.json').read_text());assert quality['quality_exit_code']==0
sources=json.loads((S/'quality-inputs.json').read_text())['go_sources'];assert len(sources)==671 and all(sha(R/n)==v for n,v in sources.items())
assert sha(p/'ELab.app/Contents/MacOS/ELab')==b['native_sha256'] and sha(p/'elab-agent')==b['agent_sha256']
shutil.copytree(R/'build/ELab-0.176.0-193-candidate/Examples',p/'Examples')
sdk=R/'build/.vellum-sdk-e58d405-elab1';licenses=p/'Licenses/Vellum';licenses.mkdir(parents=True)
for name in ['LICENSE','PRIVATE_BUILD.txt','THIRD_PARTY_INVENTORY.json']:shutil.copyfile(sdk/name,licenses/name)
shutil.copytree(sdk/'THIRD_PARTY_NOTICES',licenses/'THIRD_PARTY_NOTICES')
(p/'README.md').write_text('''# ELab 0.178.0 /195 — private review candidate

Open ELab.app to try the app locally. The matching elab-agent, three editable
paused Examples and current Vellum dependency notices are included. Save As
preserves original examples and owner projects.

This build repairs a blank inspector when replacing a deeply scrolled recording
with a shorter document. Targeted native input corrections passed on /194; the
/195 inspector transition, source checks and paired native/agent LED, RC and
flasher regressions are documented separately. Public command identities remain
the same for users and agents. Start agent discovery with capabilities.list.

Review the four core tasks: draw/edit an LED loop; charge/discharge an RC circuit;
measure the flasher; save/reopen/export. Full physical workflow/layout acceptance
and owner first-use feedback remain open. /189 is preserved and this build is
not a promoted replacement. Keep your original projects.

Educational generic models; not general SPICE compatibility or PCB design.
Local ad-hoc signature; not notarized. Clean-account/default-startup acceptance
was deferred only for this private alpha. Broader accessibility, IME, environments,
performance, distribution and hobbyist study remain outside this acceptance.
''')
(p/'ROLLBACK.md').write_text('''Save your project and quit the candidate before switching binaries. The existing
ELab-0.172.0-189-alpha package and earlier candidates are preserved separately.
No installation or owner package replacement was performed. Open a separate
copy of your project for review. This candidate uses format version 4; keep the
original file and use Save As when testing. Do not run two apps against one file.
''')
status=dict(kind='inspector-repair-review-candidate',version=b['version'],build=b['build'],source_commit=b['source_commit'],native_sha256=b['native_sha256'],agent_sha256=b['agent_sha256'],source_quality_passed=True,go_source_inputs=671,native_inspector_transition_verified=True,public_reference_workflows_matched=True,targeted_input_evidence_predecessor='0.177.0 /194; separate exact-byte evidence',full_native_workflows_accepted=False,owner_walkthrough_accepted=False,ready_for_owner_testing=True,release_qualified=False,promoted=False,preserved_owner_alpha='0.172.0 /189')
(p/'CANDIDATE_STATUS.json').write_text(json.dumps(status,indent=2)+'\n');(p/'CANDIDATE_MANIFEST.json').write_text(json.dumps(dict(kind=status['kind'],release_qualified=False,files=members(p)),indent=2)+'\n');expected=members(p)
archive=p.parent/(p.name+'.zip');assert not archive.exists()
with archive.open('xb') as f:
 archive.chmod(0o600)
 with zipfile.ZipFile(f,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,v in expected.items():
   e=zipfile.ZipInfo(p.name+'/'+name,date_time=(1980,1,1,0,0,0));e.create_system=3;e.external_attr=(stat.S_IFREG|int(v['mode'],8))<<16;e.compress_type=zipfile.ZIP_DEFLATED;z.writestr(e,(p/name).read_bytes(),compresslevel=9)
verify_archive(archive,p.name,expected);extract=O/'Extracted candidate µ with spaces';r=subprocess.run(['/usr/bin/ditto','-x','-k',str(archive),str(extract)],capture_output=True,timeout=120);(O/'ditto.txt').write_bytes(r.stdout+r.stderr);r.check_returncode();extracted=extract/p.name;assert members(extracted)==expected==members(p)
r=subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict','--verbose=2',str(extracted/'ELab.app')],capture_output=True,timeout=30);(O/'signature.txt').write_bytes(r.stdout+r.stderr);r.check_returncode()
wrapper=O/'agent';wrapper.write_text('#!/bin/sh\nexec /usr/bin/sandbox-exec -f '+shlex.quote('/private/tmp/elab-native-195-runtime/runtime.sb')+' '+shlex.quote(str(extracted/'elab-agent'))+' "$@"\n');wrapper.chmod(0o755)
spec=importlib.util.spec_from_file_location('package195',R/'scripts/persistence-demo.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);examples=[]
for file in sorted((extracted/'Examples').glob('*.elab')):
 c=m.Client(command_preconditions=True,agent_binary=wrapper)
 try:
  saved=json.loads(file.read_text());c.ask('project.load',{'path':str(file)},True);state=c.ask('simulation.wait');assert not state['document']['dirty'] and state['paused'] and state['components']==saved['graph']['components'] and state['wires']==saved['graph']['wires']
  job=c.ask('app.close',{'discard_changes':False},True)['shutdown'];job=c.wait_for_shutdown_outcome(job);assert job['status']=='completed' and all(job[k] for k in ('workers_joined','recovery_finalized','exit_ready'));examples.append(dict(file=file.name,sha256=sha(file),graph_preserved=True,paused_and_clean=True,shutdown=job))
 finally:c.close()
assert len(examples)==3 and members(extracted)==expected==members(p)
protected=json.loads((S/'preservation-before.json').read_text());assert all(sha(R/n)==v for n,v in protected.items());prior=json.loads((S/'prior-candidates-before.json').read_text());assert all(members(R/'build'/n)==v for n,v in prior.items())
report=dict(passed=True,source_commit=b['source_commit'],candidate=str(p),archive=str(archive),archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,verified_files=len(expected),strict_extracted_signature_valid=True,extracted_bytes_and_modes_match=True,examples=examples,current_sdk_notices_included=True,source_hashes_match_671=True,protected_files_preserved=protected,prior_candidate_trees_preserved=list(prior),ready_for_owner_testing=True,release_qualified=False,promoted=False,limits=['No extracted native startup, installation/quarantine/notarization/clean-account acceptance','Physical four-workflow and complete layout/owner acceptance remain open'])
(O/'report.json').write_text(json.dumps(report,indent=2)+'\n');archive.with_suffix('.zip.sha256').write_text(sha(archive)+'  '+archive.name+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['protected_files_preserved','examples']},indent=2))
