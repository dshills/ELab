from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys,xml.etree.ElementTree as ET
R=Path('/Users/dshills/Development/projects/ELab');O=Path('/private/tmp/elab-native-195');RUN=Path('/private/tmp/elab-native-195-runtime');sys.path.insert(0,str(R/'scripts'))
spec=importlib.util.spec_from_file_location('nativefinish195',R/'scripts/first-version-parity.py');ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref);Client=ref.helper.Client
receipt=json.loads((O/'session.json').read_text());assert subprocess.check_output(['/bin/ps','-p',str(receipt['owned_pid']),'-o','command='],text=True).strip()==receipt['observed_command']
c=Client(str(O/'endpoint.json'),command_preconditions=True,agent_binary=RUN/'agent')
try:
 state=c.ask('simulation.wait');assert state['document']['path']==str(O/'LED UI.elab') and not state['document']['dirty'];assert next(x['value'] for x in state['components'] if x['id']=='R1')==2000
 assert .00147<state['result']['current_a']<.00148
 (O/'native-final.json').write_text(json.dumps(state,indent=2)+'\n')
finally:c.close()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();saved=O/'LED UI.elab';before=sha(saved)
head=Client(command_preconditions=True,agent_binary=RUN/'agent')
try:
 head.ask('project.load',{'path':str(saved)},True);restored=head.ask('simulation.wait');assert restored['components']==state['components'] and restored['wires']==state['wires'];ref.compare(restored['result'],state['result']);assert not restored['document']['dirty']
 job=head.ask('app.close',{'discard_changes':False},True)['shutdown'];job=head.wait_for_shutdown_outcome(job);assert job['status']=='completed' and all(job[k] for k in ('workers_joined','recovery_finalized','exit_ready'))
finally:head.close()
assert sha(saved)==before and sha(O/'npn-fixture.elab')==sha(Path('/private/tmp/elab-native-check-193-prepared/npn-fixture.elab'))
svg=O/'LED schematic.svg';root=ET.fromstring(svg.read_bytes());texts=[x.text for x in root.iter('{http://www.w3.org/2000/svg}text')];assert all(any(expected in (t or '') for t in texts) for expected in ['V1','R1 · 2 kΩ','D1','GND'])
assert 'node:c2lkZWJhci02' in (O/'led-replaced.ax.txt').read_text();assert 'Value: 2 kΩ' in (O/'unsaved-canceled.ax.txt').read_text();assert '1.477 mA' in (O/'led-native-reopened.ax.txt').read_text()
report=dict(status='targeted_native_repair_passed',source_commit=receipt['source_commit'],native_sha256=receipt['native_sha256'],agent_sha256=receipt['agent_sha256'],inspector_transition_verified=True,inspector_visual_evidence=['long-inspector-keyboard-revealed.jpg','led-inspector-restored.jpg','led-dark.jpg'],method='CUA keyboard/accessibility focus revealed long recording timing section; native Examples menu replaced it; screenshots show new inspector at top. Initial wheel/AX focus attempts retained.',led_native_edit_undo_redo=True,displayed_current_ma_sequence=[2.917,1.477,2.917,1.477],native_save_chooser_cancel_and_unsaved_cancel_preserve_edit=True,native_save_and_open_dialogs_verified=True,saved_project=dict(path=str(saved),sha256=before,graph_and_result_match_exact_packaged_agent=True),native_svg_export=dict(path=str(svg),sha256=sha(svg),bytes=svg.stat().st_size,component_labels_complete=True),original_npn_fixture_file_unchanged=True,themes_observed=['Light','Dark'],capture_size=[1053,802],counterpart_shutdown=job,release_qualified=False,promoted=False,limitations=['Not physical drawing/wiring from blank or complete RC/flasher interaction walkthrough','No all-controls/minimum-height/second-working-size layout acceptance','No new latency, clean-account, distribution, accessibility/IME or owner acceptance','SVG format/labels checked; no fresh PDF/CSV or additional physical print test in this native session'])
(O/'repair-acceptance-report.json').write_text(json.dumps(report,indent=2)+'\n');(O/'stop.request').write_text('Targeted /195 repair and saved project checks completed; normal owned close.\n');print(json.dumps(report,indent=2))
