from pathlib import Path
import json,plistlib,subprocess,shlex
R=Path('/Users/dshills/Development/projects/ELab');S=Path(__file__).resolve().parent;O=Path('/private/tmp/elab-first-version-completion-204');N=O/'keyboard-review';N.mkdir(mode=0o700);E=Path(json.loads((O/'runtime-report.json').read_text())['extracted']);A=N/'ELab-release-check-204.app';(A/'Contents/MacOS').mkdir(parents=True)
source=(R/'docs/validation/latency-launch-preflight-170/launcher.swift.txt').read_text().replace('/private/tmp/elab-latency-launch-preflight-170',str(N)).replace('/private/tmp/elab-first-version-170-runtime/runtime.sb',str(O/'runtime.sb')).replace('/private/tmp/elab-first-version-170-runtime/ELab.app/Contents/MacOS/ELab',str(E/'ELab.app/Contents/MacOS/ELab'))
(S/'keyboard-launcher.swift').write_text(source)
with (A/'Contents/Info.plist').open('wb') as f:plistlib.dump(dict(CFBundleExecutable='ELabOwnedLauncher',CFBundleIdentifier='com.dshills.elab.releasecheck204',CFBundleName='ELab release check 204',CFBundlePackageType='APPL',CFBundleVersion='204',CFBundleShortVersionString='0.181.3',NSHighResolutionCapable=True),f)
q=subprocess.run(['/usr/bin/xcrun','swiftc','-module-cache-path',str(N/'swift-cache'),str(S/'keyboard-launcher.swift'),'-o',str(A/'Contents/MacOS/ELabOwnedLauncher')],capture_output=True,check=True,timeout=90);(N/'launcher-build.txt').write_bytes(q.stdout+q.stderr)
print(json.dumps(dict(app=str(A),endpoint=str(N/'endpoint.json'),native=str(E/'ELab.app/Contents/MacOS/ELab'))))
