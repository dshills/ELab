from pathlib import Path
import importlib.util,json,sys
R=Path('/Users/dshills/Development/projects/ELab');O=Path('/private/tmp/elab-first-version-completion-204');N=O/'keyboard-review'
spec=importlib.util.spec_from_file_location('client',R/'scripts/persistence-demo.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
c=m.Client(str(N/'endpoint.json'),command_preconditions=True,agent_binary=O/'agent')
try:
 s=c.ask('project.inspect');(N/(sys.argv[1]+'.json')).write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(dict(label=sys.argv[1],components=len(s['components']),wires=len(s['wires']),resistor=[p['value'] for p in s['components'] if p['kind']=='resistor'],result=s['result'],dirty=s['document']['dirty'])))
finally:c.close()
