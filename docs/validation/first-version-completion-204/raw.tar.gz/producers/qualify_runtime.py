from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
R=Path('/Users/dshills/Development/projects/ELab');S=Path(__file__).resolve().parent;O=Path('/private/tmp/elab-first-version-completion-204')
sys.path.insert(0,str(R/'scripts'))
from runtime_isolation import pinned_child_runner,development_canaries,sandbox_profile,controls,launcher,native_dependencies,bundle_tree
from package_review import members
b=json.loads((R/'docs/validation/ui-input-204/build-result-signed.json').read_text());p=json.loads((R/'docs/validation/ui-input-204/package-report.json').read_text());release=Path(p['release']);archive=Path(p['archive']);sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert sha(archive)==p['archive_sha256'];assert sha(release/'ELab.app/Contents/MacOS/ELab')==b['native_sha256'];assert sha(release/'elab-agent')==b['agent_sha256']
O.mkdir(mode=0o700);expected=members(release);extract=O/'Extracted download µ with spaces'
subprocess.run(['/usr/bin/ditto','-x','-k',str(archive),str(extract)],check=True,timeout=120);E=extract/release.name;assert members(E)==expected
for label,cmd in [('signature',['/usr/bin/codesign','--verify','--deep','--strict','--verbose=2',str(E/'ELab.app')]),('native-build',['go','version','-m',str(E/'ELab.app/Contents/MacOS/ELab')]),('agent-build',['go','version','-m',str(E/'elab-agent')])]:
 q=subprocess.run(cmd,capture_output=True,text=True,check=True,timeout=30);(O/(label+'.txt')).write_text(q.stdout+q.stderr)
sdk,run=pinned_child_runner();canaries=development_canaries(sdk);roots=[Path(x['root']) for x in canaries.values()];geometry=Path('/Users/dshills/Library/Cogent Core');profile=O/'runtime.sb';profile.write_text(sandbox_profile([*roots,geometry]));working=O/'empty-working-directory';working.mkdir();admission=controls(O,profile,canaries,run)
launcher(O/'native',profile,E/'ELab.app/Contents/MacOS/ELab',working);launcher(O/'agent',profile,E/'elab-agent',working)
controller=R/'build/ui-input-204-tools/build/elab-conformance';info=subprocess.check_output(['go','version','-m',str(controller)],text=True);assert 'vcs.revision='+b['source_commit'] in info and 'vcs.modified=false' in info
report=dict(passed=False,source_commit=b['source_commit'],version=b['version'],build=b['build'],native_sha256=b['native_sha256'],agent_sha256=b['agent_sha256'],archive_sha256=p['archive_sha256'],release=str(release),extracted=str(E),blocked_development=canaries,shared_geometry_denied=str(geometry),controls=admission,controller_sha256=sha(controller),scope='Exact extracted external native/stdio/socket processes deny source, SDK, toolchain, caches, shared geometry and outbound IP; controller and in-process adapter unrestricted')
(O/'runtime-report.json').write_text(json.dumps(report,indent=2)+'\n')
command=[str(controller),'--agent-binary',str(O/'agent'),'--native-binary',str(O/'native'),'--project-contract-suite','--electrical-suite','--artifacts',str(O/'public')]
with (O/'conformance.log').open('x') as log:run(command,cwd=working,stdout=log,stderr=-2,check=True,timeout=900)
public=json.loads((O/'public/report.json').read_text());assert public['passed'] and [a['name'] for a in public['adapters']]==['in-process','headless-stdio','headless-socket','native-socket']
assert members(E)==expected==members(release);report.update(passed=True,public_report_sha256=sha(O/'public/report.json'),adapter_names=[a['name'] for a in public['adapters']],package_unchanged=True,command=command)
(O/'runtime-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(passed=True,report=str(O/'runtime-report.json'),extracted=str(E))))
