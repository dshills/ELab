from pathlib import Path
import hashlib,importlib.util,json
R=Path('/Users/dshills/Development/projects/ELab');O=Path('/private/tmp/elab-first-version-completion-204');E=Path(json.loads((O/'runtime-report.json').read_text())['extracted']);spec=importlib.util.spec_from_file_location('client',R/'scripts/persistence-demo.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);results=[]
for file in [*sorted((E/'Examples').glob('*.elab')),O/'keyboard-review/LED-keyboard.elab']:
 c=m.Client(command_preconditions=True,agent_binary=E/'elab-agent')
 try:
  original=file.read_bytes();saved=json.loads(original);c.ask('project.load',{'path':str(file)},True);state=c.ask('simulation.wait');assert not state['document']['dirty'] and state['paused']==saved['paused'] and state['components']==saved['graph']['components'] and state['wires']==saved['graph']['wires'];assert file.read_bytes()==original
  job=c.ask('app.close',{'discard_changes':False},True)['shutdown'];job=c.wait_for_shutdown_outcome(job);assert job['status']=='completed' and all(job[k] for k in ('workers_joined','recovery_finalized','exit_ready'));results.append(dict(file=file.name,sha256=hashlib.sha256(original).hexdigest(),graph_preserved=True,pause_preserved=True,clean=True,result=state['result'],shutdown=job))
 finally:c.close();assert c.process.returncode==0
assert len(results)==4
(O/'examples-report.json').write_text(json.dumps(dict(passed=True,agent_sha256=hashlib.sha256((E/'elab-agent').read_bytes()).hexdigest(),cases=results,scope='Fresh packaged-agent reopening of all three bundled examples and the actual native keyboard-created project; offline denial qualified separately'),indent=2)+'\n');print(json.dumps(dict(passed=True,files=[x['file'] for x in results])))
