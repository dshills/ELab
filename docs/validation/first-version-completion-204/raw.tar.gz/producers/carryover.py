from pathlib import Path
import hashlib,json,subprocess
r=Path('/Users/dshills/Development/projects/ELab');o=Path('/private/tmp/elab-first-version-completion-204');base='885af1ad3c2a130092e532e8ffe966a5c6789889';final='06ab9893a39a5ba13beb4dc774ceb1d27bd97d35'
files=subprocess.check_output(['git','ls-tree','-r','--name-only',final,'--','workbench','internal','transport'],cwd=r,text=True).splitlines();unchanged={};changed=[]
for f in files:
 if not f.endswith('.go') or f.endswith('_test.go'):continue
 current=(r/f).read_bytes();old=subprocess.run(['git','show',base+':'+f],cwd=r,capture_output=True)
 if old.returncode==0 and old.stdout==current:unchanged[f]=hashlib.sha256(current).hexdigest()
 else:changed.append(f)
required=['workbench/project_save.go','workbench/project_import.go','workbench/project_recordings.go','workbench/recovery_store.go','workbench/shutdown.go','workbench/export.go','workbench/printing.go','workbench/schematic_page.go','workbench/transient.go','workbench/npn_transient.go'];assert all(f in unchanged for f in required)
(o/'source-carryover.json').write_text(json.dumps(dict(base_source_commit=base,release_source_commit=final,unchanged_production_sources=unchanged,changed_production_sources=changed,required_unchanged_sources=required,review='Changed workbench sources implement session inspector/browser fields, catalog metadata and clean example baselines; no solver, sampling, storage codec, Save worker, output engine or transport implementation change. Core workflow parity/project/electrical contracts were nevertheless rerun on exact extracted /204 bytes.'),indent=2)+'\n')
