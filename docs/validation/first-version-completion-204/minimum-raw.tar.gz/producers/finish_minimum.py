from pathlib import Path
import hashlib,json,tarfile,re,subprocess
R=Path('/Users/dshills/Development/projects/ELab');S=Path(__file__).resolve().parent;O=Path('/private/tmp/elab-first-version-completion-204');N=O/'keyboard-review';D=R/'docs/validation/first-version-completion-204';E=R/'research/ui-audit/first-version-completion-204';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dimensions(p):
 return [int(v) for v in re.findall(r'pixel(?:Width|Height): (\d+)',subprocess.check_output(['/usr/bin/sips','-g','pixelWidth','-g','pixelHeight',str(p)],text=True))]
size=lambda f:dimensions(E/f)
assert size('08-minimum-light.jpg')==size('09-minimum-dark.jpg')==[1053,762]
assert size('10-window-restored.jpg')==size('11-working-dark.jpg')==size('12-before-minimum.jpg')==[1221,969]
close=json.loads((N/'minimum-session-close.json').read_text());assert close['passed'] and close['owned_process_absent'] and close['endpoint_removed']
paths=(N/'minimum-process-paths.txt').read_text();assert '24667 /Users/dshills/Development/projects/ELab/build/releases/ELab-0.181.3-macos-arm64/ELab.app/Contents/MacOS/ELab' in paths and '45492 /private/tmp/elab-first-version-completion-204/' in paths
report=dict(passed=True,scope='Native minimum/working-size header, component browser and Inspect workspace; no circuit edits',minimum_pixels=[1053,762],declared_minimum_dp=[1040,720],working_pixels=[1221,969],themes=['Light','Dark'],original_size_restored=True,original_theme_restored='Light',before_after_document='Untitled circuit, clean, 0 components, 0 wires, Undo/Redo disabled, empty search',observed_release_pid=24667,owned_helper_pid=45492,process_paths_verified=True,owned_helper_close=close,limitations=['CUA selected the existing release window because both instances share a bundle identifier; the owned helper was identified separately with a private presentation marker and closed through its endpoint','This pass changes only window size and theme temporarily; no claim of unchanged preference-file timestamps or OS window position','Populated LED compact, RC/flasher workflow, and scope/inspector scrolling checks are recorded separately; this is not every pane/state at every size'])
(D/'minimum-layout-report.json').write_text(json.dumps(report,indent=2)+'\n')
entries={'minimum-cua-states.json':N/'minimum-cua-states.json','minimum-process-paths.txt':N/'minimum-process-paths.txt','minimum-session-close.json':N/'minimum-session-close.json','minimum-initial.json':N/'minimum-initial.json'}
for f in ['identify_session.py','identify-output.txt','identify-authorized-output.txt','close_owned.py','close-output.txt','finish_minimum.py']:entries['producers/'+f]=S/f
manifest={name:dict(sha256=sha(p),bytes=p.stat().st_size) for name,p in entries.items()};(D/'minimum-raw-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(D/'minimum-raw.tar.gz','w:gz') as tar:
 for name,p in sorted(entries.items()):tar.add(p,arcname=name,recursive=False)
with tarfile.open(D/'minimum-raw.tar.gz') as tar:
 assert set(tar.getnames())==set(manifest)
 for name,v in manifest.items():data=tar.extractfile(name).read();assert hashlib.sha256(data).hexdigest()==v['sha256'] and len(data)==v['bytes']
p=D/'report.json';d=json.loads(p.read_text());d['minimum_layout']=report;d['minimum_raw_archive_sha256']=sha(D/'minimum-raw.tar.gz');d['captures']={str(f.relative_to(R)):dict(sha256=sha(f),bytes=f.stat().st_size,pixels=dimensions(f)) for f in sorted(E.glob('*.jpg'))};p.write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(dict(passed=True,minimum=report['minimum_pixels'],restored=report['working_pixels'],capture_count=len(d['captures']))))
