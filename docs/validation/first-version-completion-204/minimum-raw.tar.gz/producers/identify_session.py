from pathlib import Path
import importlib.util,json
R=Path('/Users/dshills/Development/projects/ELab');O=Path('/private/tmp/elab-first-version-completion-204');N=O/'keyboard-review';E=Path(json.loads((O/'runtime-report.json').read_text())['extracted']);spec=importlib.util.spec_from_file_location('identify',R/'scripts/persistence-demo.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
c=m.Client(str(N/'endpoint.json'),command_preconditions=True,agent_binary=E/'elab-agent')
try:
 before=c.ask('project.inspect');assert not before['components'] and not before['document']['dirty'];after=c.ask('parts.search.set',{'query':'capacitor'},True);assert after['part_search']=='capacitor';(N/'minimum-initial.json').write_text(json.dumps(after,indent=2)+'\n');print(json.dumps(dict(passed=True,pid=(N/'launcher.pid').read_text().strip(),owned_presentation_marker=after['part_search'])))
finally:c.close()
