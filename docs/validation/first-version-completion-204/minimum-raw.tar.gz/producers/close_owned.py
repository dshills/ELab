from pathlib import Path
import hashlib,importlib.util,json,os,time
R=Path('/Users/dshills/Development/projects/ELab');O=Path('/private/tmp/elab-first-version-completion-204');N=O/'keyboard-review';E=Path(json.loads((O/'runtime-report.json').read_text())['extracted']);spec=importlib.util.spec_from_file_location('close_owned',R/'scripts/persistence-demo.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
c=m.Client(str(N/'endpoint.json'),command_preconditions=True,agent_binary=E/'elab-agent');pid=int((N/'launcher.pid').read_text())
try:
 state=c.ask('project.inspect');assert not state['components'] and not state['wires'] and not state['document']['dirty'] and not state['document'].get('path') and state['part_search']=='capacitor';job=c.ask('app.close',{'discard_changes':False},True)['shutdown'];job=c.wait_for_shutdown_outcome(job);assert job['status']=='completed' and all(job[k] for k in ('workers_joined','recovery_finalized','exit_ready'))
finally:c.close()
assert c.process.returncode==0
for _ in range(100):
 try:os.kill(pid,0)
 except ProcessLookupError:break
 time.sleep(.05)
else:raise RuntimeError('owned native PID still present')
assert not (N/'endpoint.json').exists();(N/'minimum-session-close.json').write_text(json.dumps(dict(passed=True,owned_pid=pid,shutdown=job,owned_process_absent=True,endpoint_removed=True,forwarder_exit_code=0,before_close=dict(components=0,wires=0,dirty=False,marker='capacitor'),native_sha256=hashlib.sha256((E/'ELab.app/Contents/MacOS/ELab').read_bytes()).hexdigest()),indent=2)+'\n');print(json.dumps(dict(passed=True,owned_pid=pid,closed=True)))
