from pathlib import Path
import gzip,hashlib,json,os,stat,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parents[2];S=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from package_review import members,verify_archive
B=json.loads((S/'build-result-signed.json').read_text());package=Path(B['review']);out=Path('/private/tmp/elab-candidate-191-archive');out.mkdir(mode=0o700,exist_ok=False)
checks=json.loads(Path('/private/tmp/elab-candidate-191-checks/report.json').read_text());assert checks['passed'] and checks['source_commit']==B['source_commit']
status=dict(kind='separate-recorded-position-candidate',version=B['version'],build=B['build'],source_commit=B['source_commit'],native_sha256=B['native_sha256'],agent_sha256=B['agent_sha256'],source_quality_passed=True,mounted_offscreen_position_checks_passed=True,packaged_headless_checks_passed=True,headless_reference_workflows=3,example_save_and_reopen_cases=3,native_started=False,native_input_accepted=False,ready_for_owner_testing=False,release_qualified=False,promoted=False,current_owner_alpha='0.172.0 /189',archive_check='Separate report; no extracted native startup acceptance')
(package/'CANDIDATE_STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
(package/'CANDIDATE_MANIFEST.json').write_text(json.dumps(dict(kind=status['kind'],release_qualified=False,files=members(package)),indent=2)+'\n');expected=members(package)
archive=ROOT/'build/ELab-0.174.0-191-candidate.zip';assert not archive.exists()
with archive.open('xb') as f:
 archive.chmod(0o600)
 with zipfile.ZipFile(f,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,v in expected.items():
   entry=zipfile.ZipInfo(package.name+'/'+name,date_time=(1980,1,1,0,0,0));entry.create_system=3;entry.external_attr=(stat.S_IFREG|int(v['mode'],8))<<16;entry.compress_type=zipfile.ZIP_DEFLATED;z.writestr(entry,(package/name).read_bytes(),compresslevel=9)
verify_archive(archive,package.name,expected)
extraction=out/'Extracted candidate µ with spaces'
r=subprocess.run(['/usr/bin/ditto','-x','-k',str(archive),str(extraction)],capture_output=True,timeout=120);(out/'ditto.txt').write_bytes(r.stdout+r.stderr);r.check_returncode()
extracted=extraction/package.name;assert members(extracted)==expected==members(package)
verify=subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict','--verbose=2',str(extracted/'ELab.app')],capture_output=True,timeout=30);(out/'signature.txt').write_bytes(verify.stdout+verify.stderr);verify.check_returncode()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
preservation=json.loads((S/'preservation-before.json').read_text());assert all(sha(ROOT/k)==v for k,v in preservation.items())
quality=json.loads(gzip.decompress((ROOT/'docs/validation/recorded-position-recovery/quality.json.gz').read_bytes()));assert quality['exit_code']==0 and quality['sources_unchanged']
assert all(sha(ROOT/k)==v for k,v in quality['source_sha256'].items())
report=dict(passed=True,scope='Separate /191 local package/archive rehearsal and headless checks; no native window/input, owner acceptance or promotion',source_commit=B['source_commit'],source_package=str(package),extracted_package=str(extracted),archive=str(archive),archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,files_verified=len(expected),members=expected,source_package_unchanged=True,extracted_bytes_and_modes_equal=True,strict_extracted_signature_valid=True,native_started=False,protected_files=preservation,go_inputs_unchanged=len(quality['source_sha256']),release_qualified=False,promoted=False)
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');archive.with_suffix('.zip.sha256').write_text(sha(archive)+'  '+archive.name+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['members','protected_files']}))
