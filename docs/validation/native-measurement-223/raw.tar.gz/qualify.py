from pathlib import Path
import datetime, hashlib, importlib.util, json, math, subprocess, sys
root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
read=lambda name:json.loads((stage/(name+'.json')).read_text())
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
base=read('selected-default');r=base['recording'];stats=r['interval_statistics']
assert r['last_sample_time_s']==.0199999999995 and r['duration_s']==.02
assert stats['settings']['end_s']==r['last_sample_time_s']
assert stats['time_mean']==stats['time_rms']==stats['minimum']==stats['maximum']==5
assert stats['ac_rms']==stats['peak_to_peak']==0
exclude={'viewport','command_revision','revision','last_actor'}
stable=lambda state:{k:v for k,v in state.items() if k not in exclude}
for name in ['unsupported-end','endpoint-corrected','invalid-start','invalid-start-corrected',
             'negative-start','negative-start-corrected','invalid-end','invalid-end-corrected']:
    assert stable(read(name))==stable(base),name
for name in ['05-unsupported','08-invalid-start','10-negative-start','12-invalid-end']:
    text=(stage/(name+'.txt')).read_text()
    assert 'Showing the last accepted measurement.' in text and 'Average 5 V' in text and 'RMS 5 V' in text
for name in ['07-corrected-stable','09-start-corrected','11-negative-corrected','13-end-recovered']:
    text=(stage/(name+'.txt')).read_text()
    assert 'Showing the last accepted measurement.' not in text,name
assert 'Value: 20 ms' in (stage/'05-unsupported.txt').read_text()
assert '0.0199999999995 s' in (stage/'05-unsupported.txt').read_text()
assert 'Value: oops' in (stage/'08-invalid-start.txt').read_text()
assert 'Value: -1 us' in (stage/'10-negative-start.txt').read_text()
assert 'Value: oops' in (stage/'12-invalid-end.txt').read_text()
assert read('private-draft')==read('setup')['after']
assert read('private-cleared-noop')==read('private-switch')['after']
for name,probe in [('15-private-cleared','C1.1 / ground'),('17-rejection-cleared','V1.positive / ground')]:
    text=(stage/(name+'.txt')).read_text()
    assert 'Current choice: '+probe in text and 'Value: 0 s' in text and 'Value: 1 ms' in text
    assert 'Value: oops' not in text and 'Value: 4 us' not in text and 'Showing the last accepted measurement.' not in text
fresh=read('channel-fresh');before=read('channel-before-fresh')
assert fresh['command_revision']==before['command_revision']+1
assert fresh['recording']['interval_statistics']['settings']['probe_id']=='v:V1.positive'
assert fresh['recording']['interval_statistics']['settings']['start_s']==2e-6
assert fresh['recording']['interval_statistics']['time_mean']==fresh['recording']['interval_statistics']['time_rms']==5
physics=lambda state:{k:v for k,v in state.items() if k not in exclude|{'recording','scope'}}
for name in ['private-switch','rejected-switch']:
    data=read(name);assert physics(data['before'])==physics(data['after']),name
assert physics(before)==physics(fresh)

spec=importlib.util.spec_from_file_location('client',root/'scripts/persistence-demo.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
client=helper.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json',command_preconditions=True,
                     agent_binary=root/'build/ELab-0.181.22-223-candidate/elab-agent')
try:
    state=client.ask('project.inspect');rows=[];offset=0
    while True:
        page=client.ask('operation.samples',{'id':state['selected_operation'],'offset':offset,'limit':200})
        rows.extend(page['rows'])
        if len(rows)==page['total']:break
        offset=page['next_offset']
    assert rows==json.loads((root/'build/native-acceptance-220-tools/native-recording-rows.json').read_text()) and len(rows)==1001
    (stage/'two-channel-rows.json').write_text(json.dumps(rows,indent=2)+'\n')
    errors=[]
    for row in rows:
        for actual,target in zip(row['values'],[5*-math.expm1(-row['time_s']/.01),5],strict=True):
            errors.append(abs(actual-target));assert math.isclose(actual,target,rel_tol=1e-12,abs_tol=1e-12)
    duration=rows[-1]['time_s']-rows[0]['time_s']
    area=[];squares=[]
    for a,b in zip(rows,rows[1:]):
        dt=b['time_s']-a['time_s'];va=a['values'][0];vb=b['values'][0]
        area.append(dt*(va+vb)/2);squares.append(dt*(va*va+va*vb+vb*vb)/3)
    mean=math.fsum(area)/duration;rms=math.sqrt(math.fsum(squares)/duration)
    rc=read('private-switch')['after']['recording']['interval_statistics']
    assert math.isclose(rc['time_mean'],mean,abs_tol=1e-12,rel_tol=1e-12)
    assert math.isclose(rc['time_rms'],rms,abs_tol=1e-12,rel_tol=1e-12)
    original=json.loads((root/'workbench/testdata/recorded-statistics-short-tail.json').read_text())
    assert read('imported-rows')['rows']==original['rows'] and len(original['rows'])==21
    assert all(row['values']==[5] for row in original['rows'])
    restored=client.ask('project.load',{'path':str(root/'build/native-acceptance-220-tools/RC native 220.elab'),'discard_changes':True},True)
    final=client.ask('recording.speed.set',{'seconds_per_wall_second':.1},True)
    assert final['paused'] and not final['document']['dirty'] and final['transient']['sample']['time_s']==0
    assert final['theme']=='light' and final['recording']['sample_index']==0
    (stage/'final-state.json').write_text(json.dumps(final,indent=2)+'\n')
finally:client.close()
inputs=json.loads((root/'docs/validation/number-step-223/source-inputs.json').read_text())
assert all(sha(root/name)==digest for name,digest in inputs.items())
project=json.loads((root/'build/number-step-223-tools/preserved-project.json').read_text())
assert sha(Path(project['path']))==project['sha256']
update=read('prepared-update');app=Path(update['installed'])
assert sha(app/'Contents/MacOS/ELab Cursor Recovery')==update['native_sha256']
with (stage/'signature-after-checks.txt').open('w') as log:
    subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict','--verbose=2',str(app)],stdout=log,stderr=-2,check=True)
sys.path.insert(0,str(root/'scripts'));from runtime_isolation import bundle_tree
build=json.loads((root/'build/number-step-223-tools/build-result-signed.json').read_text())
assert bundle_tree(Path(build['review'])/'ELab.app')==build['source_bundle']
assert sha(root/'build/releases/ELab-0.181.4-macos-arm64.zip')=='d13973f02f9c2895d353d24338ed060492a3a2200ff8a91e3606bfa867f4946b'
report=dict(passed=True,native_checks_completed=[10,12],native_refusal_correction_cases=4,
 actual_saved_endpoint_default=True,constant_source_mean_rms_v=5,cached_statistics_preserved_on_refusal=True,
 private_start_cleared_on_probe_change=True,rejected_end_cleared_on_probe_change=True,
 old_private_return_noop_exact=True,fresh_new_channel_command_count=1,
 imported_rows_exact=21,two_channel_rows_exact=1001,independent_rc_voltage_references=len(errors),
 max_absolute_error_v=max(errors),independent_piecewise_linear_rc_mean_v=mean,independent_piecewise_linear_rc_rms_v=rms,
 source_inputs_unchanged=len(inputs),saved_fixture_unchanged=True,installed_signature_valid=True,
 original_candidate_unchanged=True,preserved_205_unchanged=True,final_clean_paused_at_zero=True,
 production_changes=0,full_source_suites_repeated=False,remaining_original_native_checks=7,
 source_commit=build['source_commit'],native_sha256=update['native_sha256'],
 observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(stage/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
