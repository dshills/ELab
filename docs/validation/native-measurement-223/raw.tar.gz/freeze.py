from pathlib import Path
import gzip, hashlib, io, json, tarfile
root=Path('/Users/dshills/Development/projects/ELab');stage=Path(__file__).resolve().parent
dest=root/'docs/validation/native-measurement-223'
assert not dest.exists()
report=json.loads((stage/'report.json').read_text());assert report['passed']
files={p.relative_to(stage).as_posix():p.read_bytes() for p in stage.rglob('*') if p.is_file() and p.suffix in {'.py','.json','.txt','.jpg'}}
for name,data in files.items():
    assert Path(name).name!='endpoint.json'
    if name.endswith('.jpg'):assert data.startswith(b'\xff\xd8\xff')
dest.mkdir(parents=True)
with (dest/'raw.tar.gz').open('xb') as disk:
    with gzip.GzipFile(fileobj=disk,mode='wb',filename='',mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for name,data in sorted(files.items()):
                info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
                tar.addfile(info,io.BytesIO(data))
sha=lambda data:hashlib.sha256(data).hexdigest()
manifest={name:sha(data) for name,data in sorted(files.items())}
(dest/'raw-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
report.update(raw_members=len(files),raw_archive_sha256=sha((dest/'raw.tar.gz').read_bytes()))
(dest/'report.json').write_text(json.dumps(report,indent=2)+'\n')
pending=json.loads((root/'docs/validation/native-recorded-position-223/native-acceptance-pending.json').read_text())
pending.update(completed_checks_for_copied_runtime=[1,2,4,5,7,8,10,12,16,17,18],remaining_checks_count=7,
               new_native_checks=[10,12],carried_forward_checks=[1,2,4,5,7,8,16,17,18],
               current_build_fresh_native_checks=[10,12],evidence='README.md',
               prior_evidence='../native-recorded-position-223/README.md',
               current_build_fresh_native_scope='Imported saved endpoint/defaults, four current measurement refusals and first corrections, cached-result labeling, private/rejected channel changes and fresh native entry')
(dest/'native-acceptance-pending.json').write_text(json.dumps(pending,indent=2)+'\n')
(dest/'README.md').write_text('''# Native captured measurements /223

[Receipt](report.json), [captures and checks](raw.tar.gz), [hashes](raw-manifest.json),
[remaining checklist](native-acceptance-pending.json).

Original native items 10 and 12 pass on the unchanged code-equivalent /223 copy.
The same already-running owned test session is reused throughout. No new feature
or production change, additional launch, owner review or permission question.

## Actual saved endpoint and correction

The repository's short-tail fixture declares 20 ms but its final saved timestamp
is 19.9999999995 ms. Selecting V1 in the native measurement menu uses that exact
saved endpoint; public accepted settings confirm it. The visible mean and RMS
are both 5 V, with zero AC ripple and peak-to-peak. Typing 20 ms reports saved
coverage, retains the typed value, preserves the cached result and labels it as
the last accepted measurement. The first correction to the accepted endpoint
clears that notice. No silent averaging over unsupported data.

Malformed start, negative start and malformed end also retain their text and
accepted results, and recover on the first correction. Negative start is a range
refusal; the unsaved end tail is the actual unsupported-data case. The cached
statistics and every root state field except viewport, revisions and actor are
exact throughout all four cases. Guidance temporarily changes canvas height.
Return moves focus to the next control and keeps it visible; wheel scrolling
exposes the full result and the editors without changing accepted settings.

## Channel ownership

In a separate two-channel capture, an unfinished 4 us start remains entirely
private. A real agent switches the measured channel from V1 to C1. Native fields
reset to the accepted 0–1 ms interval. Clicking the new editor and pressing Return
preserves the complete agent snapshot exactly; the old draft cannot commit.

A rejected end on C1 is then cleared when the agent switches back to V1. The old
text, cached-result notice and error guidance disappear. A fresh native 2 us start
targets V1 and delivers exactly one shared command, leaving live physics intact.
These are actual channel switches, not just selecting the same option again.

## Preservation and limits

All 21 imported rows and all 1,001 two-channel rows remain exact. Independent RC
and source references cover 2,002 scalar samples (maximum absolute error below
5e-16 V). Independently integrated saved linear segments reproduce C1's mean
0.24187089783287116 V and RMS 0.27814543200528197 V. This checks the documented
saved-sample method, not an unsupported continuous-signal accuracy claim.

All 897 frozen source/check inputs, saved fixture, strict installed signature,
original candidate bundle and /205 download remain unchanged. Existing full
source gates still apply; no redundant full-suite run. The disposable project is
restored clean, paused at zero, Light, with original playback preferences. Some
immediate AX captures precede the screenshot's updated frame; stable follow-up
captures and exact public snapshots establish final values. JPEG bytes are saved
unchanged with matching extensions.

Eleven of eighteen original native checks now have scoped evidence; seven remain:
3, 6, 9, 11, 13, 14 and 15. Check 9 remains partial because exact native callback
queue origin was not established. /223 stays held and /205 remains the preserved
download. Next: captured comparison recovery and independent preferences, followed
by the remaining form and keyboard paths. No new owner permission is pending.
''')
(root/'research/107-native-captured-measurements.md').write_text('''# Native captured measurement acceptance

October 24, 2026. [Evidence and checklist](../docs/validation/native-measurement-223/README.md).

Native items 10 and 12 pass. The measurement selector defaults to the actual saved
endpoint rather than nominal duration and displays 5 V mean/RMS for constant data.
An unsupported saved tail, malformed start/end and negative start retain typed
text, label cached results and accept the first correction. Actual agent channel
changes clear the previous channel's private or rejected entry; fresh native
editing then targets the new channel and preserves live circuit state.

The imported and two-channel rows are unchanged, independent electrical and
piecewise-linear statistics references pass, and source/signatures/fixtures and
/205 remain exact. No product changes or full source-suite repetition. The same
authorized native session is restored clean and paused at zero. Eleven original
native checks are now complete; seven remain, including check 9's native queue
origin qualification. Continue captured-comparison and remaining form/keyboard
checks without waiting for owner review or another launch/desktop permission.
''')
with (root/'research/README.md').open('a') as out:
    out.write('\n- [Native captured measurements](107-native-captured-measurements.md): exact endpoint defaults, cached-result correction, native/agent channel ownership, independent electrical references and seven remaining native checks.\n')
with (root/'research/80-overnight-work-plan.md').open('a') as out:
    out.write('''

## Checkpoint: native captured measurement acceptance

[Native items 10 and 12](107-native-captured-measurements.md) pass: actual saved
endpoint defaults, 5 V mean/RMS, four refusal/first-correction cases, explicit
cached-result presentation, private/rejected entries cleared by agent channel
changes, and fresh editing on the new channel. Eleven original native items are
complete and seven remain. All source, electrical references, rows, fixtures,
signatures and /205 are preserved. Next captured comparison and independent
preferences, then remaining forms and keyboard routes. Reuse the owned session
under saved authorization; no owner-review or permission wait.
''')
plan=root/'research/34-first-version-plan.md';text=plan.read_text()
start=text.index('**Current maintenance work:**');end=text.index('\n## Historical plan',start)
text=text[:start]+'''**Current maintenance work:** /223's decimal-step repair and the
[latest native captured-measurement checks](107-native-captured-measurements.md)
pass within scope. Eleven of eighteen original native items now have evidence;
seven remain: 3, 6, 9, 11, 13, 14 and 15. Item 9 remains partial; bounded races do
not establish exact native callback queue origin. Imported measurement defaults,
cached-result recovery and measured-channel draft ownership are now qualified.

Earlier validation-scroll, private-draft, footer/theme, manual-step, slider,
Verify endpoint and numeric-wheel repairs remain included. [Electronics reference
checks](95-gate-common-mode.md) cover seven RC-driven MOSFET circuits and active
work preservation. The earlier exit follows a native Quit-menu request whose
initiator is unknown; no spontaneous crash or broad lifecycle pass is claimed.
/207–/223 stay held for remaining native acceptance and do not replace /205.
Owner review remains deferred. Standing run/desktop authorization is saved in
`AGENTS.md` and must not be requested again.
'''+text[end:]
plan.write_text(text)
with tarfile.open(dest/'raw.tar.gz','r:gz') as tar:
    assert {m.name:sha(tar.extractfile(m).read()) for m in tar.getmembers()}==manifest
print(json.dumps({'archived_members':len(files),'completed_checks':[10,12],'remaining_original_checks':7}))
