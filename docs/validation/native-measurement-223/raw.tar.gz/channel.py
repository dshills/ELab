from pathlib import Path
import importlib.util, json, sys
root = Path('/Users/dshills/Development/projects/ELab')
stage = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('client', root/'scripts/persistence-demo.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
client = helper.Client('/private/tmp/elab-cursor-guidance-206/endpoint.json', command_preconditions=True,
                       agent_binary=root/'build/ELab-0.181.22-223-candidate/elab-agent')
mode = sys.argv[1]
assert mode in ['setup', 'private-switch', 'rejected-switch', 'restore']
output = stage/(mode+'.json')
assert not output.exists()
try:
    before = client.ask('project.inspect')
    if mode == 'setup':
        (stage/'invalid-end-corrected.json').write_text(json.dumps(before,indent=2)+'\n')
        rows = client.ask('operation.samples', {'id':before['selected_operation'], 'offset':0, 'limit':200})
        original = json.loads((root/'workbench/testdata/recorded-statistics-short-tail.json').read_text())
        assert rows['rows'] == original['rows'] and rows['total'] == len(original['rows']) == 21
        (stage/'imported-rows.json').write_text(json.dumps(rows,indent=2)+'\n')
        before = client.ask('project.load', {'path':str(root/'build/native-acceptance-220-tools/RC native 220.elab'), 'discard_changes':True},True)
        params = dict(id=before['recording']['id'], probe_id='v:V1.positive', start_s=0, end_s=.001)
    elif mode == 'restore':
        client.ask('project.load', {'path':str(root/'build/native-acceptance-220-tools/RC native 220.elab'), 'discard_changes':True},True)
        after = client.ask('recording.speed.set', {'seconds_per_wall_second':.1},True)
        assert after['paused'] and not after['document']['dirty'] and after['transient']['sample']['time_s']==0
        output.write_text(json.dumps(after,indent=2)+'\n')
        print(json.dumps({'mode':mode,'command_revision':after['command_revision'],'clean_paused_at_zero':True}))
        sys.exit(0)
    else:
        params = dict(before['recording']['interval_statistics']['settings'])
        params['probe_id'] = 'v:C1.1' if mode=='private-switch' else 'v:V1.positive'
    after = client.ask('recording.statistics.set', params, True)
    output.write_text(json.dumps({'before':before,'after':after},indent=2)+'\n')
    print(json.dumps({'mode':mode,'command_revision':after['command_revision'],'probe_id':params['probe_id']}))
finally:
    client.close()
