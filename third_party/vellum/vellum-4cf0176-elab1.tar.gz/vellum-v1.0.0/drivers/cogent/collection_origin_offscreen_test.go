//go:build offscreen

package cogent

import (
	"slices"
	"testing"

	"github.com/dshills/vellum/ui"
)

// Detached application wrappers may carry command/document admission context.
// Collection input must retain that wrapper while checking current eligibility.
func TestCollectionQueuedCallbacksRetainAdmittedDescriptor(t *testing.T) {
	for _, kind := range []string{"select", "select-all", "activate"} {
		t.Run(kind, func(t *testing.T) {
			f := nativeCollectionFixture()
			f.Items, f.SelectedIDs = f.Items[:4], []string{"0"}
			f.Change = func(ui.ListSelectionEvent) {}
			f.Activate = func(ui.CollectionEvent) {}
			version := 0
			var calls []int
			m, a := simpleManual(t, manualConfig(t, 79), func() ui.Node {
				n, err := f.View()
				if err != nil {
					t.Fatal(err)
				}
				origin := version
				n.SelectionChange = func(ui.ListSelectionEvent) { calls = append(calls, origin) }
				n.Collection.Activate = func(ui.CollectionEvent) { calls = append(calls, origin) }
				return n
			})
			unitSettle(t, m)
			w := m.implementation.find("one")
			r := w.state.root
			queue := func() {
				switch kind {
				case "select":
					queueListSelection(r, "1", r.control.choice.buttons["1"], 0, "0")
				case "select-all":
					queueListSelectAll(r, "0", r.control.choice.buttons["0"])
				case "activate":
					queueCollectionActivation(r, "0", r.control.choice.buttons["0"])
				}
			}
			queue()
			version = 1
			a.Invalidate("one")
			if err := m.implementation.refresh(w); err != nil {
				t.Fatal(err)
			}
			a.Drain()
			if !slices.Equal(calls, []int{0}) {
				t.Fatal("queued collection input adopted refreshed wrapper", calls)
			}
			queue()
			a.Drain()
			if !slices.Equal(calls, []int{0, 1}) {
				t.Fatal("independent fresh input did not use current wrapper", calls)
			}
		})
	}
}

func TestNonCollectionMultipleChoicesKeepLatestCallback(t *testing.T) {
	for _, kind := range []string{"select", "select-all"} {
		t.Run(kind, func(t *testing.T) {
			version := 0
			var calls []int
			m, a := simpleManual(t, manualConfig(t, 79), func() ui.Node {
				origin := version
				return ui.Node{ID: "choices", Kind: ui.ListBox, Multiple: true, Options: []ui.Option{{ID: "0", Label: "Zero"}, {ID: "1", Label: "One"}}, SelectedIDs: []string{"0"}, SelectionChange: func(ui.ListSelectionEvent) { calls = append(calls, origin) }}
			})
			unitSettle(t, m)
			w := m.implementation.find("one")
			r := w.state.root
			if kind == "select" {
				queueListSelection(r, "1", r.control.choice.buttons["1"], 0, "0")
			} else {
				queueListSelectAll(r, "0", r.control.choice.buttons["0"])
			}
			version = 1
			a.Invalidate("one")
			if err := m.implementation.refresh(w); err != nil {
				t.Fatal(err)
			}
			a.Drain()
			if !slices.Equal(calls, []int{1}) {
				t.Fatal("unproven non-collection contract was broadened", calls)
			}
		})
	}
}
