// Private, invisible Cocoa object fixtures. No event is posted or dispatched.
#import "../mouse_position_darwin.m"

@interface VellumMouseFixtureEvent : NSEvent
@property NSWindow *target;
@property NSEventType kind;
@property NSPoint location;
@end
@implementation VellumMouseFixtureEvent
- (NSWindow *)window { return self.target; }
- (NSEventType)type { return self.kind; }
- (NSPoint)locationInWindow { return self.location; }
@end

@interface VellumMouseFlippedView : NSView
@end
@implementation VellumMouseFlippedView
- (BOOL)isFlipped { return YES; }
@end

static unsigned checks;
static void expect(BOOL passed, const char *name) {
    checks++;
    if (!passed) { fprintf(stderr, "mouse position fixture failed: %s\n", name); exit(1); }
}
static void point(NSWindow *window, NSEvent *event, double wantX, double wantY) {
    double x = 918, y = 719;
    expect(vellumMouseEventPosition(window, event, &x, &y) &&
           fabs(x - wantX) < 1e-9 && fabs(y - wantY) < 1e-9, "position");
}
static void refused(NSWindow *window, NSEvent *event) {
    double x = 918, y = 719;
    expect(!vellumMouseEventPosition(window, event, &x, &y) &&
           x == 918 && y == 719, "refusal preserves outputs");
}

int main(void) {
    @autoreleasepool {
        [NSApplication sharedApplication];
        NSRect rect = NSMakeRect(100, 100, 320, 240);
        NSWindow *first = [[NSWindow alloc] initWithContentRect:rect
            styleMask:NSWindowStyleMaskBorderless backing:NSBackingStoreBuffered defer:NO];
        NSWindow *second = [[NSWindow alloc] initWithContentRect:rect
            styleMask:NSWindowStyleMaskBorderless backing:NSBackingStoreBuffered defer:NO];
        first.releasedWhenClosed = NO; second.releasedWhenClosed = NO;
        VellumMouseFixtureEvent *event = [VellumMouseFixtureEvent new];
        event.target = first; event.location = NSMakePoint(19.5, 31.25);
        NSEventType types[] = {NSEventTypeLeftMouseDown, NSEventTypeLeftMouseUp,
            NSEventTypeRightMouseDown, NSEventTypeRightMouseUp,
            NSEventTypeOtherMouseDown, NSEventTypeOtherMouseUp,
            NSEventTypeLeftMouseDragged, NSEventTypeRightMouseDragged,
            NSEventTypeOtherMouseDragged, NSEventTypeMouseMoved, NSEventTypeScrollWheel};
        for (unsigned i = 0; i < sizeof(types) / sizeof(types[0]); i++) {
            event.kind = types[i]; point(first, event, 19.5, 208.75);
        }
        // Same screen location, independent of view flipping/bounds origin.
        first.contentView = [[VellumMouseFlippedView alloc] initWithFrame:NSMakeRect(0, 0, 320, 240)];
        point(first, event, 19.5, 208.75);
        [first.contentView setBoundsOrigin:NSMakePoint(7, 11)];
        point(first, event, 19.5, 208.75);
        first.contentView = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, 320, 240)];
        [first.contentView setBoundsOrigin:NSMakePoint(7, 11)];
        point(first, event, 19.5, 208.75);
        event.location = NSMakePoint(-4.5, 300.25);
        point(first, event, -4.5, -60.25);
        refused(second, event);
        refused(nil, event); refused(first, nil);
        event.target = nil; refused(first, event); event.target = first;
        event.kind = NSEventTypeKeyDown; refused(first, event);
        event.kind = NSEventTypeApplicationDefined; refused(first, event);
        event.kind = NSEventTypeLeftMouseDown;
        event.location = NSMakePoint(NAN, 12); refused(first, event);
        event.location = NSMakePoint(12, INFINITY); refused(first, event);
        event.location = NSMakePoint(19.5, 31.25);
        double x = 918, y = 719;
        expect(!vellumMouseEventPosition(first, event, NULL, &y) && y == 719, "null x");
        expect(!vellumMouseEventPosition(first, event, &x, NULL) && x == 918, "null y");
        __block BOOL rejected = NO;
        dispatch_semaphore_t finished = dispatch_semaphore_create(0);
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_DEFAULT, 0), ^{
            double a = 918, b = 719;
            rejected = !vellumMouseEventPosition(first, event, &a, &b) && a == 918 && b == 719;
            dispatch_semaphore_signal(finished);
        });
        expect(dispatch_semaphore_wait(finished, dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC)) == 0, "worker completed");
        expect(rejected, "off-main thread");
        expect(!vellumNativeMouseEventPosition(NULL, &x, &y), "missing current window");
        first.contentView = nil; refused(first, event);
        [second close]; [first close];
        printf("{\"passed\":true,\"checks\":%u,\"scope\":\"invisible Cocoa geometry and refusal fixtures; no posted input\"}\n", checks);
    }
    return 0;
}
