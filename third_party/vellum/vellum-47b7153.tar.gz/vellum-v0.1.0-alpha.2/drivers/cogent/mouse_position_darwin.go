//go:build darwin && cgo

package cogent

/*
#cgo darwin CFLAGS: -fobjc-arc
#cgo darwin LDFLAGS: -framework Cocoa
int vellumNativeMouseEventPosition(void *window, double *x, double *y);
*/
import "C"

import "image"

// GLFW mouse-button/scroll callbacks can carry a queued event at a position
// different from the hardware cursor. Keep window matching and conversion on
// the native thread; this hook does not post work or inspect UI-owned records.
func (n *accessibilityAttachment) MouseEventPosition() (image.Point, bool) {
	if n == nil || n.window == nil || n.window.Glw == nil {
		return image.Point{}, false
	}
	var x, y C.double
	if C.vellumNativeMouseEventPosition(n.window.Glw.GetCocoaWindow(), &x, &y) == 0 {
		return image.Point{}, false
	}
	return n.window.MousePosToPoint(float64(x), float64(y)), true
}
