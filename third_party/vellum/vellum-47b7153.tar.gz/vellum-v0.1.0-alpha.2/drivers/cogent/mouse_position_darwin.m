//go:build darwin && cgo

#import <Cocoa/Cocoa.h>
#include <math.h>

// No mouse position is cached: only this window's current mouse event can
// replace hardware polling. Coordinates remain outside the view during drags.
static int vellumMouseEventPosition(NSWindow *window, NSEvent *event,
                                   double *x, double *y) {
    if (![NSThread isMainThread] || !window || !event || !x || !y ||
        event.window != window) return 0;
    switch (event.type) {
        case NSEventTypeLeftMouseDown: case NSEventTypeLeftMouseUp:
        case NSEventTypeRightMouseDown: case NSEventTypeRightMouseUp:
        case NSEventTypeOtherMouseDown: case NSEventTypeOtherMouseUp:
        case NSEventTypeLeftMouseDragged: case NSEventTypeRightMouseDragged:
        case NSEventTypeOtherMouseDragged: case NSEventTypeMouseMoved:
        case NSEventTypeScrollWheel: break;
        default: return 0;
    }
    NSView *view = window.contentView;
    if (!view) return 0;
    NSPoint point = [view convertPoint:event.locationInWindow fromView:nil];
    NSRect bounds = view.bounds;
    double left = point.x - NSMinX(bounds);
    double top = view.isFlipped ? point.y - NSMinY(bounds) : NSMaxY(bounds) - point.y;
    if (!isfinite(left) || !isfinite(top)) return 0;
    *x = left;
    *y = top;
    return 1;
}

int vellumNativeMouseEventPosition(void *rawWindow, double *x, double *y) {
    if (![NSThread isMainThread] || !rawWindow) return 0;
    return vellumMouseEventPosition((__bridge NSWindow *)rawWindow,
                                    [NSApp currentEvent], x, y);
}
