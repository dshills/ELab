//go:build darwin && cgo

package cogent

import (
	"testing"

	"cogentcore.org/core/system/driver/desktop"
)

func TestNativeMousePositionWithoutLiveWindowFallsBack(t *testing.T) {
	for _, attachment := range []*accessibilityAttachment{nil, {}, {window: &desktop.Window{}}} {
		if _, ok := attachment.MouseEventPosition(); ok {
			t.Fatal("absent native window supplied an event position")
		}
	}
}
