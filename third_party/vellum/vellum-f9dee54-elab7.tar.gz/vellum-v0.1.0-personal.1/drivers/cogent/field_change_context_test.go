package cogent

import (
	"testing"

	"cogentcore.org/core/core"
	"github.com/dshills/vellum/app"
	"github.com/dshills/vellum/ui"
)

func TestQueuedScalarChangeRetainsEventCallbackAcrossRebind(t *testing.T) {
	for _, kind := range []ui.Kind{ui.TextField, ui.NumberField, ui.Checkbox, ui.Switch, ui.ToggleButton} {
		t.Run(string(kind), func(t *testing.T) {
			a, err := app.New(app.Config{})
			if err != nil {
				t.Fatal(err)
			}
			defer a.Close()
			if err := a.Open(app.Window{ID: "main", Title: "Queued field context", Width: 200, Height: 100, View: func() ui.Node { return ui.Node{ID: "root", Kind: ui.Column} }}); err != nil {
				t.Fatal(err)
			}
			oldCalls, newCalls := 0, 0
			var oldEvent, newEvent ui.ChangeEvent
			n := ui.Node{ID: "root", Kind: ui.Column, Children: []ui.Node{{
				ID: "field", Kind: kind, Text: "accepted", Number: 7,
				Numeric: ui.Numeric{Min: 0, Max: 100, Step: 1},
				Change:  func(e ui.ChangeEvent) { oldCalls++; oldEvent = e },
			}}}
			host := core.NewFrame(core.NewBody("queued-field"))
			r, err := reconcile(host, nil, n, a, "main")
			if err != nil {
				t.Fatal(err)
			}
			widget := findRecord(r, "field").widget
			submit := func(text string, number float32) {
				switch field := widget.(type) {
				case *core.TextField:
					field.SetText(text).SendChange()
				case *core.Spinner:
					field.SetValue(number).SendChange()
				case *core.Switch:
					field.SetChecked(number != 0).SendChange()
				default:
					t.Fatal("unexpected field widget")
				}
			}
			submit("oops", 3) // Native Change is admitted; owner delivery is still queued.
			n.Children[0].Change = func(e ui.ChangeEvent) { newCalls++; newEvent = e }
			r, err = reconcile(host, r, n, a, "main")
			if err != nil {
				t.Fatal(err)
			}
			if findRecord(r, "field").widget != widget {
				t.Fatal("fixture replaced the queued field")
			}
			a.Drain()
			if oldCalls != 1 || newCalls != 0 {
				t.Fatalf("queued field borrowed refreshed callback: origin=%d refreshed=%d", oldCalls, newCalls)
			}
			if kind == ui.TextField && oldEvent.Text != "oops" || kind == ui.NumberField && oldEvent.Number != 3 || (kind == ui.Checkbox || kind == ui.Switch || kind == ui.ToggleButton) && !oldEvent.Checked {
				t.Fatal("originating event payload changed", oldEvent)
			}
			submit("fresh", 4)
			a.Drain()
			if oldCalls != 1 || newCalls != 1 {
				t.Fatal("fresh independent change did not use the new callback", oldCalls, newCalls)
			}
			if kind == ui.TextField && newEvent.Text != "fresh" || kind == ui.NumberField && newEvent.Number != 4 || (kind == ui.Checkbox || kind == ui.Switch || kind == ui.ToggleButton) && !newEvent.Checked {
				t.Fatal("fresh event payload changed", newEvent)
			}
		})
	}
}
