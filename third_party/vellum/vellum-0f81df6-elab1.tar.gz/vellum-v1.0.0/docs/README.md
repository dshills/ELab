# Documentation

Start with the [project overview](../README.md), [development guide](development.md)
and [implementation status](implementation.md). For current Mac use, follow the
[v1 support guide](macos-v1.md), [stable API contract](../specs/stable-api.md)
and [release closeout](../specs/macos-v1-release.md). The older delivery plan
retains broader qualification work.

- [Current document-workflow handoff](mac-document-workflows-handoff.md): indexed private artifact identities, static OS requirements and deferred native acceptance.
- [Private candidate index](../release/private-macos-candidate.json): checked source of identities and generated handoff commands; run `scripts/private-candidate.py` from the checkout.
- [Safe desktop resumption](mac-desktop-resumption.md): offscreen identity checks now and bounded disposable-fixture checks only after desktop deferral is lifted.
- [Mac input widgets](mac-widget-integration.md): public API setup, themes, owner values and focus helpers.
- [Mac widget demo](mac-widget-demo.md): run the private light/dark gallery.
- [Repository layout](repository-layout.md): package, module, command and archive boundaries.
- Research and recommendations (full-repository reference: `docs/research/README.md`): source-backed investigation and architecture alternatives.
- [Architecture decisions](decisions/): recorded choices and the evidence available when each was made.
- Foundation and SDK reports (full-repository reference: `docs/reports/README.md`): investigation outcomes, fixes and remaining validation gaps.
- Mac Shell exposure correction (full-repository reference: `docs/reports/macos-shell-exposure/README.md`): verified build12 and updated proposed asset set.
- Mac Shell contrast correction (full-repository reference: `docs/reports/macos-shell-contrast/README.md`): historical build11, unchanged notices and its recorded exposure/capture discrepancy.
- Published macOS build13 (full-repository reference: `docs/reports/macos-v1-build13-publication/README.md`): SDK/six apps, exact public download hashes and the final owner decision.
- Coherent macOS build13 preparation (full-repository reference: `docs/reports/macos-v1-build13/README.md`): matching-source packaging, native checks and the historical prepublication packet.
- Historical macOS public packaging (full-repository reference: `docs/reports/macos-v1-public-packaging/README.md`): prior mixed-source candidates and original checks.
- Historical delta-audit packet (full-repository reference: `docs/reports/macos-v1-distribution/README.md`): exact private inputs bound by the current approval.
- [Distribution checks](distribution.md): packaging the native foundation fixture.
- Review records (full-repository reference: `docs/reviews`): committed reviews and verification evidence.
- Architecture diagrams (full-repository reference: `docs/assets`): research illustrations.
- [Specifications](../specs/README.md): implemented framework contract and validation plan.

Research, decisions, reports and review records preserve historical context. Their
past next-step instructions describe that stage of the investigation; consult
implementation status and the framework contract for the current implementation.
Recorded evidence may contain original paths and hashes. Those capture-time values
are retained; current document links and tooling use the reorganized paths.

- Named canvas objects (full-repository reference: `docs/reports/macos-canvas-accessibility/README.md`): opt-in semantics, exact selection and completed geometry for retained Canvas2D.

- Span header construction (full-repository reference: `docs/reports/macos-span-headers/README.md`): bounded scene-builder scratch and source-capture allocation evidence.
- Packed glyph coverage (full-repository reference: `docs/reports/macos-packed-coverage/README.md`): owned cached-span replay with original admission and exact output checks.

- [Native integration session usage](desktop-integration.md).
- Full native workspace checkpoint (full-repository reference: `docs/reports/macos-native-workspace/README.md`).

- [Native macOS application examples](../examples/macapps/README.md): independently runnable Go consumers and their working interactions.
- Native application checkpoint (full-repository reference: `docs/reports/macos-app-examples/README.md`): verification and remaining visual acceptance.

- [Build a personal macOS application](building-macos-apps.md): independent SDK consumer, controlled state, commands, durable Notes files/recovery and packaging.


SDK archive scope: omitted evidence references require the matching full checkout; see [documentation scope](../SDK_DOCUMENTATION.md).
