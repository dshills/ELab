# Current native mouse-event position

Stage 75 adds the optional `desktop.NativeMouseEventPositioner` attachment
contract. Button and scroll callbacks prefer its accepted device-pixel position;
without support, or when it returns false, the original GLFW hardware-cursor
path remains. General cursor queries, file drops and GLFW-provided move/drag
coordinates retain their prior paths. A supplied point is neither cached,
clamped nor scaled twice.

On Cocoa the accessibility/native attachment uses only the current mouse event
for its exact live window, on the main thread. It converts content-view bounds
and flipping to top-left logical coordinates and applies the existing desktop
DPR conversion once. Key/application events, missing/foreign windows or views,
non-finite coordinates and off-main calls refuse without writing outputs.
Closing the native attachment withdraws its window reference first. This hook
posts no work, acquires no render/owner locks and never calls RunOnMain.

The patch/input/output hashes are owned by `native/dependencies.json` and
`prepare.py`; do not hand-edit generated upstream sources. Original upstream
files retain their BSD-style licensing; the new test is MIT under this SDK.

## Checks

From `drivers/cogent` after preparation:

```sh
go -C build/upstream test -race ./system/driver/desktop
go test -race -tags offscreen -run 'TestNativeMousePosition|TestReviewFieldSettlement' .
xcrun clang -fobjc-arc -framework Cocoa -Wall -Wextra native/mouse-position-checks.m -o build/mouse-position-checks
./build/mouse-position-checks
```

The Cocoa check creates invisible window/view objects and protocol event
fixtures. It posts or dispatches no input. Its 29 assertions cover all admitted
mouse event kinds, flipped/offset view bounds, outside-view coordinates,
window/type/thread/finite/null refusal and unchanged output sentinels. The
worker uses asynchronous dispatch: synchronous dispatch may execute inline on
the calling thread and cannot establish an off-main refusal test.

Go tests establish native-point precedence without hardware access, fresh and
unclamped device pixels, independent window attachments, unavailable-hook
fallback admission and absent live-window refusal. These are unit/protocol
proofs. Actual native button/field/scroll/menu/drag interactions and physical
DPR/cross-display/lifecycle qualification remain separate gates. There is no
claim of full platform, screen-reader, distribution or visible-latency
qualification from these checks.
