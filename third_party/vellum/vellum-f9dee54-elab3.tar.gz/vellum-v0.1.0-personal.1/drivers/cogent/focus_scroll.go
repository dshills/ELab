package cogent

import (
	"sync/atomic"

	"cogentcore.org/core/core"
	"cogentcore.org/core/math32"
	"github.com/dshills/vellum/ui"
)

const nativeFocusEntryKey = "vellum.native-focus-entry"

func consumeNativeFocusEntry(widget core.Widget) bool {
	flag, _ := widget.AsWidget().Property(nativeFocusEntryKey).(*atomic.Bool)
	return flag != nil && flag.Swap(false)
}

type focusScrollValue struct {
	frame  *core.Frame
	slider *core.Slider
	axis   math32.Dims
	value  float32
}

// A view update can insert content above an already visible focused editor.
// Its new geometry is unavailable during reconciliation, so reveal it once
// after layout. This is not a persistent "keep focus visible" policy: deliberate
// scrolling, a different editor/owner, or a disabled/hidden target cancels it.
type focusScrollReveal struct {
	record      *record
	ownerWidget core.Widget
	widget      core.Widget
	wasVisible  bool
	scroll      []focusScrollValue
}

type focusScrollCapture struct {
	before     core.Widget
	candidates []*focusScrollReveal
}

func captureFocusScroll(root *record) *focusScrollCapture {
	capture := &focusScrollCapture{}
	var visit func(*record)
	visit = func(root *record) {
		if root == nil {
			return
		}
		if root.control != nil && ui.IsFocusable(root.node.Kind) && !root.node.Disabled {
			target, err := focusWidget(root)
			if err == nil && !accessibilityTreeNil(target) {
				w := target.AsWidget()
				if w.ContainsFocus() {
					capture.before = target
				}
				full := math32.RectFromPosSizeMax(w.Geom.Pos.Total, w.Geom.Size.Actual.Total)
				anchor := &focusScrollReveal{record: root, ownerWidget: root.widget, widget: target,
					wasVisible: !full.Empty() && full == w.Geom.TotalBBox}
				for parent := w.Parent; parent != nil; parent = parent.AsTree().Parent {
					if widget, ok := parent.(core.Widget); ok {
						if frame := core.AsFrame(widget); frame != nil {
							for axis, slider := range frame.Scrolls {
								if slider != nil && frame.HasScroll[axis] {
									anchor.scroll = append(anchor.scroll, focusScrollValue{frame, slider, math32.Dims(axis), slider.Value})
								}
							}
						}
					}
				}
				if len(anchor.scroll) > 0 {
					capture.candidates = append(capture.candidates, anchor)
				}
			}
		}
		for _, child := range root.children {
			visit(child)
		}
	}
	visit(root)
	if len(capture.candidates) == 0 {
		return nil
	}
	return capture
}

// Called under the native window's root lock after children have laid out.
func (w *nativeWindow) revealFocusedEditor() {
	capture := w.focusScroll
	w.focusScroll = nil
	if w.focusScrollBlocked {
		targets := map[string]accessibilityFocusTarget{}
		accessibilityNativeFocusTargets(w.root, "", targets)
		for _, target := range targets {
			if !accessibilityTreeNil(target.widget) {
				consumeNativeFocusEntry(target.widget)
			}
		}
		w.focusScrollBlocked = false
	}
	if capture == nil || w.closing.Load() {
		return
	}
	for _, anchor := range capture.candidates {
		if anchor.record.widget != anchor.ownerWidget ||
			anchor.record.control == nil || anchor.record.control.retired || accessibilityTreeNil(anchor.widget) ||
			!anchor.widget.AsWidget().ContainsFocus() {
			continue
		}
		// Native Return/Tab can move focus before the owner view is reconciled.
		// Treat that entry as a one-shot reveal, without following later wheels.
		entered := consumeNativeFocusEntry(anchor.widget)
		if !anchor.wasVisible && anchor.widget == capture.before && !entered {
			continue
		}
		if _, ok := ui.FocusTarget(ui.FocusScope(accessibilityFocusProjection(w.root, "")), accessibilityManagedID(anchor.record.node.ID)); !ok {
			return
		}
		for _, value := range anchor.scroll {
			if accessibilityTreeNil(value.frame) || value.frame.Scrolls[value.axis] != value.slider ||
				value.slider.Value != value.value {
				return
			}
		}
		widget := anchor.widget.AsWidget()
		full := math32.RectFromPosSizeMax(widget.Geom.Pos.Total, widget.Geom.Size.Actual.Total)
		if !full.Empty() && full != widget.Geom.TotalBBox {
			widget.ScrollToThis()
		}
		return
	}
}

// Focus cancellation and retained-editor reveal need one completed host paint.
// A focus-only descriptor change need not otherwise dirty the native scene.
func (w *nativeWindow) requestFocusScrollPaint() {
	if accessibilityTreeNil(w.host) || w.closing.Load() {
		return
	}
	if w.focusScrollBlocked {
		w.host.NeedsRender()
		return
	}
	if w.focusScroll == nil {
		return
	}
	for _, anchor := range w.focusScroll.candidates {
		if anchor.record.widget != anchor.ownerWidget || accessibilityTreeNil(anchor.widget) || !anchor.widget.AsWidget().ContainsFocus() {
			continue
		}
		entry, _ := anchor.widget.AsWidget().Property(nativeFocusEntryKey).(*atomic.Bool)
		if anchor.wasVisible || entry != nil && entry.Load() {
			w.host.NeedsRender()
			return
		}
	}
}
