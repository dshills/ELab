package cogent

import (
	"image"
	"testing"

	"cogentcore.org/core/core"
	"cogentcore.org/core/events"
	"github.com/dshills/vellum/app"
	"github.com/dshills/vellum/ui"
)

func TestHeldSliderRetainsBeginCallbackAcrossControlledRepaint(t *testing.T) {
	a, err := app.New(app.Config{})
	if err != nil {
		t.Fatal(err)
	}
	defer a.Close()
	if err := a.Open(app.Window{ID: "main", Title: "Slider context", Width: 400, Height: 160, View: func() ui.Node { return ui.Node{ID: "root", Kind: ui.Column} }}); err != nil {
		t.Fatal(err)
	}
	oldCalls, newCalls := 0, 0
	n := ui.Node{ID: "root", Kind: ui.Column, Children: []ui.Node{{ID: "wiper", Kind: ui.Slider, Number: 50, Numeric: ui.Numeric{Min: 0, Max: 100, Step: 1}, Change: func(ui.ChangeEvent) { oldCalls++ }}}}
	host := core.NewFrame(core.NewBody("held-slider"))
	r, err := reconcile(host, nil, n, a, "main")
	if err != nil {
		t.Fatal(err)
	}
	slider := findRecord(r, "wiper").widget.(*core.Slider)
	slider.Update()
	slider.Geom.Size.Actual.Content.X = 300
	slider.Geom.Size.Actual.Content.Y = 20
	from, to := image.Pt(150, 10), image.Pt(225, 10)
	begin := events.NewMouse(events.SlideStart, events.Left, from, 0)
	begin.SetLocalOff(image.Point{})
	slider.HandleEvent(begin)
	move := events.NewMouseDrag(events.Left, to, from, from, 0)
	move.Typ = events.SlideMove
	move.SetLocalOff(image.Point{})
	slider.HandleEvent(move)
	if oldCalls != 0 || newCalls != 0 {
		t.Fatal("preview committed")
	}
	n.Children[0].Number = 20
	n.Children[0].Change = func(ui.ChangeEvent) { newCalls++ }
	r, err = reconcile(host, r, n, a, "main")
	if err != nil {
		t.Fatal(err)
	}
	if findRecord(r, "wiper").widget != slider {
		t.Fatal("fixture replaced the held widget")
	}
	end := events.NewMouseDrag(events.Left, to, from, from, 0)
	end.Typ = events.SlideStop
	end.SetLocalOff(image.Point{})
	slider.HandleEvent(end)
	a.Drain()
	if oldCalls != 1 || newCalls != 0 {
		t.Fatalf("gesture borrowed refreshed callback: origin=%d refreshed=%d", oldCalls, newCalls)
	}
	// A declined originating callback restores the current controlled value.
	r, err = reconcile(host, r, n, a, "main")
	if err != nil {
		t.Fatal(err)
	}
	if slider.Value != 20 {
		t.Fatal("declined old gesture did not restore current model", slider.Value)
	}
	slider.SetValue(30).SendChange()
	a.Drain()
	if oldCalls != 1 || newCalls != 1 {
		t.Fatal("future independent change failed to use current callback")
	}
}

func TestQueuedSliderChangeRetainsEventCallbackAcrossRebind(t *testing.T) {
	a, err := app.New(app.Config{})
	if err != nil {
		t.Fatal(err)
	}
	defer a.Close()
	if err := a.Open(app.Window{ID: "main", Title: "Queued context", Width: 200, Height: 100, View: func() ui.Node { return ui.Node{ID: "root", Kind: ui.Column} }}); err != nil {
		t.Fatal(err)
	}
	oldCalls, newCalls := 0, 0
	n := ui.Node{ID: "root", Kind: ui.Column, Children: []ui.Node{{ID: "slider", Kind: ui.Slider, Numeric: ui.Numeric{Min: 0, Max: 100, Step: 1}, Change: func(ui.ChangeEvent) { oldCalls++ }}}}
	host := core.NewFrame(core.NewBody("queued-control"))
	r, err := reconcile(host, nil, n, a, "main")
	if err != nil {
		t.Fatal(err)
	}
	slider := findRecord(r, "slider").widget.(*core.Slider)
	slider.SetValue(30).SendChange() // owner delivery remains queued
	n.Children[0].Change = func(ui.ChangeEvent) { newCalls++ }
	r, err = reconcile(host, r, n, a, "main")
	if err != nil {
		t.Fatal(err)
	}
	if findRecord(r, "slider").widget != slider {
		t.Fatal("fixture replaced the queued control")
	}
	a.Drain()
	if oldCalls != 1 || newCalls != 0 {
		t.Fatalf("queued event borrowed refreshed callback: origin=%d refreshed=%d", oldCalls, newCalls)
	}
	slider.SetValue(30).SendChange()
	a.Drain()
	if oldCalls != 1 || newCalls != 1 {
		t.Fatal("future event did not use the new callback")
	}
}
