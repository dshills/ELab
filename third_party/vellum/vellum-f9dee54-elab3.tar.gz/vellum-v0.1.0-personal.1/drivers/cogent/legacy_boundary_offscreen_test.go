//go:build offscreen

package cogent

import (
	"reflect"
	"testing"

	"cogentcore.org/core/core"
	"cogentcore.org/core/events/key"
	"github.com/dshills/vellum/drivers/cogent/internal/textinput"
)

func TestManagedLegacyBoundaryAcknowledgesEarlierKeyWithoutFieldMutation(t *testing.T) {
	a, w, tw, r, changes := reviewSettlementField(t)
	boundary := textinput.Update{Sequence: 1, Kind: "legacy", MarkedStart: -1, MarkedEnd: -1}
	tw.rules.Store(&gridTextRules{clients: map[uint64]gridTextRule{}})
	w.source.Load().KeyChord('8', key.Code8, 0)
	if !tw.preflightInput(boundary) {
		t.Fatal("valid acknowledgment refused before client publication")
	}
	if err := tw.commitInput(); err != nil {
		t.Fatal(err)
	}
	reviewDeliverFieldFIFO(t, w, r)
	if got := r.widget.(*core.TextField).EditingState().Text; got != "A8" {
		t.Fatal("marker changed preceding legacy text", got)
	}
	if tw.ack != 1 || len(*changes) != 0 {
		t.Fatal("marker was not a pure acknowledgment", tw.ack, *changes)
	}
	before := r.widget.(*core.TextField).EditingState()
	reviewOwner(t, a, func() { tw.apply(boundary) })
	if !reflect.DeepEqual(before, r.widget.(*core.TextField).EditingState()) {
		t.Fatal("duplicate marker changed field")
	}
	w.source.Load().KeyChord(0, key.CodeReturnEnter, 0)
	reviewDeliverFieldFIFO(t, w, r)
	a.Drain()
	if !reflect.DeepEqual(*changes, []string{"A8"}) {
		t.Fatal("Enter did not commit exactly the preceding field text", *changes)
	}
}
func TestManagedLegacyBoundaryRefusesMutationPayloads(t *testing.T) {
	_, _, tw, _, _ := reviewSettlementField(t)
	good := textinput.Update{Sequence: 1, Kind: "legacy", MarkedStart: -1, MarkedEnd: -1}
	for name, mutate := range map[string]func(*textinput.Update){
		"zero-sequence": func(u *textinput.Update) { u.Sequence = 0 },
		"client":        func(u *textinput.Update) { u.ClientID = 1 },
		"text":          func(u *textinput.Update) { u.Text = "wrong" },
		"before":        func(u *textinput.Update) { u.BeforeText = "wrong" },
		"delta":         func(u *textinput.Update) { u.Delta = true },
		"range-start":   func(u *textinput.Update) { u.ReplaceStart = 1 },
		"range-end":     func(u *textinput.Update) { u.ReplaceEnd = 1 },
		"anchor":        func(u *textinput.Update) { u.Anchor = 1 },
		"focus":         func(u *textinput.Update) { u.Focus = 1 },
		"marked-start":  func(u *textinput.Update) { u.MarkedStart = 0 },
		"marked-end":    func(u *textinput.Update) { u.MarkedEnd = 0 },
	} {
		t.Run(name, func(t *testing.T) {
			bad := good
			mutate(&bad)
			if tw.preflightInput(bad) {
				_ = tw.commitInput()
				t.Fatal("mutation payload admitted as acknowledgment")
			}
		})
	}
	if tw.ack != 0 {
		t.Fatal("refusal advanced acknowledgment")
	}
}
