//go:build offscreen

package cogent

import (
	"fmt"
	"reflect"
	"testing"

	"cogentcore.org/core/core"
	"cogentcore.org/core/math32"
	"github.com/dshills/vellum/ui"
)

func TestAccessibilityGeometryFollowsPartialScrollPaint(t *testing.T) {
	for _, dpi := range []float32{96, 192} {
		for _, nested := range []bool{false, true} {
			t.Run(fmt.Sprintf("dpi-%g/nested-%t", dpi, nested), func(t *testing.T) {
				testAccessibilityPartialScroll(t, dpi, nested)
			})
		}
	}
}

func testAccessibilityPartialScroll(t *testing.T, dpi float32, nested bool) {
	t.Helper()
	config := manualConfig(t, 7)
	config.LogicalDPI = dpi
	views := 0
	m, a := gridManual(t, config, func() ui.Node {
		views++
		rows := []ui.Node{}
		for i := range 20 {
			rows = append(rows, ui.Node{ID: fmt.Sprint("row-", i), Kind: ui.Label, Text: fmt.Sprint("Row ", i), Style: ui.Style{MinSize: ui.Some(ui.Size{Height: 40})}})
		}
		rows = append(rows, ui.Node{ID: "field", Kind: ui.TextField, Text: "Edit me"})
		scroll := ui.Node{ID: "scroll", Kind: ui.Scroll, Grow: true, Style: ui.Style{MaxSize: ui.Some(ui.Size{Height: 160})}, Children: rows}
		if nested {
			scroll = ui.Node{ID: "outer", Kind: ui.Scroll, Grow: true, Children: []ui.Node{scroll}}
		}
		return ui.Node{ID: "root", Kind: ui.Column, Grow: true, Children: []ui.Node{scroll}}
	})
	gridFrame(t, m)
	w := m.implementation.find("one").state
	var scroll *core.Frame
	var published map[string][4]float32
	publications := 0
	if err := a.Do(func() {
		w.host.This.(*accessibilityHost).publishGeometry = func() {
			publications++
			published = nativeAccessibilityBounds(w.root)
		}
		scroll = findRecord(w.root, "scroll").widget.(*core.Frame)
		if !scroll.HasScroll[math32.Y] {
			t.Fatal("fixture did not create a scroll viewport")
		}
		published = nativeAccessibilityBounds(w.root)
	}); err != nil {
		t.Fatal(err)
	}
	beforeViews := views
	before := published[accessibilityManagedID("field")]
	if err := a.Do(func() { scroll.ScrollDimToStart(math32.Y, 100000) }); err != nil {
		t.Fatal(err)
	}
	gridFrame(t, m)
	if err := a.Do(func() {
		actual := nativeAccessibilityBounds(w.root)
		field := actual[accessibilityManagedID("field")]
		if field == before || field[2] <= 0 || field[3] <= 0 {
			t.Fatal("fixture did not reveal the text field", before, field)
		}
		if publications != 1 || !reflect.DeepEqual(published, actual) || views != beforeViews {
			t.Fatalf("child-only scroll left native geometry stale: publications=%d views=%d/%d field=%v published=%v", publications, views, beforeViews, field, published[accessibilityManagedID("field")])
		}
	}); err != nil {
		t.Fatal(err)
	}
	if err := a.Do(func() {
		publications = 0
		w.host.NeedsRender()
	}); err != nil {
		t.Fatal(err)
	}
	gridFrame(t, m)
	if err := a.Do(func() {
		if publications != 1 || !reflect.DeepEqual(published, nativeAccessibilityBounds(w.root)) || views != beforeViews {
			t.Fatal("ancestor repaint published intermediate/repeated geometry", publications)
		}
		publications = 0
		scroll.ScrollDimToContentStart(math32.Y)
	}); err != nil {
		t.Fatal(err)
	}
	gridFrame(t, m)
	if err := a.Do(func() {
		if publications != 1 || published[accessibilityManagedID("field")] != before || views != beforeViews {
			t.Fatal("scrolling back retained revealed field geometry", publications, published)
		}
	}); err != nil {
		t.Fatal(err)
	}
}
