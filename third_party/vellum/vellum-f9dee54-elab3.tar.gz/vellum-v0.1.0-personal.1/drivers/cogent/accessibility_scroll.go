package cogent

import (
	"cogentcore.org/core/core"
	"cogentcore.org/core/tree"
)

// A scroll can repaint only its own subtree. The enclosing accessibility host
// is then absent from the paint traversal, despite its children's moved bounds.
type accessibilityScrollHost struct {
	core.Frame
	painting bool // Native render context only.
}

func newAccessibilityScrollHost(parent tree.Node) *core.Frame {
	return &tree.New[accessibilityScrollHost](parent).Frame
}

func renderAccessibilityFrame(frame *core.Frame, painting *bool) {
	*painting = true
	defer func() { *painting = false }()
	frame.RenderWidget()
}

func (h *accessibilityScrollHost) RenderWidget() {
	renderAccessibilityFrame(&h.Frame, &h.painting)
	// Publish after the complete partial subtree, once. Full main/modal paints
	// and nested scroll paints let their enclosing host publish at completion.
	// Resolve the parent dynamically so reparented modal content keeps its scope.
	for parent := h.Parent; !tree.IsNil(parent); parent = parent.AsTree().Parent {
		switch host := parent.AsTree().This.(type) {
		case *accessibilityScrollHost:
			if host.painting {
				return
			}
		case *accessibilityHost:
			if !host.painting && host.publishGeometry != nil {
				host.publishGeometry()
			}
			return
		case *accessibilityDialogHost:
			if !host.painting {
				host.publishGeometry()
			}
			return
		}
	}
}
