package cogent

import (
	"image"
	"testing"

	"cogentcore.org/core/core"
	"cogentcore.org/core/events"
	"github.com/dshills/vellum/app"
	"github.com/dshills/vellum/ui"
)

func TestButtonActivationRetainsInputCallbackAcrossRebind(t *testing.T) {
	for _, scenario := range []string{"held-pointer", "queued-pointer", "programmatic-latest", "canceled-pointer-keyboard", "next-pointer", "disabled", "disposed", "nil-origin"} {
		t.Run(scenario, func(t *testing.T) {
			a, err := app.New(app.Config{})
			if err != nil {
				t.Fatal(err)
			}
			defer a.Close()
			if err := a.Open(app.Window{ID: "main", Title: "Button context", Width: 200, Height: 100, View: func() ui.Node { return ui.Node{ID: "root", Kind: ui.Column} }}); err != nil {
				t.Fatal(err)
			}
			oldCalls, newCalls := 0, 0
			n := ui.Node{ID: "root", Kind: ui.Column, Children: []ui.Node{{ID: "action", Kind: ui.Button, Text: "Action", Activate: func() { oldCalls++ }}}}
			if scenario == "nil-origin" {
				n.Children[0].Activate = nil
			}
			host := core.NewFrame(core.NewBody("button-context"))
			r, err := reconcile(host, nil, n, a, "main")
			if err != nil {
				t.Fatal(err)
			}
			record := findRecord(r, "action")
			button := record.widget.(*core.Button)
			pointer := func(kind events.Types) {
				e := events.NewMouse(kind, events.Left, image.Pt(10, 10), 0)
				e.SetLocalOff(image.Point{})
				if kind == events.Click {
					// Match the native router's cloned MouseUp, including Base's
					// loss of HasPos while retaining the original mouse button.
					button.Send(events.Click, e)
				} else {
					button.HandleEvent(e)
				}
			}
			if scenario == "programmatic-latest" {
				button.Send(events.Click)
			} else {
				pointer(events.MouseDown)
				if scenario == "queued-pointer" {
					pointer(events.Click)
				}
			}
			n.Children[0].Activate = func() { newCalls++ }
			n.Children[0].Disabled = scenario == "disabled"
			r, err = reconcile(host, r, n, a, "main")
			if err != nil {
				t.Fatal(err)
			}
			if findRecord(r, "action").widget != button {
				t.Fatal("fixture replaced the widget")
			}
			switch scenario {
			case "queued-pointer", "programmatic-latest":
			case "canceled-pointer-keyboard":
				pointer(events.MouseUp) // canceled router sequences emit no Click
				button.Send(events.Click)
			case "next-pointer":
				pointer(events.MouseUp)
				pointer(events.MouseDown)
				pointer(events.Click)
			case "disposed":
				pointer(events.Click)
				disposeControl(record)
				if record.control.buttonPress.Load() != nil {
					t.Fatal("disposal retained the pressed callback")
				}
			default:
				pointer(events.MouseUp)
				pointer(events.Click)
			}
			a.Drain()
			wantOld, wantNew := 0, 0
			switch scenario {
			case "held-pointer", "queued-pointer":
				wantOld = 1
			case "programmatic-latest", "canceled-pointer-keyboard", "next-pointer":
				wantNew = 1
			}
			if oldCalls != wantOld || newCalls != wantNew {
				t.Fatalf("activation context: origin=%d refreshed=%d want %d/%d", oldCalls, newCalls, wantOld, wantNew)
			}
		})
	}
}
