package cogent

import (
	"testing"

	"cogentcore.org/core/core"
	"github.com/dshills/vellum/ui"
)

func TestControlStateKeyRetainsSameOwnerAndReplacesChangedOwner(t *testing.T) {
	for _, kind := range []ui.Kind{ui.Button, ui.Checkbox, ui.Switch, ui.ToggleButton, ui.Selector, ui.Slider, ui.NumberField, ui.TextField, ui.RadioGroup, ui.SegmentedControl, ui.ListBox, ui.MenuButton} {
		t.Run(string(kind), func(t *testing.T) {
			a, _ := newAXTest(t, 8)
			host := core.NewFrame(core.NewBody("control-owner"))
			n := ui.Node{ID: "root", Kind: ui.Column, Children: []ui.Node{{ID: "control", Kind: kind, ControlStateKey: "doc:part1", Numeric: ui.Numeric{Min: 0, Max: 100, Step: 1}, Options: []ui.Option{{ID: "one", Label: "One"}}, SelectedID: "one", Activate: func() {}, Change: func(ui.ChangeEvent) {}}}}
			if kind == ui.ListBox || kind == ui.MenuButton {
				n.Children[0].Activate = nil
			}
			if kind == ui.MenuButton {
				n.Children[0].SelectedID = ""
				n.Children[0].Text = "Actions"
			}
			r, err := reconcile(host, nil, n, a, "ax")
			if err != nil {
				t.Fatal(err)
			}
			old := findRecord(r, "control")
			r, err = reconcile(host, r, n, a, "ax")
			if err != nil || findRecord(r, "control") != old {
				t.Fatal("same owner changed binding", err)
			}
			n.Children[0].ControlStateKey = "doc:part2"
			r, err = reconcile(host, r, n, a, "ax")
			if err != nil {
				t.Fatal(err)
			}
			fresh := findRecord(r, "control")
			if fresh == old || fresh.widget == old.widget || !old.control.retired || fresh.node.ID != old.node.ID {
				t.Fatal("owner change failed to retire old binding under the same public ID")
			}
		})
	}
}
