//go:build darwin && cgo

package textinput

import "testing"

func runLegacyHandoffFixtures(run func(string, func()), rect [4]float64) {
	run("legacy-handoff", func() {
		view := fixtureInputView()
		defer fixtureReleaseInputView(view)
		var updates []Update
		i := Attach(view, func(u Update) bool { updates = append(updates, u); return true }, func() {})
		fixtureAssert(i != nil, "attach failed")
		defer i.Close()
		fixtureInputKey(i, "8", false)
		fixtureAssert(fixtureInputBaseCalls(i) == 1, "initial legacy key lost")
		fixtureAssert(!i.UpdateClient(13, "6 ms", 4, 4, -1, -1, true, 0, rect), "activated Cocoa before the earlier legacy key was acknowledged")
		for _, s := range []string{" ", "m", "s"} {
			fixtureInputKey(i, s, false)
		}
		fixtureAssert(fixtureInputBaseCalls(i) == 4, "mixed legacy/native stream before acknowledgment")
		fixtureAssert(len(updates) == 4, "missing ordered legacy acknowledgments")
		for n, u := range updates {
			fixtureAssert(u.Kind == "legacy" && u.ClientID == 0 && u.Sequence == uint64(n+1), "unexpected legacy marker")
		}
		fixtureAssert(i.UpdateClient(13, "8 ms", 4, 4, -1, -1, true, 4, rect), "coherent final publication refused")
		fixtureInputEdit(i, "!", -1, 0, 0)
		fixtureAssert(len(updates) == 5 && updates[4].Kind == "insert" && updates[4].BeforeText == "8 ms" && updates[4].Text == "8 ms!", "native edit did not use acknowledged legacy baseline")
	})
	run("legacy-select-all", func() {
		view := fixtureInputView()
		defer fixtureReleaseInputView(view)
		var updates []Update
		i := Attach(view, func(u Update) bool { updates = append(updates, u); return true }, func() {})
		fixtureAssert(i != nil, "attach failed")
		defer i.Close()
		fixtureAssert(i.UpdateClient(13, "6 ms", 4, 4, -1, -1, true, 0, rect), "initial active publication refused")
		fixtureInputKey(i, "a", true)
		fixtureAssert(!i.UpdateClient(13, "6 ms", 0, 4, -1, -1, true, 0, rect), "selection publication bypassed queued select-all")
		fixtureInputKey(i, "8", false)
		fixtureAssert(fixtureInputBaseCalls(i) == 2, "typing borrowed stale Cocoa selection")
		fixtureAssert(i.UpdateClient(13, "8", 1, 1, -1, -1, true, 2, rect), "replacement baseline refused after acknowledgment")
		fixtureInputEdit(i, " ms", -1, 0, 0)
		fixtureAssert(len(updates) == 3 && updates[2].Text == "8 ms", "native suffix used stale select-all baseline")
	})
	run("legacy-capacity-retry", func() {
		view := fixtureInputView()
		defer fixtureReleaseInputView(view)
		allow := false
		var updates []Update
		i := Attach(view, func(u Update) bool {
			if !allow {
				return false
			}
			updates = append(updates, u)
			return true
		}, func() {})
		fixtureAssert(i != nil, "attach failed")
		defer i.Close()
		fixtureInputKey(i, "8", false)
		fixtureAssert(fixtureInputBaseCalls(i) == 1, "capacity refusal lost legacy key")
		fixtureAssert(!i.UpdateClient(13, "6 ms", 4, 4, -1, -1, true, 0, rect), "capacity refusal permitted stale activation")
		allow = true
		fixtureAssert(!i.UpdateClient(13, "8", 1, 1, -1, -1, true, 0, rect), "retry marker skipped owner acknowledgment")
		fixtureAssert(len(updates) == 1 && updates[0].Kind == "legacy", "publication did not retry bounded legacy marker")
		fixtureAssert(i.UpdateClient(13, "8", 1, 1, -1, -1, true, 1, rect), "retry acknowledgment did not restore native input")
	})
}
func TestNativeLegacyHandoff(t *testing.T) {
	for _, name := range []string{"legacy-handoff", "legacy-select-all", "legacy-capacity-retry"} {
		t.Run(name, func(t *testing.T) {
			if err := nativeFixtureResults[name]; err != nil {
				t.Fatal(err)
			}
		})
	}
}
