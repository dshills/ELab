# Scoped application themes

`ui.Theme` remains the application-local style contract. `Driver.Theme` supplies
startup defaults. A `ui.Node.Theme` pointer replaces the inherited theme for that
node and its descendants; nil inherits. Returning a different value from an
owner View changes the appearance while preserving compatible keyed controls,
values and focus. Removing a scope restores its parent's current theme.

`ui.MacThemeWithAccent(dark, accent)` supplies light/dark Mac presets and opaque
semantic palette colors for window/panel/field/popup, foreground/secondary/border,
and accent/accent foreground. Zero accent chooses blue. `ui.MacTheme(dark)` stays
available. Custom palettes and kind style overrides can be made from `Theme.Clone`.
Explicit node styles continue to take precedence. Drivers snapshot scoped maps
when accepting a View; callers must not mutate theme maps concurrently with View.
Invalid nested themes reject the whole keyed update.

The Mac driver uses palette accent colors for managed focus cues and menu rows,
and palette popup color for transient menus. Full-color image pixels are never
tinted. Changing a scope retires open menus before publishing new presentation.
Themes do not change process-global Cogent colors or macOS settings. Native
AppKit titlebar appearance and its saved configuration remain separate.

```go
appearance := ui.MacThemeWithAccent(true, color.NRGBA{R: 126, G: 65, B: 194, A: 255})
return ui.Node{ID: "inspector", Kind: ui.Column, Theme: &appearance,
    Children: []ui.Node{/* ordinary keyed controls */}}
```

The gallery's Components page demonstrates live Light/Dark and Blue/Purple/Green
choices. These choices are local to that page and are not persisted yet. Apply
the same scope at an application root to theme its whole managed content. The
preset does not automatically follow system accent, appearance, increased
contrast or reduced-motion settings.

Mac presets explicitly style selector fills and focus borders. Palette-scoped
selectors with 1–64 options use the same themed popup, check, cancellation and
stale-action path as managed action menus. Larger selector catalogues retain the
legacy chooser popup and its startup/window palette; their closed control still
uses the scoped theme. Selection values/callback kinds remain `ui.Selector`.

## Following macOS preferences

Opt in with `cogent.Driver{FollowSystemAppearance: true}`. AppKit notifications
observe light/dark appearance, control accent, increased contrast, reduced motion
and reduced transparency. There is one application observer, no polling, and no
system setting changes. Changes replace one detached snapshot, wake existing
windows and deliver through an application-owner refresh, including when the
ordinary Post queue is full. Observer tokens and callbacks retire on shutdown.

`OnSystemAppearance func(cogent.SystemAppearance)` optionally receives coalesced
owner callbacks. Use `cogent.MacSystemTheme(snapshot)` for explicitly scoped Mac
content. Presets use opaque surfaces, increase semantic border/text contrast and
set `Theme.ReducedMotion`; managed toolbar insertion feedback becomes immediate
while capture/reorder still works. Application-authored animation should honor
`SystemAppearance.ReduceMotion` too. Full-color image data is not modified.
Explicit node styles and nested theme overrides retain precedence.

The gallery's `-mac-system-appearance` option follows preferences. Components gains
a System choice; Light/Dark/accent choices remain explicit local overrides. The
observer is Mac+cgo only; requesting it elsewhere returns an unsupported error.
System-change routing is tested by injecting detached observations rather than
changing the user's global preferences. Native initial observation is checked
separately; human accessibility acceptance is not inferred from these tests.
