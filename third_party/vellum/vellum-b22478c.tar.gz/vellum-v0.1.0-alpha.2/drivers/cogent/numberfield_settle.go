package cogent

import (
	"context"
	"fmt"
	"strconv"

	"cogentcore.org/core/core"
	"github.com/dshills/vellum/app"
	"github.com/dshills/vellum/editor"
	"github.com/dshills/vellum/ui"
)

// SettleNumberField commits one managed NumberField before an action that does
// not move pointer focus. Call on the Application owner. The originating-window
// FIFO delivers earlier input before reading the draft, then publishes Change
// before callback. Immediate refusal never invokes callback. Cancellation,
// retirement and window closure use the same barrier lifetime as SettleTextField.
// NumberField remains a legacy spinner; this does not activate native text input.
func SettleNumberField(ctx context.Context, a *app.Application, window, id string, callback func(error)) error {
	if ctx == nil || a == nil || id == "" || callback == nil {
		return fmt.Errorf("cogent: number field settlement requires context, owner, ID and callback")
	}
	if err := ctx.Err(); err != nil {
		return err
	}
	t := lookupTextWindow(window)
	if t == nil || t.owner != a || !t.acceptsNativeInput() {
		return app.ErrWindowClosed
	}
	binding := numberFieldRecord(t.window.root, id)
	if binding == nil || binding.control.disabled || binding.node.Change == nil || binding.control.fieldChanges.Load() == nil {
		return fmt.Errorf("%w: number field %q unavailable", ErrTextInputStale, id)
	}
	return t.admitSettlement(ctx, &textSettlement{binding: binding, number: true, field: binding.control.fieldChanges.Load(), ctx: ctx, callback: callback})
}

func numberFieldRecord(root *record, id string) *record {
	var binding *record
	ambiguous := false
	var visit func(*record)
	visit = func(r *record) {
		if r == nil {
			return
		}
		if r.node.ID == id && r.node.Kind == ui.NumberField && r.control != nil && !r.control.retired {
			ambiguous = ambiguous || binding != nil
			binding = r
		}
		for _, child := range r.children {
			visit(child)
		}
		for _, child := range activeWorkbenchRecords(r) {
			visit(child)
		}
	}
	visit(root)
	if ambiguous {
		return nil
	}
	return binding
}

func (t *textWindow) settledNumberField(id uint64, q *textSettlement) {
	r := q.binding
	if r.control.retired || numberFieldRecord(t.window.root, r.node.ID) != r || r.control.disabled || r.node.Change == nil || r.control.fieldChanges.Load() != q.field {
		t.complete(id, fmt.Errorf("%w: number field binding changed", ErrTextInputStale))
		return
	}
	spinner := r.widget.(*core.Spinner)
	if _, _, marked := spinner.NativeCompositionRange(); marked {
		t.complete(id, editor.ErrComposition)
		return
	}
	value, err := strconv.ParseFloat(spinner.EditingState().Text, 32)
	number, valid := ui.ClampNumeric(float32(value), r.node.Numeric)
	if err != nil || !valid {
		t.complete(id, fmt.Errorf("cogent: invalid number field entry"))
		return
	}
	// Finish may enqueue an ordinary Change. Retire it (and older queued
	// snapshots) before delivering the exact value once on the owner.
	spinner.FinishNativeFocusLost()
	r.control.fieldChanges.Store(&fieldChangeEpoch{})
	spinner.SetValue(number)
	if number != r.node.Number {
		r.node.Change(ui.ChangeEvent{ID: r.node.ID, Kind: ui.NumberField, Number: number})
		if !t.acceptsNativeInput() {
			t.complete(id, app.ErrWindowClosed)
			return
		}
		if r.control.retired {
			t.complete(id, ErrTextInputStale)
			return
		}
		r.control.committed = true
	}
	_ = t.owner.Invalidate(r.control.window)
	t.complete(id, nil)
}
