package cogent

import (
	"testing"

	"cogentcore.org/core/core"
	"github.com/dshills/vellum/ui"
)

func TestTextStateKeyReplacesPrivateFieldStateAndRetiresQueuedChanges(t *testing.T) {
	a, _ := newAXTest(t, 8)
	host := core.NewFrame(core.NewBody("field-owner"))
	calls := 0
	n := ui.Node{ID: "root", Kind: ui.Column, Children: []ui.Node{{ID: "field", Kind: ui.TextField, TextStateKey: "doc1:part1", Text: "1k", Change: func(ui.ChangeEvent) { calls++ }}}}
	r, err := reconcile(host, nil, n, a, "ax")
	if err != nil {
		t.Fatal(err)
	}
	old := findRecord(r, "field")
	field := old.widget.(*core.TextField)
	if !field.ApplyNativeEdit("2.2k", 4, 4, -1, -1, "insert") {
		t.Fatal("private native edit refused")
	}
	r, err = reconcile(host, r, n, a, "ax")
	if err != nil {
		t.Fatal(err)
	}
	if findRecord(r, "field") != old || field.EditingState().Text != "2.2k" {
		t.Fatal("ordinary redraw lost private text")
	}
	field.SendChange() // owner callback is queued before the binding is retired
	n.Children[0].TextStateKey = "doc2:part1"
	r, err = reconcile(host, r, n, a, "ax")
	if err != nil {
		t.Fatal(err)
	}
	a.Drain()
	fresh := findRecord(r, "field")
	if fresh == old || fresh.widget == field || !old.control.retired || calls != 0 {
		t.Fatal("logical owner change retained field or delivered old queued change")
	}
	current := fresh.widget.(*core.TextField)
	if current.EditingState().Text != "1k" {
		t.Fatal("replacement inherited private text", current.EditingState())
	}
	if !current.ApplyNativeEdit("3.3k", 4, 4, -1, -1, "insert") {
		t.Fatal("fresh field edit refused")
	}
	current.SendChange()
	a.Drain()
	if calls != 1 {
		t.Fatal("fresh field did not deliver its change")
	}
}
