//go:build offscreen

package cogent

import (
	"context"
	"errors"
	"testing"

	"cogentcore.org/core/core"
	"cogentcore.org/core/events/key"
	"github.com/dshills/vellum/app"
	"github.com/dshills/vellum/drivers/cogent/internal/mailbox"
	"github.com/dshills/vellum/ui"
)

func numberSettlementFixture(t *testing.T) (*app.Application, *nativeWindow, *textWindow, *record, *[]float32) {
	t.Helper()
	a, w, tw, _, _ := editorFixture(t, "peer")
	disposeControlTree(w.root)
	var changes []float32
	n := ui.Node{ID: "number", Kind: ui.NumberField, Number: 0, Numeric: ui.Numeric{Min: -200, Max: 200, Step: 10}, Change: func(e ui.ChangeEvent) { changes = append(changes, e.Number) }}
	r, err := reconcile(w.body, nil, n, a, w.window.ID)
	if err != nil {
		t.Fatal(err)
	}
	w.root = r
	tw.manual = true
	if err := bindTextWindow(w); err != nil {
		t.Fatal(err)
	}
	return a, w, tw, r, &changes
}

func numberDraft(t *testing.T, r *record, text string) {
	t.Helper()
	if !r.widget.(*core.Spinner).ApplyNativeEdit(text, len(text), len(text), -1, -1, "insert") {
		t.Fatal("private numeric draft refused")
	}
}

func TestNumberSettlementFIFOAndOnce(t *testing.T) {
	a, w, tw, r, changes := numberSettlementFixture(t)
	numberDraft(t, r, "-11")
	w.source.Load().KeyChord('0', key.Code0, 0)
	called := 0
	reviewOwner(t, a, func() {
		if err := SettleNumberField(context.Background(), a, w.window.ID, r.node.ID, func(err error) {
			called++
			if err != nil || len(*changes) != 1 || (*changes)[0] != -110 {
				t.Errorf("callback preceded final numeric Change: %v %v", err, *changes)
			}
		}); err != nil {
			t.Fatal(err)
		}
	})
	if called != 0 || len(*changes) != 0 {
		t.Fatal("barrier ran before explicit originating FIFO delivery")
	}
	reviewDeliverFieldFIFO(t, w, r)
	a.Drain()
	if called != 1 || len(*changes) != 1 || len(tw.requests) != 0 {
		t.Fatal("settled Change replayed or barrier did not finish", called, *changes)
	}
}

func TestNumberSettlementRetiresQueuedChange(t *testing.T) {
	a, w, _, r, changes := numberSettlementFixture(t)
	spinner := r.widget.(*core.Spinner)
	numberDraft(t, r, "10")
	spinner.Text() // old Change queued, not delivered
	numberDraft(t, r, "-110")
	reviewOwner(t, a, func() {
		if err := SettleNumberField(context.Background(), a, w.window.ID, r.node.ID, func(err error) {
			if err != nil {
				t.Error(err)
			}
		}); err != nil {
			t.Fatal(err)
		}
	})
	reviewDeliverFieldFIFO(t, w, r)
	a.Drain()
	if len(*changes) != 1 || (*changes)[0] != -110 {
		t.Fatal("older queued Change survived", *changes)
	}
	spinner.SetValue(20).SendChange()
	a.Drain()
	if len(*changes) != 2 || (*changes)[1] != 20 {
		t.Fatal("future ordinary numeric Change lost", *changes)
	}
}

func TestNumberSettlementRefusesInvalidOrRetiredEntry(t *testing.T) {
	for _, scenario := range []string{"invalid", "nan", "range-error", "marked", "cancel", "retire", "disabled"} {
		t.Run(scenario, func(t *testing.T) {
			a, w, tw, r, changes := numberSettlementFixture(t)
			text := "-110"
			if scenario == "invalid" {
				text = "-"
			} else if scenario == "nan" {
				text = "NaN"
			} else if scenario == "range-error" {
				text = "1e999"
			}
			numberDraft(t, r, text)
			if scenario == "marked" {
				if !r.widget.(*core.Spinner).ApplyNativeEdit(text, 4, 4, 0, 4, "mark") {
					t.Fatal("marked fixture refused")
				}
			}
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			called := 0
			reviewOwner(t, a, func() {
				if err := SettleNumberField(ctx, a, w.window.ID, r.node.ID, func(err error) {
					called++
					if err == nil {
						t.Error("refused settlement reported success")
					}
				}); err != nil {
					t.Fatal(err)
				}
			})
			switch scenario {
			case "cancel":
				cancel()
			case "retire":
				r.control.retired = true
			case "disabled":
				r.control.disabled = true
			}
			reviewDeliverFieldFIFO(t, w, r)
			a.Drain()
			if called != 1 || len(*changes) != 0 || len(tw.requests) != 0 {
				t.Fatal("refused numeric entry mutated/did not finish", called, *changes)
			}
		})
	}
}

func TestNumberSettlementAdmissionAndUnchangedValue(t *testing.T) {
	a, w, _, r, changes := numberSettlementFixture(t)
	if err := SettleNumberField(nil, a, w.window.ID, r.node.ID, func(error) {}); err == nil {
		t.Fatal("nil context admitted")
	}
	if err := SettleNumberField(context.Background(), a, w.window.ID, "missing", func(error) {}); !errors.Is(err, ErrTextInputStale) {
		t.Fatal("unknown numeric field admitted", err)
	}
	called := 0
	reviewOwner(t, a, func() {
		if err := SettleNumberField(context.Background(), a, w.window.ID, r.node.ID, func(err error) {
			called++
			if err != nil {
				t.Error(err)
			}
		}); err != nil {
			t.Fatal(err)
		}
		if err := SettleNumberField(context.Background(), a, w.window.ID, r.node.ID, func(error) { t.Error("refused callback invoked") }); !errors.Is(err, mailbox.ErrFull) {
			t.Fatal("second barrier admitted", err)
		}
	})
	if err := bindTextWindow(w); err != nil {
		t.Fatal(err)
	}
	reviewDeliverFieldFIFO(t, w, r)
	a.Drain()
	if called != 1 || len(*changes) != 0 {
		t.Fatal("unchanged numeric value emitted Change", called, *changes)
	}
}
