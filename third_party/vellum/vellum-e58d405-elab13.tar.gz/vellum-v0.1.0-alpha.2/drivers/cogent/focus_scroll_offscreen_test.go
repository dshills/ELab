//go:build offscreen

package cogent

import (
	"fmt"
	"testing"

	"cogentcore.org/core/core"
	"cogentcore.org/core/events"
	"cogentcore.org/core/math32"
	"github.com/dshills/vellum/ui"
)

func focusScrollDraft(t *testing.T, r *record) core.TextFieldEditingState {
	t.Helper()
	if field, ok := r.widget.(interface {
		EditingState() core.TextFieldEditingState
	}); ok {
		return field.EditingState()
	}
	t.Fatal("fixture is not an editable managed control")
	return core.TextFieldEditingState{}
}

func TestManagedFocusScrollRevealAfterInsertion(t *testing.T) {
	for _, kind := range []ui.Kind{ui.TextField, ui.NumberField} {
		t.Run(string(kind), func(t *testing.T) {
			inserted, calls := false, 0
			m, a := simpleManual(t, manualConfig(t, 7), func() ui.Node {
				children := []ui.Node{}
				if inserted {
					children = append(children, ui.Node{ID: "guidance", Kind: ui.Label, Text: "Correct the requested value", MinHeight: 240})
				}
				field := ui.Node{ID: "field", Kind: kind, Text: "accepted", Number: 25, Numeric: ui.Numeric{Min: 0, Max: 100, Step: 1}, MinHeight: 40, Change: func(ui.ChangeEvent) { calls++ }}
				if kind == ui.TextField {
					field.Numeric = ui.Numeric{}
				} else {
					field.Text = ""
				}
				children = append(children, field)
				for i := range 16 {
					children = append(children, ui.Node{ID: fmt.Sprintf("tail-%d", i), Kind: ui.Label, Text: "Following controls", MinHeight: 32})
				}
				return ui.Node{ID: "root", Kind: ui.Column, Grow: true, Focus: ui.FocusRequest{ID: "field", Sequence: 1}, Children: []ui.Node{
					{ID: "scroll", Kind: ui.Scroll, Grow: true, Children: []ui.Node{{ID: "content", Kind: ui.Column, Children: children}}},
				}}
			})
			unitSettle(t, m)
			w := m.implementation.find("one")
			if err := m.Input(testContext, ManualInput{Window: "one", WindowIncarnation: w.incarnation, Type: events.KeyChord, Rune: '9'}); err != nil {
				t.Fatal(err)
			}
			unitSettle(t, m)
			field := findRecord(w.state.root, "field")
			draft := focusScrollDraft(t, field)
			if err := a.Do(func() { inserted = true; a.Invalidate("one") }); err != nil {
				t.Fatal(err)
			}
			unitSettle(t, m)
			scroll := findRecord(w.state.root, "scroll").widget.AsWidget()
			box := field.widget.AsWidget().Geom.TotalBBox
			if box.Empty() || !box.In(scroll.Geom.ContentBBox) {
				t.Fatal("inserted content hid the focused editor", box, scroll.Geom.ContentBBox)
			}
			after := focusScrollDraft(t, field)
			after.Caret = draft.Caret
			if after != draft || calls != 0 {
				t.Fatal("revealing the editor changed its draft or committed it", draft, after, calls)
			}
			// A subsequent user wheel remains authoritative, even if an
			// unrelated view invalidation follows while focus is retained.
			if err := m.Input(testContext, ManualInput{Window: "one", WindowIncarnation: w.incarnation, Type: events.Scroll, Position: box.Min.Add(box.Size().Div(2)), Delta: math32.Vec2(0, 300)}); err != nil {
				t.Fatal(err)
			}
			unitSettle(t, m)
			frame := core.AsFrame(findRecord(w.state.root, "scroll").widget)
			value := frame.Scrolls[math32.Y].Value
			if !field.widget.AsWidget().Geom.TotalBBox.Empty() {
				t.Fatal("wheel fixture did not intentionally hide the focused editor")
			}
			if err := a.Do(func() { a.Invalidate("one") }); err != nil {
				t.Fatal(err)
			}
			unitSettle(t, m)
			if frame.Scrolls[math32.Y].Value != value || !field.widget.AsWidget().Geom.TotalBBox.Empty() || calls != 0 {
				t.Fatal("repaint overrode deliberate user scrolling")
			}
		})
	}
}

func TestManagedFocusScrollRevealDoesNotFollowReplacedEditor(t *testing.T) {
	for _, replacement := range []string{"owner", "disabled"} {
		t.Run(replacement, func(t *testing.T) {
			changed := false
			m, a := simpleManual(t, manualConfig(t, 7), func() ui.Node {
				field := ui.Node{ID: "field", Kind: ui.TextField, Text: "original", TextStateKey: "first", MinHeight: 40}
				focus := ui.FocusRequest{ID: "field", Sequence: 1}
				children := []ui.Node{}
				if changed {
					children = append(children, ui.Node{ID: "guidance", Kind: ui.Label, Text: "Different context", MinHeight: 240})
					focus = ui.FocusRequest{ID: "other", Sequence: 2}
					if replacement == "owner" {
						field.TextStateKey, field.Text = "second", "authoritative"
					} else {
						field.Disabled = true
					}
				}
				children = append(children, field, ui.Node{ID: "tail", Kind: ui.Label, Text: "Following controls", MinHeight: 400})
				return ui.Node{ID: "root", Kind: ui.Column, Grow: true, Focus: focus, Children: []ui.Node{
					{ID: "other", Kind: ui.Button, Text: "New focus"},
					{ID: "scroll", Kind: ui.Scroll, Grow: true, Children: []ui.Node{{ID: "content", Kind: ui.Column, Children: children}}},
				}}
			})
			unitSettle(t, m)
			w := m.implementation.find("one")
			frame := core.AsFrame(findRecord(w.state.root, "scroll").widget)
			beforeScroll := frame.Scrolls[math32.Y].Value
			if err := a.Do(func() { changed = true; a.Invalidate("one") }); err != nil {
				t.Fatal(err)
			}
			unitSettle(t, m)
			snapshot, err := m.Snapshot(testContext)
			if err != nil {
				t.Fatal(err)
			}
			if snapshot.Windows[0].FocusedID != "other" || frame.Scrolls[math32.Y].Value != beforeScroll {
				t.Fatal("old editor reveal stole the new focus or viewport", snapshot.Windows[0].FocusedID, frame.Scrolls[math32.Y].Value)
			}
		})
	}
}

func TestManagedNumberFieldDraftSurvivesParentStructureChange(t *testing.T) {
	inserted, calls := false, 0
	m, a := simpleManual(t, manualConfig(t, 7), func() ui.Node {
		children := []ui.Node{{ID: "field", Kind: ui.NumberField, Number: 25,
			Numeric: ui.Numeric{Min: 0, Max: 100, Step: 1}, Change: func(ui.ChangeEvent) { calls++ }}}
		if inserted {
			children = append(children, ui.Node{ID: "guidance", Kind: ui.Label, Text: "Unrelated guidance below the field"})
		}
		return ui.Node{ID: "root", Kind: ui.Column, Focus: ui.FocusRequest{ID: "field", Sequence: 1}, Children: children}
	})
	unitSettle(t, m)
	w := m.implementation.find("one")
	if err := m.Input(testContext, ManualInput{Window: "one", WindowIncarnation: w.incarnation, Type: events.KeyChord, Rune: '9'}); err != nil {
		t.Fatal(err)
	}
	unitSettle(t, m)
	field := findRecord(w.state.root, "field")
	before := focusScrollDraft(t, field)
	if before.Text == "25" {
		t.Fatal("fixture did not establish an unfinished number")
	}
	if err := a.Do(func() { inserted = true; a.Invalidate("one") }); err != nil {
		t.Fatal(err)
	}
	unitSettle(t, m)
	after := focusScrollDraft(t, field)
	after.Caret = before.Caret
	if after != before || calls != 0 {
		t.Fatal("unrelated parent insertion erased or committed the private number", before, after, calls)
	}
}
