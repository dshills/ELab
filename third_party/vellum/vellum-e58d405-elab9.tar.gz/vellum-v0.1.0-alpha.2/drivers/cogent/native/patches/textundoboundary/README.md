# Text field Undo boundary

ELab compatibility stage 0109 after the existing native stages. No public API
or model changes. Empty/exhausted text Undo returns no record instead of an
implicit empty field, preserving its accepted baseline and selection. Normal
undo/redo, repeated boundary calls, Unicode and branch-after-undo are tested.

Original and output hashes pin the exact prepared dependency. The patch adds
its regression alongside the implementation. Previous stages are unchanged.
